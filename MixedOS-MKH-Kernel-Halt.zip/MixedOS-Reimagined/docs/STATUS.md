# Implementation and validation status

Status vocabulary:

- **Not started** — no implementation.
- **Foundation** — design, ABI, or early support exists; meaningful functionality is incomplete.
- **Source implemented** — executable source exists, but compilation may not have been verified.
- **Compiled** — successful build recorded for a named toolchain and source version.
- **VM tested** — the actual image was booted and behavior was observed in a named VM configuration.
- **Hardware tested** — behavior was tested on identified physical hardware.

## User-confirmed baseline (2026-11-11)

The user supplied successful Windows build logs for Stage 1, Stage 2, and the unified input subsystem revisions. The user also supplied a VirtualBox screenshot showing the live framebuffer console, keyboard receive counter, mouse receive counter, mouse position/buttons, zero input errors/dropped events, and successful execution of `help`, `mem`, `uptime`, and `input`. This confirms that the Stage 2 interactive input path works in the user's VM. The exact VirtualBox firmware mode, machine profile, virtual CPU model, and VM RAM settings were not recorded.

## Current implementation snapshot

| Subsystem | Status | Evidence / limit |
|---|---|---|
| x86_64 kernel entry and Limine boot | VM tested by user | Stage 1 successful Windows build and VirtualBox boot; later interactive console screenshot confirms the kernel still starts. |
| Architecture API facade | Source implemented | Public x86_64 byte/word/dword port I/O, CPU control, interrupt control, and FPU initialization exports. |
| Serial diagnostics | VM tested by user | COM1 diagnostics; serial input is normalized into the shared event queue. |
| Framebuffer output | VM tested by user | Screenshot shows the interactive text console. Software rendering only; no GPU acceleration. |
| Memory map and HHDM | Compiled in prior release; Stage 3 integration source implemented | Limine memory-map and higher-half direct-map responses are used by the frame allocator. |
| C ABI | Compiled in user-reported build | Freestanding C runtime object linked; kernel checks ABI revision. |
| IDT and exception reporting | VM tested by user | Stage 2 kernel boots with the IDT; detailed fault-path coverage still needs dedicated tests. |
| Legacy timer | VM tested by user | Screenshot shows increasing uptime; PIT nominally 100 Hz, no APIC/high-resolution timer. |
| Unified input subsystem | VM tested by user | Screenshot shows changing keyboard/mouse byte counters, typed shell commands, mouse coordinates/buttons, and zero errors/dropped events. |
| PS/2 keyboard | VM tested by user | Screenshot-confirmed typed `help`, `mem`, `uptime`, and `input` commands. USB HID and international layouts are not implemented. |
| PS/2 mouse | Foundation / source implemented | Earlier standard three-byte packet path was VM-tested by user. IntelliMouse ID 3 negotiation, four-byte wheel decoding, and shell wheel scrolling are source/model-checked but need a new Windows build and VM device test. |
| Kernel command loop | VM tested by user | `help`, `mem`, `uptime`, and `input` visibly executed. This is still a ring-0 debug console, not a user shell. |
| Physical frame allocator | VM tested by user | User supplied a Stage 3 VirtualBox screenshot showing managed/free pages, eight-page `memtest` success, zero free errors, and restored allocation accounting. |
| Page-table manager / virtual mapping | VM tested by user | User supplied a VirtualBox screenshot showing `vmtest` mapped, accessed, translated, unmapped, and reclaimed two pages; zero map failures; 7 TLB invalidations; zero MixedOS-owned page-table pages remaining; active Limine CR3 preserved. Stage 4 build log reports successful Rust compilation and ISO creation. |
| Kernel heap | VM tested by user | User screenshot confirms seven aligned allocations written, verified, freed, and coalesced; zero active allocations, consistent 40 KiB accounting, and no allocator errors. |
| Rust global allocator | Not started | Explicit heap API must pass its VM test before integration with `alloc` or `GlobalAlloc`. |
| GDT/TSS and privilege isolation | VM tested by user | User screenshot for Stage 6 Fix 5 shows the two ring-3 processes entered and exited, and the shell returned with CR3 verified. |
| Processes / scheduling / user mode | VM tested by user | Screenshot shows two processes exited, zero faults, four syscall reports, five context switches, zero cleanup errors, and both private address spaces/stacks reclaimed. General ELF loading and per-process FPU state are not implemented. |
| Legacy IDE ATA PIO block device | Compiled in user-reported Windows build | IDENTIFY, LBA28 512-byte sector PIO read/write, bounded status polling, and optional flush. Physical storage-controller compatibility and safe disk I/O still need dedicated hardware testing. No AHCI/NVMe/USB storage. |
| MIXFS v1 persistent filesystem | Compiled in user-reported Windows build | Dual CRC superblocks, bitmap, fixed inode table, extents, path-based VFS, file/dir operations, fsck consistency check and persistent self-test; dedicated expendable-disk runtime testing remains pending. No journal or full recovery. |
| PCI discovery | Compiled and boot-smoke-tested by user | Read-only mechanism #1 scan; user reports 11 devices found and 11 listed. No BAR mapping, resource assignment, bus mastering, or drivers. |
| Ethernet / Wi-Fi / TCP/IP | Not started | No network drivers or stack. |
| Clock / timezone service | Not started | PIT tick counter only; no RTC, timezone, or wall clock. |
| Desktop / window manager | Not started | No user-space app model or compositor. |
| Java / Lua / Zig runtimes | Not started | Not started. |
| SQLite | Not started | No persistent filesystem to support it. |
| Firefox | Not started | No browser binary or engine port. |
| Windows compatibility | Not started | No PE loader or Win32 APIs. |
| Installer / updater | Not started | No partition or recovery tooling. |


## Stage 8.0 — read-only PCI discovery

The kernel now has x86 port-I/O `inl`/`outl` operations and a read-only PCI
configuration-space scanner using mechanism #1. The user reports that MixedOS boots
and the `pci` command finds 11 devices (11 listed). The `pci` shell command scans
conventional bus/device/function space, honors multifunction headers, reports
vendor/device IDs and class codes, and caps printed output at 32 devices. It
does not enable bus mastering, map BARs, assign resources, or load drivers.
This is a discovery foundation for later network, audio, and graphics drivers;
it is not a driver framework and has not yet been compiled or VM-tested.

## Stage 4 validation boundary

The user supplied a successful Windows build log for Stage 4, including a
successful Rust kernel compile, ISO creation, and Limine BIOS installation. A
VirtualBox screenshot then showed `vmtest` mapping, accessing, translating,
unmapping, and reclaiming two pages; the screenshot showed zero map failures,
seven TLB invalidations, zero MixedOS-owned page-table pages remaining, and the
active Limine CR3 preserved. The same screenshot showed keyboard and mouse
input still active. This is VM-test evidence for the specific Stage 4 image the
user booted, not physical-hardware or SMP validation.

## Stage 5 validation boundary

Stage 5 adds an explicit kernel heap API but does not install it as Rust's global
allocator. The heap maps a bounded high-half arena through the Stage 4 page-table
manager, obtains zeroed frames from Stage 3, splits and coalesces address-sorted
free blocks, validates allocation headers, and exposes `heap`/`heaptest` shell
commands. The user's VirtualBox screenshots confirmed seven differently sized
and aligned allocations were written, verified, freed in a fragmented order,
and coalesced. The heap ended with 40 KiB capacity, zero used bytes, zero live
allocations, one free block, and zero free errors. Physical frame accounting
remained consistent.

## Stage 6 validation boundary

Stage 6 source includes a first ring-3 process/scheduler implementation: GDT/TSS,
DPL3 `int 0x80`, cloned process roots with private user pages, round-robin yield,
PIT preemption, per-process kernel stacks, user-fault retirement, and
`proctest`/`procs` commands. The first disposable VirtualBox `proctest` attempt
failed closed before entering ring 3 with `InheritedUserMapping`. The original
check treated any present PML4 parent U/S bit as an inherited user mapping.
However, x86 user access requires U/S at every level, so a bootloader-set U/S bit
on a parent can still lead only to supervisor leaves. Stage 6 Fix 1 clears U/S on
inherited present PML4 entries in each private cloned process root, preserves
the active kernel root, and verifies the clone before adding the process-owned
user subtree. The dedicated user PML4 slot must still be empty. Fix 2's framebuffer output showed both ring-3 tasks reaching report, yield, and
exit syscalls but did not return to the shell. Fix 3 added exit/return-path
breadcrumbs. Fix 4 simplifies final teardown: an assembly-only leaf stub
restores the saved kernel CR3 and shell stack, then returns normally to
`run_demo()`, where Rust verifies CR3, restores TSS.RSP0, and reclaims process
resources. Host source/model checks and Clang assembly/C checks pass; a new
Windows build and disposable VirtualBox `proctest` are still required. The user subsequently
built Stage 6 Fix 5 and supplied a VirtualBox screenshot showing both processes
exited, zero faults, four syscall reports, five context switches, zero cleanup
errors, the kernel CR3 restored/verified, both private address spaces and stacks
reclaimed, and the `MIXEDOS>` prompt returned. Stage 6's built-in demonstration
process lifecycle is therefore VM-tested. This does not validate a general
process API, ELF loader, preemptive multitasking under arbitrary workloads, or
physical SMP.


### Stage 6 Fix 5 validation boundary

The user's VirtualBox screenshot for Fix 5 confirms the built-in process test
completed end-to-end: both ring-3 processes exited, zero faulted, four syscall
reports were received, five context switches occurred, zero cleanup errors
were reported, the kernel CR3 was restored/verified, both private address spaces
and kernel stacks were reclaimed, and the `MIXEDOS>` prompt returned. This
validates the built-in two-process demonstration on that VM image. It does not
validate a general ELF loader, arbitrary workloads, per-process SIMD state,
or SMP.


## Stage 7 validation boundary

Stage 7 source adds a legacy IDE ATA PIO block driver, a block-device contract,
a VFS facade, and MIXFS v1. MIXFS uses dual CRC-protected superblocks, a sector
bitmap, 256 fixed inodes, extents, basic path resolution, directories, file
create/read/explicit-overwrite/bounded-append/same-directory-rename/delete,
structural checks, and a persistent round-trip self-test. The user has booted
the previous Stage 7 safe-target build in VirtualBox, formatted the dedicated
secondary 256 MiB VDI, created nested directories and two files, and confirmed
both files remained readable after a VM reboot. The new file-operation update
in this archive is included in the user-reported successful Windows build; its
new file-operation paths still need dedicated expendable-disk runtime testing. It never formats on mount. Formatting requires an explicit
`format ataN --erase-dedicated-disk` target; the first detected ATA disk is
protected and targets larger than 512 MiB are rejected during this bring-up
stage. Host-side layout/source-model checks pass. The previous safe-target
build has been booted and its basic create/read/reboot-persistence path was
confirmed by the user. This new file-operation revision still needs a Windows
Rust build and a VM test before the added commands are considered verified. It
is not journaled and does not claim power-loss recovery. The future custom MixedOS Windows
compatibility layer is documented as a separate later project that will use
the VFS; no PE loader or Win32 API implementation exists yet.


## Stage 7 safety revision

The original Stage 7 formatter was unsafe: it always targeted the first ATA
hard disk. The revised source enumerates all four legacy IDE positions, lists
them as `ata0`–`ata3`, protects the first detected ATA disk from formatting,
rejects targets above 512 MiB, and requires an explicit target ID plus the
destructive confirmation token.
At boot, MIXFS mount scans detected disks using reads only so a previously
formatted secondary data VDI can be remounted. A fresh Windows build is now confirmed by the supplied log; dedicated expendable-disk runtime testing on a compatible controller remains pending.


## Console usability update

The console has a bounded 256-line framebuffer scrollback buffer, mouse-drag scrollbar, `scroll` command, and 16-entry boot-session command history recalled with Up/Down. The PS/2 input update negotiates IntelliMouse wheel protocol ID 3, falls back to standard three-byte packets for unsupported devices, and normalizes wheel polarity so wheel-up moves toward older output and wheel-down returns toward newer output. Everyday `help` is now compact; `diagnostics` lists internal developer and hardware commands separately. The user has now supplied a successful Windows build log and reports a successful boot with 11 PCI devices found. This follow-up source update still needs a fresh Windows rebuild and physical-hardware wheel-direction check.
