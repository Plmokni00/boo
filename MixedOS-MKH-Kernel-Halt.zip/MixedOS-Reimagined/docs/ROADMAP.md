# Development roadmap

The sequence follows dependency order. A later stage must not be marked complete
because an interface or UI control merely exists.

## Stage 1 — boot and kernel foundation

- [x] BIOS/UEFI boot path defined through Limine and an ISO build workflow.
- [x] x86_64 Rust kernel entry point.
- [x] Early serial diagnostics through COM1.
- [x] Early RGB framebuffer console.
- [x] Bootloader memory-map and HHDM request handling.
- [x] Freestanding C ABI object compiled and linked in the user-reported build.
- [x] Windows build and ISO creation completed successfully by the user.
- [x] Initial VirtualBox boot reported and screenshot-confirmed by the user.
- [x] IDT source, exception stubs, and CPU fault reporting.
- [x] Legacy PIC/PIT timer source (100 Hz) and IRQ plumbing.
- [ ] BIOS and UEFI boot both verified separately.
- [ ] Real hardware boot verified.

## Stage 2 — interactive input and kernel console

- [x] Shared i8042 poller with primary/auxiliary channel demultiplexing.
- [x] Keyboard key-down/key-up decoder and US-layout text events.
- [x] Standard three-byte PS/2 mouse packet decoder and relative pointer state.
- [x] Optional IntelliMouse wheel negotiation (ID 3), four-byte packet decoding, and shell scroll integration (source/model checked; VM device test pending).
- [x] Bounded device-neutral input event queue consumed by the kernel console.
- [x] Framebuffer input counters and `input` diagnostics command.
- [x] Framebuffer text console with 256-line scrollback, PageUp/PageDown, Ctrl+Home/Ctrl+End, and shell scroll commands (source/model-checked; VM key testing pending).
- [x] Bounded 16-command session history with Up/Down recall and `history` command (source/model-checked; VM key testing pending).
- [x] Kernel command loop: `help`, `clear`, `mem`, `uptime`, `input`, `reboot`.
- [x] COM1 serial input normalized into the shared event queue.
- [x] Keyboard, mouse, shell command processing, and timer behavior observed in
      the user's VirtualBox screenshot (2026-11-11).
- [ ] USB HID controller/device support (USB keyboard, mouse, tablet); extra PS/2 mouse buttons and physical wheel-device coverage also remain to be tested.

## Stage 3 — physical memory foundation (user VM-confirmed)

- [x] Bounded Limine memory-map iterator.
- [x] 4 KiB physical frame allocator with managed/allocated bitmaps.
- [x] Non-usable memory regions and the first MiB remain reserved.
- [x] Checked HHDM conversion and zeroed-frame allocation helper.
- [x] Allocation/free counters and double-free/invalid-free rejection.
- [x] `mem`, `frames`, and full-page `memtest` shell diagnostics.
- [x] User screenshot confirms the eight-page physical memory test passes and frames are returned with zero free errors (2026-11-11).
- [ ] Allocation exhaustion and recovery test on the VM.

## Stage 4 — virtual memory foundation (user VM-confirmed)

- [x] Inspect active four-level CR3 root without replacing it.
- [x] Detect physical-address width, NX capability, and unsupported LA57 mode.
- [x] Enable/verify EFER.NXE when supported and CR0.WP.
- [x] Map/unmap allocator-owned 4 KiB pages with parent permission checks.
- [x] Refuse existing-page collisions and huge-page splitting.
- [x] Track and reclaim only MixedOS-owned empty page-table pages.
- [x] Roll back partially created page-table paths on mapping errors.
- [x] Invalidate local TLB entries after mapping changes.
- [x] Add `paging` and real-virtual-access `vmtest` console commands.
- [x] Windows build completed successfully; Rust kernel compiled, hybrid ISO authored, and Limine BIOS installation completed (user build log).
- [x] User VirtualBox screenshot confirms two pages mapped, accessed, translated, unmapped, and reclaimed; zero map failures; seven TLB invalidations; active Limine CR3 preserved.
- [x] User screenshot confirms keyboard and mouse remained responsive during the Stage 4 VM test.
- [ ] Repeat `vmtest` and verify allocator accounting under repeated runs.

## Stage 5 — kernel heap (user VM-confirmed)

- [x] Explicit allocation/deallocation API with size and power-of-two alignment.
- [x] Bounded high-half heap arena mapped through the Stage 4 active-root manager.
- [x] Physical backing frames allocated/zeroed through Stage 3.
- [x] Intrusive address-sorted free list with splitting and adjacent-block coalescing.
- [x] Allocation headers, bounds checks, invalid-free and repeated-free detection.
- [x] On-demand arena growth, usage/fragmentation counters, and `heap` diagnostics.
- [x] `heaptest` covers varied sizes, alignments, data readback, fragmented free order, and accounting recovery.
- [x] Windows Rust build and VirtualBox `heaptest` verification confirmed by user screenshots.
- [x] Seven varied aligned allocations, write/readback, fragmented free, full coalescing, and zero-error byte accounting confirmed in VirtualBox.
- [ ] Repeated allocation/free stress and exhaustion/recovery on the VM.
- [ ] Integrate as Rust `GlobalAlloc` only after the explicit heap API is VM-tested and scheduler/interrupt locking policy exists.

## Stage 6 — processes, privilege, and scheduling

- [x] GDT/TSS ownership, ring-3 selectors, and per-task kernel interrupt stacks (user VM-tested for the built-in demo).
- [x] User-mode transition and minimal DPL3 `int 0x80` report/yield/exit syscall ABI (user VM-tested for the built-in demo).
- [x] Two built-in ring-3 tasks with separate cloned roots, private code/stack pages, and supervisor-only inherited kernel mappings (user VM-tested).
- [x] Uniprocessor round-robin switching on yield and PIT timer preemption; user-fault retirement and cleanup path (user VM-tested for cooperative switching and clean exit; arbitrary preemptive workload coverage remains future work).
- [ ] General ELF loader, relocation policy, and dynamic process creation.
- [ ] General process/thread lifecycle, wait/signals, synchronization primitives, and SMP scheduling.
- [ ] Per-process FPU/SSE/AVX context and kernel-stack guard pages.
- [x] Windows Rust build and disposable VirtualBox `proctest` verification; user screenshot confirms 2 exits, 0 faults, 4 syscall reports, 5 context switches, zero cleanup errors, and return to the shell.
- [ ] General ELF loader, per-process FPU/SIMD state, wait/signals, SMP, and production scheduling remain future work.

## Stage 7 — storage and persistence (source implemented; Windows build/VM test pending)

- [x] 512-byte block-device interface with legacy IDE ATA PIO backend and bounded polling.
- [x] LBA28 IDENTIFY, sector read/write, and optional flush path.
- [x] MIXFS v1 whole-disk format with dual CRC superblocks, sector bitmap, 256 fixed inodes, and extent-based file/directory data.
- [x] Path-based VFS facade; `ls`, `mkdir`, `write`, `cat`, and `rm` shell commands.
- [x] Explicit destructive format confirmation; unrecognized disks are never auto-formatted.
- [x] File management: `overwrite`, bounded `append`, and same-directory `rename`; user VM-tested across reboot.
- [x] Directory management: `ls`, `rm` (files only), `rmdir` (empty directories only), and structural `fsck`; source/model-checked; Windows build/runtime testing pending for this package.
- [x] Dirty/clean superblock generation protocol, read-only mount after interrupted writes, and structural `fsck` consistency checks.
- [x] Persistent filesystem `fstest` for create/write/read/verify/delete/free-space round trip.
- [ ] Windows Rust build and VirtualBox disposable-VDI tests, including reboot persistence.
- [ ] Journal/redo recovery, repair, partition support, AHCI/NVMe/USB storage, ACL enforcement, symlinks/hardlinks, cross-directory moves, and broader filesystem stress.
- [ ] SQLite compiled for MixedOS and integrated above filesystem I/O.
- [ ] File manager as a user-space application.

## Stage 8 — hardware discovery and networking

- [x] Read-only conventional PCI configuration-space enumeration with a bounded 32-device shell report (source/model checked; VirtualBox scan pending).
- [ ] PCI/USB device discovery framework beyond legacy PCI configuration mechanism #1.
- [ ] Ethernet driver(s) and link-state reporting.
- [ ] IPv4/IPv6, ARP/NDP, ICMP, UDP, and TCP.
- [ ] DHCP and DNS clients.
- [ ] TLS and certificate validation.
- [ ] Wi-Fi chipset support and authentication management.
- [ ] Real-world connectivity tests from supported hardware.

## Stage 9 — desktop and services

- [ ] RTC, UTC clock service, timezone database, and NTP.
- [ ] Audio and input device services.
- [ ] Window-system protocol and compositor.
- [ ] Window manager and focus/input routing.
- [ ] Panel, launcher, dock, notifications, and settings.
- [ ] Lua runtime embedded in a user-space service.
- [ ] GPU driver architecture and software fallback.

## Stage 10 — application environment

- [ ] Native app ABI, loader, libraries, and package format.
- [ ] User-space terminal, process groups, file descriptors, pipes, and real shell.
- [ ] Java runtime with JVM conformance tests; not a bytecode demo.
- [ ] Software installation, updates, permissions, and rollback.
- [ ] Firefox port/build feasibility study against the completed user-space API;
      include the real Firefox engine or do not call it Firefox.

## Stage 11 — Windows compatibility

This is a major long-term capability, not an optional EXE launcher. It must be
implemented for MixedOS itself and must not require an installed Linux or
Windows operating system underneath it.

- [ ] PE32/PE32+ executable loader, section mapping, relocations, imports, and module loader.
- [ ] Windows DLL loading and dependency resolution.
- [ ] Win32 API compatibility for filesystem, processes, memory, threads, synchronization, time, environment, and registry-like settings.
- [ ] Windows application installation, execution, dependencies, and per-application compatibility profiles.
- [ ] Common application frameworks and their required runtime/library surfaces.
- [ ] Graphics API translation plus audio, input, and window-system bridges.
- [ ] Compatibility test suite using selected real Windows executables and DLLs.
- [ ] Investigate Windows game compatibility only after ordinary applications and graphics paths work.

## Stage 12 — production readiness

- [ ] Installer, partitioning, boot entry setup, and recovery environment.
- [ ] Secure update system and data-preserving upgrades.
- [ ] Hardware compatibility matrix and automated regression testing.
- [ ] Performance, power, security, and reliability testing.
- [ ] ARM64 port as a separate architecture milestone.


## Stage 13 — Android application compatibility research

- [ ] Research an Android-compatible execution environment after the native
      application ABI and core services are stable.
- [ ] Identify the required Android runtime, framework APIs, package/install
      lifecycle, graphics, input, and service dependencies.
- [ ] Build compatibility incrementally; APK parsing or installation alone is
      not Android application support.
