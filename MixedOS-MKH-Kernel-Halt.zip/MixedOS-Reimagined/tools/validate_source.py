#!/usr/bin/env python3
"""Repository structure and regression checks; this does not compile or boot MixedOS."""
from pathlib import Path
import hashlib
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "Build.bat", "build.ps1", "Cargo.toml", ".cargo/config.toml",
    "boot/limine.conf", "kernel/Cargo.toml", "kernel/build.rs", "kernel/linker.ld",
    "kernel/src/main.rs", "kernel/src/boot/limine.rs", "kernel/src/process.rs", "kernel/src/pci.rs", "kernel/src/mkh.rs",
    "kernel/src/arch/x86_64/gdt.rs",
    "kernel/src/console/serial.rs", "kernel/src/console/framebuffer.rs",
    "kernel/src/interrupts/mod.rs", "kernel/src/arch/x86_64/interrupts.S", "tools/test_mkh.py",
    "kernel/src/input/mod.rs", "kernel/src/input/keyboard.rs",
    "kernel/src/input/mouse.rs", "kernel/src/input/ps2.rs",
    "kernel/src/shell/mod.rs", "kernel/native/c/runtime.c", "include/mixedos/abi.h",
    "docs/STATUS.md", "docs/ROADMAP.md", "docs/STAGE2.md", "docs/BUILD-FIX-STAGE4-FIX2.md",
    "docs/INPUT-SUBSYSTEM.md", "docs/BUILD-FIX-2026-11-11.md",
    "kernel/src/memory/physical.rs", "kernel/src/memory/paging.rs", "kernel/src/memory/heap.rs",
    "tools/stage4-memory-baseline.sha256", "docs/PHYSICAL-MEMORY.md", "docs/STAGE3.md", "docs/STAGE4.md", "docs/STAGE5.md",
    "tools/test_memory_model.py", "tools/test_paging_model.py", "tools/test_heap_model.py", "tools/test_arch_facade.py",
    "tools/test_process_model.py", "tools/stage2-input-baseline.sha256", "tools/stage5-heap-baseline.sha256",
    "tools/stage6-process-baseline.sha256",
    "kernel/src/storage/mod.rs", "kernel/src/storage/ata.rs", "kernel/src/storage/block.rs",
    "kernel/src/storage/mixfs.rs", "kernel/src/storage/vfs.rs",
    "tools/test_storage_model.py", "tools/test_mixfs_model.py", "tools/test_directory_management.py", "tools/test_console_scrollback.py", "tools/test_ps2_mouse_wheel.py", "tools/test_pci_discovery.py", "docs/STAGE7-DIRECTORY-MANAGEMENT.md", "docs/STAGE7-CONSOLE-UPDATE.md",
    "docs/STAGE7.md", "docs/WINDOWS-COMPATIBILITY.md",
    "docs/STAGE6.md", "docs/STAGE6-FIX2.md", "docs/STAGE6-FIX3.md", "docs/STAGE6-FIX4.md", "docs/STAGE6-FIX5.md",
]
FORBIDDEN_DIRS = {"target", "build", "dist", "node_modules", ".git", "toolchains", "iso_root", "__pycache__"}
errors: list[str] = []
for rel in REQUIRED:
    if not (ROOT / rel).is_file():
        errors.append(f"missing required file: {rel}")

for path in ROOT.rglob("*"):
    relative = path.relative_to(ROOT)
    # build/ is the build system's live output directory. Build.ps1 creates it
    # (including the transcript log) before this validator runs, so scanning it
    # would make every normal build reject its own generated output. Ignore
    # only the repository-root build/ tree; a nested source/vendor directory
    # named build remains subject to the bundled-artifact checks below.
    if relative.parts and relative.parts[0] == "build":
        continue
    if path.is_dir() and path.name in FORBIDDEN_DIRS:
        errors.append(f"generated or bundled directory found: {relative}")
    if path.is_file() and path.suffix.lower() in {".iso", ".exe", ".dll", ".efi", ".o", ".elf", ".bin", ".pyc"}:
        errors.append(f"generated image, object, or host binary included: {relative}")

# Architecture facade coverage.
arch_facade = (ROOT / "kernel/src/arch/mod.rs").read_text(encoding="utf-8")
# Accept both `pub use x86_64::{...}` and the equivalent explicit
# `pub use self::x86_64::{...}` spelling. Rust permits both inside arch/mod.rs.
match = re.search(r"pub\s+use\s+(?:self::)?x86_64::\{([^}]+)\}", arch_facade)
if not match:
    errors.append("architecture facade is missing its public x86_64 re-export list")
else:
    exported = {part.strip().split(" as ")[0].strip() for part in match.group(1).split(",") if part.strip()}
    required_exports = {"disable_interrupts", "enable_interrupts", "halt_forever", "inb", "inl", "inw", "initialize_fpu", "outb", "outl", "outw", "wait_for_interrupt", "initialize_gdt_tss", "gdt_tss_ready", "kernel_interrupt_stack_top", "set_kernel_stack", "read_cr3", "write_cr3", "KERNEL_CODE_SELECTOR", "KERNEL_DATA_SELECTOR", "USER_CODE_SELECTOR", "USER_DATA_SELECTOR"}
    missing_required = sorted(required_exports - exported)
    if missing_required:
        errors.append("architecture facade missing required public exports: " + ", ".join(missing_required))
    referenced: set[str] = set()
    for rel in ("kernel/src/main.rs", "kernel/src/console/serial.rs", "kernel/src/interrupts/mod.rs", "kernel/src/shell/mod.rs", "kernel/src/input/ps2.rs", "kernel/src/storage/ata.rs", "kernel/src/pci.rs"):
        source = (ROOT / rel).read_text(encoding="utf-8")
        referenced.update(re.findall(r"(?<![A-Za-z0-9_:])(?:crate::)?arch::([A-Za-z_][A-Za-z0-9_]*)", source))
    missing = sorted(referenced - exported)
    if missing:
        errors.append("architecture facade missing exports: " + ", ".join(missing))

# Windows/MSYS2 xorriso path handling regression.
build_script = (ROOT / "build.ps1").read_text(encoding="utf-8")
for token in ("function Test-MsysXorriso", "function ConvertTo-MsysPath", "ConvertTo-MsysPath $IsoRoot", "ConvertTo-MsysPath $iso", "$isoSourceArgument, '-o', $isoOutputArgument"):
    if token not in build_script:
        errors.append("build.ps1 missing MSYS2 xorriso path handling: " + token)

# MKH crash handling contract: early IDT, emergency IST stacks, bounded fatal path.
mkh = (ROOT / "kernel/src/mkh.rs").read_text(encoding="utf-8")
gdt = (ROOT / "kernel/src/arch/x86_64/gdt.rs").read_text(encoding="utf-8")
interrupts = (ROOT / "kernel/src/interrupts/mod.rs").read_text(encoding="utf-8")
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
framebuffer = (ROOT / "kernel/src/console/framebuffer.rs").read_text(encoding="utf-8")
for token in ("pub fn rust_panic", "pub fn cpu_exception", "pub fn fatal_message", "AtomicBool",
              "No filesystem or disk writes were attempted", "serial::write_fmt", "screen::render_mkh_screen",
              "pub fn set_framebuffer", "struct FixedText", "exception_name"):
    if token not in mkh:
        errors.append("MKH fatal-path implementation missing: " + token)
for token in ("DOUBLE_FAULT_STACK", "NMI_STACK", "MACHINE_CHECK_STACK", "ptr::addr_of_mut!((*tss_pointer).ist)"):
    if token not in gdt:
        errors.append("MKH emergency TSS stack missing: " + token)
for token in ("pub fn install_exception_handlers", "vector { 8 => 1, 2 => 2, 18 => 3", "crate::mkh::cpu_exception", "crate::mkh::fatal_message"):
    if token not in interrupts:
        errors.append("MKH interrupt integration missing: " + token)
if main.find("interrupts::install_exception_handlers()") > main.find("if !boot::limine::base_revision_supported()"):
    errors.append("MKH exception IDT is not installed early enough during boot")
if "mkh::rust_panic(info)" not in main:
    errors.append("Rust panic handler does not route to MKH")
for token in ("pub fn render_mkh_screen", "CRASH CODE:", "fn draw_wrapped_text", "fn text_hex64"):
    if token not in framebuffer:
        errors.append("MKH framebuffer renderer missing: " + token)

# Read-only PCI configuration-space discovery contract.
pci = (ROOT / "kernel/src/pci.rs").read_text(encoding="utf-8")
for token in ("CONFIG_ADDRESS: u16 = 0x0CF8", "CONFIG_DATA: u16 = 0x0CFC",
              "MAX_REPORTED_DEVICES: usize = 32", "pub fn enumerate",
              "header_type & 0x80", "fn read_config_u32",
              "arch::outl(CONFIG_ADDRESS, address)", "arch::inl(CONFIG_DATA)",
              "truncated: found > reported", "pub enum PciBar",
              "pub struct PciBridgeInfo", "revision_id: u8",
              "subsystem_vendor_id: Option<u16>", "if normalized_header_type == 0",
              "interrupt_pin: u8", "fn read_bars(",
              "CardBus uses a different header layout", "Memory64 { base: u64"):
    if token not in pci:
        errors.append("PCI device model missing marker: " + token)
for forbidden in ("arch::outb", "arch::inb", "bus_master", "write_config"):
    if forbidden in pci:
        errors.append("PCI discovery must remain read-only and use 32-bit config access: " + forbidden)

# IDT and assembly consistency.
interrupts = (ROOT / "kernel/src/interrupts/mod.rs").read_text(encoding="utf-8")
asm = (ROOT / "kernel/src/arch/x86_64/interrupts.S").read_text(encoding="utf-8")
for token in ("const IDT_ENTRIES: usize = 256", "lidt", "PIT_HZ: u32 = 100", "mixedos_interrupt_dispatch", "Page fault address", "arch::outb(PIC1_DATA, 0xFE)"):
    if token not in interrupts:
        errors.append("interrupt controller source missing marker: " + token)
entries = {int(n): kind for kind, n in re.findall(r"^ISR_(NOERR|ERR)\s+(\d+)$", asm, re.MULTILINE)}
expected_errors = {8, 10, 11, 12, 13, 14, 17, 21, 29, 30}
if set(entries) != set(range(256)):
    errors.append("interrupt assembly must define exactly one ISR stub for vectors 0-255")
for vector in range(256):
    expected = "ERR" if vector in expected_errors else "NOERR"
    if entries.get(vector) != expected:
        errors.append(f"interrupt vector {vector} must use ISR_{expected}")
        break
vector_table = [int(n) for n in re.findall(r"^\s*\.quad mixedos_isr_(\d+)$", asm, re.MULTILINE)]
if vector_table != list(range(256)):
    errors.append("mixedos_isr_table must contain vectors 0-255 in order")

# Unified input design regressions.
input_mod = (ROOT / "kernel/src/input/mod.rs").read_text(encoding="utf-8")
ps2 = (ROOT / "kernel/src/input/ps2.rs").read_text(encoding="utf-8")
keyboard = (ROOT / "kernel/src/input/keyboard.rs").read_text(encoding="utf-8")
mouse = (ROOT / "kernel/src/input/mouse.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
framebuffer = (ROOT / "kernel/src/console/framebuffer.rs").read_text(encoding="utf-8")
checks = {
    "kernel/src/input/mod.rs": ("pub enum InputEvent", "SerialByte(u8)", "EVENT_CAPACITY: usize = 256", "pub fn pop_event()", "pub(crate) fn push_event", "ps2::poll()"),
    "kernel/src/input/ps2.rs": ("0xAD", "0xA7", "0xAE", "0xA8", "0xD4", "send_device_command(false, 0xF0)", "send_device_command(false, 0x02)", "send_device_command(false, 0xF4)", "send_device_command(true, 0xF4)", "status & AUXILIARY", "mouse::handle_byte(byte)", "keyboard::handle_scancode(byte)"),
    "kernel/src/input/keyboard.rs": ("pub fn handle_scancode", "MOD_SHIFT", "MOD_CAPS_LOCK", "KeyEvent", "0xE0", "0xE1", "b'\\n'", "b'\\t'"),
    "kernel/src/input/mouse.rs": ("pub fn handle_byte", "PACKET_INDEX", "byte & 0x08", "raw_x as i8", "raw_y as i8", "buttons"),
    "kernel/src/shell/mod.rs": ("input::poll()", "input::pop_event()", "InputEvent::Key", "InputEvent::Mouse", "InputEvent::SerialByte", "b" + "\"input\""),
    "kernel/src/console/framebuffer.rs": ("set_input_status(&mut self, status: InputStats)", "status.keyboard_bytes", "status.mouse_bytes", "status.mouse_buttons"),
}
for rel, tokens in checks.items():
    source = (ROOT / rel).read_text(encoding="utf-8")
    for token in tokens:
        if token not in source:
            errors.append(f"{rel} missing input-subsystem marker: {token}")

# Shared ownership: exactly one code path is permitted to read the i8042 data port.
for rel in ("kernel/src/interrupts/mod.rs", "kernel/src/shell/mod.rs", "kernel/src/input/keyboard.rs", "kernel/src/input/mouse.rs"):
    source = (ROOT / rel).read_text(encoding="utf-8")
    if "arch::inb(0x60)" in source or "inb(DATA_PORT)" in source:
        errors.append(f"{rel} must not read the PS/2 data port outside the shared controller manager")
if "let byte = unsafe { arch::inb(DATA_PORT) };" not in ps2:
    errors.append("shared PS/2 controller manager must own port 0x60 reads")
if "let byte = unsafe { arch::inb(DATA_PORT) };" not in ps2 or "let _ = unsafe { arch::inb(DATA_PORT) };" not in ps2:
    errors.append("shared PS/2 manager must separate polled data reads from bounded initialization flushes")
if "arch::wait_for_interrupt" in shell:
    errors.append("polling bring-up shell must not HLT while waiting for events")


# Stage 3 physical-memory manager regressions.
physical = (ROOT / "kernel/src/memory/physical.rs").read_text(encoding="utf-8")
mem_mod = (ROOT / "kernel/src/memory/mod.rs").read_text(encoding="utf-8")
limine = (ROOT / "kernel/src/boot/limine.rs").read_text(encoding="utf-8")
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
memory_checks = {
    "kernel/src/boot/limine.rs": ("pub struct MemoryRegion", "pub struct MemoryMapIter", "pub fn memory_regions()", "response.entry_count > 4096"),
    "kernel/src/memory/physical.rs": ("PAGE_SIZE: u64 = 4096", "MAX_TRACKED_PHYSICAL_BYTES", "FIRST_MANAGED_ADDRESS", "pub fn initialize()", "pub fn allocate_frame()", "pub fn free_frame", "AlreadyFree", "OutsideManagedMemory", "pub fn frame_to_hhdm", "pub fn allocate_zeroed_frame", "pub fn self_test", "read_volatile", "write_volatile"),
    "kernel/src/memory/mod.rs": ("pub mod physical", "pub fn initialize()"),
    "kernel/src/main.rs": ("let memory_status = memory::initialize()", "physical frame allocator"),
    "kernel/src/shell/mod.rs": ("b\"frames\"", "b\"memtest\"", "physical::self_test(8)"),
}
for rel, tokens in memory_checks.items():
    source = (ROOT / rel).read_text(encoding="utf-8")
    for token in tokens:
        if token not in source:
            errors.append(f"{rel} missing physical-memory marker: {token}")

# Lock the known-working Stage 2 input drivers against accidental changes.
baseline = ROOT / "tools/stage2-input-baseline.sha256"
for line in baseline.read_text(encoding="utf-8").splitlines():
    expected, relative = line.split("  ", 1)
    candidate = ROOT / relative
    if not candidate.is_file():
        errors.append("Stage 2 input baseline file missing: " + relative)
    elif hashlib.sha256(candidate.read_bytes()).hexdigest() != expected:
        errors.append("Known-working Stage 2 input source changed: " + relative)

# Keep the user-tested Stage 3 physical allocator and Stage 4 page-table manager
# byte-for-byte unchanged while Stage 5 adds the heap layer above them.
for line in (ROOT / "tools/stage4-memory-baseline.sha256").read_text(encoding="utf-8").splitlines():
    expected, relative = line.split("  ", 1)
    candidate = ROOT / relative
    if not candidate.is_file():
        errors.append("Stage 4 memory baseline file missing: " + relative)
    elif hashlib.sha256(candidate.read_bytes()).hexdigest() != expected:
        errors.append("Previously tested Stage 3/4 memory source changed: " + relative)

# Stage 4 active-root virtual-memory manager regressions.
paging = (ROOT / "kernel/src/memory/paging.rs").read_text(encoding="utf-8")
mem_mod = (ROOT / "kernel/src/memory/mod.rs").read_text(encoding="utf-8")
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
paging_checks = {
    "kernel/src/memory/paging.rs": (
        "pub struct PageFlags", "pub enum PagingError", "pub fn initialize() -> bool",
        'asm!("mov {}, cr3"', "CR4_LA57", "EFER_NXE", "CR0_WP",
        "pub fn map_page(", "pub fn unmap_page(", "pub fn translate(",
        "invlpg", "HUGE_PAGE", "rollback_created_tables", "register_owned_table",
        "unregister_owned_table", "is_owned_table", "physical::is_allocated_frame_address",
        "NonPresentEntryConflict", "fence(Ordering::Release)", "WriteProtectUnavailable",
        "pub fn self_test()", "user_accessible", "NO_EXECUTE",
    ),
    "kernel/src/memory/physical.rs": (
        "hhdm_pointer_for_page_table", "is_allocated_frame_address", "free_allocated_frame_at",
    ),
    "kernel/src/memory/mod.rs": ("pub mod paging", "paging::initialize()", "paging_ready"),
    "kernel/src/main.rs": ("memory_status.paging_ready", "memory::paging::stats()"),
    "kernel/src/shell/mod.rs": ("b\"paging\"", "b\"vmtest\"", "paging::self_test()"),
}
for rel, tokens in paging_checks.items():
    source = (ROOT / rel).read_text(encoding="utf-8")
    for token in tokens:
        if token not in source:
            errors.append(f"{rel} missing Stage 4 paging marker: {token}")

# Stage 4 must never write a replacement CR3; it edits only checked entries
# beneath the existing root and uses INVLPG for the changed virtual address.
if re.search(r'asm!\(\s*"mov\s+cr3\s*,', paging):
    errors.append("Stage 4 must not replace the active CR3 root")
if "write_entry(pt, ix[3], entry)" not in paging or "invalidate(address)" not in paging:
    errors.append("Stage 4 page mapping must write the leaf and invalidate its TLB entry")
rollback_start = paging.find("fn rollback_created_tables(")
rollback_end = paging.find("/// Add one 4 KiB mapping", rollback_start)
rollback = paging[rollback_start:rollback_end] if rollback_start >= 0 and rollback_end > rollback_start else ""
rollback_order = [rollback.find("write_volatile(0)"), rollback.find("invalidate(address)"), rollback.find("physical::free_frame(item.frame)")]
if not rollback or any(position < 0 for position in rollback_order) or rollback_order != sorted(rollback_order):
    errors.append("Stage 4 rollback must detach, invalidate, and only then free each page-table frame")

# Stage 5 kernel heap regressions. The heap must use Stage 3 frames and Stage 4
# mappings, keep a bounded arena, maintain aligned intrusive free blocks, and
# remain outside interrupt context until scheduler-aware locking exists.
heap = (ROOT / "kernel/src/memory/heap.rs").read_text(encoding="utf-8")
heap_checks = {
    "kernel/src/memory/heap.rs": (
        "pub fn initialize() -> bool", "pub fn allocate(", "pub fn kmalloc(", "pub fn kmalloc_aligned(",
        "pub unsafe fn deallocate(", "pub unsafe fn kfree(", "pub fn stats()", "pub fn self_test()", "MAX_HEAP_PAGES", "HEAP_BASE_CANDIDATES",
        "physical::allocate_zeroed_frame()", "paging::map_page(", "paging::unmap_page(",
        "physical::free_allocated_frame_at", "insert_free_block", "OverlappingFreeBlock",
        "DoubleFree", "InvalidAlignment", "MIN_USER_OFFSET", "PageFlags::KERNEL_READ_WRITE",
    ),
    "kernel/src/memory/mod.rs": ("pub mod heap", "paging::initialize()", "heap is initialized lazily"),
    "kernel/src/main.rs": ("let memory_status = memory::initialize()",),
    "kernel/src/shell/mod.rs": ("b\"heap\"", "b\"heaptest\"", "heap::initialize()", "heap::self_test()", "heap::stats()"),
    "tools/test_heap_model.py": ("on-demand heap growth", "double-free detection", "byte-accounting consistency"),
}
for rel, tokens in heap_checks.items():
    source = (ROOT / rel).read_text(encoding="utf-8")
    for token in tokens:
        if token not in source:
            errors.append(f"{rel} missing Stage 5 kernel-heap marker: {token}")
if "heap::allocate" in (ROOT / "kernel/src/interrupts/mod.rs").read_text(encoding="utf-8"):
    errors.append("kernel heap allocation must not be called from interrupt context")
if "impl core::alloc::GlobalAlloc" in heap:
    errors.append("Stage 5 explicit heap must not claim global allocator support before the scheduler/alloc integration")

# Ensure the memory allocator is not exposed through the interrupt dispatcher.
if "physical::allocate_frame" in (ROOT / "kernel/src/interrupts/mod.rs").read_text(encoding="utf-8"):
    errors.append("physical frame allocation must not be called from interrupt context")

# Stage 5 heap baseline: Stage 6 must consume the tested heap API without
# silently rewriting the allocator's splitting/coalescing and ownership logic.
for line in (ROOT / "tools/stage5-heap-baseline.sha256").read_text(encoding="utf-8").splitlines():
    expected, relative = line.split("  ", 1)
    candidate = ROOT / relative
    if not candidate.is_file():
        errors.append("Stage 5 heap baseline file missing: " + relative)
    elif hashlib.sha256(candidate.read_bytes()).hexdigest() != expected:
        errors.append("Previously tested Stage 5 heap source changed: " + relative)

# Stage 6: GDT/TSS, user transition, isolated address spaces, syscalls, and
# scheduler wiring. These source checks do not replace a Rust build or VM run.
gdt = (ROOT / "kernel/src/arch/x86_64/gdt.rs").read_text(encoding="utf-8")
process = (ROOT / "kernel/src/process.rs").read_text(encoding="utf-8")
interrupts = (ROOT / "kernel/src/interrupts/mod.rs").read_text(encoding="utf-8")
asm = (ROOT / "kernel/src/arch/x86_64/interrupts.S").read_text(encoding="utf-8")
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
stage6_checks = {
    "kernel/src/arch/x86_64/gdt.rs": (
        "KERNEL_CODE_SELECTOR: u16 = 0x08", "USER_DATA_SELECTOR: u16 = 0x1B",
        "USER_CODE_SELECTOR: u16 = 0x23", "struct TaskStateSegment", "io_map_base",
        "pub fn initialize() -> bool", "pub fn set_kernel_stack", "kernel_interrupt_stack_top",
    ),
    "kernel/src/process.rs": (
        "const USER_PML4_SLOT: usize = 1", "const SYS_REPORT: u64 = 1", "const SYS_YIELD: u64 = 2", "const SYS_EXIT: u64 = 3",
        "hhdm_pointer_for_page_table", "PRESENT | WRITABLE | USER", "NO_EXECUTE",
        "sanitize_inherited_kernel_entries(new_root)?", "entry & !USER",
        "pub fn run_demo()", "pub(crate) fn on_timer", "pub(crate) fn handle_syscall", "pub(crate) fn handle_fault",
        "FiveLevelPagingUnsupported", "ActiveRootChanged", "arch::read_cr3()",
        "mixedos_kernel_return_cr3", "cleanup_all()", "arch::write_cr3", "arch::set_kernel_stack",
        "write_bytes(0, KERNEL_STACK_BYTES)",
        "PROGRESS_TERMINAL", "set_progress_terminal", "clear_progress_terminal", "progress_line(",
        "private CR3 active; attempting first IRETQ to CPL3",
        "ring-3 REPORT syscall received", "ring-3 YIELD syscall received", "ring-3 EXIT syscall received",
        "exit handler entered; updating current process state", "scanning for another READY process",
        "no READY processes remain; requesting direct ISR return", "returned from user mode; verifying restored kernel CR3",
        "request_kernel_return()", "mixedos_return_to_kernel",
        "cleanup: releasing private page-table frames",
        "if arch::read_cr3() != kernel_root", "process cleanup refused: return stub did not restore kernel CR3",
        "struct UserInterruptFrame", "user_rsp: u64", "user_ss: u64", "user_frame_ptr(frame)",
        "size_of::<InterruptFrame>()", "size_of::<UserInterruptFrame>()",
    ),
    "kernel/src/interrupts/mod.rs": (
        "let dpl = if vector == 128 { 3 } else { 0 }", "pub struct InterruptFrame",
        "128 =>", "crate::process::handle_syscall(frame)", "crate::process::on_timer(frame)",
        "crate::process::handle_fault(frame, vector, fault_address)",
    ),
    "kernel/src/arch/x86_64/interrupts.S": (
        "mixedos_gdt_reload", "mixedos_enter_user", "mixedos_kernel_return_rsp",
        "mixedos_return_to_kernel", ".Lmixedos_return_to_kernel", "mixedos_kernel_return_cr3", "mov cr3, rax",
        "iretq", "push 0x1B", "push 0x23", "fxsave64", "mov ss, ax",
    ),
    "kernel/src/main.rs": ("mod process;", "arch::initialize_gdt_tss()"),
    "kernel/src/shell/mod.rs": ("b\"proctest\"", "b\"procs\"", "crate::process::set_progress_terminal", "crate::process::clear_progress_terminal", "crate::process::run_demo()", "crate::process::stats()"),
    "tools/test_process_model.py": ("reserved per-process PML4 slot", "round-robin yield order", "unique per-process roots"),
    "tools/test_mkh.py": ("early exception gate installation", "double-fault IST", "register dump coverage"),
}
for rel, tokens in stage6_checks.items():
    source = (ROOT / rel).read_text(encoding="utf-8")
    for token in tokens:
        if token not in source:
            errors.append(f"{rel} missing Stage 6 process/user-mode marker: {token}")

# The syscall gate must be DPL3, while all other interrupt gates remain DPL0.
if "attributes: 0x8E | ((dpl & 3) << 5)" not in interrupts:
    errors.append("IDT gate attributes must encode the requested DPL")
if "let dpl = if vector == 128 { 3 } else { 0 };" not in interrupts:
    errors.append("only vector 128 may be exposed as a ring-3 syscall gate")
# Verify the process code sanitizes inherited U/S parent bits in its private
# PML4 clone and rejects an occupied dedicated user slot before adding the
# private user subtree. The original kernel root must remain untouched.
if "sanitize_inherited_kernel_entries(new_root)?" not in process or "entry & !USER" not in process or "if entry != 0 { return Err(ProcessError::UserSlotOccupied); }" not in process:
    errors.append("Stage 6 must sanitize inherited PML4 U/S bits and reject an occupied user slot")
if "ptr::copy_nonoverlapping(source_root.as_ptr().cast::<u8>(), new_root.cast::<u8>(), 4096)" not in process:
    errors.append("Stage 6 must clone a distinct root page before adding user mappings")
if "if code_segment & 3 == 3 { crate::process::on_timer(frame); }" not in interrupts:
    errors.append("PIT interrupts from CPL3 must reach the user-task scheduler")
if "pub user_rsp: u64" in interrupts or "pub user_ss: u64" in interrupts:
    errors.append("base InterruptFrame must remain valid for same-CPL ring-0 interrupts")
if "mov cr3, rax" not in asm or "mov rsp, qword ptr [rip + mixedos_kernel_return_rsp]" not in asm:
    errors.append("user-session return trampoline must restore kernel CR3 and the saved shell stack")
if "call mixedos_user_session_finished" in asm:
    errors.append("user-session return trampoline must not call Rust cleanup from synthetic IRET context")
if "source_root.as_ptr().cast::<u8>()" not in process:
    errors.append("page-table root clone must use matching byte-pointer types")
if "process cleanup refused: return stub did not restore kernel CR3" not in process:
    errors.append("Stage 6 must refuse to free process roots until the return stub restores the kernel CR3")
if "call mixedos_user_session_finished" in asm:
    errors.append("Rust process cleanup must run after the assembly return stub resumes run_demo(), not inside synthetic IRET return")

# Stage 7 storage and MIXFS source regressions. The filesystem is intentionally
# a dedicated raw-disk format for the first VirtualBox bring-up; it must never
# auto-format a disk and must fail closed after incomplete metadata mutation.
storage_mod = (ROOT / "kernel/src/storage/mod.rs").read_text(encoding="utf-8")
ata = (ROOT / "kernel/src/storage/ata.rs").read_text(encoding="utf-8")
block = (ROOT / "kernel/src/storage/block.rs").read_text(encoding="utf-8")
mixfs = (ROOT / "kernel/src/storage/mixfs.rs").read_text(encoding="utf-8")
vfs = (ROOT / "kernel/src/storage/vfs.rs").read_text(encoding="utf-8")
port = (ROOT / "kernel/src/arch/x86_64/port.rs").read_text(encoding="utf-8")
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
storage_checks = {
    "kernel/src/arch/x86_64/port.rs": ("pub unsafe fn inw", "pub unsafe fn outw", '"in ax, dx"', '"out dx, ax"'),
    "kernel/src/storage/ata.rs": ("MAX_LBA28_SECTORS", "0xEC", "0x20", "0x30", "0xE7", "wait_data_request", "POLL_LIMIT", "words[49]", "words[60]", "words[61]", "words[83]", "pub const DEVICE_SLOTS", "pub fn disk_info", "pub fn selected_index", "pub fn protected_index", "pub fn is_safe_format_target", "pub fn read_sector", "pub fn write_sector"),
    "kernel/src/storage/block.rs": ("pub trait BlockDevice", "fn geometry(&self)", "fn read_block(&self", "fn write_block(&self", "pub struct AtaPioBlockDevice", "pub fn select_device", "pub fn is_safe_format_target", "pub fn flush()"),
    "kernel/src/storage/mixfs.rs": ("MIXFS1", "SUPER_CRC_OFFSET", "fn crc32", "bitmap_start: 2", "INODE_COUNT: u32 = 256", "EXTENTS_MAX: usize = 12", "fn begin_mutation", "fn finish_mutation", "pub fn format(target_index: usize", "is_safe_format_target(target_index)", "FsError::ProtectedDisk", "MAX_FORMAT_SECTORS", "FsError::TargetTooLarge", "--erase-dedicated-disk", "pub fn mkdir", "pub fn write_file", "pub fn overwrite_file", "pub fn append_file", "pub fn rename_file", "pub fn read_file", "pub fn remove", "pub fn remove_file", "pub fn remove_dir", "pub fn check", "pub fn self_test", "WriteMode::CreateOnly", "WriteMode::ReplaceOnly", "state_store(MountState { mounted: true, read_only: true, superblock: sb });"),
    "kernel/src/storage/vfs.rs": ("pub fn mount", "pub fn format(target_index: usize", "pub fn list", "pub fn read_file", "pub fn write_file", "pub fn overwrite_file", "pub fn append_file", "pub fn rename_file", "pub fn mkdir", "pub fn remove", "pub fn remove_file", "pub fn remove_dir", "pub fn check", "pub fn sync"),
    "kernel/src/storage/mod.rs": ("pub mod ata", "pub mod block", "pub mod mixfs", "pub mod vfs", "pub fn initialize()", "ata::protected_index()", "ata::DEVICE_SLOTS", "vfs::mount()"),
    "kernel/src/main.rs": ("mod storage;", "let storage_status = storage::initialize();", "interrupts::initialize();", "no legacy IDE ATA hard disk detected", "disk left unchanged (format is manual)"),
    "kernel/src/shell/mod.rs": ("b\"disk\"", "b\"format\"", "b\"fstest\"", "b\"fsck\"", "b\"mkdir\"", "b\"write\"", "b\"overwrite\"", "b\"append\"", "b\"rename\"", "b\"cat\"", "b\"rm\"", "b\"sync\"", "format ataN --erase-dedicated-disk", "parse_ata_id", "ProtectedDisk", "PROTECTED", "fn split_command"),
}
for rel, tokens in storage_checks.items():
    source = (ROOT / rel).read_text(encoding="utf-8")
    for token in tokens:
        if token not in source:
            errors.append(f"{rel} missing Stage 7 storage marker: {token}")
if "ata::read_sector" in mixfs or "ata::write_sector" in mixfs or "ata::flush()" in mixfs:
    errors.append("MIXFS must use the block-device abstraction rather than the ATA driver directly")
if "pub fn initialize()" in mixfs and "format(" in mixfs[mixfs.find("pub fn initialize()"):] :
    errors.append("filesystem mount path must never automatically format unrecognized disks")
if "if confirmation != b\"--erase-dedicated-disk\"" not in mixfs:
    errors.append("MIXFS formatting must require the explicit destructive confirmation token")
if "state_store(MountState { mounted: true, read_only: true, superblock: sb });" not in mixfs:
    errors.append("MIXFS formatter must mark its in-memory state read-only before destructive writes")
if mixfs.find("if !block::is_safe_format_target(target_index)") < 0 or mixfs.find("if !block::is_safe_format_target(target_index)") > mixfs.find("block::write(0, &zero)"):
    errors.append("MIXFS formatter must reject protected/missing targets before its first disk write")
if "if state_copy().mounted { return Err(FsError::AlreadyMounted); }" not in mixfs:
    errors.append("MIXFS must not replace an active mount while formatting another device")
if "Some(index) != protected_index()" not in ata:
    errors.append("the first detected ATA disk must be protected from formatting")

# Stage 7 must not mutate the user-tested Stage 6 privilege/scheduler paths.
for line in (ROOT / "tools/stage6-process-baseline.sha256").read_text(encoding="utf-8").splitlines():
    expected, relative = line.split("  ", 1)
    candidate = ROOT / relative
    if not candidate.is_file():
        errors.append("Stage 6 process baseline file missing: " + relative)
    elif hashlib.sha256(candidate.read_bytes()).hexdigest() != expected:
        errors.append("Previously VM-tested Stage 6 process/interrupt source changed: " + relative)

if errors:
    print("MixedOS source validation FAILED:")
    for error in errors:
        print(" - " + error)
    sys.exit(1)

print(f"MixedOS source validation passed ({len(REQUIRED)} required files checked).")
print("Verified: Stage 2 input regressions, Stage 3 frame ownership, Stage 4 active-root paging, Stage 5 heap baseline, Stage 6 process baseline, and Stage 7 block/MIXFS structure.")
print("This is a source-structure check only; it does not compile, link, or boot the kernel.")
