#!/usr/bin/env python3
"""Source-level contract tests for MixedOS Kernel Halt (MKH)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
mkh = (ROOT / "kernel/src/mkh.rs").read_text(encoding="utf-8")
gdt = (ROOT / "kernel/src/arch/x86_64/gdt.rs").read_text(encoding="utf-8")
interrupts = (ROOT / "kernel/src/interrupts/mod.rs").read_text(encoding="utf-8")
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
framebuffer = (ROOT / "kernel/src/console/framebuffer.rs").read_text(encoding="utf-8")

# Early exception gates are loaded before memory, storage, and the boot checks.
assert main.index("interrupts::install_exception_handlers()") < main.index("if !boot::limine::base_revision_supported()")
assert "fn panic(info: &PanicInfo<'_>) -> !" in main
assert "mkh::rust_panic(info)" in main
print("early exception gate installation: passed")

# Dedicated TSS IST stacks protect the critical exceptions from a damaged RSP.
for name in ("DOUBLE_FAULT_STACK", "NMI_STACK", "MACHINE_CHECK_STACK"):
    assert name in gdt
assert "ptr::addr_of_mut!((*tss_pointer).ist)" in gdt
assert "vector { 8 => 1, 2 => 2, 18 => 3" in interrupts
print("double-fault IST: passed")

# Fatal reporting is bounded, register-aware, and does not write to disk.
for token in ("pub fn rust_panic", "pub fn cpu_exception", "pub fn fatal_message",
              "struct FixedText", "frame.r15", "frame.r14", "frame.r13", "frame.r12",
              "frame.r11", "frame.r10", "frame.r9", "frame.r8", "frame.rax",
              "frame.rbx", "frame.rcx", "frame.rdx", "frame.rsi", "frame.rdi",
              "frame.rbp", "frame.instruction_pointer", "frame.error_code",
              "No filesystem or disk writes were attempted"):
    assert token in mkh, f"missing MKH behavior: {token}"
assert "crate::mkh::cpu_exception" in interrupts
assert "crate::mkh::fatal_message" in interrupts
print("register dump coverage: passed")

# The framebuffer renderer avoids the mutable shell terminal and can wrap details.
for token in ("pub fn render_mkh_screen", "CRASH CODE:", "fn draw_wrapped_text", "fn text_hex64"):
    assert token in framebuffer
assert "screen::render_mkh_screen" in mkh
assert "HALTING.swap(true" in mkh
# Fatal handling must not allocate or risk writing to a possibly failing disk.
for forbidden in ("crate::memory::heap", "crate::storage", "crate::process", "crate::input"):
    assert forbidden not in mkh, f"fatal MKH path must not depend on {forbidden}"
assert "AtomicU64" in mkh and "Ordering::Acquire" in mkh
assert "#[repr(align(16))]" in gdt and "EXCEPTION_STACK_BYTES: usize = 16 * 1024" in gdt
print("MKH crash screen, recursion guard, and emergency-path isolation: passed")
