from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
facade = (ROOT / "kernel/src/arch/mod.rs").read_text(encoding="utf-8")
match = re.search(r"pub\s+use\s+(?:self::)?x86_64::\{([^}]+)\}", facade)
assert match, "public x86_64 facade re-export list is missing"
for spelling in ("pub use x86_64::{inb, outb};", "pub use self::x86_64::{inb, outb};"):
    assert re.search(r"pub\s+use\s+(?:self::)?x86_64::\{([^}]+)\}", spelling), spelling
exports = {item.strip().split(" as ")[0].strip() for item in match.group(1).split(",") if item.strip()}
required = {"disable_interrupts", "enable_interrupts", "halt_forever", "inb", "inl", "initialize_fpu", "outb", "outl", "wait_for_interrupt"}
assert required <= exports, f"missing public exports: {sorted(required - exports)}"
print("Architecture facade regression test passed.")
