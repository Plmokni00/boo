# MixedOS — clean-room rebuild

MixedOS is an independent x86_64 operating-system project. It is **not** a Linux distribution: its kernel is freestanding Rust and does not use the Linux kernel. Limine is currently used as a third-party firmware bootloader only.

This repository is a clean-room replacement for the previous `MixedOS.zip`. None of that archive's source files, bundled compilers, generated output, ISO images, or nested project copies are included. The previous archive was used only to identify the project name and goals.

## Current milestone: Stage 7 storage plus Stage 8.0 hardware/input foundations (Windows build succeeds; user reports boot + 11 PCI devices; warning/wheel-fix rebuild pending)

Stages 1–6 were built and observed in the user's VirtualBox environment. In particular, the Stage 6 Fix 5 screenshot confirms two ring-3 demonstration processes exited, four syscalls were reported, five context switches occurred, no processes faulted, resources were reclaimed, and the original kernel shell prompt returned. Stage 7 adds a real persistent-disk path on legacy IDE ATA PIO and a native MIXFS v1 filesystem. The current source also adds PS/2 wheel support and read-only PCI discovery as early Stage 8 groundwork. The exact Windows Rust build and VirtualBox VDI/device tests are still pending.

Implemented in source:

- A freestanding Rust x86_64 kernel loaded through Limine.
- Early COM1 diagnostics and non-blocking COM1 input.
- A direct RGB framebuffer console for supported 24-bit and 32-bit modes, with a fixed 256-line scrollback ring, a visible mouse-draggable scrollbar, and a bounded 16-command in-session history recalled with Up/Down.
- Limine memory-map iteration and higher-half direct-map request handling.
- A 4 KiB physical frame allocator using managed/allocated bitmaps. Only Limine type-0 usable RAM is considered; non-usable ranges and the first MiB remain reserved.
- A 64 GiB physical-address tracking ceiling, checked region arithmetic, checked HHDM pointer conversion, and a zeroed-frame helper.
- Invalid/double-free detection plus `mem`, `frames`, and `memtest` diagnostics. `memtest` writes and verifies every 64-bit word in eight owned frames, clears them, and returns them.
- A conservative four-level x86-64 page-table manager that preserves Limine's active CR3 root, inspects existing huge pages, maps/unmaps allocator-owned 4 KiB frames, enforces parent permission constraints, tracks/reclaims only MixedOS-owned table pages, and invalidates local TLB entries. The user has built Stage 4 on Windows and supplied a VirtualBox screenshot confirming a two-page `vmtest` passed.
- An explicit bounded kernel heap (not a Rust global allocator) backed by Stage 3 frames and Stage 4 mappings, with lazy initialization, size/alignment allocation, free-list splitting/coalescing, invalid/double-free checks, on-demand growth, stats, and `heap`/`heaptest` commands. The user supplied a VirtualBox screenshot showing seven aligned allocations written, verified, freed, and coalesced, with zero active allocations and consistent 40 KiB byte accounting.
- A Stage 6 ring-3 process foundation: a dedicated GDT and 64-bit TSS, a DPL3 `int 0x80` syscall gate, two cloned CR3 roots with a private user page-table subtree in the same reserved PML4 slot in each root, read/execute code pages, writable/NX user stacks, per-process kernel interrupt stacks, and a simple round-robin scheduler that switches on syscall yield and PIT timer preemption. `proctest` runs two built-in integer-only user tasks through report/yield/exit syscalls; `procs` reports scheduler counters. Stage 6 Fix 5 uses a one-shot common-ISR handoff to bypass the final synthetic IRETQ and restore the original kernel CR3/shell stack in a leaf assembly stub. The user supplied a successful Windows build log and a VirtualBox screenshot confirming two clean process exits, four syscalls, five context switches, and a return to the kernel prompt.
- CPU physical-address-width/NX detection, verified EFER.NXE enablement where supported, and CR0.WP enforcement.
- `paging` and `vmtest` diagnostics. `vmtest` uses an unused PML4 slot, maps two test frames with distinct user/supervisor permissions, performs an actual supervisor virtual read/write and checks both translations, then unmaps and reclaims the temporary tables.
- A 256-entry IDT with stubs for CPU exception vectors 0–31 and legacy PIC IRQs 0 and 1.
- CPU exception reporting to COM1, including the faulting instruction pointer and page-fault address.
- Legacy 8259 PIC remapping and a 100 Hz 8254 PIT tick counter. This is not an APIC or high-resolution timer implementation.
- A unified kernel input event queue for PS/2 keyboard, PS/2 mouse, and COM1 serial input.
- A shared i8042 controller poller that demultiplexes primary keyboard and auxiliary mouse bytes, a US-layout keyboard decoder, and a PS/2 mouse decoder that negotiates IntelliMouse wheel protocol ID 3 with a safe three-byte fallback.
- Read-only conventional PCI configuration-space discovery through mechanism #1, exposed by the `pci` shell command. It reports vendor/device IDs and class codes, caps output at 32 devices, and does not enable bus mastering, map BARs, or load drivers. The user reports a successful boot and 11 devices found/listed by the scanner; driver functionality is not implied by enumeration.
- A small **ring-0 kernel bring-up console** with a compact everyday `help` list and a separate `diagnostics` command for memory, paging, heap, process, PCI, storage, input, and self-test tools. File commands include `ls`, `mkdir`, `write`, `overwrite`, `append`, `rename`, `cat`, `rm`, and `rmdir`. The destructive `format ataN --erase-dedicated-disk` command is deliberately kept out of everyday help.
- A freestanding C runtime with a versioned ABI. The user's Stage 1 build confirms the earlier build pipeline compiled and linked the baseline.
- A Windows-native build entry point (`Build.bat`) that does not use WSL or Docker.

The command loop remains a kernel bring-up console, not the intended everyday user interface. `help` shows only normal console and file operations; `diagnostics` exposes developer/hardware tests separately. Its framebuffer output can be browsed with the mouse-drag scrollbar, and the shell keeps a small RAM-only command history for the current boot; neither facility makes it a user-mode shell, POSIX shell, general process environment, or desktop. Stage 6 adds only the initial CPL3 process/scheduler demonstration described below. Stage 7 adds kernel-side storage commands, not user-mode file descriptor syscalls. The input stack currently supports i8042-compatible PS/2 keyboard and standard three-byte PS/2 mice, with optional four-byte IntelliMouse wheel protocol ID 3, plus COM1 serial input. USB HID drivers (including USB tablet/mouse and USB keyboard), extra PS/2 mouse buttons, international layouts, and configurable key repeat are not implemented. IntelliMouse wheel packets are source-implemented; this update normalizes the direction after the user reported reversed scrolling and needs a fresh build plus physical-device check. The kernel actively polls in a non-sleeping bring-up loop; PIT IRQ0 remains enabled while PS/2 IRQ delivery is disabled. This temporary busy loop can use a full CPU core until a scheduler-aware idle task exists.

**Stage 4 deliberately does not replace CR3 or switch address spaces.** It only adds checked 4 KiB mappings into the active Limine tree, refuses to widen existing parent permissions, and reclaims only page-table frames that MixedOS allocated. The user has successfully built and VM-tested Stage 4, including a screenshot-confirmed two-page virtual access/translation/unmap test. This is still a uniprocessor bring-up implementation.

**Stage 5 adds an explicit kernel heap**, backed by Stage 3 frames and Stage 4 virtual mappings. It is not installed as Rust's global allocator. The user's VirtualBox screenshots confirmed seven aligned allocate/write/verify/free/coalesce operations, zero live allocations afterward, one coalesced free block, consistent 40 KiB accounting, and zero free errors.

Stage 6 limitations: no general executable loader, ELF parser, userspace runtime, user-pointer syscall ABI, wait/signal API, multithreading, SMP scheduling, APIC timer, per-process FPU/AVX state, or kernel-stack guard pages. The built-in Stage 6 test tasks are integer-only and run under the minimal report/yield/exit syscall ABI. This is not yet a general-purpose process environment.

Not implemented: Rust global allocator integration, PCI driver framework and BAR/resource management, AHCI/NVMe/USB storage, a journaled or production-ready filesystem, per-user permission enforcement, USB HID, TCP/IP, Wi-Fi, audio, a desktop/window manager, Java VM, Lua runtime, SQLite integration, GPU acceleration, Firefox, Windows API compatibility, installer, or recovery/update services. No menu, icon, service status, or application shortcut is supplied to imply that these features exist.

## Stage 7 storage and filesystem

The first persistent-storage stack is layered as legacy IDE ATA PIO → block-device
contract → MIXFS v1 → path-based VFS. It supports basic file/directory creation,
listing, reading, explicit replacement, bounded append, same-directory rename,
delete, metadata checks, and a persistent round-trip self-test. `write` refuses
an existing filename; use `overwrite` to replace it deliberately. The whole-disk formatter requires an explicit `ataN`
target, refuses to format the first detected ATA disk, and rejects targets
larger than 512 MiB for this bring-up stage. Use only a new, disposable VirtualBox IDE
VDI as the named data target. It does not yet support partitions, AHCI, NVMe,
USB storage, or journaling/full crash recovery. Mount never formats an
unrecognized disk. See [docs/STAGE7.md](docs/STAGE7.md) for the exact safe VM
setup and command sequence.

A future custom MixedOS Windows-compatibility layer (Wine-like in purpose, but
implemented specifically for MixedOS) is planned to sit above user-mode
processes and the VFS. Its planned PE loader, path translation, Win32 API
shims, DLL loading, and application test suite are described in
[docs/WINDOWS-COMPATIBILITY.md](docs/WINDOWS-COMPATIBILITY.md); none of that
compatibility implementation exists yet.

## Build on Windows

1. Extract the repository to a writable folder.
2. Run `Build.bat` normally from File Explorer or a terminal.
3. The script checks for Rust stable, LLVM/Clang, and xorriso. Where possible it uses WinGet to install the official Rustup and LLVM packages, plus MSYS2 for xorriso.
4. Limine's binary release is downloaded to `build/deps` and checked against a pinned SHA-256 before extraction.
5. The build compiles the freestanding C runtime, builds the Rust kernel for `x86_64-unknown-none`, stages an ISO root, writes a BIOS/UEFI hybrid ISO, then runs Limine's BIOS installation step.

Output:

- `build/artifacts/MixedOS-x86_64.iso`
- `build/artifacts/MixedOS-x86_64.iso.sha256`
- `target/x86_64-unknown-none/release/mixedos-kernel` (kernel ELF)
- `build/logs/build-YYYYMMDD-HHMMSS.log` (build transcript)

Useful commands:

```powershell
.\Build.bat
.\Build.bat -KernelOnly
.\Build.bat -Clean
.\Build.bat -NoInstall
```

`-KernelOnly` skips ISO authoring and builds the kernel only. `-Clean` removes generated `build` and Cargo `target` directories. `-NoInstall` makes missing host dependencies a hard error instead of trying to install them; a full ISO build still downloads the pinned Limine archive if it is not cached.

No WSL or Docker is used. MSYS2 is only a Windows-hosted way to obtain the xorriso ISO authoring utility; it is not an OS runtime and is not used to compile the kernel.

## Stage 2 input regression test

Primary acceptance is a real x86-64 computer with BIOS or UEFI firmware, a compatible legacy i8042 keyboard/mouse path, and a serial console where available. Boot from USB or optical media and test keyboard input, mouse movement/buttons, wheel direction, console scrolling, and reboot. Type `input` under `diagnostics` to inspect readiness and raw-byte counters. Test `help`, `diagnostics`, `clear`, Shift, Caps Lock, Tab, Enter, and Backspace. A modern machine that exposes only USB HID input may not provide a usable keyboard/mouse yet; native USB HID support is a planned driver, not a VM requirement. VirtualBox is an optional repeatable regression target, not the definition of supported hardware.

If the framebuffer is unavailable, the kernel should still provide diagnostics and command input through COM1. If a real machine hangs, capture complete serial output where possible and record its firmware mode, CPU, RAM, motherboard/chipset, graphics adapter, and input-device connection type.

## Stage 3 physical memory and Stage 4 virtual memory tests

After rebuilding and booting this release, run `mem`, `frames`, `memtest`, and `paging`. Confirm the Stage 3 allocator test still returns all eight pages. Then run `vmtest` on a test installation after confirming the target boot path and memory map; it performs real virtual reads and writes through newly installed page-table mappings. VirtualBox can be used as an additional repeatable check, but is not the only accepted environment. After it passes, run `paging` and `frames` again; MixedOS-owned table count, allocated frames, and free frames must return to their pre-test values, and free errors must remain unchanged. Repeat `vmtest` several times, then confirm keyboard and mouse input still work. Stage 5 adds `heap` and `heaptest`; use a machine or boot medium with no valuable data attached for its first run because heap bugs can fault in kernel mode. The explicit heap test allocates different sizes/alignment, checks written data, frees in a fragmented order, and verifies usage/free-byte accounting. These steps validate the Stage 3–5 memory path; Stage 6 has a separate, higher-risk user-mode test sequence.

A VM boot does not prove physical hardware support. The timer is currently a legacy PIT/PIC implementation. This input stack supports legacy PS/2 keyboard and three-byte mouse devices plus COM1; USB HID keyboard, mouse, and tablet support is not implemented.

## Engineering rules

- Do not mark a subsystem complete based on a type, icon, interface, or build-only placeholder.
- Preserve the distinction between source implemented, compiled, emulator tested, and physical-hardware tested.
- Keep user applications out of the kernel as user-mode support is added.
- Keep kernel, native ABI, and future user-space APIs versioned and documented.
- Add tests with each subsystem and record the exact environment used to validate them.
- Introduce languages when they have executable responsibilities; do not add empty integration folders.

See [docs/STAGE7.md](docs/STAGE7.md), [docs/WINDOWS-COMPATIBILITY.md](docs/WINDOWS-COMPATIBILITY.md), [docs/STAGE6.md](docs/STAGE6.md), [docs/STAGE2.md](docs/STAGE2.md), [docs/STAGE3.md](docs/STAGE3.md), [docs/STAGE5.md](docs/STAGE5.md), [docs/PHYSICAL-MEMORY.md](docs/PHYSICAL-MEMORY.md), [docs/INPUT-SUBSYSTEM.md](docs/INPUT-SUBSYSTEM.md), [docs/STAGE4.md](docs/STAGE4.md), [docs/STATUS.md](docs/STATUS.md), [docs/ROADMAP.md](docs/ROADMAP.md), and [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

### Architecture facade regression
The build validator checks the public x86-64 architecture facade and accepts both
`pub use x86_64::{...}` and `pub use self::x86_64::{...}`. The canonical facade
exports the interrupt, halt, port-I/O, and FPU initialization helpers used by
kernel subsystems. Run `python tools/test_arch_facade.py` for the focused check.


## Stage 6 — Processes and user mode (built-in demo VM-tested)

Stage 6 adds a minimal GDT/TSS, two built-in integer-only ring-3 demonstration
processes, private user page-table roots, per-process kernel stacks, a
uniprocessor round-robin scheduler, a DPL3 `int 0x80` report/yield/exit ABI,
PIT preemption, user-fault retirement, and `proctest` / `procs` shell commands.
The user built Stage 6 Fix 5 and confirmed in VirtualBox that two processes
exited, four syscalls were reported, five context switches occurred, resources
were reclaimed, and the prompt returned. This is not yet a general ELF loader
or production process API. Per-process x87/SSE/AVX state, wait/signals, SMP, and
user-space libraries remain future work.
See `docs/STAGE6.md` for the design and verification procedure.
