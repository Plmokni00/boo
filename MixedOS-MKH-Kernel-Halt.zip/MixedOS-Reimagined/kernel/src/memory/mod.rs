pub mod boot_map;
pub mod physical;
pub mod paging;
pub mod heap;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct MemoryInitStatus {
    pub allocator_ready: bool,
    pub hhdm_ready: bool,
    pub paging_ready: bool,
}

/// Initialize the physical frame allocator and inspect the active page tables.
/// The heap is initialized lazily on first use so a heap-mapping defect cannot
/// prevent the already-working boot console and input subsystem from starting.
pub fn initialize() -> MemoryInitStatus {
    let allocator_ready = physical::initialize();
    let paging_ready = allocator_ready && paging::initialize();
    MemoryInitStatus {
        allocator_ready,
        hhdm_ready: physical::stats().hhdm_ready,
        paging_ready,
    }
}
