mod port;
mod gdt;

pub use port::{inb, inl, inw, outb, outl, outw};
pub use gdt::{initialize as initialize_gdt_tss, is_ready as gdt_tss_ready, kernel_interrupt_stack_top, set_kernel_stack, KERNEL_CODE_SELECTOR, KERNEL_DATA_SELECTOR, USER_CODE_SELECTOR, USER_DATA_SELECTOR};

#[inline]
pub fn disable_interrupts() {
    // The early boot path deliberately keeps interrupts disabled until an IDT exists.
    unsafe { core::arch::asm!("cli", options(nostack)); }
}

/// Enable the architectural x87/SSE state area used by the interrupt entry stubs.
/// x86_64 guarantees FXSAVE and SSE2; the kernel does not enable AVX yet.
pub fn initialize_fpu() {
    static DEFAULT_MXCSR: u32 = 0x1F80;
    unsafe {
        let mut cr0: u64;
        core::arch::asm!("mov {}, cr0", out(reg) cr0, options(nostack, preserves_flags));
        cr0 &= !((1 << 2) | (1 << 3)); // Clear EM and TS.
        cr0 |= 1 << 1; // Set MP.
        core::arch::asm!("mov cr0, {}", in(reg) cr0, options(nostack, preserves_flags));

        let mut cr4: u64;
        core::arch::asm!("mov {}, cr4", out(reg) cr4, options(nostack, preserves_flags));
        cr4 |= (1 << 9) | (1 << 10); // OSFXSR and OSXMMEXCPT.
        core::arch::asm!("mov cr4, {}", in(reg) cr4, options(nostack, preserves_flags));
        core::arch::asm!("fninit", options(nostack));
        core::arch::asm!("ldmxcsr [{}]", in(reg) &DEFAULT_MXCSR, options(readonly, nostack, preserves_flags));
    }
}

#[inline]
pub fn enable_interrupts() {
    unsafe { core::arch::asm!("sti", options(nostack)); }
}

#[allow(dead_code)] // Used by the future scheduler idle path once IRQ-driven sleep is enabled.
#[inline]
pub fn wait_for_interrupt() {
    unsafe { core::arch::asm!("hlt", options(nostack)); }
}

#[inline(never)]
pub fn halt_forever() -> ! {
    loop {
        unsafe { core::arch::asm!("hlt", options(nostack)); }
    }
}


/// Read the active page-table root physical address.
#[inline]
pub fn read_cr3() -> u64 {
    let value: u64;
    unsafe { core::arch::asm!("mov {}, cr3", out(reg) value, options(nomem, nostack, preserves_flags)); }
    value & 0x000F_FFFF_FFFF_F000
}

/// Switch to a previously validated CR3 root. The caller must ensure that the
/// current instruction, stack, IDT, GDT, TSS, and all kernel data are mapped
/// identically in both roots.
#[inline]
pub unsafe fn write_cr3(root_physical: u64) {
    unsafe { core::arch::asm!("mov cr3, {}", in(reg) root_physical, options(nostack, preserves_flags)); }
}
