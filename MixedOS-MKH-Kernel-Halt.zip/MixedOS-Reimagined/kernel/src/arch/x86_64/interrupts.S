
.section .text

.macro ISR_NOERR number
.global mixedos_isr_\number
.type mixedos_isr_\number, @function
mixedos_isr_\number:
    push 0
    push \number
    jmp mixedos_isr_common
.endm

.macro ISR_ERR number
.global mixedos_isr_\number
.type mixedos_isr_\number, @function
mixedos_isr_\number:
    push \number
    jmp mixedos_isr_common
.endm

ISR_NOERR 0
ISR_NOERR 1
ISR_NOERR 2
ISR_NOERR 3
ISR_NOERR 4
ISR_NOERR 5
ISR_NOERR 6
ISR_NOERR 7
ISR_ERR   8
ISR_NOERR 9
ISR_ERR   10
ISR_ERR   11
ISR_ERR   12
ISR_ERR   13
ISR_ERR   14
ISR_NOERR 15
ISR_NOERR 16
ISR_ERR   17
ISR_NOERR 18
ISR_NOERR 19
ISR_NOERR 20
ISR_ERR   21
ISR_NOERR 22
ISR_NOERR 23
ISR_NOERR 24
ISR_NOERR 25
ISR_NOERR 26
ISR_NOERR 27
ISR_NOERR 28
ISR_ERR   29
ISR_ERR   30
ISR_NOERR 31
ISR_NOERR 32
ISR_NOERR 33
ISR_NOERR 34
ISR_NOERR 35
ISR_NOERR 36
ISR_NOERR 37
ISR_NOERR 38
ISR_NOERR 39
ISR_NOERR 40
ISR_NOERR 41
ISR_NOERR 42
ISR_NOERR 43
ISR_NOERR 44
ISR_NOERR 45
ISR_NOERR 46
ISR_NOERR 47
ISR_NOERR 48
ISR_NOERR 49
ISR_NOERR 50
ISR_NOERR 51
ISR_NOERR 52
ISR_NOERR 53
ISR_NOERR 54
ISR_NOERR 55
ISR_NOERR 56
ISR_NOERR 57
ISR_NOERR 58
ISR_NOERR 59
ISR_NOERR 60
ISR_NOERR 61
ISR_NOERR 62
ISR_NOERR 63
ISR_NOERR 64
ISR_NOERR 65
ISR_NOERR 66
ISR_NOERR 67
ISR_NOERR 68
ISR_NOERR 69
ISR_NOERR 70
ISR_NOERR 71
ISR_NOERR 72
ISR_NOERR 73
ISR_NOERR 74
ISR_NOERR 75
ISR_NOERR 76
ISR_NOERR 77
ISR_NOERR 78
ISR_NOERR 79
ISR_NOERR 80
ISR_NOERR 81
ISR_NOERR 82
ISR_NOERR 83
ISR_NOERR 84
ISR_NOERR 85
ISR_NOERR 86
ISR_NOERR 87
ISR_NOERR 88
ISR_NOERR 89
ISR_NOERR 90
ISR_NOERR 91
ISR_NOERR 92
ISR_NOERR 93
ISR_NOERR 94
ISR_NOERR 95
ISR_NOERR 96
ISR_NOERR 97
ISR_NOERR 98
ISR_NOERR 99
ISR_NOERR 100
ISR_NOERR 101
ISR_NOERR 102
ISR_NOERR 103
ISR_NOERR 104
ISR_NOERR 105
ISR_NOERR 106
ISR_NOERR 107
ISR_NOERR 108
ISR_NOERR 109
ISR_NOERR 110
ISR_NOERR 111
ISR_NOERR 112
ISR_NOERR 113
ISR_NOERR 114
ISR_NOERR 115
ISR_NOERR 116
ISR_NOERR 117
ISR_NOERR 118
ISR_NOERR 119
ISR_NOERR 120
ISR_NOERR 121
ISR_NOERR 122
ISR_NOERR 123
ISR_NOERR 124
ISR_NOERR 125
ISR_NOERR 126
ISR_NOERR 127
ISR_NOERR 128
ISR_NOERR 129
ISR_NOERR 130
ISR_NOERR 131
ISR_NOERR 132
ISR_NOERR 133
ISR_NOERR 134
ISR_NOERR 135
ISR_NOERR 136
ISR_NOERR 137
ISR_NOERR 138
ISR_NOERR 139
ISR_NOERR 140
ISR_NOERR 141
ISR_NOERR 142
ISR_NOERR 143
ISR_NOERR 144
ISR_NOERR 145
ISR_NOERR 146
ISR_NOERR 147
ISR_NOERR 148
ISR_NOERR 149
ISR_NOERR 150
ISR_NOERR 151
ISR_NOERR 152
ISR_NOERR 153
ISR_NOERR 154
ISR_NOERR 155
ISR_NOERR 156
ISR_NOERR 157
ISR_NOERR 158
ISR_NOERR 159
ISR_NOERR 160
ISR_NOERR 161
ISR_NOERR 162
ISR_NOERR 163
ISR_NOERR 164
ISR_NOERR 165
ISR_NOERR 166
ISR_NOERR 167
ISR_NOERR 168
ISR_NOERR 169
ISR_NOERR 170
ISR_NOERR 171
ISR_NOERR 172
ISR_NOERR 173
ISR_NOERR 174
ISR_NOERR 175
ISR_NOERR 176
ISR_NOERR 177
ISR_NOERR 178
ISR_NOERR 179
ISR_NOERR 180
ISR_NOERR 181
ISR_NOERR 182
ISR_NOERR 183
ISR_NOERR 184
ISR_NOERR 185
ISR_NOERR 186
ISR_NOERR 187
ISR_NOERR 188
ISR_NOERR 189
ISR_NOERR 190
ISR_NOERR 191
ISR_NOERR 192
ISR_NOERR 193
ISR_NOERR 194
ISR_NOERR 195
ISR_NOERR 196
ISR_NOERR 197
ISR_NOERR 198
ISR_NOERR 199
ISR_NOERR 200
ISR_NOERR 201
ISR_NOERR 202
ISR_NOERR 203
ISR_NOERR 204
ISR_NOERR 205
ISR_NOERR 206
ISR_NOERR 207
ISR_NOERR 208
ISR_NOERR 209
ISR_NOERR 210
ISR_NOERR 211
ISR_NOERR 212
ISR_NOERR 213
ISR_NOERR 214
ISR_NOERR 215
ISR_NOERR 216
ISR_NOERR 217
ISR_NOERR 218
ISR_NOERR 219
ISR_NOERR 220
ISR_NOERR 221
ISR_NOERR 222
ISR_NOERR 223
ISR_NOERR 224
ISR_NOERR 225
ISR_NOERR 226
ISR_NOERR 227
ISR_NOERR 228
ISR_NOERR 229
ISR_NOERR 230
ISR_NOERR 231
ISR_NOERR 232
ISR_NOERR 233
ISR_NOERR 234
ISR_NOERR 235
ISR_NOERR 236
ISR_NOERR 237
ISR_NOERR 238
ISR_NOERR 239
ISR_NOERR 240
ISR_NOERR 241
ISR_NOERR 242
ISR_NOERR 243
ISR_NOERR 244
ISR_NOERR 245
ISR_NOERR 246
ISR_NOERR 247
ISR_NOERR 248
ISR_NOERR 249
ISR_NOERR 250
ISR_NOERR 251
ISR_NOERR 252
ISR_NOERR 253
ISR_NOERR 254
ISR_NOERR 255

.global mixedos_gdt_reload
.type mixedos_gdt_reload, @function
mixedos_gdt_reload:
    push 0x08
    lea rax, [rip + .Lmixedos_gdt_reloaded]
    push rax
    retfq
.Lmixedos_gdt_reloaded:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov ss, ax
    xor eax, eax
    mov fs, ax
    mov gs, ax
    ret

.global mixedos_enter_user
.type mixedos_enter_user, @function
mixedos_enter_user:
    // Preserve the SysV callee-saved registers so the kernel call can resume
    // after the final user task exits through mixedos_user_session_return.
    push rbx
    push rbp
    push r12
    push r13
    push r14
    push r15
    mov qword ptr [rip + mixedos_kernel_return_rsp], rsp

    // Install user data selectors before IRETQ changes CPL.
    mov ax, 0x1B
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax

    push 0x1B                // user SS
    push rsi                 // user RSP
    push 0x202               // reserved bit + IF
    push 0x23                // user CS
    push rdi                 // user RIP
    xor eax, eax
    xor ebx, ebx
    xor ecx, ecx
    xor edx, edx
    xor ebp, ebp
    xor esi, esi
    xor edi, edi
    xor r8d, r8d
    xor r9d, r9d
    xor r10d, r10d
    xor r11d, r11d
    xor r12d, r12d
    xor r13d, r13d
    xor r14d, r14d
    xor r15d, r15d
    iretq

.Lmixedos_return_to_kernel:
    cli
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov ss, ax                // explicitly restore the kernel stack selector
    mov fs, ax
    mov gs, ax
    // This label is reached by a direct branch from the common ISR after the
    // final user task exits. Do not IRETQ through a synthetic CPL0 frame and do
    // not call Rust here: first restore
    // the known kernel root, then restore the original shell call stack and
    // return normally to run_demo(), which performs checked resource cleanup.
    mov rax, qword ptr [rip + mixedos_kernel_return_cr3]
    test rax, rax
    jz .Lmixedos_bad_return_context
    mov cr3, rax
    mov rsp, qword ptr [rip + mixedos_kernel_return_rsp]
    pop r15
    pop r14
    pop r13
    pop r12
    pop rbp
    pop rbx
    ret
.Lmixedos_bad_return_context:
    cli
.Lmixedos_bad_return_halt:
    hlt
    jmp .Lmixedos_bad_return_halt

.type mixedos_isr_common, @function
mixedos_isr_common:
    cld
    push rax
    push rbx
    push rcx
    push rdx
    push rbp
    push rsi
    push rdi
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15

    mov rdi, rsp
    mov rbx, rsp
    and rsp, -16
    sub rsp, 512
    fxsave64 [rsp]
    call mixedos_interrupt_dispatch
    fxrstor64 [rsp]
    // The final user EXIT requests a direct return. Branch before restoring the
    // retired process interrupt frame or executing IRETQ; the leaf stub switches
    // to the saved kernel CR3/stack and returns normally to run_demo().
    cmp qword ptr [rip + mixedos_return_to_kernel], 0
    jne .Lmixedos_return_to_kernel
    mov rsp, rbx

    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rdi
    pop rsi
    pop rbp
    pop rdx
    pop rcx
    pop rbx
    pop rax
    add rsp, 16
    iretq

.section .rodata
.balign 8
.global mixedos_isr_table
.type mixedos_isr_table, @object
mixedos_isr_table:
    .quad mixedos_isr_0
    .quad mixedos_isr_1
    .quad mixedos_isr_2
    .quad mixedos_isr_3
    .quad mixedos_isr_4
    .quad mixedos_isr_5
    .quad mixedos_isr_6
    .quad mixedos_isr_7
    .quad mixedos_isr_8
    .quad mixedos_isr_9
    .quad mixedos_isr_10
    .quad mixedos_isr_11
    .quad mixedos_isr_12
    .quad mixedos_isr_13
    .quad mixedos_isr_14
    .quad mixedos_isr_15
    .quad mixedos_isr_16
    .quad mixedos_isr_17
    .quad mixedos_isr_18
    .quad mixedos_isr_19
    .quad mixedos_isr_20
    .quad mixedos_isr_21
    .quad mixedos_isr_22
    .quad mixedos_isr_23
    .quad mixedos_isr_24
    .quad mixedos_isr_25
    .quad mixedos_isr_26
    .quad mixedos_isr_27
    .quad mixedos_isr_28
    .quad mixedos_isr_29
    .quad mixedos_isr_30
    .quad mixedos_isr_31
    .quad mixedos_isr_32
    .quad mixedos_isr_33
    .quad mixedos_isr_34
    .quad mixedos_isr_35
    .quad mixedos_isr_36
    .quad mixedos_isr_37
    .quad mixedos_isr_38
    .quad mixedos_isr_39
    .quad mixedos_isr_40
    .quad mixedos_isr_41
    .quad mixedos_isr_42
    .quad mixedos_isr_43
    .quad mixedos_isr_44
    .quad mixedos_isr_45
    .quad mixedos_isr_46
    .quad mixedos_isr_47
    .quad mixedos_isr_48
    .quad mixedos_isr_49
    .quad mixedos_isr_50
    .quad mixedos_isr_51
    .quad mixedos_isr_52
    .quad mixedos_isr_53
    .quad mixedos_isr_54
    .quad mixedos_isr_55
    .quad mixedos_isr_56
    .quad mixedos_isr_57
    .quad mixedos_isr_58
    .quad mixedos_isr_59
    .quad mixedos_isr_60
    .quad mixedos_isr_61
    .quad mixedos_isr_62
    .quad mixedos_isr_63
    .quad mixedos_isr_64
    .quad mixedos_isr_65
    .quad mixedos_isr_66
    .quad mixedos_isr_67
    .quad mixedos_isr_68
    .quad mixedos_isr_69
    .quad mixedos_isr_70
    .quad mixedos_isr_71
    .quad mixedos_isr_72
    .quad mixedos_isr_73
    .quad mixedos_isr_74
    .quad mixedos_isr_75
    .quad mixedos_isr_76
    .quad mixedos_isr_77
    .quad mixedos_isr_78
    .quad mixedos_isr_79
    .quad mixedos_isr_80
    .quad mixedos_isr_81
    .quad mixedos_isr_82
    .quad mixedos_isr_83
    .quad mixedos_isr_84
    .quad mixedos_isr_85
    .quad mixedos_isr_86
    .quad mixedos_isr_87
    .quad mixedos_isr_88
    .quad mixedos_isr_89
    .quad mixedos_isr_90
    .quad mixedos_isr_91
    .quad mixedos_isr_92
    .quad mixedos_isr_93
    .quad mixedos_isr_94
    .quad mixedos_isr_95
    .quad mixedos_isr_96
    .quad mixedos_isr_97
    .quad mixedos_isr_98
    .quad mixedos_isr_99
    .quad mixedos_isr_100
    .quad mixedos_isr_101
    .quad mixedos_isr_102
    .quad mixedos_isr_103
    .quad mixedos_isr_104
    .quad mixedos_isr_105
    .quad mixedos_isr_106
    .quad mixedos_isr_107
    .quad mixedos_isr_108
    .quad mixedos_isr_109
    .quad mixedos_isr_110
    .quad mixedos_isr_111
    .quad mixedos_isr_112
    .quad mixedos_isr_113
    .quad mixedos_isr_114
    .quad mixedos_isr_115
    .quad mixedos_isr_116
    .quad mixedos_isr_117
    .quad mixedos_isr_118
    .quad mixedos_isr_119
    .quad mixedos_isr_120
    .quad mixedos_isr_121
    .quad mixedos_isr_122
    .quad mixedos_isr_123
    .quad mixedos_isr_124
    .quad mixedos_isr_125
    .quad mixedos_isr_126
    .quad mixedos_isr_127
    .quad mixedos_isr_128
    .quad mixedos_isr_129
    .quad mixedos_isr_130
    .quad mixedos_isr_131
    .quad mixedos_isr_132
    .quad mixedos_isr_133
    .quad mixedos_isr_134
    .quad mixedos_isr_135
    .quad mixedos_isr_136
    .quad mixedos_isr_137
    .quad mixedos_isr_138
    .quad mixedos_isr_139
    .quad mixedos_isr_140
    .quad mixedos_isr_141
    .quad mixedos_isr_142
    .quad mixedos_isr_143
    .quad mixedos_isr_144
    .quad mixedos_isr_145
    .quad mixedos_isr_146
    .quad mixedos_isr_147
    .quad mixedos_isr_148
    .quad mixedos_isr_149
    .quad mixedos_isr_150
    .quad mixedos_isr_151
    .quad mixedos_isr_152
    .quad mixedos_isr_153
    .quad mixedos_isr_154
    .quad mixedos_isr_155
    .quad mixedos_isr_156
    .quad mixedos_isr_157
    .quad mixedos_isr_158
    .quad mixedos_isr_159
    .quad mixedos_isr_160
    .quad mixedos_isr_161
    .quad mixedos_isr_162
    .quad mixedos_isr_163
    .quad mixedos_isr_164
    .quad mixedos_isr_165
    .quad mixedos_isr_166
    .quad mixedos_isr_167
    .quad mixedos_isr_168
    .quad mixedos_isr_169
    .quad mixedos_isr_170
    .quad mixedos_isr_171
    .quad mixedos_isr_172
    .quad mixedos_isr_173
    .quad mixedos_isr_174
    .quad mixedos_isr_175
    .quad mixedos_isr_176
    .quad mixedos_isr_177
    .quad mixedos_isr_178
    .quad mixedos_isr_179
    .quad mixedos_isr_180
    .quad mixedos_isr_181
    .quad mixedos_isr_182
    .quad mixedos_isr_183
    .quad mixedos_isr_184
    .quad mixedos_isr_185
    .quad mixedos_isr_186
    .quad mixedos_isr_187
    .quad mixedos_isr_188
    .quad mixedos_isr_189
    .quad mixedos_isr_190
    .quad mixedos_isr_191
    .quad mixedos_isr_192
    .quad mixedos_isr_193
    .quad mixedos_isr_194
    .quad mixedos_isr_195
    .quad mixedos_isr_196
    .quad mixedos_isr_197
    .quad mixedos_isr_198
    .quad mixedos_isr_199
    .quad mixedos_isr_200
    .quad mixedos_isr_201
    .quad mixedos_isr_202
    .quad mixedos_isr_203
    .quad mixedos_isr_204
    .quad mixedos_isr_205
    .quad mixedos_isr_206
    .quad mixedos_isr_207
    .quad mixedos_isr_208
    .quad mixedos_isr_209
    .quad mixedos_isr_210
    .quad mixedos_isr_211
    .quad mixedos_isr_212
    .quad mixedos_isr_213
    .quad mixedos_isr_214
    .quad mixedos_isr_215
    .quad mixedos_isr_216
    .quad mixedos_isr_217
    .quad mixedos_isr_218
    .quad mixedos_isr_219
    .quad mixedos_isr_220
    .quad mixedos_isr_221
    .quad mixedos_isr_222
    .quad mixedos_isr_223
    .quad mixedos_isr_224
    .quad mixedos_isr_225
    .quad mixedos_isr_226
    .quad mixedos_isr_227
    .quad mixedos_isr_228
    .quad mixedos_isr_229
    .quad mixedos_isr_230
    .quad mixedos_isr_231
    .quad mixedos_isr_232
    .quad mixedos_isr_233
    .quad mixedos_isr_234
    .quad mixedos_isr_235
    .quad mixedos_isr_236
    .quad mixedos_isr_237
    .quad mixedos_isr_238
    .quad mixedos_isr_239
    .quad mixedos_isr_240
    .quad mixedos_isr_241
    .quad mixedos_isr_242
    .quad mixedos_isr_243
    .quad mixedos_isr_244
    .quad mixedos_isr_245
    .quad mixedos_isr_246
    .quad mixedos_isr_247
    .quad mixedos_isr_248
    .quad mixedos_isr_249
    .quad mixedos_isr_250
    .quad mixedos_isr_251
    .quad mixedos_isr_252
    .quad mixedos_isr_253
    .quad mixedos_isr_254
    .quad mixedos_isr_255
.size mixedos_isr_table, .-mixedos_isr_table
.section .note.GNU-stack,"",@progbits
