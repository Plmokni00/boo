pub mod x86_64;

// Stable architecture facade used by kernel subsystems. Keep callers independent
// of the internal x86_64 module layout.
#[allow(unused_imports)] // Stable kernel architecture facade; some hooks are consumed by later stages.
pub use self::x86_64::{
    disable_interrupts,
    enable_interrupts,
    halt_forever,
    initialize_gdt_tss,
    gdt_tss_ready,
    kernel_interrupt_stack_top,
    inb,
    inl,
    inw,
    initialize_fpu,
    outb,
    outl,
    outw,
    wait_for_interrupt,
    read_cr3,
    set_kernel_stack,
    write_cr3,
    KERNEL_CODE_SELECTOR,
    KERNEL_DATA_SELECTOR,
    USER_CODE_SELECTOR,
    USER_DATA_SELECTOR,
};
