use crate::boot::limine::Framebuffer;
use crate::console::font5x7;
use crate::input::InputStats;

/// Draw the MKH fatal-error screen using only the bootloader framebuffer.
/// This path avoids the terminal history buffer, heap, filesystem, and input stack.
pub fn render_mkh_screen(
    framebuffer: Framebuffer,
    kind: &str,
    code: &str,
    detail: &str,
    registers: Option<(u64, u64, u64)>,
    fault_address: Option<u64>,
) -> bool {
    let Some(mut canvas) = Canvas::new(framebuffer) else { return false; };
    let width = canvas.width;
    let height = canvas.height;
    let scale = if width >= 900 { 2 } else { 1 };
    let background = rgb(10, 12, 22);
    let panel = rgb(20, 24, 39);
    let accent = rgb(226, 91, 121);
    let bright = rgb(246, 239, 246);
    let muted = rgb(170, 177, 199);
    let warning = rgb(255, 173, 120);

    canvas.fill(background);
    canvas.rect(0, 0, width, 7, accent);
    canvas.rect(0, 7, 12, height.saturating_sub(7), rgb(95, 46, 89));
    canvas.text(42, 35, "MIXEDOS KERNEL HALT", bright, scale);
    canvas.text(44, 35 + 12 * scale, "MKH / CRITICAL KERNEL FAILURE", accent, 1);
    canvas.rect(42, 68 + 12 * scale, width.saturating_sub(84), 1, rgb(65, 55, 78));

    let panel_y = 100 + 12 * scale;
    let panel_height = height.saturating_sub(panel_y + 54).min(360);
    canvas.rect(36, panel_y, width.saturating_sub(72), panel_height, panel);
    canvas.rect(36, panel_y, 5, panel_height, accent);
    canvas.text(58, panel_y + 18, "THE KERNEL STOPPED TO PROTECT SYSTEM STATE", bright, 1);
    canvas.text(58, panel_y + 38, "NO FURTHER KERNEL WORK WILL BE EXECUTED", muted, 1);
    canvas.text(58, panel_y + 70, "FAILURE TYPE:", muted, 1);
    canvas.text(150, panel_y + 70, kind, warning, 1);
    canvas.text(58, panel_y + 88, "CRASH CODE:", muted, 1);
    canvas.text(150, panel_y + 88, code, bright, 1);

    let mut info_y = panel_y + 112;
    if let Some((vector, error_code, instruction_pointer)) = registers {
        canvas.text(58, info_y, "CPU VECTOR:", muted, 1);
        canvas.text_dec(145, info_y, vector.min(u32::MAX as u64) as u32, 3, bright);
        info_y += 18;
        canvas.text(58, info_y, "ERROR CODE:", muted, 1);
        canvas.text_hex64(145, info_y, error_code, warning);
        info_y += 18;
        canvas.text(58, info_y, "INSTRUCTION:", muted, 1);
        canvas.text_hex64(145, info_y, instruction_pointer, bright);
        info_y += 18;
    }
    if let Some(address) = fault_address {
        canvas.text(58, info_y, "FAULT ADDRESS:", muted, 1);
        canvas.text_hex64(160, info_y, address, warning);
        info_y += 18;
    }

    if info_y + 48 < panel_y + panel_height {
        canvas.rect(58, info_y + 5, width.saturating_sub(116), 1, rgb(65, 55, 78));
        canvas.text(58, info_y + 17, "DETAIL:", muted, 1);
        draw_wrapped_text(&mut canvas, 58, info_y + 31, detail, bright, 1, width.saturating_sub(116), 3);
    }

    let footer_y = height.saturating_sub(36);
    canvas.text(42, footer_y, "DIAGNOSTICS: CHECK THE COM1 SERIAL LOG", muted, 1);
    canvas.text(width.saturating_sub(330), footer_y, "RESTART THE MACHINE TO CONTINUE", accent, 1);
    true
}

fn draw_wrapped_text(canvas: &mut Canvas, x: usize, y: usize, text: &str, color: u32, scale: usize, available_width: usize, max_lines: usize) {
    let max_chars = (available_width / (6 * scale)).max(1).min(100);
    let mut line = [0u8; 100];
    let mut length = 0usize;
    let mut row = 0usize;
    for byte in text.bytes() {
        if byte == b'\n' || length >= max_chars {
            if let Ok(value) = core::str::from_utf8(&line[..length]) {
                canvas.text(x, y + row * 12 * scale, value, color, scale);
            }
            row += 1;
            length = 0;
            if row >= max_lines { return; }
            if byte == b'\n' { continue; }
        }
        if byte.is_ascii_graphic() || byte == b' ' {
            line[length] = byte;
            length += 1;
        }
    }
    if row < max_lines {
        if let Ok(value) = core::str::from_utf8(&line[..length]) {
            canvas.text(x, y + row * 12 * scale, value, color, scale);
        }
    }
}

pub fn render_boot_screen(framebuffer: Framebuffer) -> bool {
    let Some(mut canvas) = Canvas::new(framebuffer) else {
        return false;
    };

    let width = framebuffer.width as usize;
    let height = framebuffer.height as usize;
    canvas.fill(rgb(12, 17, 29));

    canvas.rect(0, 0, width, 5, rgb(48, 116, 238));
    canvas.rect(42, 42, 5, 58, rgb(72, 190, 173));
    canvas.rect(55, 42, 5, 58, rgb(48, 116, 238));
    canvas.rect(68, 42, 5, 58, rgb(160, 116, 238));

    let scale = if width >= 1200 { 3 } else { 2 };
    canvas.text(94, 43, "MIXEDOS", rgb(242, 246, 255), scale);
    canvas.text(95, 82, "INDEPENDENT KERNEL", rgb(178, 192, 215), 1);
    canvas.rect(94, 112, width.saturating_sub(188).min(520), 1, rgb(58, 76, 104));
    canvas.text(94, 132, "LIMINE BOOT CONFIRMED", rgb(114, 215, 185), 1);
    canvas.text(94, 151, "FRAMEBUFFER ONLINE", rgb(178, 192, 215), 1);
    canvas.text(94, 170, "C ABI LINKED", rgb(178, 192, 215), 1);

    let footer_y = height.saturating_sub(35);
    canvas.text(42, footer_y, "STAGE 2 / X86_64 / INTERACTIVE CONSOLE", rgb(118, 135, 162), 1);
    true
}

const HISTORY_LINES: usize = 256;
const HISTORY_COLUMNS: usize = 256;
const CONTENT_TOP: usize = 96;
const CONSOLE_BACKGROUND: u32 = 0x000A0F1A;
const CONSOLE_FOREGROUND: u32 = 0x00D3DEF1;

#[derive(Clone, Copy)]
struct HistoryLine {
    bytes: [u8; HISTORY_COLUMNS],
    len: usize,
}

impl HistoryLine {
    const fn empty() -> Self { Self { bytes: [0; HISTORY_COLUMNS], len: 0 } }
}

struct Scrollback {
    lines: [HistoryLine; HISTORY_LINES],
    oldest: usize,
    count: usize,
    column: usize,
}

impl Scrollback {
    const fn new() -> Self {
        Self {
            lines: [HistoryLine::empty(); HISTORY_LINES],
            oldest: 0,
            count: 0,
            column: 0,
        }
    }

    fn reset(&mut self) {
        self.lines.fill(HistoryLine::empty());
        self.oldest = 0;
        self.count = 0;
        self.column = 0;
        self.push_line();
    }

    fn current_index(&self) -> usize {
        if self.count == 0 { self.oldest } else { (self.oldest + self.count - 1) % HISTORY_LINES }
    }

    fn push_line(&mut self) {
        let index = if self.count < HISTORY_LINES {
            let index = (self.oldest + self.count) % HISTORY_LINES;
            self.count += 1;
            index
        } else {
            self.oldest = (self.oldest + 1) % HISTORY_LINES;
            (self.oldest + self.count - 1) % HISTORY_LINES
        };
        self.lines[index] = HistoryLine::empty();
        self.column = 0;
    }

    fn append(&mut self, byte: u8) {
        let index = self.current_index();
        if self.column < HISTORY_COLUMNS {
            self.lines[index].bytes[self.column] = byte;
            self.column += 1;
            self.lines[index].len = self.lines[index].len.max(self.column);
        }
    }

    fn backspace(&mut self) {
        if self.column == 0 { return; }
        self.column -= 1;
        let index = self.current_index();
        self.lines[index].bytes[self.column] = 0;
        self.lines[index].len = self.column;
    }
}

struct ScrollbackCell(core::cell::UnsafeCell<Scrollback>);
unsafe impl Sync for ScrollbackCell {}
static SCROLLBACK: ScrollbackCell = ScrollbackCell(core::cell::UnsafeCell::new(Scrollback::new()));

pub struct Terminal {
    canvas: Canvas,
    cursor_x: usize,
    cursor_y: usize,
    scale: usize,
    line_height: usize,
    text_left: usize,
    text_right: usize,
    text_bottom: usize,
    scroll_offset: usize,
}

impl Terminal {
    pub fn new(framebuffer: Framebuffer) -> Option<Self> {
        let canvas = Canvas::new(framebuffer)?;
        if canvas.width < 240 || canvas.height < 160 {
            return None;
        }
        let scale = if canvas.width >= 1000 { 2 } else { 1 };
        let mut terminal = Self {
            canvas,
            cursor_x: 34,
            cursor_y: CONTENT_TOP,
            scale,
            line_height: 11 * scale,
            text_left: 34,
            text_right: 24,
            text_bottom: 22,
            scroll_offset: 0,
        };
        terminal.clear();
        Some(terminal)
    }

    fn history(&mut self) -> &mut Scrollback {
        // The terminal is single-owner and called only by the polling shell.
        // The fixed history lives in BSS so it does not consume the boot stack.
        unsafe { &mut *SCROLLBACK.0.get() }
    }

    fn visible_lines(&self) -> usize {
        self.canvas.height
            .saturating_sub(self.text_bottom + CONTENT_TOP)
            .checked_div(self.line_height.max(1))
            .unwrap_or(1)
            .max(1)
    }

    fn maximum_y(&self) -> usize { self.canvas.height.saturating_sub(self.text_bottom) }

    fn current_line_capacity(&self) -> usize {
        self.canvas.width
            .saturating_sub(self.text_left + self.text_right)
            .checked_div(6 * self.scale)
            .unwrap_or(1)
            .min(HISTORY_COLUMNS)
            .max(1)
    }

    pub fn clear(&mut self) {
        self.canvas.fill(CONSOLE_BACKGROUND);
        self.canvas.rect(0, 0, self.canvas.width, 4, rgb(72, 143, 255));
        self.canvas.text(34, 20, "MIXEDOS KERNEL CONSOLE", rgb(236, 242, 255), 2);
        self.canvas.text(34, 44, "STAGE 2 / INTERACTIVE KERNEL", rgb(110, 207, 187), 1);
        self.canvas.rect(34, 58, self.canvas.width.saturating_sub(68), 1, rgb(47, 64, 91));
        self.canvas.text(34, 65, "KBD RX", rgb(114, 215, 185), 1);
        self.canvas.text_hex(76, 65, 0, 8, CONSOLE_FOREGROUND);
        self.canvas.text(132, 65, "LAST", rgb(118, 135, 162), 1);
        self.canvas.text_hex(160, 65, 0, 2, CONSOLE_FOREGROUND);
        self.canvas.text(194, 65, "MOUSE RX", rgb(114, 215, 185), 1);
        self.canvas.text_hex(250, 65, 0, 8, CONSOLE_FOREGROUND);
        self.canvas.text(306, 65, "LAST", rgb(118, 135, 162), 1);
        self.canvas.text_hex(334, 65, 0, 2, CONSOLE_FOREGROUND);
        self.canvas.text(34, 79, "MOUSE X", rgb(118, 135, 162), 1);
        self.canvas.text(98, 79, "0000", CONSOLE_FOREGROUND, 1);
        self.canvas.text(136, 79, "Y", rgb(118, 135, 162), 1);
        self.canvas.text(148, 79, "0000", CONSOLE_FOREGROUND, 1);
        self.canvas.text(190, 79, "BUTTONS", rgb(118, 135, 162), 1);
        self.canvas.text(244, 79, "00", CONSOLE_FOREGROUND, 1);
        self.history().reset();
        self.scroll_offset = 0;
        self.cursor_x = self.text_left;
        self.cursor_y = CONTENT_TOP;
        self.draw_scrollbar();
    }

    pub fn set_input_status(&mut self, status: InputStats) {
        let foreground = CONSOLE_FOREGROUND;
        let background = CONSOLE_BACKGROUND;
        self.canvas.rect(72, 63, self.canvas.width.saturating_sub(96), 27, background);
        self.canvas.text(132, 65, "LAST", rgb(118, 135, 162), 1);
        self.canvas.text(194, 65, "MOUSE RX", rgb(114, 215, 185), 1);
        self.canvas.text(306, 65, "LAST", rgb(118, 135, 162), 1);
        self.canvas.text(34, 79, "MOUSE X", rgb(118, 135, 162), 1);
        self.canvas.text(136, 79, "Y", rgb(118, 135, 162), 1);
        self.canvas.text(190, 79, "BUTTONS", rgb(118, 135, 162), 1);
        self.canvas.text_hex(76, 65, status.keyboard_bytes.min(u32::MAX as usize) as u32, 8, foreground);
        self.canvas.text_hex(160, 65, status.last_keyboard_byte as u32, 2, foreground);
        self.canvas.text_hex(250, 65, status.mouse_bytes.min(u32::MAX as usize) as u32, 8, foreground);
        self.canvas.text_hex(334, 65, status.last_mouse_byte as u32, 2, foreground);
        self.canvas.text_dec(98, 79, status.mouse_x.max(0) as u32, 4, foreground);
        self.canvas.text_dec(148, 79, status.mouse_y.max(0) as u32, 4, foreground);
        self.canvas.text_hex(244, 79, status.mouse_buttons as u32, 2, foreground);
        if self.canvas.width >= 430 {
            self.canvas.text(280, 79, if status.keyboard_ready { "KBD OK" } else { "KBD --" }, if status.keyboard_ready { rgb(114,215,185) } else { rgb(238,171,96) }, 1);
            self.canvas.text(330, 79, if status.mouse_ready { "MOUSE OK" } else { "MOUSE --" }, if status.mouse_ready { rgb(114,215,185) } else { rgb(238,171,96) }, 1);
        }
        self.draw_scrollbar();
    }

    /// Scroll by dragging/clicking the visible scrollbar with the left mouse button.
    /// Mouse coordinates are normalized by the PS/2 driver to the 0..4095 range.
    pub fn scrollbar_pointer(&mut self, mouse_x: i32, mouse_y: i32, left_down: bool) -> bool {
        let x = (mouse_x.max(0) as usize).saturating_mul(self.canvas.width) / 4096;
        let y = (mouse_y.max(0) as usize).saturating_mul(self.canvas.height) / 4096;
        let track_x = self.canvas.width.saturating_sub(18);
        let track_bottom = self.maximum_y();
        if left_down && x >= track_x && y >= CONTENT_TOP && y < track_bottom {
            self.scrollbar_drag_to(mouse_y);
            return true;
        }
        false
    }

    pub fn scrollbar_drag_to(&mut self, mouse_y: i32) {
        let y = (mouse_y.max(0) as usize).saturating_mul(self.canvas.height) / 4096;
        let visible = self.visible_lines();
        let max_offset = self.history().count.saturating_sub(visible);
        let track_height = self.maximum_y().saturating_sub(CONTENT_TOP).max(1);
        let relative = y.saturating_sub(CONTENT_TOP).min(track_height);
        self.scroll_offset = max_offset.saturating_mul(track_height.saturating_sub(relative)) / track_height;
        self.render_history();
    }

    pub fn write(&mut self, text: &str) {
        for byte in text.bytes() {
            match byte {
                b'\r' => {}
                b'\n' => self.newline(),
                8 | 127 => self.backspace(),
                0x20..=0x7e => self.put_byte(byte),
                _ => {}
            }
        }
    }

    pub fn write_line(&mut self, text: &str) {
        self.write(text);
        self.newline();
    }

    pub fn scroll_up(&mut self, lines: usize) {
        let visible = self.visible_lines();
        let max_offset = {
            let history = self.history();
            history.count.saturating_sub(visible)
        };
        self.scroll_offset = self.scroll_offset.saturating_add(lines.max(1)).min(max_offset);
        self.render_history();
    }

    pub fn scroll_down(&mut self, lines: usize) {
        self.scroll_offset = self.scroll_offset.saturating_sub(lines.max(1));
        self.render_history();
    }

    pub fn scroll_to_top(&mut self) {
        let visible = self.visible_lines();
        let max_offset = {
            let history = self.history();
            history.count.saturating_sub(visible)
        };
        self.scroll_offset = max_offset;
        self.render_history();
    }

    pub fn scroll_to_bottom(&mut self) {
        self.scroll_offset = 0;
        self.render_history();
    }

    fn render_history(&mut self) {
        let visible = self.visible_lines();
        let offset = self.scroll_offset;
        let (count, oldest, current_column) = {
            let history = self.history();
            (history.count, history.oldest, history.column)
        };
        let end = count.saturating_sub(offset);
        let start = end.saturating_sub(visible);
        let maximum = self.maximum_y();
        self.canvas.rect(0, CONTENT_TOP, self.canvas.width, maximum.saturating_sub(CONTENT_TOP), CONSOLE_BACKGROUND);
        for row in 0..end.saturating_sub(start) {
            let (bytes, len) = {
                let history = self.history();
                let line = history.lines[(oldest + start + row) % HISTORY_LINES];
                (line.bytes, line.len)
            };
            if len != 0 {
                if let Ok(text) = core::str::from_utf8(&bytes[..len]) {
                    self.canvas.text(self.text_left, CONTENT_TOP + row * self.line_height, text, CONSOLE_FOREGROUND, self.scale);
                }
            }
        }
        if offset == 0 {
            let current_row = end.saturating_sub(start + 1);
            self.cursor_y = CONTENT_TOP + current_row * self.line_height;
            self.cursor_x = self.text_left + current_column * 6 * self.scale;
        }
        self.draw_scrollbar();
    }

    fn draw_scrollbar(&mut self) {
        let x = self.canvas.width.saturating_sub(14);
        let top = CONTENT_TOP;
        let bottom = self.maximum_y();
        let track_height = bottom.saturating_sub(top).max(1);
        self.canvas.rect(x, top, 5, track_height, rgb(30, 42, 61));
        let (count, visible) = (self.history().count, self.visible_lines());
        let max_offset = count.saturating_sub(visible);
        let thumb_height = if count == 0 { track_height } else {
            (track_height.saturating_mul(visible) / count).max(18).min(track_height)
        };
        let travel = track_height.saturating_sub(thumb_height);
        let thumb_top = top + if max_offset == 0 { 0 } else { travel.saturating_mul(max_offset.saturating_sub(self.scroll_offset)) / max_offset };
        self.canvas.rect(x.saturating_sub(2), thumb_top, 9, thumb_height, rgb(82, 143, 232));
    }

    fn put_byte(&mut self, byte: u8) {
        let capacity = self.current_line_capacity();
        let column = self.history().column;
        if column >= capacity {
            self.newline();
        }
        self.history().append(byte);
        if self.scroll_offset == 0 {
            self.canvas.text(
                self.cursor_x,
                self.cursor_y,
                core::str::from_utf8(&[byte]).unwrap_or("?"),
                CONSOLE_FOREGROUND,
                self.scale,
            );
        }
        self.cursor_x += 6 * self.scale;
    }

    fn backspace(&mut self) {
        let column = self.history().column;
        if column == 0 { return; }
        self.history().backspace();
        self.cursor_x = self.cursor_x.saturating_sub(6 * self.scale);
        if self.scroll_offset == 0 {
            self.canvas.rect(self.cursor_x, self.cursor_y, 6 * self.scale, 8 * self.scale, CONSOLE_BACKGROUND);
        }
    }

    fn newline(&mut self) {
        self.history().push_line();
        if self.scroll_offset != 0 {
            let visible = self.visible_lines();
            let max_offset = {
                let history = self.history();
                history.count.saturating_sub(visible)
            };
            self.scroll_offset = self.scroll_offset.saturating_add(1).min(max_offset);
            self.render_history();
            return;
        }

        self.cursor_x = self.text_left;
        self.cursor_y += self.line_height;
        let maximum = self.maximum_y();
        if self.cursor_y + 8 * self.scale > maximum {
            let source_y = CONTENT_TOP + self.line_height;
            let copy_rows = maximum.saturating_sub(source_y);
            if copy_rows > 0 {
                let bytes = copy_rows * self.canvas.pitch;
                let destination = unsafe { self.canvas.address.add(CONTENT_TOP * self.canvas.pitch) };
                let source = unsafe { self.canvas.address.add(source_y * self.canvas.pitch) };
                unsafe { core::ptr::copy(source, destination, bytes); }
            }
            self.canvas.rect(0, maximum.saturating_sub(self.line_height), self.canvas.width, self.line_height, CONSOLE_BACKGROUND);
            self.cursor_y = maximum.saturating_sub(8 * self.scale);
        }
        self.draw_scrollbar();
    }
}

struct Canvas {
    address: *mut u8,
    width: usize,
    height: usize,
    pitch: usize,
    bytes_per_pixel: usize,
    red_size: u8,
    red_shift: u8,
    green_size: u8,
    green_shift: u8,
    blue_size: u8,
    blue_shift: u8,
}

impl Canvas {
    fn new(fb: Framebuffer) -> Option<Self> {
        if fb.address.is_null() || fb.memory_model != 1 || (fb.bpp != 24 && fb.bpp != 32) {
            return None;
        }
        let width = usize::try_from(fb.width).ok()?;
        let height = usize::try_from(fb.height).ok()?;
        let pitch = usize::try_from(fb.pitch).ok()?;
        let bytes_per_pixel = usize::from(fb.bpp / 8);
        if width == 0 || height == 0 || pitch < width.checked_mul(bytes_per_pixel)? {
            return None;
        }
        // Prove that every later row/pixel offset fits in the target address space.
        pitch.checked_mul(height)?;
        Some(Self {
            address: fb.address,
            width,
            height,
            pitch,
            bytes_per_pixel,
            red_size: fb.red_mask_size,
            red_shift: fb.red_mask_shift,
            green_size: fb.green_mask_size,
            green_shift: fb.green_mask_shift,
            blue_size: fb.blue_mask_size,
            blue_shift: fb.blue_mask_shift,
        })
    }

    fn fill(&mut self, color: u32) {
        self.rect(0, 0, self.width, self.height, color);
    }

    fn rect(&mut self, x: usize, y: usize, width: usize, height: usize, color: u32) {
        let x_end = x.saturating_add(width).min(self.width);
        let y_end = y.saturating_add(height).min(self.height);
        for py in y.min(self.height)..y_end {
            for px in x.min(self.width)..x_end {
                self.pixel(px, py, color);
            }
        }
    }

    fn text(&mut self, x: usize, y: usize, text: &str, color: u32, scale: usize) {
        if scale == 0 { return; }
        let mut cursor = x;
        for character in text.bytes() {
            let glyph = font5x7::glyph(character.to_ascii_uppercase());
            for (row, bits) in glyph.iter().enumerate() {
                for column in 0..5 {
                    if *bits & (1 << (4 - column)) != 0 {
                        self.rect(
                            cursor + column * scale,
                            y + row * scale,
                            scale,
                            scale,
                            color,
                        );
                    }
                }
            }
            cursor = cursor.saturating_add(6 * scale);
            if cursor >= self.width { break; }
        }
    }

    fn text_dec(&mut self, x: usize, y: usize, value: u32, digits: usize, color: u32) {
        let digits = digits.clamp(1, 10);
        let mut bytes = [b'0'; 10];
        let mut remaining = value;
        for index in (0..digits).rev() {
            bytes[index] = b'0' + (remaining % 10) as u8;
            remaining /= 10;
        }
        let text = core::str::from_utf8(&bytes[..digits]).unwrap_or("0");
        self.text(x, y, text, color, 1);
    }

    fn text_hex(&mut self, x: usize, y: usize, value: u32, digits: usize, color: u32) {
        const HEX: &[u8; 16] = b"0123456789ABCDEF";
        let digits = digits.min(8);
        let mut bytes = [b'0'; 8];
        for index in 0..digits {
            let shift = (digits - index - 1) * 4;
            bytes[index] = HEX[((value >> shift) & 0x0F) as usize];
        }
        let text = core::str::from_utf8(&bytes[..digits]).unwrap_or("00000000");
        self.text(x, y, text, color, 1);
    }

    fn text_hex64(&mut self, x: usize, y: usize, value: u64, color: u32) {
        const HEX: &[u8; 16] = b"0123456789ABCDEF";
        let mut bytes = [b'0'; 18];
        bytes[1] = b'x';
        for index in 0..16 {
            let shift = (15 - index) * 4;
            bytes[index + 2] = HEX[((value >> shift) & 0x0F) as usize];
        }
        if let Ok(text) = core::str::from_utf8(&bytes) {
            self.text(x, y, text, color, 1);
        }
    }

    fn pixel(&mut self, x: usize, y: usize, color: u32) {
        let offset = y * self.pitch + x * self.bytes_per_pixel;
        let pixel = self.pack(color);
        unsafe {
            if self.bytes_per_pixel == 4 {
                self.address.add(offset).cast::<u32>().write_volatile(pixel);
            } else {
                self.address.add(offset).write_volatile((pixel & 0xff) as u8);
                self.address.add(offset + 1).write_volatile(((pixel >> 8) & 0xff) as u8);
                self.address.add(offset + 2).write_volatile(((pixel >> 16) & 0xff) as u8);
            }
        }
    }

    fn pack(&self, color: u32) -> u32 {
        let red = ((color >> 16) & 0xff) as u8;
        let green = ((color >> 8) & 0xff) as u8;
        let blue = (color & 0xff) as u8;
        channel(red, self.red_size, self.red_shift)
            | channel(green, self.green_size, self.green_shift)
            | channel(blue, self.blue_size, self.blue_shift)
    }
}

fn channel(value: u8, size: u8, shift: u8) -> u32 {
    if size == 0 || size > 8 || shift >= 32 || size.saturating_add(shift) > 32 {
        return 0;
    }
    let max = (1u32 << size) - 1;
    (((value as u32 * max) / 255) & max) << shift
}

const fn rgb(red: u8, green: u8, blue: u8) -> u32 {
    ((red as u32) << 16) | ((green as u32) << 8) | (blue as u32)
}
