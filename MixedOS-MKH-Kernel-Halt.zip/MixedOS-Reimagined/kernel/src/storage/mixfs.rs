//! MIXFS v1: a small persistent native filesystem for a dedicated ATA disk.
//!
//! Layout: dual CRC-protected superblocks, on-disk sector bitmap, fixed inode
//! table, variable data sectors, extent-based files/directories. Mutations use
//! dirty/clean superblock generations and are fail-closed after interrupted
//! writes. This is not yet a journaled filesystem; see docs/STAGE7.md.
use core::cell::UnsafeCell;
use core::hint::spin_loop;
use core::sync::atomic::{AtomicBool, AtomicU64, Ordering};

use super::ata::AtaError;
use super::block::{self, BLOCK_SIZE as SECTOR_SIZE};

const MAGIC: &[u8; 8] = b"MIXFS1\0\0";
const VERSION: u32 = 1;
const SUPER_HEADER: usize = 80;
const SUPER_CRC_OFFSET: usize = 76;
const INODE_MAGIC: u32 = 0x4D49_4E4F;
const INODE_SIZE: usize = 256;
const INODE_COUNT: u32 = 256;
const INODE_SECTORS: u32 = (INODE_COUNT as usize * INODE_SIZE / SECTOR_SIZE) as u32;
const EXTENTS_MAX: usize = 12;
const NAME_MAX: usize = 55;
const DIRECTORY_ENTRY_SIZE: usize = 64;
const ROOT_INODE: u32 = 0;
const KIND_FREE: u8 = 0;
const KIND_FILE: u8 = 1;
const KIND_DIR: u8 = 2;
const MODE_FILE_DEFAULT: u16 = 0o644;
const MODE_DIR_DEFAULT: u16 = 0o755;
const MAX_LIST_ENTRIES: usize = 64;
// Stage 7 bring-up only: reject large disks even when explicitly named.
const MAX_FORMAT_SECTORS: u64 = 1_048_576; // 512 MiB at 512 bytes per sector.

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FsError {
    NoDisk,
    NotFormatted,
    AlreadyMounted,
    NotMounted,
    ReadOnlyNeedsCheck,
    #[allow(dead_code)] // Reserved for explicit superblock decode diagnostics.
    CorruptSuperblock,
    CorruptMetadata,
    Io(AtaError),
    InvalidPath,
    NameTooLong,
    NotFound,
    AlreadyExists,
    NotDirectory,
    IsDirectory,
    DirectoryNotEmpty,
    NoSpace,
    NoInodes,
    TooFragmented,
    BufferTooSmall,
    TooManyEntries,
    ConfirmationRequired,
    ProtectedDisk,
    TargetTooLarge,
}

impl From<AtaError> for FsError {
    fn from(value: AtaError) -> Self { Self::Io(value) }
}

#[derive(Clone, Copy)]
struct Superblock {
    total_sectors: u64,
    bitmap_start: u32,
    bitmap_sectors: u32,
    inode_start: u32,
    inode_sectors: u32,
    data_start: u32,
    inode_count: u32,
    generation: u64,
    clean: bool,
    free_sectors: u64,
}

#[derive(Clone, Copy)]
struct Extent { start: u32, count: u32 }
impl Extent { const EMPTY: Self = Self { start: 0, count: 0 }; }

#[derive(Clone, Copy)]
struct Inode {
    kind: u8,
    mode: u16,
    uid: u16,
    gid: u16,
    parent: u32,
    generation: u32,
    size: u64,
    atime: u64,
    mtime: u64,
    ctime: u64,
    blocks: u32,
    extent_count: u32,
    extents: [Extent; EXTENTS_MAX],
}

#[derive(Clone, Copy)]
struct MountState {
    mounted: bool,
    read_only: bool,
    superblock: Superblock,
}
impl MountState {
    const EMPTY: Self = Self {
        mounted: false, read_only: false,
        superblock: Superblock {
            total_sectors: 0, bitmap_start: 0, bitmap_sectors: 0,
            inode_start: 0, inode_sectors: 0, data_start: 0,
            inode_count: 0, generation: 0, clean: false, free_sectors: 0,
        },
    };
}
struct StateCell(UnsafeCell<MountState>);
unsafe impl Sync for StateCell {}
static STATE: StateCell = StateCell(UnsafeCell::new(MountState::EMPTY));
static LOCKED: AtomicBool = AtomicBool::new(false);
static ALLOC_CURSOR: AtomicU64 = AtomicU64::new(0);
static FILE_READS: AtomicU64 = AtomicU64::new(0);
static FILE_WRITES: AtomicU64 = AtomicU64::new(0);
static FS_ERRORS: AtomicU64 = AtomicU64::new(0);

struct LockGuard;
fn lock() -> LockGuard {
    while LOCKED.compare_exchange_weak(false, true, Ordering::Acquire, Ordering::Relaxed).is_err() { spin_loop(); }
    LockGuard
}
impl Drop for LockGuard { fn drop(&mut self) { LOCKED.store(false, Ordering::Release); } }
fn state_copy() -> MountState { unsafe { *STATE.0.get() } }
fn state_store(value: MountState) { unsafe { *STATE.0.get() = value; } }

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct FsInfo {
    pub mounted: bool,
    pub read_only: bool,
    pub total_sectors: u64,
    pub free_sectors: u64,
    pub total_inodes: u32,
    pub generation: u64,
    pub clean: bool,
    pub file_reads: u64,
    pub file_writes: u64,
    pub errors: u64,
}

#[derive(Clone, Copy)]
pub struct ListEntry {
    pub name: [u8; 56],
    pub name_len: u8,
    pub kind: u8,
    pub size: u64,
}
impl ListEntry { pub const EMPTY: Self = Self { name: [0; 56], name_len: 0, kind: 0, size: 0 }; }

fn put_u16(out: &mut [u8], offset: usize, value: u16) { out[offset..offset + 2].copy_from_slice(&value.to_le_bytes()); }
fn put_u32(out: &mut [u8], offset: usize, value: u32) { out[offset..offset + 4].copy_from_slice(&value.to_le_bytes()); }
fn put_u64(out: &mut [u8], offset: usize, value: u64) { out[offset..offset + 8].copy_from_slice(&value.to_le_bytes()); }
fn get_u16(input: &[u8], offset: usize) -> u16 { u16::from_le_bytes([input[offset], input[offset + 1]]) }
fn get_u32(input: &[u8], offset: usize) -> u32 { u32::from_le_bytes(input[offset..offset + 4].try_into().unwrap_or([0; 4])) }
fn get_u64(input: &[u8], offset: usize) -> u64 { u64::from_le_bytes(input[offset..offset + 8].try_into().unwrap_or([0; 8])) }

fn crc32(bytes: &[u8]) -> u32 {
    let mut crc = 0xFFFF_FFFFu32;
    for byte in bytes {
        crc ^= u32::from(*byte);
        for _ in 0..8 { crc = (crc >> 1) ^ (0xEDB8_8320 & (0u32.wrapping_sub(crc & 1))); }
    }
    !crc
}

fn encode_super(sb: Superblock) -> [u8; SECTOR_SIZE] {
    let mut out = [0u8; SECTOR_SIZE];
    out[..8].copy_from_slice(MAGIC);
    put_u32(&mut out, 8, VERSION);
    put_u32(&mut out, 12, SUPER_HEADER as u32);
    put_u64(&mut out, 16, sb.total_sectors);
    put_u32(&mut out, 24, sb.bitmap_start);
    put_u32(&mut out, 28, sb.bitmap_sectors);
    put_u32(&mut out, 32, sb.inode_start);
    put_u32(&mut out, 36, sb.inode_sectors);
    put_u32(&mut out, 40, sb.data_start);
    put_u32(&mut out, 44, ROOT_INODE);
    put_u32(&mut out, 48, sb.inode_count);
    put_u64(&mut out, 52, sb.generation);
    put_u32(&mut out, 60, if sb.clean { 1 } else { 0 });
    put_u32(&mut out, 64, 0);
    put_u64(&mut out, 68, sb.free_sectors);
    put_u32(&mut out, SUPER_CRC_OFFSET, 0);
    let checksum = crc32(&out[..SUPER_HEADER]);
    put_u32(&mut out, SUPER_CRC_OFFSET, checksum);
    out
}

fn decode_super(raw: &[u8; SECTOR_SIZE], disk_sectors: u64) -> Option<Superblock> {
    if &raw[..8] != MAGIC || get_u32(raw, 8) != VERSION || get_u32(raw, 12) as usize != SUPER_HEADER { return None; }
    let expected = get_u32(raw, SUPER_CRC_OFFSET);
    let mut copy = *raw;
    put_u32(&mut copy, SUPER_CRC_OFFSET, 0);
    if crc32(&copy[..SUPER_HEADER]) != expected { return None; }
    let clean_raw = get_u32(raw, 60);
    if clean_raw > 1 || get_u32(raw, 44) != ROOT_INODE || get_u32(raw, 64) != 0 {
        return None;
    }
    let sb = Superblock {
        total_sectors: get_u64(raw, 16), bitmap_start: get_u32(raw, 24),
        bitmap_sectors: get_u32(raw, 28), inode_start: get_u32(raw, 32),
        inode_sectors: get_u32(raw, 36), data_start: get_u32(raw, 40),
        inode_count: get_u32(raw, 48), generation: get_u64(raw, 52),
        clean: clean_raw == 1, free_sectors: get_u64(raw, 68),
    };
    // The superblock is untrusted disk input. Bound the disk size before
    // computing rounded bitmap geometry, avoiding overflow on corrupt media.
    if sb.total_sectors != disk_sectors || sb.total_sectors > u64::from(u32::MAX) {
        return None;
    }
    let expected_bitmap = u32::try_from(sb.total_sectors.checked_add(4095)?.checked_div(4096)?).ok()?;
    if sb.bitmap_start != 2 || sb.bitmap_sectors != expected_bitmap
        || sb.inode_start != 2 + sb.bitmap_sectors || sb.inode_sectors != INODE_SECTORS
        || sb.data_start != sb.inode_start + sb.inode_sectors || sb.inode_count != INODE_COUNT
        || sb.data_start as u64 + 2 >= sb.total_sectors || sb.total_sectors > u64::from(u32::MAX)
        || sb.generation == 0
        || sb.free_sectors > sb.total_sectors.saturating_sub(u64::from(sb.data_start) + 2)
    { return None; }
    Some(sb)
}

fn write_super_copies(sb: Superblock) -> Result<(), FsError> {
    let encoded = encode_super(sb);
    let backup = sb.total_sectors.checked_sub(1).ok_or(FsError::CorruptMetadata)?;
    block::write(backup, &encoded)?;
    block::write(0, &encoded)?;
    block::flush()?;
    Ok(())
}

fn begin_mutation(sb: &mut Superblock) -> Result<(), FsError> {
    sb.generation = sb.generation.checked_add(1).ok_or(FsError::CorruptMetadata)?;
    sb.clean = false;
    write_super_copies(*sb)
}
fn finish_mutation(sb: &mut Superblock) -> Result<(), FsError> {
    block::flush()?;
    sb.clean = true;
    write_super_copies(*sb)
}

fn encode_inode(inode: Inode) -> [u8; INODE_SIZE] {
    let mut out = [0u8; INODE_SIZE];
    if inode.kind == KIND_FREE { return out; }
    put_u32(&mut out, 0, INODE_MAGIC);
    out[4] = inode.kind;
    put_u16(&mut out, 6, inode.mode);
    put_u16(&mut out, 8, inode.uid);
    put_u16(&mut out, 10, inode.gid);
    put_u32(&mut out, 12, inode.parent);
    put_u32(&mut out, 16, inode.generation);
    put_u32(&mut out, 20, inode.extent_count);
    put_u64(&mut out, 24, inode.size);
    put_u64(&mut out, 32, inode.atime);
    put_u64(&mut out, 40, inode.mtime);
    put_u64(&mut out, 48, inode.ctime);
    put_u32(&mut out, 56, inode.blocks);
    for (i, extent) in inode.extents.iter().enumerate() {
        put_u32(&mut out, 64 + i * 8, extent.start);
        put_u32(&mut out, 68 + i * 8, extent.count);
    }
    out
}
fn decode_inode(raw: &[u8; INODE_SIZE]) -> Result<Inode, FsError> {
    if get_u32(raw, 0) != INODE_MAGIC { return Err(FsError::NotFound); }
    let kind = raw[4];
    if kind != KIND_FILE && kind != KIND_DIR { return Err(FsError::CorruptMetadata); }
    let count = get_u32(raw, 20) as usize;
    if count > EXTENTS_MAX { return Err(FsError::CorruptMetadata); }
    let mut inode = Inode {
        kind, mode: get_u16(raw, 6), uid: get_u16(raw, 8), gid: get_u16(raw, 10),
        parent: get_u32(raw, 12), generation: get_u32(raw, 16), size: get_u64(raw, 24),
        atime: get_u64(raw, 32), mtime: get_u64(raw, 40), ctime: get_u64(raw, 48),
        blocks: get_u32(raw, 56), extent_count: count as u32, extents: [Extent::EMPTY; EXTENTS_MAX],
    };
    for i in 0..count { inode.extents[i] = Extent { start: get_u32(raw, 64 + i * 8), count: get_u32(raw, 68 + i * 8) }; }
    let total: u64 = inode.extents[..count].iter().map(|e| u64::from(e.count)).sum();
    if total != u64::from(inode.blocks) || inode.size > total.saturating_mul(SECTOR_SIZE as u64) { return Err(FsError::CorruptMetadata); }
    Ok(inode)
}

fn read_inode(sb: Superblock, index: u32) -> Result<Inode, FsError> {
    if index >= sb.inode_count { return Err(FsError::CorruptMetadata); }
    let byte_offset = index as usize * INODE_SIZE;
    let sector = u64::from(sb.inode_start) + (byte_offset / SECTOR_SIZE) as u64;
    let offset = byte_offset % SECTOR_SIZE;
    let mut raw_sector = [0u8; SECTOR_SIZE];
    block::read(sector, &mut raw_sector)?;
    let mut raw_inode = [0u8; INODE_SIZE];
    raw_inode.copy_from_slice(&raw_sector[offset..offset + INODE_SIZE]);
    if get_u32(&raw_inode, 0) == 0 { return Err(FsError::NotFound); }
    decode_inode(&raw_inode)
}
fn write_inode(sb: Superblock, index: u32, inode: Inode) -> Result<(), FsError> {
    if index >= sb.inode_count { return Err(FsError::CorruptMetadata); }
    let byte_offset = index as usize * INODE_SIZE;
    let sector = u64::from(sb.inode_start) + (byte_offset / SECTOR_SIZE) as u64;
    let offset = byte_offset % SECTOR_SIZE;
    let mut raw_sector = [0u8; SECTOR_SIZE];
    block::read(sector, &mut raw_sector)?;
    raw_sector[offset..offset + INODE_SIZE].copy_from_slice(&encode_inode(inode));
    block::write(sector, &raw_sector)?;
    Ok(())
}
fn clear_inode(sb: Superblock, index: u32) -> Result<(), FsError> {
    if index >= sb.inode_count { return Err(FsError::CorruptMetadata); }
    let byte_offset = index as usize * INODE_SIZE;
    let sector = u64::from(sb.inode_start) + (byte_offset / SECTOR_SIZE) as u64;
    let offset = byte_offset % SECTOR_SIZE;
    let mut raw_sector = [0u8; SECTOR_SIZE];
    block::read(sector, &mut raw_sector)?;
    raw_sector[offset..offset + INODE_SIZE].fill(0);
    block::write(sector, &raw_sector)?;
    Ok(())
}

fn bitmap_location(lba: u32, sb: Superblock) -> (u64, usize, u8) {
    let bitmap_sector_index = lba / 4096;
    let bit_index = (lba % 4096) as usize;
    (u64::from(sb.bitmap_start) + u64::from(bitmap_sector_index), bit_index / 8, 1u8 << (bit_index % 8))
}
fn bitmap_is_set(lba: u32, sb: Superblock) -> Result<bool, FsError> {
    let (sector, byte, mask) = bitmap_location(lba, sb);
    let mut buffer = [0u8; SECTOR_SIZE];
    block::read(sector, &mut buffer)?;
    Ok(buffer[byte] & mask != 0)
}
fn bitmap_set(lba: u32, sb: Superblock, value: bool) -> Result<(), FsError> {
    let (sector, byte, mask) = bitmap_location(lba, sb);
    let mut buffer = [0u8; SECTOR_SIZE];
    block::read(sector, &mut buffer)?;
    if value { buffer[byte] |= mask; } else { buffer[byte] &= !mask; }
    block::write(sector, &buffer)?;
    Ok(())
}
fn allocate_sector(sb: &mut Superblock) -> Result<u32, FsError> {
    let first = sb.data_start;
    let last = u32::try_from(sb.total_sectors - 1).map_err(|_| FsError::CorruptMetadata)?;
    let cursor = ALLOC_CURSOR.load(Ordering::Relaxed) as u32;
    let start = if cursor >= first && cursor < last { cursor } else { first };
    for pass in 0..2 {
        let (lo, hi) = if pass == 0 { (start, last) } else { (first, start) };
        if lo >= hi { continue; }
        let first_bitmap = lo / 4096;
        let last_bitmap = (hi - 1) / 4096;
        for bitmap_index in first_bitmap..=last_bitmap {
            let mut bits = [0u8; SECTOR_SIZE];
            block::read(u64::from(sb.bitmap_start + bitmap_index), &mut bits)?;
            let sector_base = bitmap_index * 4096;
            let candidate_start = lo.max(sector_base);
            let candidate_end = hi.min(sector_base.saturating_add(4096));
            for lba in candidate_start..candidate_end {
                let bit = (lba - sector_base) as usize;
                let byte = bit / 8;
                let mask = 1u8 << (bit % 8);
                if bits[byte] & mask == 0 {
                    bits[byte] |= mask;
                    block::write(u64::from(sb.bitmap_start + bitmap_index), &bits)?;
                    sb.free_sectors = sb.free_sectors.checked_sub(1).ok_or(FsError::CorruptMetadata)?;
                    ALLOC_CURSOR.store(u64::from(if lba + 1 >= last { first } else { lba + 1 }), Ordering::Relaxed);
                    return Ok(lba);
                }
            }
        }
    }
    Err(FsError::NoSpace)
}
fn free_sector(lba: u32, sb: &mut Superblock) -> Result<(), FsError> {
    if lba < sb.data_start || u64::from(lba) >= sb.total_sectors - 1 { return Err(FsError::CorruptMetadata); }
    if !bitmap_is_set(lba, *sb)? { return Err(FsError::CorruptMetadata); }
    bitmap_set(lba, *sb, false)?;
    sb.free_sectors = sb.free_sectors.checked_add(1).ok_or(FsError::CorruptMetadata)?;
    Ok(())
}
fn append_extent(inode: &mut Inode, lba: u32) -> Result<(), FsError> {
    let count = inode.extent_count as usize;
    if count > EXTENTS_MAX { return Err(FsError::CorruptMetadata); }
    if count > 0 {
        let last = &mut inode.extents[count - 1];
        if last.start.checked_add(last.count) == Some(lba) {
            last.count = last.count.checked_add(1).ok_or(FsError::TooFragmented)?;
            inode.blocks = inode.blocks.checked_add(1).ok_or(FsError::NoSpace)?;
            return Ok(());
        }
    }
    if count == EXTENTS_MAX { return Err(FsError::TooFragmented); }
    inode.extents[count] = Extent { start: lba, count: 1 };
    inode.extent_count += 1;
    inode.blocks = inode.blocks.checked_add(1).ok_or(FsError::NoSpace)?;
    Ok(())
}
fn release_extents(sb: &mut Superblock, inode: &Inode) -> Result<(), FsError> {
    for extent in inode.extents.iter().take(inode.extent_count as usize) {
        for lba in extent.start..extent.start.checked_add(extent.count).ok_or(FsError::CorruptMetadata)? {
            free_sector(lba, sb)?;
        }
    }
    Ok(())
}
fn sector_for_index(inode: &Inode, mut index: u32) -> Option<u32> {
    for extent in inode.extents.iter().take(inode.extent_count as usize) {
        if index < extent.count { return extent.start.checked_add(index); }
        index -= extent.count;
    }
    None
}
fn read_inode_sector(inode: &Inode, index: u32, out: &mut [u8; SECTOR_SIZE]) -> Result<(), FsError> {
    let lba = sector_for_index(inode, index).ok_or(FsError::CorruptMetadata)?;
    block::read(u64::from(lba), out)?;
    Ok(())
}
fn write_inode_sector(_sb: Superblock, inode: &Inode, index: u32, data: &[u8; SECTOR_SIZE]) -> Result<(), FsError> {
    let lba = sector_for_index(inode, index).ok_or(FsError::CorruptMetadata)?;
    block::write(u64::from(lba), data)?;
    Ok(())
}

fn read_dir_entry(dir: &Inode, index: u64) -> Result<Option<(u32, u8, [u8; 56], u8)>, FsError> {
    if dir.kind != KIND_DIR { return Err(FsError::NotDirectory); }
    let byte_offset = index.checked_mul(DIRECTORY_ENTRY_SIZE as u64).ok_or(FsError::CorruptMetadata)?;
    if byte_offset + DIRECTORY_ENTRY_SIZE as u64 > dir.size { return Ok(None); }
    let sector_index = (byte_offset / SECTOR_SIZE as u64) as u32;
    let offset = (byte_offset % SECTOR_SIZE as u64) as usize;
    let mut sector = [0u8; SECTOR_SIZE];
    read_inode_sector(dir, sector_index, &mut sector)?;
    let raw = &sector[offset..offset + DIRECTORY_ENTRY_SIZE];
    let inode = get_u32(raw, 0);
    if inode == 0 { return Ok(None); }
    if inode >= INODE_COUNT || (raw[4] != KIND_FILE && raw[4] != KIND_DIR) { return Err(FsError::CorruptMetadata); }
    let name_len = raw[5];
    if name_len == 0 || usize::from(name_len) > NAME_MAX { return Err(FsError::CorruptMetadata); }
    let mut name = [0u8; 56];
    name.copy_from_slice(&raw[8..64]);
    if name[..usize::from(name_len)].contains(&0) || name[..usize::from(name_len)].contains(&b'/') {
        return Err(FsError::CorruptMetadata);
    }
    Ok(Some((inode, raw[4], name, name_len)))
}
fn write_dir_entry(sb: &mut Superblock, dir_index: u32, dir: &mut Inode, index: u64, inode_index: u32, kind: u8, name: &[u8]) -> Result<(), FsError> {
    if dir.kind != KIND_DIR { return Err(FsError::NotDirectory); }
    if name.is_empty() || name.len() > NAME_MAX || name.contains(&b'/') { return Err(FsError::InvalidPath); }
    let byte_offset = index.checked_mul(DIRECTORY_ENTRY_SIZE as u64).ok_or(FsError::CorruptMetadata)?;
    let sector_index = (byte_offset / SECTOR_SIZE as u64) as u32;
    let offset = (byte_offset % SECTOR_SIZE as u64) as usize;
    let need_new_sector = sector_index >= dir.blocks;
    if need_new_sector {
        let previous_dir = *dir;
        let lba = allocate_sector(sb)?;
        if let Err(error) = append_extent(dir, lba) {
            let _ = free_sector(lba, sb);
            *dir = previous_dir;
            return Err(error);
        }
        let zero = [0u8; SECTOR_SIZE];
        if let Err(error) = block::write(u64::from(lba), &zero) {
            let _ = free_sector(lba, sb);
            *dir = previous_dir;
            return Err(error.into());
        }
    }
    let mut sector = [0u8; SECTOR_SIZE];
    if !need_new_sector { read_inode_sector(dir, sector_index, &mut sector)?; }
    let target = &mut sector[offset..offset + DIRECTORY_ENTRY_SIZE];
    target.fill(0);
    put_u32(target, 0, inode_index);
    target[4] = kind;
    target[5] = name.len() as u8;
    target[8..8 + name.len()].copy_from_slice(name);
    let lba = sector_for_index(dir, sector_index).ok_or(FsError::CorruptMetadata)?;
    block::write(u64::from(lba), &sector)?;
    dir.size = dir.size.max(byte_offset + DIRECTORY_ENTRY_SIZE as u64);
    dir.mtime = dir.mtime.saturating_add(1);
    write_inode(*sb, dir_index, *dir)?;
    Ok(())
}

fn find_child(sb: Superblock, parent_index: u32, name: &[u8]) -> Result<Option<u32>, FsError> {
    let parent = read_inode(sb, parent_index)?;
    if parent.kind != KIND_DIR { return Err(FsError::NotDirectory); }
    let count = parent.size / DIRECTORY_ENTRY_SIZE as u64;
    for index in 0..count {
        if let Some((child, _kind, entry_name, length)) = read_dir_entry(&parent, index)? {
            if length as usize == name.len() && &entry_name[..name.len()] == name { return Ok(Some(child)); }
        }
    }
    Ok(None)
}
fn resolve(sb: Superblock, path: &[u8]) -> Result<u32, FsError> {
    if path.is_empty() { return Err(FsError::InvalidPath); }
    let mut current = ROOT_INODE;
    let mut position = 0usize;
    while position < path.len() {
        while position < path.len() && path[position] == b'/' { position += 1; }
        if position >= path.len() { break; }
        let start = position;
        while position < path.len() && path[position] != b'/' { position += 1; }
        let part = &path[start..position];
        if part == b"." { continue; }
        if part == b".." { current = read_inode(sb, current)?.parent; continue; }
        if part.len() > NAME_MAX { return Err(FsError::NameTooLong); }
        current = find_child(sb, current, part)?.ok_or(FsError::NotFound)?;
    }
    Ok(current)
}
fn split_parent(path: &[u8]) -> Result<(u32, &[u8]), FsError> {
    if path.is_empty() { return Err(FsError::InvalidPath); }
    let trimmed = path.iter().rposition(|b| *b != b'/').map(|end| &path[..=end]).ok_or(FsError::InvalidPath)?;
    let slash = trimmed.iter().rposition(|b| *b == b'/');
    let (parent_path, name) = match slash {
        Some(index) => (&trimmed[..=index], &trimmed[index + 1..]),
        None => (b"/".as_slice(), trimmed),
    };
    if name.is_empty() || name == b"." || name == b".." || name.len() > NAME_MAX || name.contains(&0) { return Err(FsError::InvalidPath); }
    let parent = resolve(superblock()?, parent_path)?;
    let parent_inode = read_inode(superblock()?, parent)?;
    if parent_inode.kind != KIND_DIR { return Err(FsError::NotDirectory); }
    Ok((parent, name))
}
fn superblock() -> Result<Superblock, FsError> {
    let state = state_copy();
    if !state.mounted { return Err(FsError::NotMounted); }
    Ok(state.superblock)
}
fn allocate_inode(sb: Superblock) -> Result<u32, FsError> {
    for index in 1..sb.inode_count {
        let byte_offset = index as usize * INODE_SIZE;
        let sector = u64::from(sb.inode_start) + (byte_offset / SECTOR_SIZE) as u64;
        let offset = byte_offset % SECTOR_SIZE;
        let mut raw = [0u8; SECTOR_SIZE];
        block::read(sector, &mut raw)?;
        if get_u32(&raw, offset) == 0 { return Ok(index); }
    }
    Err(FsError::NoInodes)
}
fn new_inode(kind: u8, parent: u32, mode: u16) -> Inode {
    Inode {
        kind, mode, uid: 0, gid: 0, parent, generation: 1,
        size: 0, atime: 0, mtime: 0, ctime: 0, blocks: 0,
        extent_count: 0, extents: [Extent::EMPTY; EXTENTS_MAX],
    }
}

fn mount_locked() -> Result<FsInfo, FsError> {
    let disk = block::geometry();
    if !disk.present { return Err(FsError::NoDisk); }
    let mut primary = [0u8; SECTOR_SIZE];
    let mut backup = [0u8; SECTOR_SIZE];
    block::read(0, &mut primary)?;
    block::read(disk.sectors - 1, &mut backup)?;
    let a = decode_super(&primary, disk.sectors);
    let b = decode_super(&backup, disk.sectors);
    let sb = match (a, b) {
        (Some(x), Some(y)) => if x.generation >= y.generation { x } else { y },
        (Some(x), None) => x,
        (None, Some(y)) => y,
        (None, None) => return Err(FsError::NotFormatted),
    };
    let root = read_inode(sb, ROOT_INODE)?;
    if root.kind != KIND_DIR || root.parent != ROOT_INODE { return Err(FsError::CorruptMetadata); }
    let read_only = !sb.clean;
    state_store(MountState { mounted: true, read_only, superblock: sb });
    ALLOC_CURSOR.store(u64::from(sb.data_start), Ordering::Relaxed);
    Ok(info_locked(sb, read_only))
}

fn info_locked(sb: Superblock, read_only: bool) -> FsInfo {
    FsInfo {
        mounted: true, read_only, total_sectors: sb.total_sectors, free_sectors: sb.free_sectors,
        total_inodes: sb.inode_count, generation: sb.generation, clean: sb.clean,
        file_reads: FILE_READS.load(Ordering::Relaxed), file_writes: FILE_WRITES.load(Ordering::Relaxed),
        errors: FS_ERRORS.load(Ordering::Relaxed),
    }
}

pub fn mount() -> Result<FsInfo, FsError> {
    let _guard = lock();
    match mount_locked() { Ok(info) => Ok(info), Err(error) => { FS_ERRORS.fetch_add(1, Ordering::Relaxed); Err(error) } }
}

pub fn format(target_index: usize, confirmation: &[u8]) -> Result<FsInfo, FsError> {
    if confirmation != b"--erase-dedicated-disk" { return Err(FsError::ConfirmationRequired); }
    let _guard = lock();
    if state_copy().mounted { return Err(FsError::AlreadyMounted); }
    let candidate = block::disk_info(target_index).ok_or(FsError::NoDisk)?;
    if !block::is_safe_format_target(target_index) { return Err(FsError::ProtectedDisk); }
    if candidate.sectors > MAX_FORMAT_SECTORS { return Err(FsError::TargetTooLarge); }
    block::select_device(target_index)?;
    let disk = block::geometry();
    if !disk.present { return Err(FsError::NoDisk); }
    if disk.sectors < 8192 || disk.sectors > u64::from(u32::MAX) { return Err(FsError::NoSpace); }
    let bitmap_sectors = ((disk.sectors + 4095) / 4096) as u32;
    let inode_start = 2u32.checked_add(bitmap_sectors).ok_or(FsError::NoSpace)?;
    let data_start = inode_start.checked_add(INODE_SECTORS).ok_or(FsError::NoSpace)?;
    if u64::from(data_start) + 2 >= disk.sectors { return Err(FsError::NoSpace); }
    let sb = Superblock {
        total_sectors: disk.sectors, bitmap_start: 2, bitmap_sectors,
        inode_start, inode_sectors: INODE_SECTORS, data_start,
        inode_count: INODE_COUNT, generation: 1, clean: false,
        free_sectors: disk.sectors - u64::from(data_start) - 2,
    };
    // Once destructive work begins, never leave an old in-memory mount writable
    // if any subsequent disk operation fails. A successful format replaces this
    // state with the clean mounted superblock at the very end.
    state_store(MountState { mounted: true, read_only: true, superblock: sb });

    // Clear all inode-table sectors first.
    let zero = [0u8; SECTOR_SIZE];
    block::write(0, &zero)?;
    block::write(disk.sectors - 1, &zero)?;
    block::flush()?;
    for sector in 0..INODE_SECTORS { block::write(u64::from(inode_start + sector), &zero)?; }
    // Initialize allocation bitmap. Metadata, superblocks, and the backup sector are reserved.
    for bitmap_index in 0..bitmap_sectors {
        let mut bits = [0u8; SECTOR_SIZE];
        let base = u64::from(bitmap_index) * 4096;
        for bit in 0..4096u64 {
            let lba = base + bit;
            if lba < u64::from(data_start) || lba == u64::from(data_start) || lba == disk.sectors - 1 {
                let byte = (bit / 8) as usize;
                bits[byte] |= 1 << (bit % 8);
            }
        }
        block::write(u64::from(2 + bitmap_index), &bits)?;
    }
    // The root inode is a directory with POSIX-like mode metadata.
    let mut root = new_inode(KIND_DIR, ROOT_INODE, MODE_DIR_DEFAULT);
    root.extent_count = 1;
    root.blocks = 1;
    root.extents[0] = Extent { start: data_start, count: 1 };
    let root_raw = encode_inode(root);
    let mut root_table_sector = [0u8; SECTOR_SIZE];
    root_table_sector[..INODE_SIZE].copy_from_slice(&root_raw);
    block::write(u64::from(inode_start), &root_table_sector)?;
    block::write(u64::from(data_start), &zero)?;
    block::flush()?;
    // Write the backup first, then primary. A valid primary means format completed.
    let encoded = encode_super(Superblock { clean: true, ..sb });
    block::write(disk.sectors - 1, &encoded)?;
    block::write(0, &encoded)?;
    block::flush()?;
    state_store(MountState { mounted: true, read_only: false, superblock: Superblock { clean: true, ..sb } });
    ALLOC_CURSOR.store(u64::from(data_start), Ordering::Relaxed);
    Ok(info_locked(Superblock { clean: true, ..sb }, false))
}

pub fn info() -> FsInfo {
    let _guard = lock();
    let state = state_copy();
    if !state.mounted {
        let disk = block::geometry();
        return FsInfo { mounted: false, read_only: true, total_sectors: disk.sectors, free_sectors: 0, total_inodes: 0, generation: 0, clean: false, file_reads: FILE_READS.load(Ordering::Relaxed), file_writes: FILE_WRITES.load(Ordering::Relaxed), errors: FS_ERRORS.load(Ordering::Relaxed) };
    }
    info_locked(state.superblock, state.read_only)
}

pub fn list(path: &str, output: &mut [ListEntry; MAX_LIST_ENTRIES]) -> Result<usize, FsError> {
    let _guard = lock();
    let sb = superblock()?;
    let directory_index = resolve(sb, path.as_bytes())?;
    let directory = read_inode(sb, directory_index)?;
    if directory.kind != KIND_DIR { return Err(FsError::NotDirectory); }
    output.fill(ListEntry::EMPTY);
    let mut count = 0usize;
    for index in 0..directory.size / DIRECTORY_ENTRY_SIZE as u64 {
        if let Some((child_index, kind, name, name_len)) = read_dir_entry(&directory, index)? {
            if count == output.len() { return Err(FsError::TooManyEntries); }
            let child = read_inode(sb, child_index)?;
            output[count] = ListEntry { name, name_len, kind, size: child.size };
            count += 1;
            let _ = kind;
        }
    }
    Ok(count)
}

fn read_file_locked(sb: Superblock, path: &str, output: &mut [u8]) -> Result<usize, FsError> {
    let index = resolve(sb, path.as_bytes())?;
    let inode = read_inode(sb, index)?;
    if inode.kind == KIND_DIR { return Err(FsError::IsDirectory); }
    let size = usize::try_from(inode.size).map_err(|_| FsError::BufferTooSmall)?;
    if size > output.len() { return Err(FsError::BufferTooSmall); }
    let mut remaining = size;
    let mut offset = 0usize;
    let mut sector_index = 0u32;
    while remaining > 0 {
        let mut sector = [0u8; SECTOR_SIZE];
        read_inode_sector(&inode, sector_index, &mut sector)?;
        let copy = remaining.min(SECTOR_SIZE);
        output[offset..offset + copy].copy_from_slice(&sector[..copy]);
        offset += copy;
        remaining -= copy;
        sector_index += 1;
    }
    FILE_READS.fetch_add(1, Ordering::Relaxed);
    Ok(size)
}

pub fn read_file(path: &str, output: &mut [u8]) -> Result<usize, FsError> {
    let _guard = lock();
    let sb = superblock()?;
    read_file_locked(sb, path, output)
}

fn write_contents(sb: &mut Superblock, inode: &mut Inode, data: &[u8]) -> Result<(), FsError> {
    let mut replacement = *inode;
    replacement.extent_count = 0;
    replacement.blocks = 0;
    replacement.extents = [Extent::EMPTY; EXTENTS_MAX];
    replacement.size = data.len() as u64;
    replacement.mtime = replacement.mtime.saturating_add(1);
    let mut offset = 0usize;
    while offset < data.len() {
        let lba = match allocate_sector(sb) {
            Ok(value) => value,
            Err(error) => { let _ = release_extents(sb, &replacement); return Err(error); }
        };
        if let Err(error) = append_extent(&mut replacement, lba) {
            let _ = free_sector(lba, sb);
            let _ = release_extents(sb, &replacement);
            return Err(error);
        }
        let mut sector = [0u8; SECTOR_SIZE];
        let count = (data.len() - offset).min(SECTOR_SIZE);
        sector[..count].copy_from_slice(&data[offset..offset + count]);
        if let Err(error) = block::write(u64::from(lba), &sector) {
            let _ = release_extents(sb, &replacement);
            return Err(error.into());
        }
        offset += count;
    }
    *inode = replacement;
    // The caller commits the new inode before releasing old data blocks.
    Ok(())
}

#[derive(Clone, Copy, Eq, PartialEq)]
enum WriteMode { CreateOnly, ReplaceOnly }

fn write_file_locked(state: &mut MountState, path: &str, data: &[u8], mode: WriteMode) -> Result<(), FsError> {
    if !state.mounted { return Err(FsError::NotMounted); }
    if state.read_only { return Err(FsError::ReadOnlyNeedsCheck); }
    let sb = state.superblock;
    let (parent_index, name) = split_parent(path.as_bytes())?;
    let existing = find_child(sb, parent_index, name)?;
    let inode_index = match (existing, mode) {
        (Some(_), WriteMode::CreateOnly) => return Err(FsError::AlreadyExists),
        (None, WriteMode::ReplaceOnly) => return Err(FsError::NotFound),
        (Some(index), _) => index,
        (None, _) => allocate_inode(sb)?,
    };
    let mut parent = read_inode(sb, parent_index)?;
    let mut inode = match existing {
        Some(index) => read_inode(sb, index)?,
        None => new_inode(KIND_FILE, parent_index, MODE_FILE_DEFAULT),
    };
    if inode.kind == KIND_DIR { return Err(FsError::IsDirectory); }

    state.read_only = true;
    state_store(*state);
    if let Err(error) = begin_mutation(&mut state.superblock) {
        state_store(*state);
        return Err(error);
    }
    state_store(*state);
    let old_inode = inode;
    if let Err(error) = write_contents(&mut state.superblock, &mut inode, data) {
        state.read_only = true;
        state_store(*state);
        FS_ERRORS.fetch_add(1, Ordering::Relaxed);
        return Err(error);
    }
    if let Err(error) = write_inode(state.superblock, inode_index, inode) {
        state.read_only = true;
        state_store(*state);
        return Err(error);
    }
    if existing.is_none() {
        let append_index = parent.size / DIRECTORY_ENTRY_SIZE as u64;
        if let Err(error) = write_dir_entry(&mut state.superblock, parent_index, &mut parent, append_index, inode_index, KIND_FILE, name) {
            state.read_only = true;
            state_store(*state);
            return Err(error);
        }
    } else if let Err(error) = release_extents(&mut state.superblock, &old_inode) {
        state.read_only = true;
        state_store(*state);
        return Err(error);
    }
    if let Err(error) = finish_mutation(&mut state.superblock) {
        state.read_only = true;
        state_store(*state);
        return Err(error);
    }
    state.read_only = false;
    state_store(*state);
    FILE_WRITES.fetch_add(1, Ordering::Relaxed);
    Ok(())
}

/// Create a new file. Existing files are never silently replaced.
pub fn write_file(path: &str, data: &[u8]) -> Result<(), FsError> {
    let _guard = lock();
    let mut state = state_copy();
    write_file_locked(&mut state, path, data, WriteMode::CreateOnly)
}

/// Replace the contents of an existing file. Does not create missing files.
pub fn overwrite_file(path: &str, data: &[u8]) -> Result<(), FsError> {
    let _guard = lock();
    let mut state = state_copy();
    write_file_locked(&mut state, path, data, WriteMode::ReplaceOnly)
}

/// Append text to an existing file. Stage 7's shell text-edit limit is 2 KiB;
/// larger existing files return BufferTooSmall and remain unchanged.
pub fn append_file(path: &str, data: &[u8]) -> Result<(), FsError> {
    const APPEND_LIMIT: usize = 2048;
    let _guard = lock();
    let mut state = state_copy();
    if !state.mounted { return Err(FsError::NotMounted); }
    if state.read_only { return Err(FsError::ReadOnlyNeedsCheck); }
    let mut combined = [0u8; APPEND_LIMIT];
    let old_len = read_file_locked(state.superblock, path, &mut combined)?;
    let new_len = old_len.checked_add(data.len()).ok_or(FsError::BufferTooSmall)?;
    if new_len > combined.len() { return Err(FsError::BufferTooSmall); }
    combined[old_len..new_len].copy_from_slice(data);
    write_file_locked(&mut state, path, &combined[..new_len], WriteMode::ReplaceOnly)
}

/// Rename a file or directory within its current parent directory.
pub fn rename_file(path: &str, new_name: &str) -> Result<(), FsError> {
    let _guard = lock();
    let mut state = state_copy();
    if !state.mounted { return Err(FsError::NotMounted); }
    if state.read_only { return Err(FsError::ReadOnlyNeedsCheck); }
    let sb = state.superblock;
    let (parent_index, old_name) = split_parent(path.as_bytes())?;
    let new_name = new_name.as_bytes();
    if new_name.is_empty() || new_name.len() > NAME_MAX || new_name.contains(&b'/') || new_name.contains(&0)
        || new_name == b"." || new_name == b".." {
        return Err(FsError::InvalidPath);
    }
    let child_index = find_child(sb, parent_index, old_name)?.ok_or(FsError::NotFound)?;
    if let Some(existing) = find_child(sb, parent_index, new_name)? {
        if existing == child_index && old_name == new_name { return Ok(()); }
        return Err(FsError::AlreadyExists);
    }
    let mut parent = read_inode(sb, parent_index)?;
    state.read_only = true;
    state_store(state);
    if let Err(error) = begin_mutation(&mut state.superblock) {
        state_store(state);
        return Err(error);
    }
    state_store(state);

    let count = parent.size / DIRECTORY_ENTRY_SIZE as u64;
    let mut renamed = false;
    for index in 0..count {
        let byte_offset = index * DIRECTORY_ENTRY_SIZE as u64;
        let sector_index = (byte_offset / SECTOR_SIZE as u64) as u32;
        let offset = (byte_offset % SECTOR_SIZE as u64) as usize;
        let mut sector = [0u8; SECTOR_SIZE];
        if let Err(error) = read_inode_sector(&parent, sector_index, &mut sector) {
            state_store(state);
            return Err(error);
        }
        if get_u32(&sector, offset) == child_index {
            let entry = &mut sector[offset..offset + DIRECTORY_ENTRY_SIZE];
            entry.fill(0);
            put_u32(entry, 0, child_index);
            entry[4] = read_inode(state.superblock, child_index)?.kind;
            entry[5] = new_name.len() as u8;
            entry[8..8 + new_name.len()].copy_from_slice(new_name);
            let lba = sector_for_index(&parent, sector_index).ok_or(FsError::CorruptMetadata)?;
            if let Err(error) = block::write(u64::from(lba), &sector) {
                state_store(state);
                return Err(error.into());
            }
            parent.mtime = parent.mtime.saturating_add(1);
            if let Err(error) = write_inode(state.superblock, parent_index, parent) {
                state_store(state);
                return Err(error);
            }
            renamed = true;
            break;
        }
    }
    if !renamed {
        state_store(state);
        return Err(FsError::CorruptMetadata);
    }
    if let Err(error) = finish_mutation(&mut state.superblock) {
        state_store(state);
        return Err(error);
    }
    state.read_only = false;
    state_store(state);
    Ok(())
}

pub fn mkdir(path: &str) -> Result<(), FsError> {
    let _guard = lock();
    let mut state = state_copy();
    if !state.mounted { return Err(FsError::NotMounted); }
    if state.read_only { return Err(FsError::ReadOnlyNeedsCheck); }
    let sb = state.superblock;
    let (parent_index, name) = split_parent(path.as_bytes())?;
    if find_child(sb, parent_index, name)?.is_some() { return Err(FsError::AlreadyExists); }
    let inode_index = allocate_inode(sb)?;
    let mut parent = read_inode(sb, parent_index)?;
    state.read_only = true;
    state_store(state);
    if let Err(error) = begin_mutation(&mut state.superblock) {
        state_store(state);
        return Err(error);
    }
    state_store(state);
    let directory = new_inode(KIND_DIR, parent_index, MODE_DIR_DEFAULT);
    if let Err(error) = write_inode(state.superblock, inode_index, directory) { state.read_only = true; state_store(state); return Err(error); }
    let append_index = parent.size / DIRECTORY_ENTRY_SIZE as u64;
    if let Err(error) = write_dir_entry(&mut state.superblock, parent_index, &mut parent, append_index, inode_index, KIND_DIR, name) {
        state.read_only = true; state_store(state); return Err(error);
    }
    if let Err(error) = finish_mutation(&mut state.superblock) { state.read_only = true; state_store(state); return Err(error); }
    state.read_only = false;
    state_store(state);
    Ok(())
}

/// Backwards-compatible generic removal used by the in-kernel self-test.
/// Shell users should prefer the type-specific `remove_file` and `remove_dir`.
pub fn remove(path: &str) -> Result<(), FsError> { remove_entry(path, None) }

/// Remove one file. Refuses directories so a typo cannot delete a directory.
pub fn remove_file(path: &str) -> Result<(), FsError> { remove_entry(path, Some(KIND_FILE)) }

/// Remove one empty directory. Never removes directory trees recursively.
pub fn remove_dir(path: &str) -> Result<(), FsError> { remove_entry(path, Some(KIND_DIR)) }

fn remove_entry(path: &str, expected_kind: Option<u8>) -> Result<(), FsError> {
    let _guard = lock();
    let mut state = state_copy();
    if !state.mounted { return Err(FsError::NotMounted); }
    if state.read_only { return Err(FsError::ReadOnlyNeedsCheck); }
    let sb = state.superblock;
    let (parent_index, name) = split_parent(path.as_bytes())?;
    let child_index = find_child(sb, parent_index, name)?.ok_or(FsError::NotFound)?;
    if child_index == ROOT_INODE { return Err(FsError::InvalidPath); }
    let child = read_inode(sb, child_index)?;
    if let Some(expected) = expected_kind {
        if child.kind != expected {
            return Err(if expected == KIND_FILE { FsError::IsDirectory } else { FsError::NotDirectory });
        }
    }
    if child.kind == KIND_DIR && child.size > 0 {
        let mut has_entries = false;
        for index in 0..child.size / DIRECTORY_ENTRY_SIZE as u64 {
            if read_dir_entry(&child, index)?.is_some() { has_entries = true; break; }
        }
        if has_entries { return Err(FsError::DirectoryNotEmpty); }
    } else if child.kind != KIND_FILE && child.kind != KIND_DIR {
        return Err(FsError::CorruptMetadata);
    }
    let mut parent = read_inode(sb, parent_index)?;
    state.read_only = true;
    state_store(state);
    if let Err(error) = begin_mutation(&mut state.superblock) {
        state_store(state);
        return Err(error);
    }
    state_store(state);
    let count = parent.size / DIRECTORY_ENTRY_SIZE as u64;
    let mut found = false;
    for index in 0..count {
        let byte_offset = index * DIRECTORY_ENTRY_SIZE as u64;
        let sector_index = (byte_offset / SECTOR_SIZE as u64) as u32;
        let offset = (byte_offset % SECTOR_SIZE as u64) as usize;
        let mut sector = [0u8; SECTOR_SIZE];
        read_inode_sector(&parent, sector_index, &mut sector)?;
        if get_u32(&sector, offset) == child_index {
            sector[offset..offset + DIRECTORY_ENTRY_SIZE].fill(0);
            write_inode_sector(state.superblock, &parent, sector_index, &sector)?;
            found = true;
            break;
        }
    }
    if !found { state.read_only = true; state_store(state); return Err(FsError::CorruptMetadata); }
    release_extents(&mut state.superblock, &child)?;
    clear_inode(state.superblock, child_index)?;
    parent.mtime = parent.mtime.saturating_add(1);
    write_inode(state.superblock, parent_index, parent)?;
    if let Err(error) = finish_mutation(&mut state.superblock) { state.read_only = true; state_store(state); return Err(error); }
    state.read_only = false;
    state_store(state);
    Ok(())
}

fn check_inode_tree(sb: Superblock, index: u32, visited: &mut [bool; INODE_COUNT as usize], depth: u8) -> Result<u64, FsError> {
    if depth > 16 || index >= sb.inode_count || visited[index as usize] { return Err(FsError::CorruptMetadata); }
    visited[index as usize] = true;
    let inode = read_inode(sb, index)?;
    let mut referenced = 0u64;
    for extent in inode.extents.iter().take(inode.extent_count as usize) {
        let end = extent.start.checked_add(extent.count).ok_or(FsError::CorruptMetadata)?;
        if extent.count == 0 || extent.start < sb.data_start || u64::from(end) > sb.total_sectors - 1 { return Err(FsError::CorruptMetadata); }
        for lba in extent.start..end {
            if !bitmap_is_set(lba, sb)? { return Err(FsError::CorruptMetadata); }
        }
        referenced += u64::from(extent.count);
    }
    if inode.kind == KIND_DIR {
        if inode.size % DIRECTORY_ENTRY_SIZE as u64 != 0 { return Err(FsError::CorruptMetadata); }
        let count = inode.size / DIRECTORY_ENTRY_SIZE as u64;
        for entry in 0..count {
            if let Some((child_index, entry_kind, _name, _len)) = read_dir_entry(&inode, entry)? {
                let child = read_inode(sb, child_index)?;
                if child.parent != index || child.kind != entry_kind { return Err(FsError::CorruptMetadata); }
                referenced += check_inode_tree(sb, child_index, visited, depth + 1)?;
            }
        }
    }
    Ok(referenced)
}

/// Check reachable inode/directory/extent metadata. If the volume was left dirty,
/// a successful check re-enables writes. Orphaned allocated sectors are reported
/// by the free-space delta but are not reclaimed automatically.
fn count_free_data_sectors(sb: Superblock) -> Result<u64, FsError> {
    let last = sb.total_sectors - 1;
    let mut free = 0u64;
    for bitmap_index in 0..sb.bitmap_sectors {
        let mut bits = [0u8; SECTOR_SIZE];
        block::read(u64::from(sb.bitmap_start + bitmap_index), &mut bits)?;
        let base = u64::from(bitmap_index) * 4096;
        for bit in 0..4096u64 {
            let lba = base + bit;
            if lba >= u64::from(sb.data_start) && lba < last && bits[(bit / 8) as usize] & (1 << (bit % 8)) == 0 {
                free += 1;
            }
        }
    }
    Ok(free)
}

pub fn check() -> Result<u64, FsError> {
    let _guard = lock();
    let mut state = state_copy();
    if !state.mounted { return Err(FsError::NotMounted); }
    let was_read_only = state.read_only;
    state.read_only = true;
    state_store(state);
    let root = read_inode(state.superblock, ROOT_INODE)?;
    if root.kind != KIND_DIR || root.parent != ROOT_INODE { return Err(FsError::CorruptMetadata); }
    let mut visited = [false; INODE_COUNT as usize];
    let referenced = check_inode_tree(state.superblock, ROOT_INODE, &mut visited, 0)?;
    // Every allocated inode must be reachable from the root directory.
    for index in 0..state.superblock.inode_count {
        match read_inode(state.superblock, index) {
            Ok(_) if !visited[index as usize] => return Err(FsError::CorruptMetadata),
            Ok(_) | Err(FsError::NotFound) => {},
            Err(error) => return Err(error),
        }
    }
    // All metadata sectors, the root directory's first data sector, and the
    // trailing backup superblock must stay marked allocated in the bitmap.
    for lba in 0..=state.superblock.data_start {
        if !bitmap_is_set(lba, state.superblock)? { return Err(FsError::CorruptMetadata); }
    }
    let backup_lba = u32::try_from(state.superblock.total_sectors - 1).map_err(|_| FsError::CorruptMetadata)?;
    if !bitmap_is_set(backup_lba, state.superblock)? { return Err(FsError::CorruptMetadata); }
    let free = count_free_data_sectors(state.superblock)?;
    let capacity = state.superblock.total_sectors - u64::from(state.superblock.data_start) - 1;
    if free > capacity || capacity - free != referenced || (free != state.superblock.free_sectors && !was_read_only) {
        return Err(FsError::CorruptMetadata);
    }
    state.superblock.free_sectors = free;
    state.superblock.clean = true;
    write_super_copies(state.superblock)?;
    state.read_only = false;
    state_store(state);
    Ok(referenced)
}

pub fn sync() -> Result<(), FsError> {
    let _guard = lock();
    let state = state_copy();
    if !state.mounted { return Err(FsError::NotMounted); }
    block::flush()?;
    Ok(())
}

pub fn self_test() -> Result<usize, FsError> {
    let before = info();
    if !before.mounted || before.read_only { return Err(FsError::ReadOnlyNeedsCheck); }
    let test_dir = "/.mixedos-test";
    let test_file = "/.mixedos-test/roundtrip.txt";
    let content = b"MixedOS persistent filesystem round-trip test v1\nblock IO, directories, file data, and metadata verified.\n";
    let _ = remove(test_file);
    let _ = remove(test_dir);
    mkdir(test_dir)?;
    write_file(test_file, content)?;
    let mut buffer = [0u8; 256];
    let count = read_file(test_file, &mut buffer)?;
    if count != content.len() || &buffer[..count] != content { return Err(FsError::CorruptMetadata); }
    remove(test_file)?;
    remove(test_dir)?;
    sync()?;
    let after = info();
    if after.read_only || after.free_sectors != before.free_sectors { return Err(FsError::CorruptMetadata); }
    Ok(1)
}
