#ifndef MIXEDOS_ABI_H
#define MIXEDOS_ABI_H

/* Versioned C boundary shared by native components and the Rust kernel. */
#define MIXEDOS_C_ABI_REVISION 1u

typedef unsigned char mixedos_u8;
typedef unsigned short mixedos_u16;
typedef unsigned int mixedos_u32;
typedef unsigned long long mixedos_u64;
typedef unsigned long mixedos_size_t;

#ifdef __cplusplus
extern "C" {
#endif

mixedos_u32 mixedos_c_abi_revision(void);
void *memcpy(void *destination, const void *source, mixedos_size_t length);
void *memset(void *destination, int value, mixedos_size_t length);
void *memmove(void *destination, const void *source, mixedos_size_t length);
int memcmp(const void *left, const void *right, mixedos_size_t length);

#ifdef __cplusplus
}
#endif
#endif
