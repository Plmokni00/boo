[CmdletBinding()]
param(
    [switch]$KernelOnly,
    [switch]$Clean,
    [switch]$NoInstall
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Root = $PSScriptRoot
$Build = Join-Path $Root 'build'
$Deps = Join-Path $Build 'deps'
$Native = Join-Path $Build 'native'
$Artifacts = Join-Path $Build 'artifacts'
$Logs = Join-Path $Build 'logs'
$LogPath = Join-Path $Logs ("build-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))

function Fail([string]$Message) { throw "MixedOS: $Message" }
function Invoke-Checked([string]$Executable, [string[]]$Arguments) {
    Write-Host ("> {0} {1}" -f $Executable, ($Arguments -join ' ')) -ForegroundColor DarkGray
    & $Executable @Arguments | Out-Host
    if ($LASTEXITCODE -ne 0) { Fail "Command failed with exit code $LASTEXITCODE`: $Executable" }
}
function Find-Executable([string]$Name) {
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}
function Install-WingetPackage([string]$Id) {
    $winget = Find-Executable 'winget.exe'
    if (-not $winget) { Fail "'$Id' is missing and winget is unavailable. Install it manually, then rerun Build.bat." }
    Invoke-Checked $winget @('install', '--id', $Id, '--exact', '--silent', '--accept-package-agreements', '--accept-source-agreements')
}
function Invoke-SourceChecks {
    $python = Find-Executable 'python.exe'
    if (-not $python) { $python = Find-Executable 'python' }
    if (-not $python) {
        Write-Host 'Python not found; optional host-side source/model checks are skipped.' -ForegroundColor Yellow
        return
    }
    foreach ($script in @('tools\validate_source.py', 'tools\test_memory_model.py', 'tools\test_paging_model.py')) {
        Invoke-Checked $python @((Join-Path $Root $script))
    }
}

function Ensure-Rust {
    $cargoBin = Join-Path $env:USERPROFILE '.cargo\bin'
    if (Test-Path $cargoBin) { $env:PATH = $cargoBin + ';' + $env:PATH }

    $rustup = Find-Executable 'rustup.exe'
    if (-not $rustup) {
        if ($NoInstall) { Fail 'rustup is missing and -NoInstall was selected.' }
        Write-Host 'Installing the official Rustup package through WinGet...' -ForegroundColor Cyan
        Install-WingetPackage 'Rustlang.Rustup'
        if (Test-Path $cargoBin) { $env:PATH = $cargoBin + ';' + $env:PATH }
        $rustup = Find-Executable 'rustup.exe'
    }
    if (-not $rustup) { Fail 'rustup.exe was not found after setup. Ensure %USERPROFILE%\.cargo\bin is on PATH, then rerun Build.bat.' }

    if ($NoInstall) {
        $installedToolchains = & $rustup 'toolchain' 'list'
        if ($LASTEXITCODE -ne 0) { Fail 'Unable to query installed Rust toolchains.' }
        if (($installedToolchains -join "`n") -notmatch '(^|\s)stable([ -]|$)') {
            Fail 'The stable Rust toolchain is not installed; rerun without -NoInstall.'
        }
        $installedTargets = & $rustup 'target' 'list' '--installed' '--toolchain' 'stable'
        if ($LASTEXITCODE -ne 0) { Fail 'Unable to query installed Rust targets.' }
        if (($installedTargets -join "`n") -notmatch 'x86_64-unknown-none') {
            Fail 'Rust target x86_64-unknown-none is not installed; rerun without -NoInstall.'
        }
    }
    else {
        Invoke-Checked $rustup @('toolchain', 'install', 'stable', '--profile', 'minimal')
        Invoke-Checked $rustup @('target', 'add', 'x86_64-unknown-none', '--toolchain', 'stable')
    }

    $cargo = Find-Executable 'cargo.exe'
    $rustc = Find-Executable 'rustc.exe'
    if (-not $cargo -or -not $rustc) { Fail 'Rust compiler commands are unavailable. Reopen the terminal and run Build.bat again.' }
    $rustVersion = (& $rustc --version) -join ' '
    if ($LASTEXITCODE -ne 0) { Fail "Rust compiler version query failed: $rustVersion" }
    $rustMatch = [regex]::Match($rustVersion, '^rustc (\d+)\.(\d+)')
    if (-not $rustMatch.Success) { Fail "Unable to determine Rust compiler version: $rustVersion" }
    $rustMajor = [int]$rustMatch.Groups[1].Value
    $rustMinor = [int]$rustMatch.Groups[2].Value
    if ($rustMajor -lt 1 -or ($rustMajor -eq 1 -and $rustMinor -lt 85)) {
        Fail "Rust 1.85 or newer is required for edition 2024; found '$rustVersion'."
    }
    Write-Host $rustVersion
}
function Ensure-Clang {
    $clang = Find-Executable 'clang.exe'
    if (-not $clang) {
        $default = Join-Path $env:ProgramFiles 'LLVM\bin'
        if (Test-Path (Join-Path $default 'clang.exe')) {
            $env:PATH = $default + ';' + $env:PATH
            $clang = Find-Executable 'clang.exe'
        }
    }
    if (-not $clang) {
        if ($NoInstall) { Fail 'LLVM Clang is missing and -NoInstall was selected.' }
        Write-Host 'Installing LLVM/Clang through WinGet...' -ForegroundColor Cyan
        Install-WingetPackage 'LLVM.LLVM'
        $default = Join-Path $env:ProgramFiles 'LLVM\bin'
        if (Test-Path $default) { $env:PATH = $default + ';' + $env:PATH }
        $clang = Find-Executable 'clang.exe'
    }
    if (-not $clang) { Fail 'clang.exe was not found. Install the LLVM package and ensure LLVM\bin is on PATH.' }
    $clangOutput = & $clang --version
    if ($LASTEXITCODE -ne 0) { Fail 'clang.exe did not run successfully.' }
    $clangVersion = [string]($clangOutput | Select-Object -First 1)
    $clangMatch = [regex]::Match($clangVersion, 'version\s+(\d+)\.')
    if (-not $clangMatch.Success) { Fail "Could not parse Clang version: $clangVersion" }
    if ([int]$clangMatch.Groups[1].Value -lt 16) { Fail "LLVM/Clang 16 or newer is required; found '$clangVersion'." }
    Write-Host $clangVersion
    return $clang
}
function Test-MsysXorriso([string]$Path) {
    # MSYS2's xorriso expects POSIX paths such as /c/Users/name/... . Passing
    # C:\Users\... makes xorriso treat the drive path as a relative name.
    $binDir = Split-Path -Parent $Path
    $usrDir = Split-Path -Parent $binDir
    return ((Test-Path (Join-Path $usrDir 'bin\bash.exe')) -and
            (Test-Path (Join-Path $usrDir 'bin\pacman.exe')))
}
function ConvertTo-MsysPath([string]$Path) {
    $fullPath = [System.IO.Path]::GetFullPath($Path)
    if ($fullPath -match '^([A-Za-z]):[\\/](.*)$') {
        $drive = $Matches[1].ToLowerInvariant()
        $tail = $Matches[2] -replace '\\', '/'
        return "/$drive/$tail"
    }
    Fail "Cannot convert path for MSYS2 xorriso (expected a local drive path): $fullPath"
}

function Confirm-Xorriso([string]$Path) {
    $versionOutput = & $Path '-version'
    if ($LASTEXITCODE -ne 0) { Fail "xorriso failed its version check: $Path" }
    $versionText = $versionOutput -join "`n"
    $versionMatch = [regex]::Match($versionText, 'xorriso\s+(\d+)\.(\d+)\.(\d+)')
    if (-not $versionMatch.Success) { Fail "Could not parse xorriso version output from '$Path'." }
    $major = [int]$versionMatch.Groups[1].Value
    $minor = [int]$versionMatch.Groups[2].Value
    $patch = [int]$versionMatch.Groups[3].Value
    $foundVersion = [version]::new($major, $minor, $patch)
    if ($foundVersion -lt [version]'1.5.4') { Fail 'xorriso 1.5.4 or newer is required.' }
    Write-Host ("xorriso {0}.{1}.{2}" -f $major, $minor, $patch)
    return $Path
}
function Ensure-Xorriso {
    $xorriso = Find-Executable 'xorriso.exe'
    if ($xorriso) { return (Confirm-Xorriso $xorriso) }

    $roots = @(
        (Join-Path $env:SystemDrive 'msys64'),
        (Join-Path $env:ProgramFiles 'MSYS2'),
        (Join-Path $env:LOCALAPPDATA 'Programs\MSYS2')
    )
    $msysRoot = $null
    foreach ($candidate in $roots) {
        if (Test-Path (Join-Path $candidate 'usr\bin\pacman.exe')) { $msysRoot = $candidate; break }
    }
    if ($msysRoot) {
        $existingXorriso = Join-Path $msysRoot 'usr\bin\xorriso.exe'
        if (Test-Path $existingXorriso) { return (Confirm-Xorriso $existingXorriso) }
    }

    if ($NoInstall) { Fail 'xorriso is missing and -NoInstall was selected.' }
    if (-not $msysRoot) {
        Write-Host 'Installing MSYS2 to obtain the xorriso ISO authoring tool...' -ForegroundColor Cyan
        Install-WingetPackage 'MSYS2.MSYS2'
        foreach ($candidate in $roots) {
            if (Test-Path (Join-Path $candidate 'usr\bin\pacman.exe')) { $msysRoot = $candidate; break }
        }
    }
    if (-not $msysRoot) { Fail 'MSYS2 was not found. Install MSYS2, then rerun Build.bat.' }

    $pacman = Join-Path $msysRoot 'usr\bin\pacman.exe'
    Invoke-Checked $pacman @('-Syu', '--noconfirm')
    Invoke-Checked $pacman @('-S', '--needed', '--noconfirm', 'xorriso')
    $xorriso = Join-Path $msysRoot 'usr\bin\xorriso.exe'
    if (-not (Test-Path $xorriso)) { Fail 'MSYS2 package installation completed but xorriso.exe is missing.' }
    return (Confirm-Xorriso $xorriso)
}
function Get-LimineTools {
    $version = '12.9.6'
    $expectedHash = 'b38aabb042b0c0f9f562b7741be3c1204838d7bbacfa78bb411c674bd5b984ee'
    $dir = Join-Path $Deps "limine-$version"
    $archive = Join-Path $Deps "limine-binary-$version.tar.gz"
    $marker = Join-Path $dir '.verified-sha256'
    if (-not (Test-Path $marker) -or ((Get-Content $marker -Raw).Trim() -ne $expectedHash)) {
        if (Test-Path $dir) { Remove-Item $dir -Recurse -Force }
        if (Test-Path $archive) { Remove-Item $archive -Force }
        Write-Host "Downloading Limine $version binary release..." -ForegroundColor Cyan
        Invoke-WebRequest -Uri "https://github.com/limine-bootloader/limine/releases/download/v$version/limine-binary.tar.gz" -OutFile $archive
        $actualHash = (Get-FileHash -Path $archive -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualHash -ne $expectedHash) { Fail "Limine archive checksum mismatch. Expected $expectedHash; received $actualHash." }
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
        $tar = Find-Executable 'tar.exe'
        if (-not $tar) { Fail 'Windows tar.exe is required to unpack the verified Limine archive.' }
        Invoke-Checked $tar @('-xzf', $archive, '-C', $dir)
        Set-Content -Path $marker -Value $expectedHash -NoNewline
    }
    $required = @('limine-bios.sys', 'limine-bios-cd.bin', 'limine-uefi-cd.bin', 'BOOTX64.EFI', 'limine.exe')
    $found = @{}
    foreach ($name in $required) {
        $item = Get-ChildItem -Path $dir -Filter $name -File -Recurse | Select-Object -First 1
        if (-not $item) { Fail "The verified Limine archive does not contain required file '$name'." }
        $found[$name] = $item.FullName
    }
    return $found
}

try {
    New-Item -ItemType Directory -Force -Path $Logs | Out-Null
    Start-Transcript -Path $LogPath -Force | Out-Null
    Write-Host ("Build log: {0}" -f $LogPath) -ForegroundColor Cyan
    if ($Clean) {
        foreach ($path in @((Join-Path $Root 'target'), $Build)) {
            if (Test-Path $path) { Remove-Item $path -Recurse -Force }
        }
    }
    New-Item -ItemType Directory -Force -Path $Deps, $Native, $Artifacts | Out-Null

    Invoke-SourceChecks
    Ensure-Rust
    $clang = Ensure-Clang
    $cObject = Join-Path $Native 'runtime.o'
    Invoke-Checked $clang @(
        '--target=x86_64-unknown-none-elf', '-ffreestanding', '-fno-builtin',
        '-fno-stack-protector', '-fno-pic', '-mno-red-zone', '-O2',
        '-c', (Join-Path $Root 'kernel\native\c\runtime.c'), '-o', $cObject
    )

    $env:MIXEDOS_C_OBJECT = $cObject
    Push-Location $Root
    try {
        Invoke-Checked (Find-Executable 'cargo.exe') @('build', '--package', 'mixedos-kernel', '--release', '--target', 'x86_64-unknown-none')
    }
    finally {
        Pop-Location
        Remove-Item Env:\MIXEDOS_C_OBJECT -ErrorAction SilentlyContinue
    }

    $kernel = Join-Path $Root 'target\x86_64-unknown-none\release\mixedos-kernel'
    if (-not (Test-Path $kernel)) { Fail 'Cargo reported success, but the kernel ELF was not produced.' }
    if ($KernelOnly) {
        Write-Host "Kernel build complete: $kernel" -ForegroundColor Green
        return
    }

    $xorriso = Ensure-Xorriso
    $limine = Get-LimineTools
    $IsoRoot = Join-Path $Build 'iso-root'
    if (Test-Path $IsoRoot) { Remove-Item $IsoRoot -Recurse -Force }
    $bootDir = Join-Path $IsoRoot 'boot'
    $efiDir = Join-Path $IsoRoot 'EFI\BOOT'
    New-Item -ItemType Directory -Force -Path $bootDir, $efiDir | Out-Null

    Copy-Item $kernel (Join-Path $bootDir 'mixedos-kernel.elf')
    Copy-Item (Join-Path $Root 'boot\limine.conf') (Join-Path $IsoRoot 'limine.conf')
    Copy-Item $limine['limine-bios.sys'] (Join-Path $bootDir 'limine-bios.sys')
    Copy-Item $limine['limine-bios-cd.bin'] (Join-Path $bootDir 'limine-bios-cd.bin')
    Copy-Item $limine['limine-uefi-cd.bin'] (Join-Path $bootDir 'limine-uefi-cd.bin')
    Copy-Item $limine['BOOTX64.EFI'] (Join-Path $efiDir 'BOOTX64.EFI')

    $iso = Join-Path $Artifacts 'MixedOS-x86_64.iso'
    if (Test-Path $iso) { Remove-Item $iso -Force }
    $isoSourceArgument = $IsoRoot
    $isoOutputArgument = $iso
    if (Test-MsysXorriso $xorriso) {
        $isoSourceArgument = ConvertTo-MsysPath $IsoRoot
        $isoOutputArgument = ConvertTo-MsysPath $iso
        Write-Host 'Detected MSYS2 xorriso; using MSYS2 POSIX paths for ISO source/output.' -ForegroundColor Cyan
    }
    Invoke-Checked $xorriso @(
        '-as', 'mkisofs', '-R', '-r', '-J', '-b', 'boot/limine-bios-cd.bin',
        '-no-emul-boot', '-boot-load-size', '4', '-boot-info-table', '-hfsplus',
        '-apm-block-size', '2048', '--efi-boot', 'boot/limine-uefi-cd.bin',
        '-efi-boot-part', '--efi-boot-image', '--protective-msdos-label',
        $isoSourceArgument, '-o', $isoOutputArgument
    )
    $limineExe = $limine['limine.exe']
    Invoke-Checked $limineExe @('bios-install', $iso)
    if (-not (Test-Path $iso) -or (Get-Item $iso).Length -lt 1048576) { Fail 'ISO output is missing or unexpectedly small.' }
    $isoHash = (Get-FileHash -Path $iso -Algorithm SHA256).Hash.ToLowerInvariant()
    Set-Content -Path ($iso + '.sha256') -Value "$isoHash  MixedOS-x86_64.iso"

    Write-Host ''
    Write-Host 'MIXEDOS BUILD SUCCESSFUL' -ForegroundColor Green
    Write-Host "ISO: $iso"
    Write-Host "SHA256: $isoHash"
    Write-Host 'Stage 4 virtual-memory source build complete. A heap/global allocator, user-mode execution, USB HID, storage, networking, and desktop are not implemented.' -ForegroundColor Yellow
}
catch {
    Write-Error $_
    exit 1
}
finally {
    try { Stop-Transcript | Out-Null } catch { }
}
