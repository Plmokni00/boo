@echo off
setlocal
cd /d "%~dp0"
echo.
echo ============================================================
echo MixedOS - Build
echo ============================================================
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1" %*
set "RESULT=%ERRORLEVEL%"
echo.
if "%RESULT%"=="0" (
  echo ============================================================
  echo MixedOS build script completed successfully.
  echo Check build\artifacts for MixedOS-x86_64.iso.
  echo ============================================================
) else (
  echo ============================================================
  echo MixedOS build FAILED with exit code %RESULT%.
  echo Check build\logs for the full build log.
  echo ============================================================
)
echo.
echo Press any key to close this window...
pause >nul
exit /b %RESULT%
