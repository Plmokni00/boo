#!/usr/bin/env python3
"""Repository structure and regression checks; this does not compile or boot MixedOS."""
from pathlib import Path
import hashlib
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "Build.bat", "build.ps1", "Cargo.toml", ".cargo/config.toml",
    "boot/limine.conf", "kernel/Cargo.toml", "kernel/build.rs", "kernel/linker.ld",
    "kernel/src/main.rs", "kernel/src/boot/limine.rs",
    "kernel/src/console/serial.rs", "kernel/src/console/framebuffer.rs",
    "kernel/src/interrupts/mod.rs", "kernel/src/arch/x86_64/interrupts.S",
    "kernel/src/input/mod.rs", "kernel/src/input/keyboard.rs",
    "kernel/src/input/mouse.rs", "kernel/src/input/ps2.rs",
    "kernel/src/shell/mod.rs", "kernel/native/c/runtime.c", "include/mixedos/abi.h",
    "docs/STATUS.md", "docs/ROADMAP.md", "docs/STAGE2.md",
    "docs/INPUT-SUBSYSTEM.md", "docs/BUILD-FIX-2026-11-11.md",
    "kernel/src/memory/physical.rs", "kernel/src/memory/paging.rs", "docs/PHYSICAL-MEMORY.md", "docs/STAGE3.md", "docs/STAGE4.md",
    "tools/test_memory_model.py", "tools/test_paging_model.py",
    "tools/stage2-input-baseline.sha256",
]
FORBIDDEN_DIRS = {"target", "build", "dist", "node_modules", ".git", "toolchains", "iso_root", "__pycache__"}
errors: list[str] = []
for rel in REQUIRED:
    if not (ROOT / rel).is_file():
        errors.append(f"missing required file: {rel}")

for path in ROOT.rglob("*"):
    if path.is_dir() and path.name in FORBIDDEN_DIRS:
        errors.append(f"generated or bundled directory found: {path.relative_to(ROOT)}")
    if path.is_file() and path.suffix.lower() in {".iso", ".exe", ".dll", ".efi", ".o", ".elf", ".bin", ".pyc"}:
        errors.append(f"generated image, object, or host binary included: {path.relative_to(ROOT)}")

# Architecture facade coverage.
arch_facade = (ROOT / "kernel/src/arch/mod.rs").read_text(encoding="utf-8")
match = re.search(r"pub\s+use\s+x86_64::\{([^}]+)\}", arch_facade)
if not match:
    errors.append("architecture facade is missing its public x86_64 re-export list")
else:
    exported = {part.strip() for part in match.group(1).split(",") if part.strip()}
    referenced: set[str] = set()
    for rel in ("kernel/src/main.rs", "kernel/src/console/serial.rs", "kernel/src/interrupts/mod.rs", "kernel/src/shell/mod.rs", "kernel/src/input/ps2.rs"):
        source = (ROOT / rel).read_text(encoding="utf-8")
        referenced.update(re.findall(r"(?<![A-Za-z0-9_:])(?:crate::)?arch::([A-Za-z_][A-Za-z0-9_]*)", source))
    missing = sorted(referenced - exported)
    if missing:
        errors.append("architecture facade missing exports: " + ", ".join(missing))

# Windows/MSYS2 xorriso path handling regression.
build_script = (ROOT / "build.ps1").read_text(encoding="utf-8")
for token in ("function Test-MsysXorriso", "function ConvertTo-MsysPath", "ConvertTo-MsysPath $IsoRoot", "ConvertTo-MsysPath $iso", "$isoSourceArgument, '-o', $isoOutputArgument"):
    if token not in build_script:
        errors.append("build.ps1 missing MSYS2 xorriso path handling: " + token)

# IDT and assembly consistency.
interrupts = (ROOT / "kernel/src/interrupts/mod.rs").read_text(encoding="utf-8")
asm = (ROOT / "kernel/src/arch/x86_64/interrupts.S").read_text(encoding="utf-8")
for token in ("const IDT_ENTRIES: usize = 256", "lidt", "PIT_HZ: u32 = 100", "mixedos_interrupt_dispatch", "Page fault address", "arch::outb(PIC1_DATA, 0xFE)"):
    if token not in interrupts:
        errors.append("interrupt controller source missing marker: " + token)
entries = {int(n): kind for kind, n in re.findall(r"^ISR_(NOERR|ERR)\s+(\d+)$", asm, re.MULTILINE)}
expected_errors = {8, 10, 11, 12, 13, 14, 17, 21, 29, 30}
if set(entries) != set(range(256)):
    errors.append("interrupt assembly must define exactly one ISR stub for vectors 0-255")
for vector in range(256):
    expected = "ERR" if vector in expected_errors else "NOERR"
    if entries.get(vector) != expected:
        errors.append(f"interrupt vector {vector} must use ISR_{expected}")
        break
vector_table = [int(n) for n in re.findall(r"^\s*\.quad mixedos_isr_(\d+)$", asm, re.MULTILINE)]
if vector_table != list(range(256)):
    errors.append("mixedos_isr_table must contain vectors 0-255 in order")

# Unified input design regressions.
input_mod = (ROOT / "kernel/src/input/mod.rs").read_text(encoding="utf-8")
ps2 = (ROOT / "kernel/src/input/ps2.rs").read_text(encoding="utf-8")
keyboard = (ROOT / "kernel/src/input/keyboard.rs").read_text(encoding="utf-8")
mouse = (ROOT / "kernel/src/input/mouse.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
framebuffer = (ROOT / "kernel/src/console/framebuffer.rs").read_text(encoding="utf-8")
checks = {
    "kernel/src/input/mod.rs": ("pub enum InputEvent", "SerialByte(u8)", "EVENT_CAPACITY: usize = 256", "pub fn pop_event()", "pub(crate) fn push_event", "ps2::poll()"),
    "kernel/src/input/ps2.rs": ("0xAD", "0xA7", "0xAE", "0xA8", "0xD4", "send_device_command(false, 0xF0)", "send_device_command(false, 0x02)", "send_device_command(false, 0xF4)", "send_device_command(true, 0xF4)", "status & AUXILIARY", "mouse::handle_byte(byte)", "keyboard::handle_scancode(byte)"),
    "kernel/src/input/keyboard.rs": ("pub fn handle_scancode", "MOD_SHIFT", "MOD_CAPS_LOCK", "KeyEvent", "0xE0", "0xE1", "b'\\n'", "b'\\t'"),
    "kernel/src/input/mouse.rs": ("pub fn handle_byte", "PACKET_INDEX", "byte & 0x08", "raw_x as i8", "raw_y as i8", "buttons"),
    "kernel/src/shell/mod.rs": ("input::poll()", "input::pop_event()", "InputEvent::Key", "InputEvent::Mouse", "InputEvent::SerialByte", "b" + "\"input\""),
    "kernel/src/console/framebuffer.rs": ("set_input_status(&mut self, status: InputStats)", "status.keyboard_bytes", "status.mouse_bytes", "status.mouse_buttons"),
}
for rel, tokens in checks.items():
    source = (ROOT / rel).read_text(encoding="utf-8")
    for token in tokens:
        if token not in source:
            errors.append(f"{rel} missing input-subsystem marker: {token}")

# Shared ownership: exactly one code path is permitted to read the i8042 data port.
for rel in ("kernel/src/interrupts/mod.rs", "kernel/src/shell/mod.rs", "kernel/src/input/keyboard.rs", "kernel/src/input/mouse.rs"):
    source = (ROOT / rel).read_text(encoding="utf-8")
    if "arch::inb(0x60)" in source or "inb(DATA_PORT)" in source:
        errors.append(f"{rel} must not read the PS/2 data port outside the shared controller manager")
if "let byte = unsafe { arch::inb(DATA_PORT) };" not in ps2:
    errors.append("shared PS/2 controller manager must own port 0x60 reads")
if "let byte = unsafe { arch::inb(DATA_PORT) };" not in ps2 or "let _ = unsafe { arch::inb(DATA_PORT) };" not in ps2:
    errors.append("shared PS/2 manager must separate polled data reads from bounded initialization flushes")
if "arch::wait_for_interrupt" in shell:
    errors.append("polling bring-up shell must not HLT while waiting for events")


# Stage 3 physical-memory manager regressions.
physical = (ROOT / "kernel/src/memory/physical.rs").read_text(encoding="utf-8")
mem_mod = (ROOT / "kernel/src/memory/mod.rs").read_text(encoding="utf-8")
limine = (ROOT / "kernel/src/boot/limine.rs").read_text(encoding="utf-8")
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
memory_checks = {
    "kernel/src/boot/limine.rs": ("pub struct MemoryRegion", "pub struct MemoryMapIter", "pub fn memory_regions()", "response.entry_count > 4096"),
    "kernel/src/memory/physical.rs": ("PAGE_SIZE: u64 = 4096", "MAX_TRACKED_PHYSICAL_BYTES", "FIRST_MANAGED_ADDRESS", "pub fn initialize()", "pub fn allocate_frame()", "pub fn free_frame", "AlreadyFree", "OutsideManagedMemory", "pub fn frame_to_hhdm", "pub fn allocate_zeroed_frame", "pub fn self_test", "read_volatile", "write_volatile"),
    "kernel/src/memory/mod.rs": ("pub mod physical", "pub fn initialize()"),
    "kernel/src/main.rs": ("let memory_status = memory::initialize()", "physical frame allocator"),
    "kernel/src/shell/mod.rs": ("b\"frames\"", "b\"memtest\"", "physical::self_test(8)"),
}
for rel, tokens in memory_checks.items():
    source = (ROOT / rel).read_text(encoding="utf-8")
    for token in tokens:
        if token not in source:
            errors.append(f"{rel} missing physical-memory marker: {token}")

# Lock the known-working Stage 2 input drivers against accidental changes.
baseline = ROOT / "tools/stage2-input-baseline.sha256"
for line in baseline.read_text(encoding="utf-8").splitlines():
    expected, relative = line.split("  ", 1)
    candidate = ROOT / relative
    if not candidate.is_file():
        errors.append("Stage 2 input baseline file missing: " + relative)
    elif hashlib.sha256(candidate.read_bytes()).hexdigest() != expected:
        errors.append("Known-working Stage 2 input source changed: " + relative)

# Stage 4 active-root virtual-memory manager regressions.
paging = (ROOT / "kernel/src/memory/paging.rs").read_text(encoding="utf-8")
mem_mod = (ROOT / "kernel/src/memory/mod.rs").read_text(encoding="utf-8")
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
paging_checks = {
    "kernel/src/memory/paging.rs": (
        "pub struct PageFlags", "pub enum PagingError", "pub fn initialize() -> bool",
        'asm!("mov {}, cr3"', "CR4_LA57", "EFER_NXE", "CR0_WP",
        "pub fn map_page(", "pub fn unmap_page(", "pub fn translate(",
        "invlpg", "HUGE_PAGE", "rollback_created_tables", "register_owned_table",
        "unregister_owned_table", "is_owned_table", "physical::is_allocated_frame_address",
        "NonPresentEntryConflict", "fence(Ordering::Release)", "WriteProtectUnavailable",
        "pub fn self_test()", "user_accessible", "NO_EXECUTE",
    ),
    "kernel/src/memory/physical.rs": (
        "hhdm_pointer_for_page_table", "is_allocated_frame_address", "free_allocated_frame_at",
    ),
    "kernel/src/memory/mod.rs": ("pub mod paging", "paging::initialize()", "paging_ready"),
    "kernel/src/main.rs": ("memory_status.paging_ready", "memory::paging::stats()"),
    "kernel/src/shell/mod.rs": ("b\"paging\"", "b\"vmtest\"", "paging::self_test()"),
}
for rel, tokens in paging_checks.items():
    source = (ROOT / rel).read_text(encoding="utf-8")
    for token in tokens:
        if token not in source:
            errors.append(f"{rel} missing Stage 4 paging marker: {token}")

# Stage 4 must never write a replacement CR3; it edits only checked entries
# beneath the existing root and uses INVLPG for the changed virtual address.
if re.search(r'asm!\(\s*"mov\s+cr3\s*,', paging):
    errors.append("Stage 4 must not replace the active CR3 root")
if "write_entry(pt, ix[3], entry)" not in paging or "invalidate(address)" not in paging:
    errors.append("Stage 4 page mapping must write the leaf and invalidate its TLB entry")
rollback_start = paging.find("fn rollback_created_tables(")
rollback_end = paging.find("/// Add one 4 KiB mapping", rollback_start)
rollback = paging[rollback_start:rollback_end] if rollback_start >= 0 and rollback_end > rollback_start else ""
rollback_order = [rollback.find("write_volatile(0)"), rollback.find("invalidate(address)"), rollback.find("physical::free_frame(item.frame)")]
if not rollback or any(position < 0 for position in rollback_order) or rollback_order != sorted(rollback_order):
    errors.append("Stage 4 rollback must detach, invalidate, and only then free each page-table frame")

# Ensure the memory allocator is not exposed through the interrupt dispatcher.
if "physical::allocate_frame" in (ROOT / "kernel/src/interrupts/mod.rs").read_text(encoding="utf-8"):
    errors.append("physical frame allocation must not be called from interrupt context")

if errors:
    print("MixedOS source validation FAILED:")
    for error in errors:
        print(" - " + error)
    sys.exit(1)

print(f"MixedOS source validation passed ({len(REQUIRED)} required files checked).")
print("Verified: shared PS/2 ownership, unified input regressions, physical-frame ownership, active-root paging, permissions, rollback, TLB invalidation, and Stage 4 self-test hooks.")
print("This is a source-structure check only; it does not compile, link, or boot the kernel.")
