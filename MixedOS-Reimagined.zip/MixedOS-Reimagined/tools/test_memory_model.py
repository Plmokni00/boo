#!/usr/bin/env python3
"""Host-side invariant model for Stage 3 frame ownership logic.

This model tests clipping, reservation, uniqueness, exhaustion, free, and
 double-free behavior. It is not a test of the compiled Rust kernel.
"""
from dataclasses import dataclass

PAGE = 4096
LOW_RESERVED = 1024 * 1024
MAX_PHYS = 64 * 1024 * 1024 * 1024

@dataclass(frozen=True)
class Region:
    base: int
    length: int
    kind: int  # Limine type 0 is usable RAM.

class FrameModel:
    def __init__(self, regions: list[Region], frame_limit: int = 1 << 18):
        self.limit = min(frame_limit, MAX_PHYS // PAGE)
        self.managed: set[int] = set()
        self.allocated: set[int] = set()
        for region in regions:
            if region.kind != 0 or region.length <= 0:
                continue
            end = region.base + region.length
            if end < region.base:
                continue
            start = max(region.base, LOW_RESERVED)
            start = (start + PAGE - 1) & ~(PAGE - 1)
            end = min(end, MAX_PHYS) & ~(PAGE - 1)
            for frame in range(start // PAGE, end // PAGE):
                if frame < self.limit:
                    self.managed.add(frame)

    def allocate(self):
        for frame in sorted(self.managed - self.allocated):
            self.allocated.add(frame)
            return frame * PAGE
        return None

    def free(self, address: int):
        if address % PAGE:
            return "unaligned"
        frame = address // PAGE
        if frame not in self.managed:
            return "outside"
        if frame not in self.allocated:
            return "already-free"
        self.allocated.remove(frame)
        return "ok"


def check(condition: bool, message: str):
    if not condition:
        raise AssertionError(message)


def main():
    model = FrameModel([
        Region(0, 2 * 1024 * 1024, 0),             # First MiB reserved.
        Region(2 * 1024 * 1024 + 1, 5 * PAGE, 0), # Rounded inward.
        Region(4 * 1024 * 1024, 2 * PAGE, 1),     # Reserved type.
        Region(MAX_PHYS - PAGE, 8 * PAGE, 0),     # Clipped to 64 GiB.
    ], frame_limit=MAX_PHYS // PAGE)

    check(0 not in model.managed, "physical frame zero must stay reserved")
    check((LOW_RESERVED // PAGE) in model.managed, "first page after 1 MiB should be usable")
    check((4 * 1024 * 1024 // PAGE) not in model.managed, "non-usable map entry was exposed")
    check((2 * 1024 * 1024 // PAGE) not in model.managed, "unaligned region start was rounded down")
    check((MAX_PHYS // PAGE) not in model.managed, "64 GiB exclusive upper limit must be clipped")

    start_count = len(model.managed)
    frames = []
    for _ in range(start_count):
        address = model.allocate()
        check(address is not None, "allocator exhausted before all managed frames were used")
        check(address % PAGE == 0, "allocator returned an unaligned frame")
        check(address // PAGE in model.managed, "allocator returned reserved memory")
        frames.append(address)
    check(model.allocate() is None, "allocator must report exhaustion")
    check(len(set(frames)) == len(frames), "allocator returned duplicate frames")

    for address in frames:
        check(model.free(address) == "ok", "allocated frame failed to free")
    check(len(model.allocated) == 0, "free pass leaked allocated frames")
    check(model.free(frames[0]) == "already-free", "double-free was not rejected")
    check(model.free(frames[0] + 1) == "unaligned", "unaligned free was not rejected")
    check(model.free(4 * 1024 * 1024) == "outside", "reserved frame free was not rejected")

    print("Memory allocator model passed:")
    print(f"  managed frames: {start_count}")
    print("  unique allocation, exhaustion, free, reservation, clipping, and invalid-free checks passed")

if __name__ == "__main__":
    main()
