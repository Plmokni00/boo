#![no_std]
#![no_main]

mod arch;
mod boot;
mod console;
mod memory;
mod interrupts;
mod input;
mod shell;

use core::panic::PanicInfo;
use console::serial;

unsafe extern "C" {
    fn mixedos_c_abi_revision() -> u32;
}

#[unsafe(no_mangle)]
pub extern "C" fn _start() -> ! {
    arch::disable_interrupts();
    arch::initialize_fpu();
    serial::initialize();
    kprintln!("MixedOS: Rust x86_64 kernel entry reached");

    if !boot::limine::base_revision_supported() {
        panic!("Limine base revision 6 is not supported by the bootloader");
    }
    kprintln!("[ok] Limine base protocol revision 6");

    let c_abi = unsafe { mixedos_c_abi_revision() };
    if c_abi != 1 {
        panic!("C ABI revision mismatch: expected 1, received {}", c_abi);
    }
    kprintln!("[ok] freestanding C runtime linked (ABI revision {})", c_abi);

    let memory_summary = memory::boot_map::summary();
    match memory_summary {
        Some(summary) => kprintln!(
            "[ok] Limine memory map: {} usable regions, {} MiB usable",
            summary.usable_regions,
            summary.usable_bytes / (1024 * 1024)
        ),
        None => kprintln!("[warn] Limine memory map response unavailable"),
    }

    let framebuffer = boot::limine::framebuffer();
    let mut terminal = match framebuffer {
        Some(info) => {
            kprintln!("[ok] framebuffer: {}x{} @ {} bpp", info.width, info.height, info.bpp);
            if console::framebuffer::render_boot_screen(info) {
                kprintln!("[ok] framebuffer status screen rendered");
            } else {
                kprintln!("[warn] framebuffer format is not supported by the Stage 1 renderer");
            }
            console::framebuffer::Terminal::new(info)
        }
        None => {
            kprintln!("[warn] framebuffer response unavailable; serial console remains active");
            None
        }
    };

    if boot::limine::hhdm_offset().is_some() {
        kprintln!("[ok] higher-half direct-map response received");
    } else {
        kprintln!("[warn] higher-half direct-map response unavailable");
    }

    let memory_status = memory::initialize();
    if memory_status.allocator_ready {
        let stats = memory::physical::stats();
        kprintln!(
            "[ok] physical frame allocator: {} MiB managed, {} MiB free, 4 KiB pages",
            stats.managed_frames * memory::physical::PAGE_SIZE / (1024 * 1024),
            stats.free_frames * memory::physical::PAGE_SIZE / (1024 * 1024),
        );
    } else {
        kprintln!("[warn] physical frame allocator unavailable; boot memory map will remain read-only");
    }
    if memory_status.hhdm_ready {
        kprintln!("[ok] HHDM address translation available for allocated-frame tests");
    } else {
        kprintln!("[warn] HHDM unavailable; frame metadata works, page contents cannot be tested");
    }
    if memory_status.paging_ready {
        let paging = memory::paging::stats();
        kprintln!(
            "[ok] four-level page tables inspected; CR3={:#018x}, physical bits={}, NX={}, CR0.WP={}",
            paging.root_physical_address,
            paging.physical_address_bits,
            if paging.nx_enabled { "enabled" } else { "unavailable" },
            if paging.write_protect_enabled { "enabled" } else { "unavailable" },
        );
        kprintln!("[ok] Limine CR3 preserved; MixedOS page-table edits are restricted to checked 4 KiB mappings");
    } else {
        kprintln!("[warn] virtual memory manager unavailable; active Limine page tables left unchanged");
    }

    interrupts::initialize();
    let input_status = input::initialize();
    kprintln!(
        "[input] controller={} keyboard={} mouse={} config=0x{:02X}",
        input_status.controller_present,
        input_status.keyboard_ready,
        input_status.mouse_ready,
        input_status.command_byte
    );
    shell::run(&mut terminal, memory_summary)
}

#[panic_handler]
fn panic(info: &PanicInfo<'_>) -> ! {
    serial::write_line("*** MIXEDOS KERNEL PANIC ***");
    serial::write_fmt(format_args!("{}\r\n", info));
    arch::halt_forever()
}

#[macro_export]
macro_rules! kprintln {
    ($($arg:tt)*) => {{
        $crate::console::serial::write_fmt(format_args!($($arg)*));
        $crate::console::serial::write_line("");
    }};
}
