mod port;

pub use port::{inb, outb};

#[inline]
pub fn disable_interrupts() {
    // The early boot path deliberately keeps interrupts disabled until an IDT exists.
    unsafe { core::arch::asm!("cli", options(nostack)); }
}

/// Enable the architectural x87/SSE state area used by the interrupt entry stubs.
/// x86_64 guarantees FXSAVE and SSE2; the kernel does not enable AVX yet.
pub fn initialize_fpu() {
    static DEFAULT_MXCSR: u32 = 0x1F80;
    unsafe {
        let mut cr0: u64;
        core::arch::asm!("mov {}, cr0", out(reg) cr0, options(nostack, preserves_flags));
        cr0 &= !((1 << 2) | (1 << 3)); // Clear EM and TS.
        cr0 |= 1 << 1; // Set MP.
        core::arch::asm!("mov cr0, {}", in(reg) cr0, options(nostack, preserves_flags));

        let mut cr4: u64;
        core::arch::asm!("mov {}, cr4", out(reg) cr4, options(nostack, preserves_flags));
        cr4 |= (1 << 9) | (1 << 10); // OSFXSR and OSXMMEXCPT.
        core::arch::asm!("mov cr4, {}", in(reg) cr4, options(nostack, preserves_flags));
        core::arch::asm!("fninit", options(nostack));
        core::arch::asm!("ldmxcsr [{}]", in(reg) &DEFAULT_MXCSR, options(readonly, nostack, preserves_flags));
    }
}

#[inline]
pub fn enable_interrupts() {
    unsafe { core::arch::asm!("sti", options(nostack)); }
}

#[inline]
pub fn wait_for_interrupt() {
    unsafe { core::arch::asm!("hlt", options(nostack)); }
}

#[inline(never)]
pub fn halt_forever() -> ! {
    loop {
        unsafe { core::arch::asm!("hlt", options(nostack)); }
    }
}
