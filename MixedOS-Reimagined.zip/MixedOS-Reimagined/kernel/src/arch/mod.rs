pub mod x86_64;

// Stable architecture facade used by kernel subsystems. Keep callers independent
// of the internal x86_64 module layout.
pub use x86_64::{disable_interrupts, enable_interrupts, halt_forever, inb, initialize_fpu, outb, wait_for_interrupt};
