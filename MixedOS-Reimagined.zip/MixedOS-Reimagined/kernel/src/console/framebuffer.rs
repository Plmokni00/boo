use crate::boot::limine::Framebuffer;
use crate::console::font5x7;
use crate::input::InputStats;

pub fn render_boot_screen(framebuffer: Framebuffer) -> bool {
    let Some(mut canvas) = Canvas::new(framebuffer) else {
        return false;
    };

    let width = framebuffer.width as usize;
    let height = framebuffer.height as usize;
    canvas.fill(rgb(12, 17, 29));

    canvas.rect(0, 0, width, 5, rgb(48, 116, 238));
    canvas.rect(42, 42, 5, 58, rgb(72, 190, 173));
    canvas.rect(55, 42, 5, 58, rgb(48, 116, 238));
    canvas.rect(68, 42, 5, 58, rgb(160, 116, 238));

    let scale = if width >= 1200 { 3 } else { 2 };
    canvas.text(94, 43, "MIXEDOS", rgb(242, 246, 255), scale);
    canvas.text(95, 82, "INDEPENDENT KERNEL", rgb(178, 192, 215), 1);
    canvas.rect(94, 112, width.saturating_sub(188).min(520), 1, rgb(58, 76, 104));
    canvas.text(94, 132, "LIMINE BOOT CONFIRMED", rgb(114, 215, 185), 1);
    canvas.text(94, 151, "FRAMEBUFFER ONLINE", rgb(178, 192, 215), 1);
    canvas.text(94, 170, "C ABI LINKED", rgb(178, 192, 215), 1);

    let footer_y = height.saturating_sub(35);
    canvas.text(42, footer_y, "STAGE 2 / X86_64 / INTERACTIVE CONSOLE", rgb(118, 135, 162), 1);
    true
}

pub struct Terminal {
    canvas: Canvas,
    cursor_x: usize,
    cursor_y: usize,
    scale: usize,
    line_height: usize,
    text_left: usize,
    text_right: usize,
    text_bottom: usize,
}

impl Terminal {
    pub fn new(framebuffer: Framebuffer) -> Option<Self> {
        let canvas = Canvas::new(framebuffer)?;
        if canvas.width < 240 || canvas.height < 160 {
            return None;
        }
        let scale = if canvas.width >= 1000 { 2 } else { 1 };
        let mut terminal = Self {
            canvas,
            cursor_x: 34,
            cursor_y: 66,
            scale,
            line_height: 11 * scale,
            text_left: 34,
            text_right: 24,
            text_bottom: 22,
        };
        terminal.clear();
        Some(terminal)
    }

    pub fn clear(&mut self) {
        self.canvas.fill(rgb(10, 15, 26));
        self.canvas.rect(0, 0, self.canvas.width, 4, rgb(72, 143, 255));
        self.canvas.text(34, 20, "MIXEDOS KERNEL CONSOLE", rgb(236, 242, 255), 2);
        self.canvas.text(34, 44, "STAGE 2 / INTERACTIVE KERNEL", rgb(110, 207, 187), 1);
        self.canvas.rect(34, 58, self.canvas.width.saturating_sub(68), 1, rgb(47, 64, 91));
        self.canvas.text(34, 65, "KBD RX", rgb(114, 215, 185), 1);
        self.canvas.text_hex(76, 65, 0, 8, rgb(211, 222, 241));
        self.canvas.text(132, 65, "LAST", rgb(118, 135, 162), 1);
        self.canvas.text_hex(160, 65, 0, 2, rgb(211, 222, 241));
        self.canvas.text(194, 65, "MOUSE RX", rgb(114, 215, 185), 1);
        self.canvas.text_hex(250, 65, 0, 8, rgb(211, 222, 241));
        self.canvas.text(306, 65, "LAST", rgb(118, 135, 162), 1);
        self.canvas.text_hex(334, 65, 0, 2, rgb(211, 222, 241));
        self.canvas.text(34, 79, "MOUSE X", rgb(118, 135, 162), 1);
        self.canvas.text(98, 79, "0000", rgb(211, 222, 241), 1);
        self.canvas.text(136, 79, "Y", rgb(118, 135, 162), 1);
        self.canvas.text(148, 79, "0000", rgb(211, 222, 241), 1);
        self.canvas.text(190, 79, "BUTTONS", rgb(118, 135, 162), 1);
        self.canvas.text(244, 79, "00", rgb(211, 222, 241), 1);
        self.cursor_x = self.text_left;
        self.cursor_y = 96;
    }

    pub fn set_input_status(&mut self, status: InputStats) {
        let foreground = rgb(211, 222, 241);
        let background = rgb(10, 15, 26);
        self.canvas.rect(72, 63, self.canvas.width.saturating_sub(96), 27, background);
        self.canvas.text(132, 65, "LAST", rgb(118, 135, 162), 1);
        self.canvas.text(194, 65, "MOUSE RX", rgb(114, 215, 185), 1);
        self.canvas.text(306, 65, "LAST", rgb(118, 135, 162), 1);
        self.canvas.text(34, 79, "MOUSE X", rgb(118, 135, 162), 1);
        self.canvas.text(136, 79, "Y", rgb(118, 135, 162), 1);
        self.canvas.text(190, 79, "BUTTONS", rgb(118, 135, 162), 1);
        self.canvas.text_hex(76, 65, status.keyboard_bytes.min(u32::MAX as usize) as u32, 8, foreground);
        self.canvas.text_hex(160, 65, status.last_keyboard_byte as u32, 2, foreground);
        self.canvas.text_hex(250, 65, status.mouse_bytes.min(u32::MAX as usize) as u32, 8, foreground);
        self.canvas.text_hex(334, 65, status.last_mouse_byte as u32, 2, foreground);
        self.canvas.text_dec(98, 79, status.mouse_x.max(0) as u32, 4, foreground);
        self.canvas.text_dec(148, 79, status.mouse_y.max(0) as u32, 4, foreground);
        self.canvas.text_hex(244, 79, status.mouse_buttons as u32, 2, foreground);
        if self.canvas.width >= 430 {
            self.canvas.text(280, 79, if status.keyboard_ready { "KBD OK" } else { "KBD --" }, if status.keyboard_ready { rgb(114,215,185) } else { rgb(238,171,96) }, 1);
            self.canvas.text(330, 79, if status.mouse_ready { "MOUSE OK" } else { "MOUSE --" }, if status.mouse_ready { rgb(114,215,185) } else { rgb(238,171,96) }, 1);
        }
    }

    pub fn write(&mut self, text: &str) {
        for byte in text.bytes() {
            match byte {
                b'\r' => {}
                b'\n' => self.newline(),
                8 | 127 => self.backspace(),
                0x20..=0x7e => self.put_byte(byte),
                _ => {}
            }
        }
    }

    pub fn write_line(&mut self, text: &str) {
        self.write(text);
        self.newline();
    }

    fn put_byte(&mut self, byte: u8) {
        let glyph_width = 6 * self.scale;
        if self.cursor_x + glyph_width > self.canvas.width.saturating_sub(self.text_right) {
            self.newline();
        }
        self.canvas.text(
            self.cursor_x,
            self.cursor_y,
            core::str::from_utf8(&[byte]).unwrap_or("?"),
            rgb(211, 222, 241),
            self.scale,
        );
        self.cursor_x += glyph_width;
    }

    fn backspace(&mut self) {
        let glyph_width = 6 * self.scale;
        if self.cursor_x >= self.text_left + glyph_width {
            self.cursor_x -= glyph_width;
            self.canvas.rect(
                self.cursor_x,
                self.cursor_y,
                glyph_width,
                8 * self.scale,
                rgb(10, 15, 26),
            );
        }
    }

    fn newline(&mut self) {
        self.cursor_x = self.text_left;
        self.cursor_y += self.line_height;
        let maximum = self.canvas.height.saturating_sub(self.text_bottom);
        if self.cursor_y + 8 * self.scale > maximum {
            let scroll_pixels = self.line_height.min(maximum.saturating_sub(70));
            let source_y = 70 + scroll_pixels;
            let copy_rows = maximum.saturating_sub(source_y);
            if copy_rows > 0 {
                let bytes = copy_rows * self.canvas.pitch;
                let destination = unsafe { self.canvas.address.add(70 * self.canvas.pitch) };
                let source = unsafe { self.canvas.address.add(source_y * self.canvas.pitch) };
                unsafe { core::ptr::copy(source, destination, bytes); }
            }
            self.canvas.rect(
                0,
                maximum.saturating_sub(scroll_pixels),
                self.canvas.width,
                scroll_pixels,
                rgb(10, 15, 26),
            );
            self.cursor_y = maximum.saturating_sub(8 * self.scale);
        }
    }
}

struct Canvas {
    address: *mut u8,
    width: usize,
    height: usize,
    pitch: usize,
    bytes_per_pixel: usize,
    red_size: u8,
    red_shift: u8,
    green_size: u8,
    green_shift: u8,
    blue_size: u8,
    blue_shift: u8,
}

impl Canvas {
    fn new(fb: Framebuffer) -> Option<Self> {
        if fb.address.is_null() || fb.memory_model != 1 || (fb.bpp != 24 && fb.bpp != 32) {
            return None;
        }
        let width = usize::try_from(fb.width).ok()?;
        let height = usize::try_from(fb.height).ok()?;
        let pitch = usize::try_from(fb.pitch).ok()?;
        let bytes_per_pixel = usize::from(fb.bpp / 8);
        if width == 0 || height == 0 || pitch < width.checked_mul(bytes_per_pixel)? {
            return None;
        }
        // Prove that every later row/pixel offset fits in the target address space.
        pitch.checked_mul(height)?;
        Some(Self {
            address: fb.address,
            width,
            height,
            pitch,
            bytes_per_pixel,
            red_size: fb.red_mask_size,
            red_shift: fb.red_mask_shift,
            green_size: fb.green_mask_size,
            green_shift: fb.green_mask_shift,
            blue_size: fb.blue_mask_size,
            blue_shift: fb.blue_mask_shift,
        })
    }

    fn fill(&mut self, color: u32) {
        self.rect(0, 0, self.width, self.height, color);
    }

    fn rect(&mut self, x: usize, y: usize, width: usize, height: usize, color: u32) {
        let x_end = x.saturating_add(width).min(self.width);
        let y_end = y.saturating_add(height).min(self.height);
        for py in y.min(self.height)..y_end {
            for px in x.min(self.width)..x_end {
                self.pixel(px, py, color);
            }
        }
    }

    fn text(&mut self, x: usize, y: usize, text: &str, color: u32, scale: usize) {
        if scale == 0 { return; }
        let mut cursor = x;
        for character in text.bytes() {
            let glyph = font5x7::glyph(character.to_ascii_uppercase());
            for (row, bits) in glyph.iter().enumerate() {
                for column in 0..5 {
                    if *bits & (1 << (4 - column)) != 0 {
                        self.rect(
                            cursor + column * scale,
                            y + row * scale,
                            scale,
                            scale,
                            color,
                        );
                    }
                }
            }
            cursor = cursor.saturating_add(6 * scale);
            if cursor >= self.width { break; }
        }
    }

    fn text_dec(&mut self, x: usize, y: usize, value: u32, digits: usize, color: u32) {
        let digits = digits.clamp(1, 10);
        let mut bytes = [b'0'; 10];
        let mut remaining = value;
        for index in (0..digits).rev() {
            bytes[index] = b'0' + (remaining % 10) as u8;
            remaining /= 10;
        }
        let text = core::str::from_utf8(&bytes[..digits]).unwrap_or("0");
        self.text(x, y, text, color, 1);
    }

    fn text_hex(&mut self, x: usize, y: usize, value: u32, digits: usize, color: u32) {
        const HEX: &[u8; 16] = b"0123456789ABCDEF";
        let digits = digits.min(8);
        let mut bytes = [b'0'; 8];
        for index in 0..digits {
            let shift = (digits - index - 1) * 4;
            bytes[index] = HEX[((value >> shift) & 0x0F) as usize];
        }
        let text = core::str::from_utf8(&bytes[..digits]).unwrap_or("00000000");
        self.text(x, y, text, color, 1);
    }

    fn pixel(&mut self, x: usize, y: usize, color: u32) {
        let offset = y * self.pitch + x * self.bytes_per_pixel;
        let pixel = self.pack(color);
        unsafe {
            if self.bytes_per_pixel == 4 {
                self.address.add(offset).cast::<u32>().write_volatile(pixel);
            } else {
                self.address.add(offset).write_volatile((pixel & 0xff) as u8);
                self.address.add(offset + 1).write_volatile(((pixel >> 8) & 0xff) as u8);
                self.address.add(offset + 2).write_volatile(((pixel >> 16) & 0xff) as u8);
            }
        }
    }

    fn pack(&self, color: u32) -> u32 {
        let red = ((color >> 16) & 0xff) as u8;
        let green = ((color >> 8) & 0xff) as u8;
        let blue = (color & 0xff) as u8;
        channel(red, self.red_size, self.red_shift)
            | channel(green, self.green_size, self.green_shift)
            | channel(blue, self.blue_size, self.blue_shift)
    }
}

fn channel(value: u8, size: u8, shift: u8) -> u32 {
    if size == 0 || size > 8 || shift >= 32 || size.saturating_add(shift) > 32 {
        return 0;
    }
    let max = (1u32 << size) - 1;
    (((value as u32 * max) / 255) & max) << shift
}

const fn rgb(red: u8, green: u8, blue: u8) -> u32 {
    ((red as u32) << 16) | ((green as u32) << 8) | (blue as u32)
}
