use core::fmt::{self, Write};

const COM1: u16 = 0x3F8;

pub fn initialize() {
    unsafe {
        crate::arch::outb(COM1 + 1, 0x00); // Disable interrupts.
        crate::arch::outb(COM1 + 3, 0x80); // Enable divisor latch.
        crate::arch::outb(COM1, 0x03);     // 38400 baud divisor low byte.
        crate::arch::outb(COM1 + 1, 0x00);
        crate::arch::outb(COM1 + 3, 0x03); // 8 data bits, no parity, one stop bit.
        crate::arch::outb(COM1 + 2, 0xC7); // Enable and clear FIFO.
        crate::arch::outb(COM1 + 4, 0x0B); // Assert DTR, RTS, and OUT2.
    }
}

struct Port;

impl Port {
    fn write_byte(&mut self, byte: u8) {
        // Bound the wait so an absent or non-responsive UART cannot hang boot forever.
        for _ in 0..100_000 {
            let ready = unsafe { crate::arch::inb(COM1 + 5) } & 0x20 != 0;
            if ready {
                unsafe { crate::arch::outb(COM1, byte); }
                return;
            }
            core::hint::spin_loop();
        }
    }
}

impl Write for Port {
    fn write_str(&mut self, text: &str) -> fmt::Result {
        for byte in text.bytes() {
            if byte == b'\n' {
                self.write_byte(b'\r');
            }
            self.write_byte(byte);
        }
        Ok(())
    }
}

pub fn write_fmt(arguments: fmt::Arguments<'_>) {
    let _ = Port.write_fmt(arguments);
}

pub fn write_line(text: &str) {
    write_fmt(format_args!("{}\n", text));
}

/// Non-blocking COM1 input. Returns one byte when the UART receive buffer is ready.
pub fn try_read_byte() -> Option<u8> {
    let status = unsafe { crate::arch::inb(COM1 + 5) };
    if status & 0x01 == 0 {
        None
    } else {
        Some(unsafe { crate::arch::inb(COM1) })
    }
}
