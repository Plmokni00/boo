use core::cell::UnsafeCell;

const COMMON_MAGIC: [u64; 2] = [0xc7b1_dd30_df4c_8b88, 0x0a82_e883_a194_f07b];

#[repr(C)]
struct BaseRevision(UnsafeCell<[u64; 3]>);
unsafe impl Sync for BaseRevision {}

impl BaseRevision {
    const fn new() -> Self {
        Self(UnsafeCell::new([
            0xf956_2b2d_5c95_a6c8,
            0x6a7b_3849_4453_6bdc,
            6,
        ]))
    }

    fn supported(&self) -> bool {
        let revision_ptr = unsafe { self.0.get().cast::<u64>().add(2) };
        unsafe { revision_ptr.read_volatile() == 0 }
    }
}

#[repr(C)]
struct Request<T> {
    magic: [u64; 2],
    id: [u64; 2],
    revision: u64,
    response: UnsafeCell<*mut T>,
}
unsafe impl<T> Sync for Request<T> {}

impl<T> Request<T> {
    const fn new(id: [u64; 2], revision: u64) -> Self {
        Self {
            magic: COMMON_MAGIC,
            id,
            revision,
            response: UnsafeCell::new(core::ptr::null_mut()),
        }
    }

    fn get(&self) -> Option<&'static T> {
        let response = unsafe { self.response.get().read_volatile() };
        if response.is_null() {
            None
        } else {
            Some(unsafe { &*response })
        }
    }
}

#[repr(C)]
#[derive(Clone, Copy)]
pub struct Framebuffer {
    pub address: *mut u8,
    pub width: u64,
    pub height: u64,
    pub pitch: u64,
    pub bpp: u16,
    pub memory_model: u8,
    pub red_mask_size: u8,
    pub red_mask_shift: u8,
    pub green_mask_size: u8,
    pub green_mask_shift: u8,
    pub blue_mask_size: u8,
    pub blue_mask_shift: u8,
}

#[repr(C)]
struct FramebufferResponse {
    revision: u64,
    framebuffer_count: u64,
    framebuffers: *const *const Framebuffer,
}

#[repr(C)]
struct MemoryMapEntry {
    base: u64,
    length: u64,
    entry_type: u64,
}

/// A copy of one Limine memory-map region. `entry_type == 0` is usable RAM.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct MemoryRegion {
    pub base: u64,
    pub length: u64,
    pub entry_type: u64,
}

/// Bounded iterator over the bootloader-owned memory map response.
pub struct MemoryMapIter {
    entries: *const *const MemoryMapEntry,
    count: usize,
    index: usize,
}

impl Iterator for MemoryMapIter {
    type Item = MemoryRegion;

    fn next(&mut self) -> Option<Self::Item> {
        while self.index < self.count {
            let index = self.index;
            self.index += 1;
            let entry_ptr = unsafe { self.entries.add(index).read() };
            if entry_ptr.is_null() {
                continue;
            }
            let entry = unsafe { &*entry_ptr };
            return Some(MemoryRegion {
                base: entry.base,
                length: entry.length,
                entry_type: entry.entry_type,
            });
        }
        None
    }
}

#[repr(C)]
struct MemoryMapResponse {
    revision: u64,
    entry_count: u64,
    entries: *const *const MemoryMapEntry,
}

#[repr(C)]
struct HhdmResponse {
    revision: u64,
    offset: u64,
}

#[used]
#[unsafe(link_section = ".limine_req_start")]
static REQUESTS_START: [u64; 4] = [
    0xf6b8_f4b3_9de7_d1ae,
    0xfab9_1a69_40fc_b9cf,
    0x785c_6ed0_15d3_e316,
    0x181e_920a_7852_b9d9,
];

#[used]
#[unsafe(link_section = ".limine_reqs")]
static BASE_REVISION: BaseRevision = BaseRevision::new();

#[used]
#[unsafe(link_section = ".limine_reqs")]
static FRAMEBUFFER_REQUEST: Request<FramebufferResponse> =
    Request::new([0x9d58_27dc_d881_dd75, 0xa314_8604_f6fa_b11b], 0);

#[used]
#[unsafe(link_section = ".limine_reqs")]
static MEMORY_MAP_REQUEST: Request<MemoryMapResponse> =
    Request::new([0x67cf_3d9d_378a_806f, 0xe304_acdf_c50c_3c62], 0);

#[used]
#[unsafe(link_section = ".limine_reqs")]
static HHDM_REQUEST: Request<HhdmResponse> =
    Request::new([0x48dc_f1cb_8ad2_b852, 0x6398_4e95_9a98_244b], 0);

#[used]
#[unsafe(link_section = ".limine_req_end")]
static REQUESTS_END: [u64; 2] = [0xadc0_e053_1bb1_0d03, 0x9572_709f_3176_4c62];

pub fn base_revision_supported() -> bool {
    BASE_REVISION.supported()
}

pub fn framebuffer() -> Option<Framebuffer> {
    let response = FRAMEBUFFER_REQUEST.get()?;
    if response.framebuffer_count == 0 || response.framebuffers.is_null() {
        return None;
    }
    let first = unsafe { *response.framebuffers };
    if first.is_null() {
        return None;
    }
    Some(unsafe { *first })
}

pub fn memory_regions() -> Option<MemoryMapIter> {
    let response = MEMORY_MAP_REQUEST.get()?;
    if response.entries.is_null() || response.entry_count == 0 || response.entry_count > 4096 {
        return None;
    }
    Some(MemoryMapIter {
        entries: response.entries,
        count: response.entry_count as usize,
        index: 0,
    })
}

pub fn usable_memory() -> (u64, usize) {
    let Some(regions) = memory_regions() else {
        return (0, 0);
    };
    let mut total = 0u64;
    let mut count = 0usize;
    for region in regions {
        // Limine memory-map type 0 denotes usable RAM.
        if region.entry_type == 0 {
            total = total.saturating_add(region.length);
            count = count.saturating_add(1);
        }
    }
    (total, count)
}

pub fn hhdm_offset() -> Option<u64> {
    HHDM_REQUEST.get().map(|response| response.offset)
}
