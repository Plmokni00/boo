//! Set-1 keyboard decoder. The i8042 translates a standard PS/2 set-2 stream
//! into set 1 before bytes reach this module.

use core::sync::atomic::{AtomicBool, AtomicU8, Ordering};

use super::{InputEvent, KeyEvent, MOD_ALT, MOD_CAPS_LOCK, MOD_CONTROL, MOD_SHIFT};

static MODIFIERS: AtomicU8 = AtomicU8::new(0);
static EXTENDED: AtomicBool = AtomicBool::new(false);
static PAUSE_REMAINING: AtomicU8 = AtomicU8::new(0);

pub fn reset() {
    MODIFIERS.store(0, Ordering::Relaxed);
    EXTENDED.store(false, Ordering::Relaxed);
    PAUSE_REMAINING.store(0, Ordering::Relaxed);
}

pub fn handle_scancode(byte: u8) {
    let pause_left = PAUSE_REMAINING.load(Ordering::Relaxed);
    if pause_left != 0 {
        PAUSE_REMAINING.store(pause_left - 1, Ordering::Relaxed);
        return;
    }
    if byte == 0xE1 {
        PAUSE_REMAINING.store(5, Ordering::Relaxed);
        EXTENDED.store(false, Ordering::Relaxed);
        return;
    }
    if byte == 0xE0 {
        EXTENDED.store(true, Ordering::Relaxed);
        return;
    }

    let extended = EXTENDED.swap(false, Ordering::Relaxed);
    let pressed = byte & 0x80 == 0;
    let code = byte & 0x7F;
    update_modifiers(code, extended, pressed);
    let modifiers = MODIFIERS.load(Ordering::Relaxed);
    let ascii = if pressed { translate(code, extended, modifiers) } else { None };

    super::push_event(InputEvent::Key(KeyEvent {
        scancode: code,
        extended,
        pressed,
        ascii,
        modifiers,
    }));
}

fn update_modifiers(code: u8, extended: bool, pressed: bool) {
    let mut value = MODIFIERS.load(Ordering::Relaxed);
    if !extended {
        match code {
            0x2A | 0x36 => set_flag(&mut value, MOD_SHIFT, pressed),
            0x1D => set_flag(&mut value, MOD_CONTROL, pressed),
            0x38 => set_flag(&mut value, MOD_ALT, pressed),
            0x3A if pressed => value ^= MOD_CAPS_LOCK,
            _ => {}
        }
    } else {
        match code {
            0x1D => set_flag(&mut value, MOD_CONTROL, pressed),
            0x38 => set_flag(&mut value, MOD_ALT, pressed),
            _ => {}
        }
    }
    MODIFIERS.store(value, Ordering::Relaxed);
}

fn set_flag(value: &mut u8, flag: u8, enabled: bool) {
    if enabled { *value |= flag; } else { *value &= !flag; }
}

fn translate(code: u8, extended: bool, modifiers: u8) -> Option<u8> {
    if extended {
        return match code {
            0x1C => Some(b'\n'), // keypad Enter
            0x35 => Some(b'/'),   // keypad slash
            _ => None,
        };
    }
    match code {
        0x01 => return Some(0x1B),
        0x0E => return Some(8),
        0x0F => return Some(b'\t'),
        0x1C => return Some(b'\n'),
        _ => {}
    }

    let shift = modifiers & MOD_SHIFT != 0;
    let caps = modifiers & MOD_CAPS_LOCK != 0;
    let (normal, shifted) = match code {
        0x02 => (b'1', b'!'), 0x03 => (b'2', b'@'), 0x04 => (b'3', b'#'),
        0x05 => (b'4', b'$'), 0x06 => (b'5', b'%'), 0x07 => (b'6', b'^'),
        0x08 => (b'7', b'&'), 0x09 => (b'8', b'*'), 0x0A => (b'9', b'('),
        0x0B => (b'0', b')'), 0x0C => (b'-', b'_'), 0x0D => (b'=', b'+'),
        0x10 => (b'q', b'Q'), 0x11 => (b'w', b'W'), 0x12 => (b'e', b'E'),
        0x13 => (b'r', b'R'), 0x14 => (b't', b'T'), 0x15 => (b'y', b'Y'),
        0x16 => (b'u', b'U'), 0x17 => (b'i', b'I'), 0x18 => (b'o', b'O'),
        0x19 => (b'p', b'P'), 0x1A => (b'[', b'{'), 0x1B => (b']', b'}'),
        0x1E => (b'a', b'A'), 0x1F => (b's', b'S'), 0x20 => (b'd', b'D'),
        0x21 => (b'f', b'F'), 0x22 => (b'g', b'G'), 0x23 => (b'h', b'H'),
        0x24 => (b'j', b'J'), 0x25 => (b'k', b'K'), 0x26 => (b'l', b'L'),
        0x27 => (b';', b':'), 0x28 => (b'\'', b'"'), 0x29 => (b'`', b'~'),
        0x2B => (b'\\', b'|'), 0x2C => (b'z', b'Z'), 0x2D => (b'x', b'X'),
        0x2E => (b'c', b'C'), 0x2F => (b'v', b'V'), 0x30 => (b'b', b'B'),
        0x31 => (b'n', b'N'), 0x32 => (b'm', b'M'), 0x33 => (b',', b'<'),
        0x34 => (b'.', b'>'), 0x35 => (b'/', b'?'), 0x39 => (b' ', b' '),
        _ => return None,
    };
    let use_shift = if normal.is_ascii_alphabetic() { shift ^ caps } else { shift };
    Some(if use_shift { shifted } else { normal })
}
