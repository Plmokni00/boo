//! Shared i8042 controller manager for primary (keyboard) and auxiliary (mouse)
//! PS/2 ports. IRQ delivery remains disabled; one poller demultiplexes the
//! controller's output buffer using status bit 5, so device bytes never race
//! separate drivers or get consumed by an unrelated interrupt handler.

use core::sync::atomic::{AtomicBool, AtomicU8, AtomicUsize, Ordering};

use crate::arch;

use super::{keyboard, mouse};

const STATUS_PORT: u16 = 0x64;
const DATA_PORT: u16 = 0x60;
const OUTPUT_FULL: u8 = 1 << 0;
const INPUT_FULL: u8 = 1 << 1;
const AUXILIARY: u8 = 1 << 5;
const TIMEOUT_OR_PARITY: u8 = (1 << 6) | (1 << 7);

static CONTROLLER_PRESENT: AtomicBool = AtomicBool::new(false);
static COMMAND_BYTE_VERIFIED: AtomicBool = AtomicBool::new(false);
static KEYBOARD_READY: AtomicBool = AtomicBool::new(false);
static MOUSE_READY: AtomicBool = AtomicBool::new(false);
static COMMAND_BYTE: AtomicU8 = AtomicU8::new(0);
static KEYBOARD_BYTES: AtomicUsize = AtomicUsize::new(0);
static LAST_KEYBOARD_BYTE: AtomicU8 = AtomicU8::new(0);
static CONTROLLER_ERRORS: AtomicUsize = AtomicUsize::new(0);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Ps2Stats {
    pub controller_present: bool,
    pub command_byte_verified: bool,
    pub keyboard_ready: bool,
    pub mouse_ready: bool,
    pub command_byte: u8,
    pub controller_status: u8,
    pub keyboard_bytes: usize,
    pub last_keyboard_byte: u8,
    pub controller_errors: usize,
}

pub fn initialize() {
    CONTROLLER_PRESENT.store(false, Ordering::Relaxed);
    COMMAND_BYTE_VERIFIED.store(false, Ordering::Relaxed);
    KEYBOARD_READY.store(false, Ordering::Relaxed);
    MOUSE_READY.store(false, Ordering::Relaxed);
    COMMAND_BYTE.store(0, Ordering::Relaxed);
    KEYBOARD_BYTES.store(0, Ordering::Relaxed);
    LAST_KEYBOARD_BYTE.store(0, Ordering::Relaxed);
    CONTROLLER_ERRORS.store(0, Ordering::Relaxed);

    // Disable both channels while changing the command byte, then drain stale
    // output. Unlike the old keyboard-only code, the auxiliary port is brought
    // back up and is not permanently disabled.
    if !wait_input_empty() { return; }
    unsafe { arch::outb(STATUS_PORT, 0xAD); }
    if !wait_input_empty() { return; }
    unsafe { arch::outb(STATUS_PORT, 0xA7); }
    flush_output();

    let Some(old_config) = read_command_byte() else { return; };
    CONTROLLER_PRESENT.store(true, Ordering::Relaxed);

    // IRQ1/IRQ12 off for polling; both clock-disable bits clear; translation on
    // so native set-2 keyboard data becomes the set-1 stream our decoder uses.
    let config = (old_config & !(0x01 | 0x02 | 0x10 | 0x20)) | 0x40;
    if !write_command_byte(config) { return; }
    let Some(readback) = read_command_byte() else { return; };
    COMMAND_BYTE.store(readback, Ordering::Relaxed);
    let verified = (readback & 0x73) == 0x40;
    COMMAND_BYTE_VERIFIED.store(verified, Ordering::Relaxed);
    if !verified { return; }

    if !wait_input_empty() { return; }
    unsafe { arch::outb(STATUS_PORT, 0xAE); } // Enable keyboard port.
    if !wait_input_empty() { return; }
    unsafe { arch::outb(STATUS_PORT, 0xA8); } // Enable auxiliary mouse port.

    // Keyboard: disable scan stream while choosing set 2, then restart it.
    let keyboard_paused = send_device_command(false, 0xF5);
    let keyboard_set2 = send_device_command(false, 0xF0)
        && send_device_command(false, 0x02);
    let keyboard_scanning = send_device_command(false, 0xF4);
    let keyboard_ready = keyboard_paused && keyboard_set2 && keyboard_scanning;
    KEYBOARD_READY.store(keyboard_ready, Ordering::Relaxed);

    // Mouse: standard three-button defaults, then enable movement reporting.
    // If there is no PS/2 auxiliary device (for example, USB tablet only), this
    // channel reports unavailable without breaking keyboard operation.
    let mouse_paused = send_device_command(true, 0xF5);
    let mouse_defaults = send_device_command(true, 0xF6);
    let mouse_streaming = send_device_command(true, 0xF4);
    MOUSE_READY.store(mouse_paused && mouse_defaults && mouse_streaming, Ordering::Relaxed);
}

pub fn poll() {
    if !CONTROLLER_PRESENT.load(Ordering::Relaxed) || !COMMAND_BYTE_VERIFIED.load(Ordering::Relaxed) {
        return;
    }
    // Bound each pass so a continuously-chatty device cannot starve the shell.
    for _ in 0..64 {
        let status = unsafe { arch::inb(STATUS_PORT) };
        if status == 0xFF || status & OUTPUT_FULL == 0 { break; }
        let byte = unsafe { arch::inb(DATA_PORT) };
        if status & TIMEOUT_OR_PARITY != 0 {
            CONTROLLER_ERRORS.fetch_add(1, Ordering::Relaxed);
            continue;
        }
        if status & AUXILIARY != 0 {
            mouse::handle_byte(byte);
        } else {
            KEYBOARD_BYTES.fetch_add(1, Ordering::Relaxed);
            LAST_KEYBOARD_BYTE.store(byte, Ordering::Relaxed);
            keyboard::handle_scancode(byte);
        }
    }
}

pub fn stats() -> Ps2Stats {
    Ps2Stats {
        controller_present: CONTROLLER_PRESENT.load(Ordering::Relaxed),
        command_byte_verified: COMMAND_BYTE_VERIFIED.load(Ordering::Relaxed),
        keyboard_ready: KEYBOARD_READY.load(Ordering::Relaxed),
        mouse_ready: MOUSE_READY.load(Ordering::Relaxed),
        command_byte: COMMAND_BYTE.load(Ordering::Relaxed),
        controller_status: unsafe { arch::inb(STATUS_PORT) },
        keyboard_bytes: KEYBOARD_BYTES.load(Ordering::Relaxed),
        last_keyboard_byte: LAST_KEYBOARD_BYTE.load(Ordering::Relaxed),
        controller_errors: CONTROLLER_ERRORS.load(Ordering::Relaxed),
    }
}

fn read_command_byte() -> Option<u8> {
    if !wait_input_empty() { return None; }
    unsafe { arch::outb(STATUS_PORT, 0x20); }
    for _ in 0..100_000 {
        let status = unsafe { arch::inb(STATUS_PORT) };
        if status & OUTPUT_FULL != 0 {
            let value = unsafe { arch::inb(DATA_PORT) };
            if status & AUXILIARY == 0 { return Some(value); }
            return None;
        }
        core::hint::spin_loop();
    }
    None
}

fn write_command_byte(value: u8) -> bool {
    if !wait_input_empty() { return false; }
    unsafe { arch::outb(STATUS_PORT, 0x60); }
    if !wait_input_empty() { return false; }
    unsafe { arch::outb(DATA_PORT, value); }
    wait_input_empty()
}

fn send_device_command(auxiliary: bool, command: u8) -> bool {
    for _ in 0..3 {
        if !wait_input_empty() { return false; }
        if auxiliary {
            unsafe { arch::outb(STATUS_PORT, 0xD4); }
            if !wait_input_empty() { return false; }
        }
        unsafe { arch::outb(DATA_PORT, command); }

        for _ in 0..100_000 {
            let status = unsafe { arch::inb(STATUS_PORT) };
            if status & OUTPUT_FULL == 0 {
                core::hint::spin_loop();
                continue;
            }
            let response = unsafe { arch::inb(DATA_PORT) };
            let response_is_aux = status & AUXILIARY != 0;
            if response_is_aux != auxiliary {
                // Preserve unsolicited bytes from the other channel.
                if response_is_aux { mouse::handle_byte(response); }
                else {
                    KEYBOARD_BYTES.fetch_add(1, Ordering::Relaxed);
                    LAST_KEYBOARD_BYTE.store(response, Ordering::Relaxed);
                    keyboard::handle_scancode(response);
                }
                continue;
            }
            match response {
                0xFA => return true,
                0xFE => break,
                _ => return false,
            }
        }
    }
    false
}

fn flush_output() {
    for _ in 0..128 {
        let status = unsafe { arch::inb(STATUS_PORT) };
        if status & OUTPUT_FULL == 0 { break; }
        let _ = unsafe { arch::inb(DATA_PORT) };
    }
}

fn wait_input_empty() -> bool {
    for _ in 0..100_000 {
        if unsafe { arch::inb(STATUS_PORT) } & INPUT_FULL == 0 { return true; }
        core::hint::spin_loop();
    }
    false
}
