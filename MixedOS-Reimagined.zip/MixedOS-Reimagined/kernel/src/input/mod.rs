//! Unified kernel input layer.
//!
//! Device drivers translate hardware bytes into typed events. The rest of the
//! kernel consumes this queue and does not need to know which controller a
//! device is attached to. This stage implements polling i8042 keyboard/mouse
//! devices; USB HID is intentionally reported as not implemented.

pub mod keyboard;
pub mod mouse;
pub mod ps2;

use core::cell::UnsafeCell;
use core::mem::MaybeUninit;
use core::sync::atomic::{AtomicUsize, Ordering};

pub const MOD_SHIFT: u8 = 1 << 0;
pub const MOD_CAPS_LOCK: u8 = 1 << 1;
pub const MOD_CONTROL: u8 = 1 << 2;
pub const MOD_ALT: u8 = 1 << 3;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct KeyEvent {
    /// Physical Set-1 scan code without the break bit.
    pub scancode: u8,
    pub extended: bool,
    pub pressed: bool,
    /// US-layout ASCII for printable/control keys; `None` for non-text keys.
    pub ascii: Option<u8>,
    pub modifiers: u8,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct MouseEvent {
    pub delta_x: i16,
    pub delta_y: i16,
    pub x: i32,
    pub y: i32,
    /// Bit 0 left, bit 1 right, bit 2 middle.
    pub buttons: u8,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum InputEvent {
    Key(KeyEvent),
    Mouse(MouseEvent),
    SerialByte(u8),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct InputStats {
    pub controller_present: bool,
    pub command_byte_verified: bool,
    pub keyboard_ready: bool,
    pub mouse_ready: bool,
    pub command_byte: u8,
    pub controller_status: u8,
    pub keyboard_bytes: usize,
    pub mouse_bytes: usize,
    pub last_keyboard_byte: u8,
    pub last_mouse_byte: u8,
    pub mouse_x: i32,
    pub mouse_y: i32,
    pub mouse_buttons: u8,
    pub controller_errors: usize,
    pub dropped_events: usize,
}

const EVENT_CAPACITY: usize = 256;

struct EventSlot(UnsafeCell<MaybeUninit<InputEvent>>);
unsafe impl Sync for EventSlot {}
impl EventSlot {
    const fn new() -> Self { Self(UnsafeCell::new(MaybeUninit::uninit())) }
}

static EVENT_QUEUE: [EventSlot; EVENT_CAPACITY] =
    [const { EventSlot::new() }; EVENT_CAPACITY];
static EVENT_HEAD: AtomicUsize = AtomicUsize::new(0);
static EVENT_TAIL: AtomicUsize = AtomicUsize::new(0);
static DROPPED_EVENTS: AtomicUsize = AtomicUsize::new(0);

/// Initialize all legacy input channels and devices.
pub fn initialize() -> InputStats {
    keyboard::reset();
    mouse::reset();
    ps2::initialize();
    stats()
}

/// Drain controller output and turn it into queued keyboard/mouse events.
/// Called by the kernel's main loop while interrupts remain available for PIT.
pub fn poll() {
    ps2::poll();
    // COM1 is a first-class input source too; normalize it into the same event
    // queue so the shell never needs to know which transport produced text.
    for _ in 0..32 {
        match crate::console::serial::try_read_byte() {
            Some(byte) => push_event(InputEvent::SerialByte(byte)),
            None => break,
        }
    }
}

/// Pop the next device-independent input event.
pub fn pop_event() -> Option<InputEvent> {
    let tail = EVENT_TAIL.load(Ordering::Relaxed);
    if tail == EVENT_HEAD.load(Ordering::Acquire) {
        return None;
    }
    let event = unsafe { (*EVENT_QUEUE[tail].0.get()).assume_init_read() };
    EVENT_TAIL.store((tail + 1) % EVENT_CAPACITY, Ordering::Release);
    Some(event)
}

pub(crate) fn push_event(event: InputEvent) {
    let head = EVENT_HEAD.load(Ordering::Relaxed);
    let next = (head + 1) % EVENT_CAPACITY;
    if next == EVENT_TAIL.load(Ordering::Acquire) {
        DROPPED_EVENTS.fetch_add(1, Ordering::Relaxed);
        return;
    }
    unsafe { (*EVENT_QUEUE[head].0.get()).write(event); }
    EVENT_HEAD.store(next, Ordering::Release);
}

pub fn stats() -> InputStats {
    let ps2 = ps2::stats();
    let mouse = mouse::stats();
    InputStats {
        controller_present: ps2.controller_present,
        command_byte_verified: ps2.command_byte_verified,
        keyboard_ready: ps2.keyboard_ready,
        mouse_ready: ps2.mouse_ready,
        command_byte: ps2.command_byte,
        controller_status: ps2.controller_status,
        keyboard_bytes: ps2.keyboard_bytes,
        mouse_bytes: mouse.bytes,
        last_keyboard_byte: ps2.last_keyboard_byte,
        last_mouse_byte: mouse.last_byte,
        mouse_x: mouse.x,
        mouse_y: mouse.y,
        mouse_buttons: mouse.buttons,
        controller_errors: ps2.controller_errors,
        dropped_events: DROPPED_EVENTS.load(Ordering::Relaxed),
    }
}
