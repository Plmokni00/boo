//! Three-byte PS/2 mouse packet decoder (standard 3-button protocol).

use core::sync::atomic::{AtomicI32, AtomicU8, AtomicUsize, Ordering};

use super::{InputEvent, MouseEvent};

static PACKET: [AtomicU8; 3] = [
    AtomicU8::new(0), AtomicU8::new(0), AtomicU8::new(0),
];
static PACKET_INDEX: AtomicUsize = AtomicUsize::new(0);
static X: AtomicI32 = AtomicI32::new(0);
static Y: AtomicI32 = AtomicI32::new(0);
static BUTTONS: AtomicU8 = AtomicU8::new(0);
static RECEIVED_BYTES: AtomicUsize = AtomicUsize::new(0);
static LAST_BYTE: AtomicU8 = AtomicU8::new(0);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct MouseStats {
    pub bytes: usize,
    pub last_byte: u8,
    pub x: i32,
    pub y: i32,
    pub buttons: u8,
}

pub fn reset() {
    PACKET_INDEX.store(0, Ordering::Relaxed);
    X.store(0, Ordering::Relaxed);
    Y.store(0, Ordering::Relaxed);
    BUTTONS.store(0, Ordering::Relaxed);
    RECEIVED_BYTES.store(0, Ordering::Relaxed);
    LAST_BYTE.store(0, Ordering::Relaxed);
}

pub fn handle_byte(byte: u8) {
    RECEIVED_BYTES.fetch_add(1, Ordering::Relaxed);
    LAST_BYTE.store(byte, Ordering::Relaxed);

    let mut index = PACKET_INDEX.load(Ordering::Relaxed);
    if index == 0 && byte & 0x08 == 0 {
        return; // discard bytes until a packet header is aligned
    }
    PACKET[index].store(byte, Ordering::Relaxed);
    index += 1;
    if index < 3 {
        PACKET_INDEX.store(index, Ordering::Relaxed);
        return;
    }
    PACKET_INDEX.store(0, Ordering::Relaxed);

    let flags = PACKET[0].load(Ordering::Relaxed);
    let raw_x = PACKET[1].load(Ordering::Relaxed);
    let raw_y = PACKET[2].load(Ordering::Relaxed);
    let buttons = flags & 0x07;
    let old_buttons = BUTTONS.swap(buttons, Ordering::Relaxed);

    // Overflow means the movement delta saturated; keep button state but ignore
    // the invalid movement sample. PS/2 positive Y is upward on screen.
    let (dx, dy) = if flags & 0xC0 == 0 {
        (raw_x as i8 as i16, -(raw_y as i8 as i16))
    } else {
        (0, 0)
    };
    let x = (X.load(Ordering::Relaxed) + dx as i32).clamp(0, 4095);
    let y = (Y.load(Ordering::Relaxed) + dy as i32).clamp(0, 4095);
    X.store(x, Ordering::Relaxed);
    Y.store(y, Ordering::Relaxed);

    if dx != 0 || dy != 0 || buttons != old_buttons {
        super::push_event(InputEvent::Mouse(MouseEvent {
            delta_x: dx,
            delta_y: dy,
            x,
            y,
            buttons,
        }));
    }
}

pub fn stats() -> MouseStats {
    MouseStats {
        bytes: RECEIVED_BYTES.load(Ordering::Relaxed),
        last_byte: LAST_BYTE.load(Ordering::Relaxed),
        x: X.load(Ordering::Relaxed),
        y: Y.load(Ordering::Relaxed),
        buttons: BUTTONS.load(Ordering::Relaxed),
    }
}
