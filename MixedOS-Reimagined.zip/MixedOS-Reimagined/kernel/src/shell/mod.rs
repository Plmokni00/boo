use core::fmt::Write;

use crate::{
    console::{framebuffer::Terminal, serial},
    input::{self, InputEvent},
    interrupts,
    memory::boot_map::MemorySummary,
};

const INPUT_CAPACITY: usize = 128;

pub fn run(terminal: &mut Option<Terminal>, memory: Option<MemorySummary>) -> ! {
    let initial = input::stats();
    emit_line(terminal, "[ok] interactive kernel services started");
    emit_line(terminal, "[ok] unified input queue online; PS/2 keyboard + mouse channels polled");
    emit_device_status(terminal, initial);
    emit_line(terminal, "USB HID: not implemented; COM1 serial input is available as fallback.");
    emit_line(terminal, "Type help to see available commands.");
    if let Some(view) = terminal.as_mut() { view.set_input_status(initial); }
    prompt(terminal);

    let mut line = [0u8; INPUT_CAPACITY];
    let mut line_len = 0usize;
    let mut serial_previous_was_cr = false;
    let mut last_stats = initial;

    loop {
        input::poll();
        let current_stats = input::stats();
        if current_stats != last_stats {
            if let Some(view) = terminal.as_mut() { view.set_input_status(current_stats); }
            last_stats = current_stats;
        }

        while let Some(event) = input::pop_event() {
            let byte = match event {
                InputEvent::Key(key) => {
                    if !key.pressed { continue; }
                    match key.ascii { Some(value) => value, None => continue }
                }
                InputEvent::SerialByte(value) => {
                    if value == b'\n' && serial_previous_was_cr {
                        serial_previous_was_cr = false;
                        continue;
                    }
                    serial_previous_was_cr = value == b'\r';
                    value
                }
                InputEvent::Mouse(_mouse) => continue,
            };

            match byte {
                b'\r' | b'\n' => {
                    emit(terminal, "\n");
                    execute(terminal, &line[..line_len], memory);
                    line_len = 0;
                    line.fill(0);
                    prompt(terminal);
                }
                8 | 127 => {
                    if line_len > 0 {
                        line_len -= 1;
                        if let Some(view) = terminal.as_mut() { view.write("\x08"); }
                        serial::write_fmt(format_args!("\x08 \x08"));
                    }
                }
                b'\t' => {
                    for _ in 0..4 {
                        if line_len < INPUT_CAPACITY - 1 {
                            line[line_len] = b' ';
                            line_len += 1;
                            emit(terminal, " ");
                        }
                    }
                }
                0x20..=0x7e if line_len < INPUT_CAPACITY - 1 => {
                    line[line_len] = byte;
                    line_len += 1;
                    let one = [byte];
                    emit(terminal, core::str::from_utf8(&one).unwrap_or(""));
                }
                _ => {}
            }
        }

        // Polling is intentionally active until the kernel has an idle task
        // and scheduler. The loop does not HLT or depend on IRQ1/IRQ12.
        core::hint::spin_loop();
    }
}

fn emit_device_status(terminal: &mut Option<Terminal>, status: input::InputStats) {
    emit_format_line(
        terminal,
        format_args!(
            "[input] i8042={} config={} kbd={} mouse={} (PS/2)",
            yes_no(status.controller_present),
            if status.command_byte_verified { "verified" } else { "unverified" },
            yes_no(status.keyboard_ready),
            yes_no(status.mouse_ready),
        ),
    );
}

fn yes_no(value: bool) -> &'static str { if value { "ready" } else { "absent" } }

fn execute(terminal: &mut Option<Terminal>, command: &[u8], memory: Option<MemorySummary>) {
    let command = trim_ascii(command);
    if command.is_empty() { return; }

    if command.eq_ignore_ascii_case(b"help") {
        emit_line(terminal, "Available commands:");
        emit_line(terminal, "  help     - show this command list");
        emit_line(terminal, "  clear    - clear the kernel console");
        emit_line(terminal, "  mem      - show usable, managed, free, and allocated memory");
        emit_line(terminal, "  frames   - show physical page-frame allocator diagnostics");
        emit_line(terminal, "  memtest  - allocate, write, verify, zero, and free test pages");
        emit_line(terminal, "  paging   - show active x86-64 paging diagnostics");
        emit_line(terminal, "  vmtest   - map, access, translate, and unmap test virtual pages");
        emit_line(terminal, "  uptime   - show time since kernel initialization");
        emit_line(terminal, "  input    - show keyboard/mouse and input-queue diagnostics");
        emit_line(terminal, "  reboot   - restart the virtual machine");
    } else if command.eq_ignore_ascii_case(b"clear") {
        if let Some(view) = terminal.as_mut() { view.clear(); view.set_input_status(input::stats()); }
        serial::write_fmt(format_args!("\x1b[2J\x1b[H"));
        emit_line(terminal, "MixedOS kernel console cleared.");
    } else if command.eq_ignore_ascii_case(b"mem") {
        match memory {
            Some(summary) => emit_format_line(
                terminal,
                format_args!("Boot map: {} MiB usable across {} regions.", summary.usable_bytes / (1024 * 1024), summary.usable_regions),
            ),
            None => emit_line(terminal, "Boot memory map is unavailable."),
        }
        let stats = crate::memory::physical::stats();
        if stats.initialized {
            emit_format_line(terminal, format_args!(
                "Frames: {} MiB managed / {} MiB free / {} MiB allocated.",
                stats.managed_frames * crate::memory::physical::PAGE_SIZE / (1024 * 1024),
                stats.free_frames * crate::memory::physical::PAGE_SIZE / (1024 * 1024),
                stats.allocated_frames * crate::memory::physical::PAGE_SIZE / (1024 * 1024),
            ));
            emit_format_line(terminal, format_args!("HHDM: {} (64 GiB physical tracking limit).", if stats.hhdm_ready { "ready" } else { "unavailable" }));
            emit_line(terminal, if stats.free_frames.saturating_add(stats.allocated_frames) == stats.managed_frames { "[ok] frame accounting consistent." } else { "[warn] frame accounting mismatch." });
        } else {
            emit_line(terminal, "Physical frame allocator: unavailable.");
        }
    } else if command.eq_ignore_ascii_case(b"frames") {
        let stats = crate::memory::physical::stats();
        if !stats.initialized {
            emit_line(terminal, "Physical frame allocator is not initialized.");
        } else {
            emit_format_line(terminal, format_args!("Managed: {} pages ({} MiB).", stats.managed_frames, stats.managed_frames * crate::memory::physical::PAGE_SIZE / (1024 * 1024)));
            emit_format_line(terminal, format_args!("Free: {} pages ({} MiB).", stats.free_frames, stats.free_frames * crate::memory::physical::PAGE_SIZE / (1024 * 1024)));
            emit_format_line(terminal, format_args!("Allocated: {} pages ({} MiB).", stats.allocated_frames, stats.allocated_frames * crate::memory::physical::PAGE_SIZE / (1024 * 1024)));
            emit_format_line(terminal, format_args!("Calls: alloc {} / failed {} / free {} / free errors {}.", stats.allocation_calls, stats.allocation_failures, stats.free_calls, stats.free_errors));
            emit_format_line(terminal, format_args!("HHDM: {} / base {:#018x} / maximum tracked {:#x} bytes.", if stats.hhdm_ready { "ready" } else { "unavailable" }, stats.hhdm_offset, stats.max_tracked_bytes));
            emit_line(terminal, if stats.free_frames.saturating_add(stats.allocated_frames) == stats.managed_frames { "[ok] frame accounting consistent." } else { "[warn] frame accounting mismatch." });
        }
    } else if command.eq_ignore_ascii_case(b"memtest") {
        match crate::memory::physical::self_test(8) {
            Ok(count) => emit_format_line(terminal, format_args!("[ok] Physical memory test passed: {} pages written, verified, zeroed, and freed.", count)),
            Err(reason) => emit_format_line(terminal, format_args!("[fail] Physical memory test: {}.", reason)),
        }
    } else if command.eq_ignore_ascii_case(b"paging") {
        let stats = crate::memory::paging::stats();
        if !stats.initialized {
            emit_line(terminal, "Virtual memory manager is unavailable; Limine mappings were preserved.");
        } else {
            emit_format_line(terminal, format_args!("Active CR3 root: {:#018x}.", stats.root_physical_address));
            emit_format_line(terminal, format_args!("Address width: {} physical bits / 48-bit virtual addresses.", stats.physical_address_bits));
            emit_format_line(terminal, format_args!("NX: {} / CR0.WP: {} / LA57: {}.", yes_no(stats.nx_enabled), yes_no(stats.write_protect_enabled), if stats.la57_enabled { "enabled" } else { "disabled" }));
            emit_format_line(terminal, format_args!("MixedOS-owned page-table pages: {}.", stats.owned_table_pages));
            emit_format_line(terminal, format_args!("Operations: map {} / unmap {} / map failures {} / TLB invalidations {}.", stats.map_calls, stats.unmap_calls, stats.map_failures, stats.tlb_invalidations));
            emit_line(terminal, "Active Limine CR3 is not replaced; only verified 4 KiB mappings can be added.");
        }
    } else if command.eq_ignore_ascii_case(b"vmtest") {
        match crate::memory::paging::self_test() {
            Ok(count) => emit_format_line(terminal, format_args!("[ok] Virtual memory test passed: {} pages mapped, accessed, translated, unmapped, and reclaimed.", count)),
            Err(error) => emit_format_line(terminal, format_args!("[fail] Virtual memory test stopped safely: {:?}.", error)),
        }
    } else if command.eq_ignore_ascii_case(b"uptime") {
        let seconds = interrupts::ticks() / 100;
        emit_format_line(terminal, format_args!("Uptime: {}m {}s (100 Hz PIT).", seconds / 60, seconds % 60));
    } else if command.eq_ignore_ascii_case(b"input") {
        let s = input::stats();
        emit_format_line(terminal, format_args!("i8042: {} / status 0x{:02X} / command byte 0x{:02X} ({})", yes_no(s.controller_present), s.controller_status, s.command_byte, if s.command_byte_verified { "verified" } else { "unverified" }));
        emit_format_line(terminal, format_args!("Keyboard: {} / bytes {} / last 0x{:02X}", yes_no(s.keyboard_ready), s.keyboard_bytes, s.last_keyboard_byte));
        emit_format_line(terminal, format_args!("PS/2 mouse: {} / bytes {} / last 0x{:02X}", yes_no(s.mouse_ready), s.mouse_bytes, s.last_mouse_byte));
        emit_format_line(terminal, format_args!("Mouse position: {},{} / buttons 0b{:03b}", s.mouse_x, s.mouse_y, s.mouse_buttons));
        emit_format_line(terminal, format_args!("Controller errors: {} / dropped events: {}", s.controller_errors, s.dropped_events));
        emit_line(terminal, "USB HID: not implemented. COM1 serial input remains available.");
    } else if command.eq_ignore_ascii_case(b"reboot") {
        emit_line(terminal, "Requesting a system reset...");
        for _ in 0..100_000 {
            if unsafe { crate::arch::inb(0x64) } & 0x02 == 0 {
                unsafe { crate::arch::outb(0x64, 0xFE); }
                break;
            }
            core::hint::spin_loop();
        }
        crate::arch::disable_interrupts();
        crate::arch::halt_forever();
    } else {
        emit_line(terminal, "Unknown command. Type help.");
    }
}

fn trim_ascii(mut bytes: &[u8]) -> &[u8] {
    while bytes.first().is_some_and(u8::is_ascii_whitespace) { bytes = &bytes[1..]; }
    while bytes.last().is_some_and(u8::is_ascii_whitespace) { bytes = &bytes[..bytes.len() - 1]; }
    bytes
}

fn emit(terminal: &mut Option<Terminal>, text: &str) {
    if let Some(view) = terminal.as_mut() { view.write(text); }
    serial::write_fmt(format_args!("{}", text));
}

fn emit_line(terminal: &mut Option<Terminal>, text: &str) {
    if let Some(view) = terminal.as_mut() { view.write_line(text); }
    serial::write_line(text);
}

fn prompt(terminal: &mut Option<Terminal>) { emit(terminal, "MIXEDOS> "); }

fn emit_format_line(terminal: &mut Option<Terminal>, arguments: core::fmt::Arguments<'_>) {
    struct Output<'a> { terminal: &'a mut Option<Terminal> }
    impl core::fmt::Write for Output<'_> {
        fn write_str(&mut self, text: &str) -> core::fmt::Result {
            if let Some(view) = self.terminal.as_mut() { view.write(text); }
            serial::write_fmt(format_args!("{}", text));
            Ok(())
        }
    }
    let mut output = Output { terminal };
    let _ = output.write_fmt(arguments);
    if let Some(view) = output.terminal.as_mut() { view.write("\n"); }
    serial::write_line("");
}
