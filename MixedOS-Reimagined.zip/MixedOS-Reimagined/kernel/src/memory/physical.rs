//! Bounded physical page-frame allocator for the first memory-management stage.
//!
//! The allocator only returns whole 4 KiB frames described by Limine as usable.
//! It does not modify page tables and does not provide a heap. Callers must not
//! use it from interrupt context. HHDM access is checked before a frame is
//! dereferenced.

use core::cell::UnsafeCell;
use core::hint::spin_loop;
use core::ptr::NonNull;
use core::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};

use crate::boot::limine;

pub const PAGE_SIZE: u64 = 4096;
pub const MAX_TRACKED_PHYSICAL_BYTES: u64 = 64 * 1024 * 1024 * 1024;
const MAX_FRAMES: usize = (MAX_TRACKED_PHYSICAL_BYTES / PAGE_SIZE) as usize;
const BITMAP_WORDS: usize = MAX_FRAMES.div_ceil(64);
const FIRST_MANAGED_ADDRESS: u64 = 1024 * 1024;

#[repr(align(4096))]
struct Bitmap(UnsafeCell<[u64; BITMAP_WORDS]>);
unsafe impl Sync for Bitmap {}

// A set allocation bit means unavailable or currently allocated. The managed
// bitmap distinguishes usable frames from firmware/bootloader-reserved frames.
static ALLOCATED: Bitmap = Bitmap(UnsafeCell::new([u64::MAX; BITMAP_WORDS]));
static MANAGED: Bitmap = Bitmap(UnsafeCell::new([0; BITMAP_WORDS]));
static LOCKED: AtomicBool = AtomicBool::new(false);
static INITIALIZED: AtomicBool = AtomicBool::new(false);
static CURSOR: AtomicUsize = AtomicUsize::new(0);
static MANAGED_FRAMES: AtomicU64 = AtomicU64::new(0);
static FREE_FRAMES: AtomicU64 = AtomicU64::new(0);
static ALLOCATED_FRAMES: AtomicU64 = AtomicU64::new(0);
static ALLOCATION_CALLS: AtomicU64 = AtomicU64::new(0);
static ALLOCATION_FAILURES: AtomicU64 = AtomicU64::new(0);
static FREE_CALLS: AtomicU64 = AtomicU64::new(0);
static FREE_ERRORS: AtomicU64 = AtomicU64::new(0);
static HHDM_OFFSET: AtomicU64 = AtomicU64::new(0);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(transparent)]
pub struct Frame(u64);

impl Frame {
    pub const fn physical_address(self) -> u64 { self.0 }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FreeError {
    NotInitialized,
    UnalignedAddress,
    OutsideManagedMemory,
    AlreadyFree,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct PhysicalStats {
    pub initialized: bool,
    pub hhdm_ready: bool,
    pub hhdm_offset: u64,
    pub managed_frames: u64,
    pub free_frames: u64,
    pub allocated_frames: u64,
    pub allocation_calls: u64,
    pub allocation_failures: u64,
    pub free_calls: u64,
    pub free_errors: u64,
    pub max_tracked_bytes: u64,
}

struct LockGuard;

fn lock() -> LockGuard {
    while LOCKED.compare_exchange_weak(false, true, Ordering::Acquire, Ordering::Relaxed).is_err() {
        spin_loop();
    }
    LockGuard
}

impl Drop for LockGuard {
    fn drop(&mut self) { LOCKED.store(false, Ordering::Release); }
}

#[inline]
unsafe fn bit_get(bitmap: &Bitmap, index: usize) -> bool {
    let words = bitmap.0.get();
    let word = unsafe { (*words).as_ptr().add(index / 64).read() };
    (word & (1u64 << (index % 64))) != 0
}

#[inline]
unsafe fn bit_set(bitmap: &Bitmap, index: usize, value: bool) {
    let words = bitmap.0.get();
    let word_ptr = unsafe { (*words).as_mut_ptr().add(index / 64) };
    let mask = 1u64 << (index % 64);
    let current = unsafe { word_ptr.read() };
    unsafe { word_ptr.write(if value { current | mask } else { current & !mask }); }
}

/// Initialize the allocator from the bootloader's memory map. All non-usable
/// regions remain reserved. The first MiB is deliberately never allocated.
pub fn initialize() -> bool {
    if INITIALIZED.load(Ordering::Acquire) { return true; }
    let Some(regions) = limine::memory_regions() else { return false; };
    let _guard = lock();
    if INITIALIZED.load(Ordering::Relaxed) { return true; }

    unsafe {
        (*ALLOCATED.0.get()).fill(u64::MAX);
        (*MANAGED.0.get()).fill(0);
    }

    let mut managed_count = 0u64;
    for region in regions {
        if region.entry_type != 0 || region.length == 0 { continue; }
        let Some(raw_end) = region.base.checked_add(region.length) else { continue; };
        let start = region.base.max(FIRST_MANAGED_ADDRESS);
        let Some(aligned_start) = start.checked_add(PAGE_SIZE - 1) else { continue; };
        let aligned_start = aligned_start & !(PAGE_SIZE - 1);
        let end = raw_end.min(MAX_TRACKED_PHYSICAL_BYTES) & !(PAGE_SIZE - 1);
        if end <= aligned_start { continue; }

        let first = (aligned_start / PAGE_SIZE) as usize;
        let last = (end / PAGE_SIZE) as usize;
        for frame_index in first..last {
            // Memory maps should not overlap, but don't double-count if a
            // malformed map does contain overlapping usable ranges.
            let already_managed = unsafe { bit_get(&MANAGED, frame_index) };
            if !already_managed {
                unsafe {
                    bit_set(&MANAGED, frame_index, true);
                    bit_set(&ALLOCATED, frame_index, false);
                }
                managed_count = managed_count.saturating_add(1);
            }
        }
    }

    if managed_count == 0 { return false; }
    let hhdm = limine::hhdm_offset()
        .filter(|offset| offset & (PAGE_SIZE - 1) == 0 && is_canonical_48(*offset))
        .unwrap_or(0);
    HHDM_OFFSET.store(hhdm, Ordering::Release);
    MANAGED_FRAMES.store(managed_count, Ordering::Release);
    FREE_FRAMES.store(managed_count, Ordering::Release);
    ALLOCATED_FRAMES.store(0, Ordering::Release);
    CURSOR.store((FIRST_MANAGED_ADDRESS / PAGE_SIZE) as usize, Ordering::Release);
    INITIALIZED.store(true, Ordering::Release);
    true
}

/// Allocate one 4 KiB physical frame. Returns None if uninitialized or full.
/// This function is intended for normal kernel context, never interrupt context.
pub fn allocate_frame() -> Option<Frame> {
    if !INITIALIZED.load(Ordering::Acquire) { return None; }
    let _guard = lock();
    ALLOCATION_CALLS.fetch_add(1, Ordering::Relaxed);
    if FREE_FRAMES.load(Ordering::Relaxed) == 0 {
        ALLOCATION_FAILURES.fetch_add(1, Ordering::Relaxed);
        return None;
    }

    let start = CURSOR.load(Ordering::Relaxed).min(MAX_FRAMES - 1);
    for offset in 0..MAX_FRAMES {
        let index = (start + offset) % MAX_FRAMES;
        let managed = unsafe { bit_get(&MANAGED, index) };
        let allocated = unsafe { bit_get(&ALLOCATED, index) };
        if managed && !allocated {
            unsafe { bit_set(&ALLOCATED, index, true); }
            CURSOR.store((index + 1) % MAX_FRAMES, Ordering::Relaxed);
            FREE_FRAMES.fetch_sub(1, Ordering::Relaxed);
            ALLOCATED_FRAMES.fetch_add(1, Ordering::Relaxed);
            return Some(Frame((index as u64) * PAGE_SIZE));
        }
    }

    // A free-count/bitmap disagreement is an allocator invariant failure.
    ALLOCATION_FAILURES.fetch_add(1, Ordering::Relaxed);
    None
}

/// Return a previously allocated frame to the allocator. Double frees and
/// attempts to free firmware/bootloader memory are rejected and counted.
pub fn free_frame(frame: Frame) -> Result<(), FreeError> {
    if !INITIALIZED.load(Ordering::Acquire) { return Err(FreeError::NotInitialized); }
    if frame.0 & (PAGE_SIZE - 1) != 0 {
        FREE_ERRORS.fetch_add(1, Ordering::Relaxed);
        return Err(FreeError::UnalignedAddress);
    }
    let index_u64 = frame.0 / PAGE_SIZE;
    if index_u64 >= MAX_FRAMES as u64 {
        FREE_ERRORS.fetch_add(1, Ordering::Relaxed);
        return Err(FreeError::OutsideManagedMemory);
    }

    let _guard = lock();
    let index = index_u64 as usize;
    if !unsafe { bit_get(&MANAGED, index) } {
        FREE_ERRORS.fetch_add(1, Ordering::Relaxed);
        return Err(FreeError::OutsideManagedMemory);
    }
    if !unsafe { bit_get(&ALLOCATED, index) } {
        FREE_ERRORS.fetch_add(1, Ordering::Relaxed);
        return Err(FreeError::AlreadyFree);
    }
    unsafe { bit_set(&ALLOCATED, index, false); }
    FREE_FRAMES.fetch_add(1, Ordering::Relaxed);
    ALLOCATED_FRAMES.fetch_sub(1, Ordering::Relaxed);
    FREE_CALLS.fetch_add(1, Ordering::Relaxed);
    Ok(())
}

/// Internal page-table access path for an address already obtained from CR3
/// or a present page-table entry. Unlike `frame_to_hhdm`, this does not require
/// allocator ownership because Limine owns the active root and boot tables.
/// The caller must ensure the physical address really names a live page table.
pub(crate) fn hhdm_pointer_for_page_table(physical_address: u64) -> Option<NonNull<u8>> {
    if physical_address >= MAX_TRACKED_PHYSICAL_BYTES
        || physical_address & (PAGE_SIZE - 1) != 0
    {
        return None;
    }
    let offset = HHDM_OFFSET.load(Ordering::Acquire);
    if offset == 0 || offset & (PAGE_SIZE - 1) != 0 {
        return None;
    }
    let virtual_address = offset.checked_add(physical_address)?;
    if virtual_address & (PAGE_SIZE - 1) != 0 || !is_canonical_48(virtual_address) {
        return None;
    }
    NonNull::new(usize::try_from(virtual_address).ok()? as *mut u8)
}

/// Internal ownership query used by the page-table manager. This rejects
/// bootloader and firmware pages, which are not owned by this allocator.
pub(crate) fn is_allocated_frame_address(physical_address: u64) -> bool {
    if !INITIALIZED.load(Ordering::Acquire)
        || physical_address >= MAX_TRACKED_PHYSICAL_BYTES
        || physical_address & (PAGE_SIZE - 1) != 0
    {
        return false;
    }
    let index = (physical_address / PAGE_SIZE) as usize;
    let _guard = lock();
    unsafe { bit_get(&MANAGED, index) && bit_get(&ALLOCATED, index) }
}

/// Internal free path used only after the paging manager confirms ownership.
pub(crate) fn free_allocated_frame_at(physical_address: u64) -> Result<(), FreeError> {
    free_frame(Frame(physical_address))
}

/// Convert an allocator-owned frame to its Limine HHDM virtual address.
/// Reserved, already-freed, unaligned, and out-of-range frames are rejected.
pub fn frame_to_hhdm(frame: Frame) -> Option<NonNull<u8>> {
    if !INITIALIZED.load(Ordering::Acquire) || frame.0 >= MAX_TRACKED_PHYSICAL_BYTES
        || frame.0 & (PAGE_SIZE - 1) != 0
    { return None; }

    let index = (frame.0 / PAGE_SIZE) as usize;
    {
        let _guard = lock();
        if !unsafe { bit_get(&MANAGED, index) } || !unsafe { bit_get(&ALLOCATED, index) } {
            return None;
        }
    }

    let offset = HHDM_OFFSET.load(Ordering::Acquire);
    if offset == 0 || offset & (PAGE_SIZE - 1) != 0 { return None; }
    let virtual_address = offset.checked_add(frame.0)?;
    if virtual_address & (PAGE_SIZE - 1) != 0 || !is_canonical_48(virtual_address) { return None; }
    NonNull::new(usize::try_from(virtual_address).ok()? as *mut u8)
}

#[inline]
fn is_canonical_48(address: u64) -> bool {
    let upper = address >> 48;
    let sign = (address >> 47) & 1;
    if sign == 0 { upper == 0 } else { upper == 0xFFFF }
}

/// Allocate a frame and clear the full page through the validated HHDM mapping.
pub fn allocate_zeroed_frame() -> Option<Frame> {
    let frame = allocate_frame()?;
    let Some(pointer) = frame_to_hhdm(frame) else {
        let _ = free_frame(frame);
        return None;
    };
    unsafe { pointer.as_ptr().write_bytes(0, PAGE_SIZE as usize); }
    Some(frame)
}

pub fn stats() -> PhysicalStats {
    let offset = HHDM_OFFSET.load(Ordering::Acquire);
    PhysicalStats {
        initialized: INITIALIZED.load(Ordering::Acquire),
        hhdm_ready: offset != 0,
        hhdm_offset: offset,
        managed_frames: MANAGED_FRAMES.load(Ordering::Relaxed),
        free_frames: FREE_FRAMES.load(Ordering::Relaxed),
        allocated_frames: ALLOCATED_FRAMES.load(Ordering::Relaxed),
        allocation_calls: ALLOCATION_CALLS.load(Ordering::Relaxed),
        allocation_failures: ALLOCATION_FAILURES.load(Ordering::Relaxed),
        free_calls: FREE_CALLS.load(Ordering::Relaxed),
        free_errors: FREE_ERRORS.load(Ordering::Relaxed),
        max_tracked_bytes: MAX_TRACKED_PHYSICAL_BYTES,
    }
}

/// Exercise the complete allocate -> HHDM-write -> readback -> free path.
/// Pages are returned on every success/failure path. This is a destructive
/// test only of pages currently owned by the allocator, never arbitrary RAM.
pub fn self_test(page_count: usize) -> Result<usize, &'static str> {
    if page_count == 0 || page_count > 32 { return Err("test size must be between 1 and 32 pages"); }
    let initial_stats = stats();
    if !initial_stats.initialized { return Err("physical frame allocator is not initialized"); }
    if !initial_stats.hhdm_ready { return Err("HHDM unavailable; cannot safely touch allocated frames"); }

    let mut frames = [Frame(0); 32];
    let mut allocated = 0usize;
    for index in 0..page_count {
        match allocate_zeroed_frame() {
            Some(frame) => { frames[index] = frame; allocated += 1; }
            None => {
                release_test_frames(&frames, allocated);
                let after_cleanup = stats();
                if after_cleanup.free_frames != initial_stats.free_frames
                    || after_cleanup.allocated_frames != initial_stats.allocated_frames
                    || after_cleanup.free_errors != initial_stats.free_errors
                {
                    return Err("allocator accounting changed after failed test cleanup");
                }
                return Err("not enough free frames or HHDM mapping failed");
            }
        }
    }

    let mut verified_pages = 0usize;
    let mut failed = false;
    for frame in frames.iter().take(page_count) {
        let Some(pointer) = frame_to_hhdm(*frame) else { failed = true; break; };
        let words = pointer.as_ptr().cast::<u64>();
        for word_index in 0..(PAGE_SIZE as usize / core::mem::size_of::<u64>()) {
            let actual = unsafe { words.add(word_index).read_volatile() };
            if actual != 0 { failed = true; break; }
        }
        if failed { break; }
        for word_index in 0..(PAGE_SIZE as usize / core::mem::size_of::<u64>()) {
            let pattern = 0x4D49_5845_444F_5300u64
                ^ frame.0.rotate_left(17)
                ^ (word_index as u64).wrapping_mul(0x9E37_79B9_7F4A_7C15);
            unsafe { words.add(word_index).write_volatile(pattern); }
        }
        for word_index in 0..(PAGE_SIZE as usize / core::mem::size_of::<u64>()) {
            let expected = 0x4D49_5845_444F_5300u64
                ^ frame.0.rotate_left(17)
                ^ (word_index as u64).wrapping_mul(0x9E37_79B9_7F4A_7C15);
            let actual = unsafe { words.add(word_index).read_volatile() };
            if actual != expected { failed = true; break; }
        }
        if failed { break; }
        verified_pages += 1;
    }

    // Zero before freeing so test patterns do not remain in reusable pages.
    for frame in frames.iter().take(allocated) {
        if let Some(pointer) = frame_to_hhdm(*frame) {
            unsafe { pointer.as_ptr().write_bytes(0, PAGE_SIZE as usize); }
        }
    }
    release_test_frames(&frames, allocated);
    let after_cleanup = stats();
    if after_cleanup.free_frames != initial_stats.free_frames
        || after_cleanup.allocated_frames != initial_stats.allocated_frames
        || after_cleanup.free_errors != initial_stats.free_errors
    {
        return Err("allocator accounting changed after test cleanup");
    }

    if failed { Err("read-back mismatch while testing allocated physical frames") }
    else { Ok(verified_pages) }
}

fn release_test_frames(frames: &[Frame; 32], count: usize) {
    for frame in frames.iter().take(count) {
        let _ = free_frame(*frame);
    }
}
