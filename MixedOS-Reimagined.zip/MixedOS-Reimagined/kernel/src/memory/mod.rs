pub mod boot_map;
pub mod physical;
pub mod paging;


#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct MemoryInitStatus {
    pub allocator_ready: bool,
    pub hhdm_ready: bool,
    pub paging_ready: bool,
}

/// Initialize the physical frame allocator after Limine has supplied the
/// memory map and HHDM response. No page tables are changed in this stage.
pub fn initialize() -> MemoryInitStatus {
    let allocator_ready = physical::initialize();
    let paging_ready = allocator_ready && paging::initialize();
    MemoryInitStatus {
        allocator_ready,
        hhdm_ready: physical::stats().hhdm_ready,
        paging_ready,
    }
}
