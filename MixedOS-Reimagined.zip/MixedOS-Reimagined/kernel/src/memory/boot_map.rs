use crate::boot::limine;

#[derive(Clone, Copy)]
pub struct MemorySummary {
    pub usable_bytes: u64,
    pub usable_regions: usize,
}

pub fn summary() -> Option<MemorySummary> {
    let (usable_bytes, usable_regions) = limine::usable_memory();
    if usable_regions == 0 {
        None
    } else {
        Some(MemorySummary {
            usable_bytes,
            usable_regions,
        })
    }
}
