use core::cell::UnsafeCell;
use core::sync::atomic::{AtomicU64, Ordering};

use crate::{arch, console::serial};

core::arch::global_asm!(include_str!("../arch/x86_64/interrupts.S"));

const IDT_ENTRIES: usize = 256;
const PIC1_COMMAND: u16 = 0x20;
const PIC1_DATA: u16 = 0x21;
const PIC2_COMMAND: u16 = 0xA0;
const PIC2_DATA: u16 = 0xA1;
const PIT_COMMAND: u16 = 0x43;
const PIT_CHANNEL_0: u16 = 0x40;
const PIT_HZ: u32 = 100;

#[repr(C, packed)]
#[derive(Clone, Copy)]
struct IdtEntry {
    offset_low: u16,
    selector: u16,
    ist: u8,
    attributes: u8,
    offset_middle: u16,
    offset_high: u32,
    reserved: u32,
}

impl IdtEntry {
    const MISSING: Self = Self {
        offset_low: 0,
        selector: 0,
        ist: 0,
        attributes: 0,
        offset_middle: 0,
        offset_high: 0,
        reserved: 0,
    };

    fn interrupt_gate(handler: usize, selector: u16) -> Self {
        Self {
            offset_low: handler as u16,
            selector,
            ist: 0,
            attributes: 0x8E,
            offset_middle: (handler >> 16) as u16,
            offset_high: (handler >> 32) as u32,
            reserved: 0,
        }
    }
}

#[repr(C, align(16))]
struct IdtTable(UnsafeCell<[IdtEntry; IDT_ENTRIES]>);
unsafe impl Sync for IdtTable {}

static IDT: IdtTable = IdtTable(UnsafeCell::new([IdtEntry::MISSING; IDT_ENTRIES]));
static TIMER_TICKS: AtomicU64 = AtomicU64::new(0);

#[repr(C, packed)]
struct Idtr {
    limit: u16,
    base: u64,
}

#[repr(C)]
pub struct InterruptFrame {
    r15: u64,
    r14: u64,
    r13: u64,
    r12: u64,
    r11: u64,
    r10: u64,
    r9: u64,
    r8: u64,
    rdi: u64,
    rsi: u64,
    rbp: u64,
    rdx: u64,
    rcx: u64,
    rbx: u64,
    rax: u64,
    vector: u64,
    error_code: u64,
    instruction_pointer: u64,
    code_segment: u64,
    flags: u64,
}

unsafe extern "C" {
    static mixedos_isr_table: [usize; IDT_ENTRIES];
}

pub fn initialize() {
    unsafe {
        let selector: u16;
        core::arch::asm!("mov {0:x}, cs", out(reg) selector, options(nomem, nostack, preserves_flags));

        let table = IDT.0.get();
        for vector in 0..IDT_ENTRIES {
            let handler = mixedos_isr_table.as_ptr().add(vector).read();
            (*table)[vector] = IdtEntry::interrupt_gate(handler, selector);
        }

        let idtr = Idtr {
            limit: (core::mem::size_of::<[IdtEntry; IDT_ENTRIES]>() - 1) as u16,
            base: table as u64,
        };
        core::arch::asm!("lidt [{}]", in(reg) &idtr, options(readonly, nostack, preserves_flags));
    }

    remap_and_enable_pic();
    initialize_pit();
    arch::enable_interrupts();
    serial::write_line("[ok] IDT installed; PIT timer IRQ enabled; legacy input is initialized separately");
}

fn remap_and_enable_pic() {
    unsafe {
        arch::outb(PIC1_COMMAND, 0x11); io_wait();
        arch::outb(PIC2_COMMAND, 0x11); io_wait();
        arch::outb(PIC1_DATA, 0x20); io_wait();
        arch::outb(PIC2_DATA, 0x28); io_wait();
        arch::outb(PIC1_DATA, 0x04); io_wait();
        arch::outb(PIC2_DATA, 0x02); io_wait();
        arch::outb(PIC1_DATA, 0x01); io_wait();
        arch::outb(PIC2_DATA, 0x01); io_wait();
        // Unmask IRQ0 (PIT) only. PS/2 IRQ1/IRQ12 are disabled in the i8042
        // command byte and the shared poller is the sole owner of port 0x60.
        // 0xFE = IRQ0 enabled, IRQ1 masked; all other master IRQs masked.
        arch::outb(PIC1_DATA, 0xFE);
        arch::outb(PIC2_DATA, 0xFF);
    }
}

fn io_wait() {
    unsafe { arch::outb(0x80, 0); }
}

fn initialize_pit() {
    let divisor = 1_193_182u32 / PIT_HZ;
    unsafe {
        arch::outb(PIT_COMMAND, 0x36);
        arch::outb(PIT_CHANNEL_0, divisor as u8);
        arch::outb(PIT_CHANNEL_0, (divisor >> 8) as u8);
    }
}

pub fn ticks() -> u64 {
    TIMER_TICKS.load(Ordering::Relaxed)
}

#[unsafe(no_mangle)]
pub extern "C" fn mixedos_interrupt_dispatch(frame: *const InterruptFrame) {
    if frame.is_null() {
        serial::write_line("[fatal] interrupt dispatcher received a null frame");
        arch::halt_forever();
    }
    let frame = unsafe { &*frame };
    match frame.vector {
        32 => {
            TIMER_TICKS.fetch_add(1, Ordering::Relaxed);
            unsafe { arch::outb(PIC1_COMMAND, 0x20); }
        }
        33 => {
            // PS/2 input runs in polling mode. A stale/spurious IRQ is
            // acknowledged without touching port 0x60; the unified input
            // poller remains the only owner of controller output bytes.
            unsafe { arch::outb(PIC1_COMMAND, 0x20); }
        }
        0..=31 => {
            serial::write_fmt(format_args!(
                "\r\n*** MIXEDOS CPU EXCEPTION {} (error {:#x}) at RIP {:#018x} ***\r\n",
                frame.vector,
                frame.error_code,
                frame.instruction_pointer
            ));
            if frame.vector == 14 {
                let fault_address: u64;
                unsafe { core::arch::asm!("mov {}, cr2", out(reg) fault_address, options(nomem, nostack, preserves_flags)); }
                serial::write_fmt(format_args!("Page fault address: {:#018x}\r\n", fault_address));
            }
            arch::halt_forever();
        }
        34..=39 => {
            serial::write_fmt(format_args!("\r\n[warn] unexpected master PIC IRQ vector {}\r\n", frame.vector));
            unsafe { arch::outb(PIC1_COMMAND, 0x20); }
        }
        40..=47 => {
            serial::write_fmt(format_args!("\r\n[warn] unexpected slave PIC IRQ vector {}\r\n", frame.vector));
            unsafe {
                arch::outb(PIC2_COMMAND, 0x20);
                arch::outb(PIC1_COMMAND, 0x20);
            }
        }
        _ => {
            serial::write_fmt(format_args!("\r\n[warn] unexpected interrupt vector {}\r\n", frame.vector));
        }
    }
}
