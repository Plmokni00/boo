/* Freestanding C ABI support linked into the Rust kernel.
 * No hosted C library, startup objects, or operating-system headers are used.
 */
#include "../../../include/mixedos/abi.h"

mixedos_u32 mixedos_c_abi_revision(void) {
    return 1u;
}

void *memcpy(void *destination, const void *source, mixedos_size_t length) {
    mixedos_u8 *out = (mixedos_u8 *)destination;
    const mixedos_u8 *in = (const mixedos_u8 *)source;
    for (mixedos_size_t i = 0; i < length; ++i) out[i] = in[i];
    return destination;
}

void *memset(void *destination, int value, mixedos_size_t length) {
    mixedos_u8 *out = (mixedos_u8 *)destination;
    for (mixedos_size_t i = 0; i < length; ++i) out[i] = (mixedos_u8)value;
    return destination;
}

void *memmove(void *destination, const void *source, mixedos_size_t length) {
    mixedos_u8 *out = (mixedos_u8 *)destination;
    const mixedos_u8 *in = (const mixedos_u8 *)source;
    unsigned long out_address = (unsigned long)out;
    unsigned long in_address = (unsigned long)in;
    if (out_address <= in_address || out_address - in_address >= length) {
        for (mixedos_size_t i = 0; i < length; ++i) out[i] = in[i];
    } else {
        for (mixedos_size_t i = length; i != 0; --i) out[i - 1] = in[i - 1];
    }
    return destination;
}

int memcmp(const void *left, const void *right, mixedos_size_t length) {
    const mixedos_u8 *a = (const mixedos_u8 *)left;
    const mixedos_u8 *b = (const mixedos_u8 *)right;
    for (mixedos_size_t i = 0; i < length; ++i) {
        if (a[i] != b[i]) return (int)a[i] - (int)b[i];
    }
    return 0;
}
