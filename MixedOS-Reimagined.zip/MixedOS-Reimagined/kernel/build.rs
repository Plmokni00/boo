use std::{env, path::Path};

fn main() {
    println!("cargo:rerun-if-env-changed=MIXEDOS_C_OBJECT");
    let object = env::var("MIXEDOS_C_OBJECT").expect(
        "MIXEDOS_C_OBJECT is missing. Build through Build.bat/build.ps1 so the freestanding C runtime is compiled and linked.",
    );
    if !Path::new(&object).is_file() {
        panic!("MIXEDOS_C_OBJECT does not point to a compiled object file: {object}");
    }
    println!("cargo:rustc-link-arg={object}");
}
