# MixedOS — clean-room rebuild

MixedOS is an independent x86_64 operating-system project. It is **not** a Linux distribution: its kernel is freestanding Rust and does not use the Linux kernel. Limine is currently used as a third-party firmware bootloader only.

This repository is a clean-room replacement for the previous `MixedOS.zip`. None of that archive's source files, bundled compilers, generated output, ISO images, or nested project copies are included. The previous archive was used only to identify the project name and goals.

## Current milestone: Stage 4 virtual memory foundation

Stage 1 was built on the user's Windows machine and booted in VirtualBox. Stage 2's keyboard, mouse, interactive console, and command processing were confirmed in the user's VirtualBox screenshot. Stage 3 adds a bounded physical page-frame allocator while preserving the working Stage 2 input sources byte-for-byte.

Implemented in source:

- A freestanding Rust x86_64 kernel loaded through Limine.
- Early COM1 diagnostics and non-blocking COM1 input.
- A direct RGB framebuffer console for supported 24-bit and 32-bit modes.
- Limine memory-map iteration and higher-half direct-map request handling.
- A 4 KiB physical frame allocator using managed/allocated bitmaps. Only Limine type-0 usable RAM is considered; non-usable ranges and the first MiB remain reserved.
- A 64 GiB physical-address tracking ceiling, checked region arithmetic, checked HHDM pointer conversion, and a zeroed-frame helper.
- Invalid/double-free detection plus `mem`, `frames`, and `memtest` diagnostics. `memtest` writes and verifies every 64-bit word in eight owned frames, clears them, and returns them.
- A conservative four-level x86-64 page-table manager that preserves Limine's active CR3 root, inspects existing huge pages, maps/unmaps allocator-owned 4 KiB frames, enforces parent permission constraints, tracks/reclaims only MixedOS-owned table pages, and invalidates local TLB entries.
- CPU physical-address-width/NX detection, verified EFER.NXE enablement where supported, and CR0.WP enforcement.
- `paging` and `vmtest` diagnostics. `vmtest` uses an unused PML4 slot, maps two test frames with distinct user/supervisor permissions, performs an actual supervisor virtual read/write and checks both translations, then unmaps and reclaims the temporary tables.
- A 256-entry IDT with stubs for CPU exception vectors 0–31 and legacy PIC IRQs 0 and 1.
- CPU exception reporting to COM1, including the faulting instruction pointer and page-fault address.
- Legacy 8259 PIC remapping and a 100 Hz 8254 PIT tick counter. This is not an APIC or high-resolution timer implementation.
- A unified kernel input event queue for PS/2 keyboard, PS/2 mouse, and COM1 serial input.
- A shared i8042 controller poller that demultiplexes primary keyboard and auxiliary mouse bytes, a US-layout keyboard decoder, and a standard three-byte PS/2 mouse packet decoder.
- A small **ring-0 kernel command loop** with `help`, `clear`, `mem`, `frames`, `memtest`, `uptime`, `input`, and `reboot`.
- A freestanding C runtime with a versioned ABI. The user's Stage 1 build confirms the earlier build pipeline compiled and linked the baseline.
- A Windows-native build entry point (`Build.bat`) that does not use WSL or Docker.

The command loop is only a kernel debugging console. It is **not** a user-mode shell, POSIX shell, process environment, or desktop. The input stack currently supports i8042-compatible PS/2 keyboard and standard three-byte PS/2 mouse devices, plus COM1 serial input. USB HID drivers (including USB tablet/mouse and USB keyboard), wheel packets, international layouts, and configurable key repeat are not implemented. The kernel actively polls in a non-sleeping bring-up loop; PIT IRQ0 remains enabled while PS/2 IRQ delivery is disabled. This temporary busy loop can use a full CPU core until a scheduler-aware idle task exists.

**Stage 4 deliberately does not replace CR3 or switch address spaces.** It only adds checked 4 KiB mappings into the active Limine tree, refuses to widen existing parent permissions, and reclaims only page-table frames that MixedOS allocated. This is still a uniprocessor bring-up implementation and must pass the Windows build plus repeated VirtualBox `vmtest` runs before it is considered verified.

Not implemented: kernel heap/global allocator, GDT/TSS ownership, user-mode execution, system calls, process/thread scheduling, per-process address spaces, PCI enumeration, storage drivers, a writable filesystem, USB HID, TCP/IP, Wi-Fi, audio, a desktop/window manager, Java VM, Lua runtime, SQLite integration, GPU acceleration, Firefox, Windows API compatibility, installer, or recovery/update services. No menu, icon, service status, or application shortcut is supplied to imply that these features exist.

## Build on Windows

1. Extract the repository to a writable folder.
2. Run `Build.bat` normally from File Explorer or a terminal.
3. The script checks for Rust stable, LLVM/Clang, and xorriso. Where possible it uses WinGet to install the official Rustup and LLVM packages, plus MSYS2 for xorriso.
4. Limine's binary release is downloaded to `build/deps` and checked against a pinned SHA-256 before extraction.
5. The build compiles the freestanding C runtime, builds the Rust kernel for `x86_64-unknown-none`, stages an ISO root, writes a BIOS/UEFI hybrid ISO, then runs Limine's BIOS installation step.

Output:

- `build/artifacts/MixedOS-x86_64.iso`
- `build/artifacts/MixedOS-x86_64.iso.sha256`
- `target/x86_64-unknown-none/release/mixedos-kernel` (kernel ELF)
- `build/logs/build-YYYYMMDD-HHMMSS.log` (build transcript)

Useful commands:

```powershell
.\Build.bat
.\Build.bat -KernelOnly
.\Build.bat -Clean
.\Build.bat -NoInstall
```

`-KernelOnly` skips ISO authoring and builds the kernel only. `-Clean` removes generated `build` and Cargo `target` directories. `-NoInstall` makes missing host dependencies a hard error instead of trying to install them; a full ISO build still downloads the pinned Limine archive if it is not cached.

No WSL or Docker is used. MSYS2 is only a Windows-hosted way to obtain the xorriso ISO authoring utility; it is not an OS runtime and is not used to compile the kernel.

## Stage 2 input regression test

Use a BIOS or UEFI VirtualBox VM with its standard PS/2 keyboard enabled and, preferably, a PS/2 pointing device plus COM1 serial console. Boot the new ISO and click inside the VM window to capture keyboard input. The framebuffer should show separate keyboard and mouse receive counters. Type `input` to inspect readiness and raw-byte counters, then test `help`, `mem`, `uptime`, `clear`, Shift, Caps Lock, Tab, Enter, and Backspace. Move/click the mouse and verify its count, position, and button state change independently. `reboot` requests a reset through the legacy keyboard controller. For serial testing, configure COM1 as a host pipe or file and connect a terminal at 38400 baud, 8-N-1.

If the framebuffer is unavailable, the kernel should still provide diagnostics and command input through COM1. If the VM freezes, capture the complete serial output and note the VM firmware, virtual CPU, RAM, display controller, and keyboard configuration.

## Stage 3 physical memory and Stage 4 virtual memory tests

After rebuilding and booting this release, run `mem`, `frames`, `memtest`, and `paging`. Confirm the Stage 3 allocator test still returns all eight pages. Then run `vmtest` only in a disposable VirtualBox VM: it performs real virtual reads and writes through newly installed page-table mappings. After it passes, run `paging` and `frames` again; MixedOS-owned table count, allocated frames, and free frames must return to their pre-test values, and free errors must remain unchanged. Repeat `vmtest` several times, then confirm keyboard and mouse input still work. A kernel heap, process address spaces, and user-mode execution are not part of this stage.

A VM boot does not prove physical hardware support. The timer is currently a legacy PIT/PIC implementation. This input stack supports legacy PS/2 keyboard and three-byte mouse devices plus COM1; USB HID keyboard, mouse, and tablet support is not implemented.

## Engineering rules

- Do not mark a subsystem complete based on a type, icon, interface, or build-only placeholder.
- Preserve the distinction between source implemented, compiled, VM tested, and hardware tested.
- Keep user applications out of the kernel as user-mode support is added.
- Keep kernel, native ABI, and future user-space APIs versioned and documented.
- Add tests with each subsystem and record the exact environment used to validate them.
- Introduce languages when they have executable responsibilities; do not add empty integration folders.

See [docs/STAGE2.md](docs/STAGE2.md), [docs/STAGE3.md](docs/STAGE3.md), [docs/PHYSICAL-MEMORY.md](docs/PHYSICAL-MEMORY.md), [docs/INPUT-SUBSYSTEM.md](docs/INPUT-SUBSYSTEM.md), [docs/STAGE4.md](docs/STAGE4.md), [docs/STATUS.md](docs/STATUS.md), [docs/ROADMAP.md](docs/ROADMAP.md), and [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).
