# Validation plan

## Source checks

Run:

```powershell
python tools/validate_source.py
```

This checks required source files, architecture API exports, key Stage 2 input invariants, Stage 3/4 memory-manager markers, the unchanged Stage 2 input-driver hash baseline, and repository hygiene. It is a source-structure check, not a Rust compiler or OS test. `python tools/test_memory_model.py` exercises a host-side frame allocator model. `python tools/test_paging_model.py` exercises a host-side four-level mapping/permission/reclamation model. Neither executes privileged Rust code or the CPU TLB.

## Build checks

Run `Build.bat` from a fresh Windows account or a clean Windows VM. Record:

- Windows version and architecture.
- `rustc --version` and `cargo --version`.
- `clang --version`.
- `xorriso -version`.
- Limine archive version and verified SHA-256.
- Build log and resulting ISO SHA-256.

The build is not validated until the kernel ELF and ISO exist and the build script exits with code 0.

## VM boot and interactive-kernel checks

Use separate BIOS and UEFI VM configurations. Attach a serial console and use the standard emulated PS/2 keyboard (VirtualBox provides one by default unless changed by the VM configuration). Click inside the VM to capture host keyboard input. Record firmware mode, virtual CPU model/count, RAM, display controller, and keyboard device.

1. Limine displays the MixedOS entry and loads the kernel.
2. COM1 reports the Rust kernel entry and ABI revision.
3. The framebuffer displays the interactive MixedOS console (if the bootloader provides supported RGB output).
4. The IDT installs and the PIC/PIT timer is enabled without an immediate fault.
5. The console accepts `help` and displays the command list.
6. `mem` reports boot-map and managed/free/allocated totals. `free + allocated` must equal `managed`.
7. `uptime` increases over time (nominally based on 100 Hz PIT ticks).
8. `clear` clears the framebuffer console.
9. The console shows separate keyboard and PS/2 mouse counters. Type letters and numbers; test Shift, Caps Lock, Tab, Enter, Backspace, and Escape. Move and click the mouse; the mouse byte counter, position, and button field should update independently.
10. Run `input` to print controller configuration, keyboard/mouse readiness, raw byte counters, last bytes, mouse position/buttons, controller errors, and event-queue drops.
11. Optional: COM1 serial receive can enter commands at 38400 baud, 8-N-1. Serial bytes are normalized into the same input event queue.
12. `reboot` requests a reset. A VM that lacks an emulated PS/2 controller may not reset through this path.
13. Trigger no deliberate CPU faults on a production machine. Exception logging should be tested only in a disposable VM and by a separately reviewed test build.

A VM boot is not a hardware-compatibility result. Timer support is currently 8254 PIT + 8259 PIC, and hardware input is legacy PS/2 only. USB HID, APIC, laptop-specific controllers, and physical-device support are not implied. The Stage 2 polling loop intentionally busy-spins until a scheduler-aware idle task exists.

## Hardware checks

Only after VM tests pass, test on a spare machine. Record motherboard, CPU, firmware mode, graphics adapter, display mode, storage controller, and boot media. Do not mark networking, storage, audio, USB, or GPU support based only on device detection.


## Stage 3 memory acceptance

After boot, run `mem`, `frames`, `memtest`, and `frames` again. The full-page
self-test must pass; managed frame count must not change; allocated frames must
return to their starting value; free-frame count must return to its starting
value; and free errors must remain zero. Repeat `memtest` multiple times. Also
verify keyboard typing and mouse movement/clicks after the memory commands.

## Stage 4 virtual-memory acceptance

Perform this only in a disposable VirtualBox VM after the Windows build and a
normal boot succeed. First run `help`, `input`, `mem`, `frames`, and `paging` to
confirm earlier functionality remains. Then run `vmtest`. It performs actual
virtual reads/writes through two new 4 KiB mappings; a paging bug can fault the
kernel. A passing result must be followed by `paging` and `frames`: owned page
tables, allocated physical frames, and free frames return to baseline; free
errors are unchanged; the test virtual addresses are not mapped. Repeat the test
several times, then test keyboard typing and mouse motion/clicks again.
