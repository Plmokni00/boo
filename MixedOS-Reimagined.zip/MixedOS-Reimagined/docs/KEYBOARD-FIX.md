# Stage 2 keyboard input revision

## User-visible problem

The prior polling revision still called `HLT` after an empty poll. That made the keyboard poller dependent on the PIT interrupt waking the CPU, defeating the intended independence from interrupt delivery. It also relied on controller translation rather than explicitly selecting the keyboard's scan-code set.

## Changes in this revision

- The shell no longer executes `HLT`; it continuously polls PS/2 and COM1 input with a CPU `PAUSE` hint when idle. This is intentionally a busy loop for early bring-up and will be replaced by a scheduler-aware idle task later.
- The i8042 setup disables keyboard and auxiliary IRQ delivery and disables controller scan-code translation.
- The keyboard is explicitly asked to disable scanning, select scan-code set 1 (`F0 01`), and re-enable scanning (`F4`), with each command byte acknowledged separately.
- Startup prints the controller status/configuration byte and whether set-1 selection and scan enable were acknowledged.
- The PS/2 driver still supports the US layout, Shift, Caps Lock, Tab, Enter, Backspace, digits, and punctuation.

## Rebuild and test

1. Extract the source ZIP into a new folder.
2. Run `Build.bat` normally.
3. Replace the ISO in VirtualBox with `build/artifacts/MixedOS-x86_64.iso`.
4. Click inside the VM window to capture the host keyboard.
5. The console should print `[kbd] i8042 present; status=...` followed by the keyboard initialization result.
6. Type `help`, then test letters, digits, Shift, Caps Lock, Tab, Enter, and Backspace.

If no key events arrive, the visible i8042 status/config line will help distinguish a nonresponsive controller from scan-code handling. USB HID is not implemented; this build expects the standard emulated PS/2 keyboard in VirtualBox.

## Verification limits

Repository source validation and assembly checks do not replace a Windows Rust/Cargo build or an actual VirtualBox typing test. Keyboard support is PS/2-only; USB HID is not implemented.


## IRQ mask correction

The keyboard still failed with polling enabled because the PIC master mask was `0xFD` (`11111101b`). That masks IRQ0 (the PIT) but unmasks IRQ1 (the keyboard). If IRQ1 was raised, the old IRQ1 handler read port `0x60` and discarded the scan code before the polling loop could see it. The mask is now `0xFE` (`11111110b`): IRQ0 is enabled, IRQ1 is masked. The defensive IRQ1 handler no longer reads port `0x60`; it re-masks IRQ1 and sends EOI.


## Fix 3: PIC routing correction and receive telemetry

The master PIC mask is now `0xFE`, which unmasks IRQ0 (PIT) and masks IRQ1 (keyboard). The old `0xFD` value inverted those two bits. The IRQ1 fallback handler does not read port `0x60`; it masks IRQ1 defensively and sends EOI, preserving any pending byte for the polling loop.

The controller command byte is read back after being written. Startup reports whether IRQ/port/translation bits match the requested polling configuration. The framebuffer console has a compact `PS/2 RX` / `LAST` indicator that updates when raw keyboard bytes are received, making it clear whether data reaches the controller even if scan-code decoding fails.
