# MixedOS physical memory manager (Stage 3)

## Scope

Stage 3 adds a physical page-frame allocator. It manages 4 KiB frames using
Limine's memory map and exposes checked access through Limine's higher-half
direct map (HHDM). It deliberately does **not** change CR3, install new page
tables, or provide a general-purpose heap. Those are later layers built after
physical frame allocation has been tested on the target VM.

## Memory safety rules

- Only Limine memory-map entries whose type is `USABLE` (type 0) are candidates.
- Every non-usable region remains reserved; kernel, bootloader, ACPI, framebuffer,
  module, and firmware regions are never added to the allocator.
- Physical memory below 1 MiB is always reserved.
- Regions are rounded inward: start up to a 4 KiB boundary and end down to one.
- Address arithmetic is checked for overflow.
- The first version tracks physical addresses below 64 GiB. Usable RAM above
  that limit is intentionally left unmanaged, not truncated into another frame.
- Two bitmaps distinguish managed frames from allocated/reserved frames.
- Free rejects unaligned addresses, untracked/reserved frames, and double frees.
- Allocation is serialized by a small atomic lock. The allocator is not callable
  from interrupt context; the current timer interrupt never allocates memory.

## HHDM access

`frame_to_hhdm` only accepts an opaque frame token that is currently managed
and allocated. It validates the HHDM response, page alignment, arithmetic, and
48-bit canonical address form before returning a pointer. `allocate_zeroed_frame`
will return a frame to the allocator if the HHDM translation cannot be formed.
Callers must still retain ownership while using the returned pointer.

## Shell diagnostics

- `mem`: boot map totals, managed/free/allocated totals, and HHDM readiness.
- `frames`: frame counts, operation counters, errors, HHDM base, and tracking cap.
- `memtest`: allocates eight frames, clears them, writes and reads a distinct
  64-bit pattern across every word, clears them again, then frees all frames.
  It verifies the full ownership and direct-map path and should leave the free
  frame count unchanged.

## Known boundaries

This is a uniprocessor bring-up allocator. It does not yet have SMP locking,
NUMA awareness, page-table editing, copy-on-write, user/supervisor page policy,
or a heap/global allocator. Keep allocations out of interrupt handlers. The
next stage should add virtual-page mapping on top of these frames; a heap comes
after mapping and rollback tests exist.

## Acceptance checks

1. Boot remains interactive and the keyboard/mouse diagnostics still work.
2. `mem` shows sensible totals and `free + allocated == managed`.
3. `frames` shows zero free errors and zero allocation failures before tests.
4. `memtest` passes and returns all eight frames.
5. Running `frames` after `memtest` shows the same free count as before and no
   increment to free errors.
6. Repeating `memtest` several times succeeds without changing `managed` or
   leaking `allocated` frames.
