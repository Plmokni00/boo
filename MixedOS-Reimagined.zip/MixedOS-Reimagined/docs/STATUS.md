# Implementation and validation status

Status vocabulary:

- **Not started** — no implementation.
- **Foundation** — design, ABI, or early support exists; meaningful functionality is incomplete.
- **Source implemented** — executable source exists, but compilation may not have been verified.
- **Compiled** — successful build recorded for a named toolchain and source version.
- **VM tested** — the actual image was booted and behavior was observed in a named VM configuration.
- **Hardware tested** — behavior was tested on identified physical hardware.

## User-confirmed baseline (2026-11-11)

The user supplied successful Windows build logs for Stage 1, Stage 2, and the unified input subsystem revisions. The user also supplied a VirtualBox screenshot showing the live framebuffer console, keyboard receive counter, mouse receive counter, mouse position/buttons, zero input errors/dropped events, and successful execution of `help`, `mem`, `uptime`, and `input`. This confirms that the Stage 2 interactive input path works in the user's VM. The exact VirtualBox firmware mode, machine profile, virtual CPU model, and VM RAM settings were not recorded.

## Current implementation snapshot

| Subsystem | Status | Evidence / limit |
|---|---|---|
| x86_64 kernel entry and Limine boot | VM tested by user | Stage 1 successful Windows build and VirtualBox boot; later interactive console screenshot confirms the kernel still starts. |
| Architecture API facade | Source implemented | Public x86_64 port I/O, CPU control, interrupt control, and FPU initialization exports. |
| Serial diagnostics | VM tested by user | COM1 diagnostics; serial input is normalized into the shared event queue. |
| Framebuffer output | VM tested by user | Screenshot shows the interactive text console. Software rendering only; no GPU acceleration. |
| Memory map and HHDM | Compiled in prior release; Stage 3 integration source implemented | Limine memory-map and higher-half direct-map responses are used by the frame allocator. |
| C ABI | Compiled in user-reported build | Freestanding C runtime object linked; kernel checks ABI revision. |
| IDT and exception reporting | VM tested by user | Stage 2 kernel boots with the IDT; detailed fault-path coverage still needs dedicated tests. |
| Legacy timer | VM tested by user | Screenshot shows increasing uptime; PIT nominally 100 Hz, no APIC/high-resolution timer. |
| Unified input subsystem | VM tested by user | Screenshot shows changing keyboard/mouse byte counters, typed shell commands, mouse coordinates/buttons, and zero errors/dropped events. |
| PS/2 keyboard | VM tested by user | Screenshot-confirmed typed `help`, `mem`, `uptime`, and `input` commands. USB HID and international layouts are not implemented. |
| PS/2 mouse | VM tested by user | Screenshot-confirmed mouse packet count, position, and button diagnostics. Wheel and framebuffer cursor are not implemented. |
| Kernel command loop | VM tested by user | `help`, `mem`, `uptime`, and `input` visibly executed. This is still a ring-0 debug console, not a user shell. |
| Physical frame allocator | VM tested by user | User supplied a Stage 3 VirtualBox screenshot showing managed/free pages, eight-page `memtest` success, zero free errors, and restored allocation accounting. |
| Page-table manager / virtual mapping | Stage 4 source implemented; Windows build/VM test pending | Four-level active-root walker, 4 KiB map/unmap, permission checks, NX/WP setup, ownership registry, local TLB invalidation, large-page inspection, and `paging`/`vmtest` commands. Host-side model/source checks do not execute the privileged Rust implementation. |
| Kernel heap/global allocator | Not started | Deferred until frame allocation and HHDM access pass repeated VM tests. |
| GDT/TSS and privilege isolation | Not started | No MixedOS-owned TSS/IST stacks or user mode yet. |
| Processes / threads / user mode | Not started | No scheduler, privilege transition, or process loader. |
| Persistent filesystem | Not started | No disk driver or filesystem implementation. |
| Ethernet / Wi-Fi / TCP/IP | Not started | No network drivers or stack. |
| Clock / timezone service | Not started | PIT tick counter only; no RTC, timezone, or wall clock. |
| Desktop / window manager | Not started | No user-space app model or compositor. |
| Java / Lua / Zig runtimes | Not started | Not started. |
| SQLite | Not started | No persistent filesystem to support it. |
| Firefox | Not started | No browser binary or engine port. |
| Windows compatibility | Not started | No PE loader or Win32 APIs. |
| Installer / updater | Not started | No partition or recovery tooling. |

## Stage 4 validation boundary

Stage 4 preserves the user-confirmed Stage 2 input files byte-for-byte and builds
on the user-confirmed Stage 3 physical allocator. It adds page-table mapping and
unmapping to the active Limine root without replacing CR3. Source validation and
host-side models can check structural and algorithmic invariants, but they do
not compile or execute privileged Rust code. Rust/Cargo are not installed in
the authoring environment, so the Stage 4 Rust kernel has **not** been compiled,
linked, or VM-tested here.

The user must build the ZIP on Windows, boot it in VirtualBox, run `paging`, then
run `vmtest` in a disposable VM. `vmtest` must perform actual virtual loads and
stores, verify effective permission bits, unmap both pages, reclaim all new
intermediate page tables, and restore the physical allocator's free/allocated
counts. The user must then confirm keyboard and mouse input still work.
