# MixedOS Stage 2 — interactive kernel and input subsystem

Stage 2 builds on the user-reported successful Stage 1 boot and adds a ring-0
interactive console, legacy timer, exception reporting, and a unified input
subsystem. The current source has not yet been compiled or VM-tested as a whole;
the user's previously successful Stage 2 builds validate earlier revisions,
not this integrated input revision.

## Included in source

- Freestanding Rust x86_64 kernel and Limine boot protocol.
- 256 IDT vectors with error-code-aware exception entry stubs.
- General-purpose register and FXSAVE state preservation around dispatch.
- Legacy PIC remapping and 8254 PIT tick counter at nominal 100 Hz.
- Framebuffer terminal and COM1 diagnostics/input.
- Unified bounded event queue for keyboard, mouse, and serial-byte events.
- Shared i8042 controller poller; status bit 5 separates primary keyboard bytes
  from auxiliary mouse bytes.
- PS/2 keyboard initialization, set-2-to-set-1 controller translation, US
  keyboard mapping, key-down/key-up events, Shift, Caps Lock, Control, Alt,
  Escape, Enter, Tab, Backspace, and printable characters.
- Standard three-byte PS/2 mouse initialization and packet decoding, relative
  coordinates, and three buttons.
- Live device counters on the framebuffer and an `input` diagnostic command.
- Shell commands: `help`, `clear`, `mem`, `uptime`, `input`, and `reboot`.

## Input architecture

The shell does not access keyboard controller ports. It polls the `input`
subsystem and consumes device-neutral `InputEvent` values. Only the shared PS/2
poller reads `0x60`; it routes bytes using the i8042 status register. This
prevents the mouse and keyboard drivers from stealing each other's bytes. COM1
input is also normalized into the queue.

PS/2 IRQ delivery is disabled for now; PIT IRQ0 remains enabled. The kernel
actively polls during bring-up. USB HID is **not implemented**. This distinction
matters in VirtualBox because a USB tablet/keyboard is not the same device as an
emulated PS/2 auxiliary/keyboard port.

## Known limitations

- Ring-0 debug console only; no user mode, scheduler, page allocator, storage,
  filesystem, networking, or desktop.
- No USB controller or HID driver (USB keyboard/tablet/mouse support is absent).
- PS/2 mouse currently supports standard three-byte packets, not wheel packets.
- Mouse coordinates are diagnostic relative coordinates, not a graphical cursor.
- US layout only; no international layout or configurable repeat.
- Busy polling consumes CPU until an idle task/scheduler exists.
- Legacy PIC/PIT only; no APIC, IOAPIC, HPET, or TSC deadline timer.
- No GDT/TSS ownership or dedicated IST stack yet.
- FXSAVE preserves x87/SSE state; AVX/XSAVE is not enabled.

## Verification

Source checks and assembly validation are part of the package. Rust/Cargo build,
ISO creation, and real keyboard/mouse behavior must be verified on the user's
Windows toolchain and VirtualBox VM. A successful build alone does not prove
that a device sent data or that the shell handled it.
