# MixedOS Stage 2 — Keyboard Fix 3

## Root cause found

The previous PIC master mask was `0xFD` (`11111101b`). On the 8259 PIC, bit 0 masks IRQ0 and bit 1 masks IRQ1. `0xFD` therefore masked the PIT timer and unmasked the keyboard IRQ, contrary to the source comment. The unexpected IRQ1 handler read port `0x60`, discarding scan-code bytes before the active polling loop could consume them.

## Changes

- Set the master PIC mask to `0xFE` (`11111110b`): IRQ0 enabled; IRQ1 masked.
- The defensive IRQ1 handler no longer reads port `0x60`; it masks IRQ1 and sends EOI.
- Read the i8042 command byte back after configuring it and verify the IRQ, keyboard-disable, auxiliary-disable, and translation bits.
- Add a compact framebuffer status indicator showing raw PS/2 bytes received and the most recent scan code. This helps distinguish “no bytes from the VM” from a scan-code decoding issue.
- Keep the existing interactive shell, scan-code set 1 decoder, polled input, and Windows `Build.bat` workflow.

## Verification limits

`tools/validate_source.py` passes, and the x86_64 interrupt assembly assembles with Clang. This environment does not have the Rust toolchain, so the Rust kernel has not been compiled here. A Windows build and VirtualBox keyboard test are still required.


## Superseded by Fix 4

Fix 4 changes the PS/2 compatibility contract: it leaves the physical/emulated keyboard on native scan-code set 2 and enables i8042 translation to the set-1 stream expected by the current decoder. See `KEYBOARD-FIX4.md`.
