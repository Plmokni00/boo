# Third-party build dependencies

MixedOS kernel source in this repository is original clean-room source. The build downloads external tools as dependencies rather than bundling host executables in the source ZIP.

- **Limine 12.9.6 binary release** — bootloader and ISO installation tools. Upstream project: https://github.com/limine-bootloader/limine. The upstream project identifies its license as BSD-2-Clause. The exact binary archive is pinned in `build.ps1` by version and SHA-256.
- **Rust toolchain** — official rustup distribution: https://rustup.rs/.
- **LLVM/Clang** — LLVM project: https://llvm.org/.
- **MSYS2 / xorriso** — MSYS2 package manager and xorriso package: https://www.msys2.org/ and https://packages.msys2.org/packages/xorriso.

The licenses of downloaded dependencies remain their respective upstream licenses. They are not relicensed as MixedOS code.
