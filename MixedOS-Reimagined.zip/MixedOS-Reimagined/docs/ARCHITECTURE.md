# MixedOS architecture

## Target and boundary

The first target is x86_64 BIOS/UEFI. The kernel is a freestanding Rust ELF loaded by the Limine boot protocol. Limine is a bootloader dependency only; it is not the kernel, userspace, distribution, or runtime base. The kernel is taking ownership incrementally from the environment supplied by the bootloader.

The architectural direction is a privileged kernel plus isolated user-space services and applications. The current command loop is still ring 0. It is a bring-up/debugging interface, not a security boundary or a POSIX shell.

## Current boot and interrupt path

1. Firmware starts the Limine bootloader.
2. Limine loads `boot/mixedos-kernel.elf` and populates the requests retained in `.limine_reqs`.
3. `_start` disables interrupts, enables the x87/SSE state required by the x86_64 ABI and interrupt context save, initializes COM1, validates the Limine base revision, and checks the linked C ABI revision.
4. The kernel reads the bootloader memory map, reports usable RAM ranges, initializes the Stage 3 physical frame allocator, and inspects the active four-level CR3 tree through the HHDM. Stage 4 never replaces CR3; only type-0 usable pages at or above 1 MiB and below the 64 GiB tracking limit become allocator-managed frames.
5. The kernel reads the boot framebuffer descriptor and draws the initial status screen, then transitions to the text console when the framebuffer format is supported.
6. The kernel installs a 256-entry IDT with a distinct assembly entry stub for every vector. The exception stubs that receive a CPU error code use the matching stack layout; all other stubs add a synthetic zero error code.
7. The 8259 PIC is remapped to vectors 32–47. Only IRQ0 is unmasked. The 8254 PIT is programmed for a nominal 100 Hz tick.
8. The IRQ0 handler increments an atomic tick counter. The PIC mask is 0xFE: IRQ0 is unmasked and IRQ1 is masked. The i8042 command byte also disables PS/2 IRQ delivery while enabling both ports and controller translation.
9. The unified input subsystem owns all reads from i8042 port 0x60. It uses status bit 5 to route primary-channel keyboard bytes and auxiliary-channel mouse bytes, then publishes typed events. COM1 bytes are normalized into the same queue. The shell consumes events without touching hardware ports.
10. The kernel runs the small interactive ring-0 command loop. Its input poller remains active until a scheduler-aware idle task exists.

The interrupt stubs save general-purpose registers and FXSAVE state before entering Rust, then restore that state before `iretq`. AVX/XSAVE state management is not implemented. Timer support is the legacy PIT/PIC path, not LAPIC/IOAPIC/APIC support.

## Kernel bring-up interfaces

- **Exceptions:** exception reports include vector number, CPU error code, and saved instruction pointer. Page faults also report CR2. Fatal CPU exceptions are logged to COM1 and halt the CPU.
- **Input:** the current input path expects an i8042-compatible controller. A shared poller demultiplexes keyboard and auxiliary mouse bytes into one event queue; a US keyboard decoder emits key-down/key-up and text events, while a standard three-byte mouse decoder reports relative motion and three buttons. USB HID, wheel packets, international layouts, and configurable repeat are not implemented.
- **Serial:** COM1 uses 38400 baud, 8-N-1. Transmit is used for diagnostics and shell output; non-blocking receive is normalized into the shared input event queue.
- **Framebuffer:** text output is software-rendered to the bootloader-provided linear RGB framebuffer. It is not a graphics driver, compositor, window manager, or accelerated GPU stack.
- **Memory:** Limine's memory map feeds a 4 KiB physical frame allocator. Stage 4 walks the active four-level page tables through the HHDM, can add/remove 4 KiB mappings of allocator-owned frames, checks effective parent permissions, tracks its own intermediate tables, and performs local `invlpg` invalidations. It does not replace CR3, split huge pages, switch address spaces, or support SMP TLB shootdowns. No heap/global allocator or user-mode process spaces exist yet.

## Language boundaries

| Technology | Intended boundary | Current evidence |
|---|---|---|
| Rust | Kernel and core services | Kernel entry, boot requests, interrupt dispatch, timer, unified keyboard/mouse/serial input queue, framebuffer console, kernel command loop |
| C | Freestanding native routines and stable C ABI | C object compiled and linked in the user's successful Windows build |
| x86_64 assembly | Interrupt entry/exit and architecture-specific operations | ISR stubs; Rust `asm!` emits control-register, `cli`, `sti`, `hlt`, `in`, and `out` instructions |
| Zig | Selected native utilities after an ABI and use case are justified | Not started |
| Java | A real managed runtime and application support | Not started |
| Lua | Embedded scripting in a real user-space service | Not started |
| GLSL/WGSL | Shader code through a real GPU API and driver | Not started |
| POSIX shell | Shell after processes, files, pipes, and descriptors exist | Not started; current command loop is a ring-0 debug console |
| SQLite | Embedded structured storage after reliable filesystem I/O exists | Not started |

The C ABI is versioned in `include/mixedos/abi.h`. Cross-language calls must use explicit fixed-width types and documented ownership rules. Do not pass Rust-only data structures across the C boundary.

## Memory and privilege plan

Before running applications, MixedOS still needs:

- Repeated VM validation of physical frame ownership and HHDM read/write access.
- Repeated VirtualBox validation of Stage 4 page-table mappings, permission checks, TLB invalidations, and cleanup.
- A kernel heap/global allocator built on verified physical and virtual allocation.
- A MixedOS-owned GDT/TSS and dedicated exception/interrupt stacks.
- A syscall entry/return contract.
- A scheduler and per-process address spaces.
- Safe copy-in/copy-out routines for user pointers.

Until those pieces exist, the kernel command loop and all currently implemented drivers execute in ring 0. No user-mode isolation is claimed.

## Storage and services plan

Storage devices and filesystems will be exposed through kernel driver interfaces. A user-space storage service can later own filesystem policy and persistence, but it must have a working block-device interface, crash-consistent writes, mount semantics, and permissions first. SQLite is an application/service dependency, not the filesystem itself.

Networking is similarly layered: PCI/USB discovery, device drivers, link layer, IP, transport protocols, DHCP/DNS, TLS libraries, and user-facing network management. UI indicators must reflect actual service state.

## Graphics plan

The current framebuffer console is software rendering through a bootloader-provided linear framebuffer. It is not a GPU driver, compositor, window manager, or accelerated graphics stack. Later graphics work needs a driver boundary, memory management, command submission, mode management, a 2D/3D userspace API, a compositor, and validated device support before advertising acceleration or shader effects.
