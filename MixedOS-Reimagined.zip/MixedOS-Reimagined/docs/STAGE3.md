# MixedOS Stage 3 — Physical memory foundation

## Goal

Build and validate the first real kernel memory-management primitive without
changing the working Stage 2 input subsystem or taking on page-table changes
before the frame allocator is proven.

## Included

- Bounded Limine memory-map iterator.
- 4 KiB physical frame allocator using managed and allocated bitmaps.
- Reservation of non-usable map entries and the first MiB.
- 64 GiB tracking limit with safe exclusion of RAM above the limit.
- Overflow-safe region clipping and page alignment.
- Checked HHDM conversion and zeroed-frame helper.
- Double-free and invalid-free detection.
- Atomic serialization for normal kernel context.
- `mem`, `frames`, and `memtest` shell commands.
- Full-page write/read verification and cleanup in `memtest`.

## Not included by design

No heap/global allocator and no CR3/page-table modifications. Those are
separate layers and should not be bundled into this bring-up milestone until
physical frame ownership and HHDM access have passed repeated VM tests.

## Build and test

1. Extract this release into a fresh directory.
2. Run `Build.bat` with no arguments.
3. Attach `build\artifacts\MixedOS-x86_64.iso` to the existing VirtualBox VM.
4. Boot, then run `help`, `mem`, `frames`, and `memtest`.
5. Run `frames` again after `memtest`; all eight test frames must have returned.
6. Type commands and move/click the mouse to confirm the Stage 2 input path remains
   operational.

The source validator and host-side allocator model are repository checks, not a
substitute for the Windows Rust build and VirtualBox acceptance test. Do not mark
Stage 3 hardware/VM-verified until those user-side checks pass.
