# Development roadmap

The sequence follows dependency order. A later stage must not be marked complete
because an interface or UI control merely exists.

## Stage 1 — boot and kernel foundation

- [x] BIOS/UEFI boot path defined through Limine and an ISO build workflow.
- [x] x86_64 Rust kernel entry point.
- [x] Early serial diagnostics through COM1.
- [x] Early RGB framebuffer console.
- [x] Bootloader memory-map and HHDM request handling.
- [x] Freestanding C ABI object compiled and linked in the user-reported build.
- [x] Windows build and ISO creation completed successfully by the user.
- [x] Initial VirtualBox boot reported and screenshot-confirmed by the user.
- [x] IDT source, exception stubs, and CPU fault reporting.
- [x] Legacy PIC/PIT timer source (100 Hz) and IRQ plumbing.
- [ ] BIOS and UEFI boot both verified separately.
- [ ] Real hardware boot verified.

## Stage 2 — interactive input and kernel console

- [x] Shared i8042 poller with primary/auxiliary channel demultiplexing.
- [x] Keyboard key-down/key-up decoder and US-layout text events.
- [x] Standard three-byte PS/2 mouse packet decoder and relative pointer state.
- [x] Bounded device-neutral input event queue consumed by the kernel console.
- [x] Framebuffer input counters and `input` diagnostics command.
- [x] Framebuffer text console and scrolling source.
- [x] Kernel command loop: `help`, `clear`, `mem`, `uptime`, `input`, `reboot`.
- [x] COM1 serial input normalized into the shared event queue.
- [x] Keyboard, mouse, shell command processing, and timer behavior observed in
      the user's VirtualBox screenshot (2026-11-11).
- [ ] USB HID controller/device support (USB keyboard, mouse, tablet).
- [ ] GDT/TSS ownership and dedicated exception stacks.

## Stage 3 — physical memory foundation (user VM-confirmed)

- [x] Bounded Limine memory-map iterator.
- [x] 4 KiB physical frame allocator with managed/allocated bitmaps.
- [x] Non-usable memory regions and the first MiB remain reserved.
- [x] Checked HHDM conversion and zeroed-frame allocation helper.
- [x] Allocation/free counters and double-free/invalid-free rejection.
- [x] `mem`, `frames`, and full-page `memtest` shell diagnostics.
- [x] User screenshot confirms the eight-page physical memory test passes and frames are returned with zero free errors (2026-11-11).
- [ ] Allocation exhaustion and recovery test on the VM.

## Stage 4 — virtual memory foundation (source implemented; build/VM test pending)

- [x] Inspect active four-level CR3 root without replacing it.
- [x] Detect physical-address width, NX capability, and unsupported LA57 mode.
- [x] Enable/verify EFER.NXE when supported and CR0.WP.
- [x] Map/unmap allocator-owned 4 KiB pages with parent permission checks.
- [x] Refuse existing-page collisions and huge-page splitting.
- [x] Track and reclaim only MixedOS-owned empty page-table pages.
- [x] Roll back partially created page-table paths on mapping errors.
- [x] Invalidate local TLB entries after mapping changes.
- [x] Add `paging` and real-virtual-access `vmtest` console commands.
- [ ] Windows build and VirtualBox page-table/permission/TLB tests.
- [ ] Repeat `vmtest` and verify allocator accounting plus Stage 2 keyboard/mouse regressions.
- [ ] Kernel heap/global allocator built on verified physical/virtual allocation.
- [ ] User mode and syscall ABI.
- [ ] Validated ELF loader and relocation policy.
- [ ] Process and thread lifecycle.
- [ ] Scheduler and synchronization primitives.
- [ ] Per-process virtual address spaces and isolation tests.

## Stage 5 — storage and persistence

- [ ] PCI enumeration and storage-controller discovery.
- [ ] Block-device abstraction and drivers.
- [ ] Persistent filesystem with recovery and integrity tests.
- [ ] Mount and permission model.
- [ ] User home directories and file operations.
- [ ] SQLite compiled for MixedOS and integrated above filesystem I/O.
- [ ] File manager as a user-space application.

## Stage 6 — networking

- [ ] PCI/USB device discovery framework.
- [ ] Ethernet driver(s) and link-state reporting.
- [ ] IPv4/IPv6, ARP/NDP, ICMP, UDP, and TCP.
- [ ] DHCP and DNS clients.
- [ ] TLS and certificate validation.
- [ ] Wi-Fi chipset support and authentication management.
- [ ] Real-world connectivity tests from supported hardware.

## Stage 7 — desktop and services

- [ ] RTC, UTC clock service, timezone database, and NTP.
- [ ] Audio and input device services.
- [ ] Window-system protocol and compositor.
- [ ] Window manager and focus/input routing.
- [ ] Panel, launcher, dock, notifications, and settings.
- [ ] Lua runtime embedded in a user-space service.
- [ ] GPU driver architecture and software fallback.

## Stage 8 — application environment

- [ ] Native app ABI, loader, libraries, and package format.
- [ ] User-space terminal, process groups, file descriptors, pipes, and real shell.
- [ ] Java runtime with JVM conformance tests; not a bytecode demo.
- [ ] Software installation, updates, permissions, and rollback.
- [ ] Firefox port/build feasibility study against the completed user-space API;
      include the real Firefox engine or do not call it Firefox.

## Stage 9 — Windows compatibility

- [ ] PE32/PE32+ loader and module loader.
- [ ] Win32 API compatibility layer, threading, sync, filesystem, and registry semantics.
- [ ] Windowing, graphics, audio, and input bridges.
- [ ] Compatibility test suite with selected real Windows programs.

## Stage 10 — production readiness

- [ ] Installer, partitioning, boot entry setup, and recovery environment.
- [ ] Secure update system and data-preserving upgrades.
- [ ] Hardware compatibility matrix and automated regression testing.
- [ ] Performance, power, security, and reliability testing.
- [ ] ARM64 port as a separate architecture milestone.
