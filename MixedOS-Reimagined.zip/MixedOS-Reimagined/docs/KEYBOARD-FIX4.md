# Historical note — Keyboard Fix 4 superseded

Keyboard Fix 4 was the last keyboard-only polling experiment. Its code disabled
the i8042 auxiliary channel and discarded auxiliary bytes. That was not a proper
shared input design and this revision supersedes it.

See [INPUT-SUBSYSTEM.md](INPUT-SUBSYSTEM.md) for the current integrated design,
which enables both PS/2 channels, demultiplexes their bytes in one controller
poller, and publishes typed keyboard/mouse/serial events through a shared queue.
