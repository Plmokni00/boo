# Windows build details

## Tools used by the current kernel build

| Tool | Why it is needed | Current build behavior |
|---|---|---|
| Rust stable + `x86_64-unknown-none` | Freestanding kernel | Installs the official `Rustlang.Rustup` WinGet package if missing, then installs stable and the target |
| LLVM Clang | Compiles the freestanding C object | Installs with WinGet package `LLVM.LLVM` if missing |
| MSYS2 xorriso (1.5.4+) | Creates the hybrid ISO | Installs MSYS2 with WinGet, updates its package database/system, installs `xorriso` with pacman if missing, and checks the reported version |
| Limine binary release | BIOS/UEFI boot files and BIOS ISO setup | Downloads release 12.9.6 and verifies the SHA-256 before use |
| PowerShell | Orchestrates the Windows build | Included with supported Windows installations |

NASM is not required: the interrupt entry stubs are included as LLVM-assembled global assembly, while control-register, port-I/O, and CPU control instructions use Rust's LLVM-backed `core::arch::asm!`. Zig, JDK, Lua, shader compilers, and SQLite are intentionally not installed by this early build because no production subsystem currently uses them. They will be added when real implementations consume them.

## Build pipeline

1. Ensure Rust stable (minimum 1.85 for edition 2024) and the `x86_64-unknown-none` target are installed. If absent, the script uses WinGet to install the official Rustup package, then installs stable and the target.
2. Ensure Clang is available.
3. Compile `kernel/native/c/runtime.c` to `build/native/runtime.o` for the freestanding x86_64 ELF target.
4. Export `MIXEDOS_C_OBJECT` and build the Rust kernel. `kernel/build.rs` refuses to link if the C object is missing.
5. Download and verify Limine 12.9.6 if it is not already cached.
6. Stage `limine.conf`, the kernel ELF, BIOS boot files, and the x86_64 UEFI loader.
7. Create a hybrid ISO using xorriso.
8. Run `limine bios-install` on the ISO.
9. Write the ISO SHA-256 sidecar and verify the artifact exists and is nontrivial in size.

The script checks the Rust and Clang minimum versions and fails on a missing required tool, failed command, checksum mismatch, missing boot file, or missing output. It never intentionally skips a required kernel component and reports success.

## Important build constraints

- This is a Windows-hosted build, not a Windows-targeted kernel.
- The Rust target is `x86_64-unknown-none`.
- The C object target is `x86_64-unknown-none-elf`.
- No WSL or Docker commands are used.
- MSYS2 is used only to host xorriso on Windows; it is not embedded in the OS image as a runtime.
- The ISO is BIOS/UEFI hybrid, but actual boot support must still be tested in both firmware modes.
