# MixedOS Stage 2 — Unified Input Subsystem

## Purpose

Input devices are normalized into a shared kernel event queue. The shell consumes
`Key`, `Mouse`, and `SerialByte` events; future desktop, window-manager, and
application code can consume the same event types without directly accessing
controller ports.

## Implemented sources

- **i8042 primary channel:** PS/2 keyboard. The controller's translation bit is
  enabled, the keyboard is requested to use native scan-code set 2, and the
  translated set-1 stream is decoded into physical key-down/key-up events plus
  US-layout text/control bytes. Shift, Caps Lock, Control, Alt, extended keys,
  Enter, Tab, Backspace, and Escape are represented.
- **i8042 auxiliary channel:** standard three-byte PS/2 mouse packets. The
  controller's auxiliary channel remains enabled; status bit 5 is used to
  demultiplex mouse bytes from keyboard bytes. Relative motion and three button
  states are maintained.
- **COM1:** non-blocking serial input is wrapped as `SerialByte` events and goes
  through the same queue as hardware input.

## Architecture

`input::poll()` is the sole i8042 output-buffer reader. It checks the controller
status before reading port `0x60`, routes primary-channel bytes to the keyboard
decoder and auxiliary-channel bytes to the mouse packet parser, and pushes
normalized events into a bounded single-producer/single-consumer queue. The
shell only consumes `InputEvent`; it does not read PS/2 ports directly.

PS/2 IRQ delivery is disabled in the i8042 command byte and the PIC keeps IRQ1
masked. The PIT IRQ0 remains enabled. This intentionally uses polling during
kernel bring-up, avoiding the earlier split ownership where an interrupt path
could consume a byte before the poller. The busy loop is temporary until an idle
task and scheduler are available.

The framebuffer status strip shows separate keyboard and mouse receive counts,
last raw bytes, pointer coordinates, buttons, and channel readiness. The `input`
command prints more detailed controller, device, error, and event-drop counters.

## Limits and compatibility

- This is **PS/2 plus COM1**, not a complete USB input implementation.
- USB HID keyboards, USB tablets, USB mice, xHCI/EHCI/UHCI/OHCI controller
  drivers, hotplug, international layouts, key repeat policy, wheel packets,
  and multi-device enumeration are not implemented.
- Mouse coordinates are relative and clamped to a 0–4095 diagnostic coordinate
  space; they are not yet mapped to a desktop or framebuffer cursor.
- The queue is a single-producer/single-consumer ring for the current one-core
  polling design. SMP support will require revisiting ownership and synchronization.
- `keyboard_ready` and `mouse_ready` mean that the device acknowledged its
  initialization command sequence. They are not claims of USB support or proof
  of physical hardware compatibility.

## Validation

Source validation checks the queue, controller channel split, device command
sequences, keyboard decoding, mouse packet assembly, serial normalization, and
shell event consumption. The assembly entry file is separately assembled by
Clang. Rust compilation and interactive device behavior still require a fresh
Windows `Build.bat` run and a VirtualBox test.

For the VM test, click inside the VM, type `input`, then press and release keys
and move/click the mouse. Keyboard bytes should increase independently of mouse
bytes. Mouse bytes and coordinates should change without affecting keyboard
text. Test `help`, `mem`, `uptime`, Shift, Caps Lock, Tab, Enter, and Backspace.
If the VM provides only a USB tablet and no PS/2 auxiliary mouse, the `input`
command should report the PS/2 mouse channel as absent; USB HID support remains
future work.
