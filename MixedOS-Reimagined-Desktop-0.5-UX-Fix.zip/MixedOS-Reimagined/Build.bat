@echo off
setlocal EnableExtensions
cd /d "%~dp0" || exit /b 1
title MixedOS Builder

where powershell.exe >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Windows PowerShell was not found.
    echo Install or enable Windows PowerShell, then run Build.bat again.
    pause
    exit /b 9009
)

echo.
echo  MixedOS - Windows Builder
echo  =========================
echo.
echo  Checking required tools, then building MixedOS...
echo  You only need to double-click this file.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"
set "RESULT=%ERRORLEVEL%"

echo.
if "%RESULT%"=="0" (
    echo [SUCCESS] MixedOS build completed.
    echo [OUTPUT] build\artifacts\MixedOS-x86_64.iso
) else (
    echo [FAILED] MixedOS builder exited with code %RESULT%.
    echo [LOG] Check the newest file in build\logs\
)

if /I not "%MIXEDOS_NO_PAUSE%"=="1" pause
exit /b %RESULT%
