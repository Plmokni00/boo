Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Root = $PSScriptRoot
$Build = Join-Path $Root 'build'
$Deps = Join-Path $Build 'deps'
$Native = Join-Path $Build 'native'
$Artifacts = Join-Path $Build 'artifacts'
$Logs = Join-Path $Build 'logs'
$LogPath = Join-Path $Logs ("build-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))

function Fail([string]$Message) { throw "MixedOS: $Message" }
function Invoke-Checked([string]$Executable, [string[]]$Arguments) {
    Write-Host ("> {0} {1}" -f $Executable, ($Arguments -join ' ')) -ForegroundColor DarkGray
    & $Executable @Arguments | Out-Host
    if ($LASTEXITCODE -ne 0) { Fail "Command failed with exit code $LASTEXITCODE`: $Executable" }
}
function Invoke-SourceChecks($PythonInfo) {
    $validator = Join-Path $Root 'tools\validate_source.py'
    $scripts = @($validator) + @(Get-ChildItem -Path (Join-Path $Root 'tools') -Filter 'test_*.py' -File | Sort-Object Name | ForEach-Object { $_.FullName })
    foreach ($script in $scripts) {
        $arguments = @($PythonInfo.Prefix) + @($script)
        Write-Host ("    > Python {0}" -f (Split-Path -Leaf $script)) -ForegroundColor DarkGray
        & $PythonInfo.Path @arguments
        if ($LASTEXITCODE -ne 0) { Fail "Python validation failed: $(Split-Path -Leaf $script) (exit code $LASTEXITCODE)." }
    }
}

function Test-MsysXorriso([string]$Path) {
    # MSYS2's xorriso expects POSIX paths such as /c/Users/name/... . Passing
    # C:\Users\... makes xorriso treat the drive path as a relative name.
    $binDir = Split-Path -Parent $Path
    $usrDir = Split-Path -Parent $binDir
    return ((Test-Path (Join-Path $usrDir 'bin\bash.exe')) -and
            (Test-Path (Join-Path $usrDir 'bin\pacman.exe')))
}
function ConvertTo-MsysPath([string]$Path) {
    $fullPath = [System.IO.Path]::GetFullPath($Path)
    if ($fullPath -match '^([A-Za-z]):[\\/](.*)$') {
        $drive = $Matches[1].ToLowerInvariant()
        $tail = $Matches[2] -replace '\\', '/'
        return "/$drive/$tail"
    }
    Fail "Cannot convert path for MSYS2 xorriso (expected a local drive path): $fullPath"
}

function Confirm-Xorriso([string]$Path) {
    $versionOutput = & $Path '-version'
    if ($LASTEXITCODE -ne 0) { Fail "xorriso failed its version check: $Path" }
    $versionText = $versionOutput -join "`n"
    $versionMatch = [regex]::Match($versionText, 'xorriso\s+(\d+)\.(\d+)\.(\d+)')
    if (-not $versionMatch.Success) { Fail "Could not parse xorriso version output from '$Path'." }
    $major = [int]$versionMatch.Groups[1].Value
    $minor = [int]$versionMatch.Groups[2].Value
    $patch = [int]$versionMatch.Groups[3].Value
    $foundVersion = [version]::new($major, $minor, $patch)
    if ($foundVersion -lt [version]'1.5.4') { Fail 'xorriso 1.5.4 or newer is required.' }
    Write-Host ("xorriso {0}.{1}.{2}" -f $major, $minor, $patch)
    return $Path
}
function Ensure-Xorriso {
    $xorriso = Find-MixedOSExecutable 'xorriso.exe'
    if ($xorriso) { return (Confirm-Xorriso $xorriso) }

    $roots = @(
        (Join-Path $env:SystemDrive 'msys64'),
        (Join-Path $env:ProgramFiles 'MSYS2'),
        (Join-Path $env:LOCALAPPDATA 'Programs\MSYS2')
    )
    $msysRoot = $null
    foreach ($candidate in $roots) {
        if (Test-Path (Join-Path $candidate 'usr\bin\pacman.exe')) { $msysRoot = $candidate; break }
    }
    if ($msysRoot) {
        $existingXorriso = Join-Path $msysRoot 'usr\bin\xorriso.exe'
        if (Test-Path $existingXorriso) { return (Confirm-Xorriso $existingXorriso) }
    }

    if (-not $msysRoot) {
        Write-Host 'Installing MSYS2 to obtain the xorriso ISO authoring tool...' -ForegroundColor Cyan
        Install-MixedOSWingetPackage 'MSYS2.MSYS2'
        foreach ($candidate in $roots) {
            if (Test-Path (Join-Path $candidate 'usr\bin\pacman.exe')) { $msysRoot = $candidate; break }
        }
    }
    if (-not $msysRoot) { Fail 'MSYS2 was not found. Install MSYS2, then rerun Build.bat.' }

    $pacman = Join-Path $msysRoot 'usr\bin\pacman.exe'
    Invoke-Checked $pacman @('-Syu', '--noconfirm')
    Invoke-Checked $pacman @('-S', '--needed', '--noconfirm', 'xorriso')
    $xorriso = Join-Path $msysRoot 'usr\bin\xorriso.exe'
    if (-not (Test-Path $xorriso)) { Fail 'MSYS2 package installation completed but xorriso.exe is missing.' }
    return (Confirm-Xorriso $xorriso)
}
function Get-LimineTools {
    $version = '12.9.6'
    $expectedHash = 'b38aabb042b0c0f9f562b7741be3c1204838d7bbacfa78bb411c674bd5b984ee'
    $persistentTools = if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { Join-Path $env:LOCALAPPDATA 'MixedOS\Toolchains' } else { Join-Path $env:USERPROFILE 'AppData\Local\MixedOS\Toolchains' }
    $limineCache = Join-Path $persistentTools 'limine'
    $dir = Join-Path $limineCache "limine-$version"
    $archive = Join-Path $limineCache "limine-binary-$version.tar.gz"
    New-Item -ItemType Directory -Force -Path $limineCache | Out-Null
    $marker = Join-Path $dir '.verified-sha256'
    if (-not (Test-Path $marker) -or ((Get-Content $marker -Raw).Trim() -ne $expectedHash)) {
        if (Test-Path $dir) { Remove-Item $dir -Recurse -Force }
        if (Test-Path $archive) { Remove-Item $archive -Force }
        Write-Host "Downloading Limine $version binary release to the persistent user cache..." -ForegroundColor Cyan
        Invoke-WebRequest -Uri "https://github.com/limine-bootloader/limine/releases/download/v$version/limine-binary.tar.gz" -OutFile $archive
        $actualHash = (Get-FileHash -Path $archive -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualHash -ne $expectedHash) { Fail "Limine archive checksum mismatch. Expected $expectedHash; received $actualHash." }
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
        $tar = Find-MixedOSExecutable 'tar.exe'
        if (-not $tar) { Fail 'Windows tar.exe is required to unpack the verified Limine archive.' }
        Invoke-Checked $tar @('-xzf', $archive, '-C', $dir)
        Set-Content -Path $marker -Value $expectedHash -NoNewline
    }
    $required = @('limine-bios.sys', 'limine-bios-cd.bin', 'limine-uefi-cd.bin', 'BOOTX64.EFI', 'limine.exe')
    $found = @{}
    foreach ($name in $required) {
        $item = Get-ChildItem -Path $dir -Filter $name -File -Recurse | Select-Object -First 1
        if (-not $item) { Fail "The verified Limine archive does not contain required file '$name'." }
        $found[$name] = $item.FullName
    }
    return $found
}

try {
    New-Item -ItemType Directory -Force -Path $Logs, $Deps, $Native, $Artifacts | Out-Null
    Start-Transcript -Path $LogPath -Force | Out-Null
    Write-Host ("Build log: {0}" -f $LogPath) -ForegroundColor Cyan

    . (Join-Path $Root 'tools\toolchain-manager.ps1')
    $tools = Ensure-MixedOSToolchains -Root $Root -Build $Build

    Write-Host '[1/6] Source validation and regression tests' -ForegroundColor Cyan
    Invoke-SourceChecks -PythonInfo $tools.Python

    Write-Host '[2/6] Compile freestanding C runtime' -ForegroundColor Cyan
    $cObject = Join-Path $Native 'runtime.o'
    Invoke-Checked $tools.Clang @(
        '--target=x86_64-unknown-none-elf', '-ffreestanding', '-fno-builtin',
        '-fno-stack-protector', '-fno-pic', '-mcmodel=kernel', '-mno-red-zone', '-O2',
        '-c', (Join-Path $Root 'kernel\native\c\runtime.c'), '-o', $cObject
    )

    Write-Host '[3/6] Compile freestanding C desktop UI runtime' -ForegroundColor Cyan
    $uiObject = Join-Path $Native 'desktop_ui.o'
    Invoke-Checked $tools.Clang @(
        '--target=x86_64-unknown-none-elf', '-ffreestanding', '-fno-builtin',
        '-fno-stack-protector', '-fno-pic', '-mcmodel=kernel', '-mno-red-zone', '-O2',
        '-c', (Join-Path $Root 'kernel\native\c\desktop_ui.c'), '-o', $uiObject
    )

    Write-Host '[4/6] Test and compile freestanding Zig component' -ForegroundColor Cyan
    $zigObject = Join-Path $Native 'crc32_zig.o'
    Invoke-Checked $tools.Zig @('test', (Join-Path $Root 'kernel\native\zig\crc32_test.zig'))
    Invoke-Checked $tools.Zig @(
        'build-obj', (Join-Path $Root 'kernel\native\zig\crc32.zig'),
        '-target', 'x86_64-freestanding-none', '-OReleaseFast',
        "-femit-bin=$zigObject"
    )

    Write-Host '[5/6] Build and link the Rust kernel' -ForegroundColor Cyan
    $env:MIXEDOS_C_OBJECT = $cObject
    $env:MIXEDOS_UI_OBJECT = $uiObject
    $env:MIXEDOS_ZIG_OBJECT = $zigObject
    Push-Location $Root
    try {
        # Keep Cargo outputs under build/, not the source root. This avoids
        # polluting distributable source archives and keeps generated objects
        # in the builder's already-ignored output directory.
        $CargoTarget = Join-Path $Build 'cargo-target'
        Invoke-Checked $tools.Rustup @('run', 'stable', 'cargo', 'build', '--package', 'mixedos-kernel', '--release', '--target', 'x86_64-unknown-none', '--target-dir', $CargoTarget)
    }
    finally {
        Pop-Location
        Remove-Item Env:\MIXEDOS_C_OBJECT -ErrorAction SilentlyContinue
        Remove-Item Env:\MIXEDOS_UI_OBJECT -ErrorAction SilentlyContinue
        Remove-Item Env:\MIXEDOS_ZIG_OBJECT -ErrorAction SilentlyContinue
    }

    $kernel = Join-Path $Build 'cargo-target\x86_64-unknown-none\release\mixedos-kernel'
    if (-not (Test-Path $kernel)) { Fail 'Cargo reported success, but the kernel ELF was not produced.' }
    Write-Host '[6/6] Package BIOS/UEFI bootable ISO' -ForegroundColor Cyan
    $xorriso = Ensure-Xorriso
    $limine = Get-LimineTools
    $IsoRoot = Join-Path $Build 'iso-root'
    if (Test-Path $IsoRoot) { Remove-Item $IsoRoot -Recurse -Force }
    $bootDir = Join-Path $IsoRoot 'boot'
    $efiDir = Join-Path $IsoRoot 'EFI\BOOT'
    New-Item -ItemType Directory -Force -Path $bootDir, $efiDir | Out-Null

    Copy-Item $kernel (Join-Path $bootDir 'mixedos-kernel.elf')
    Copy-Item (Join-Path $Root 'boot\limine.conf') (Join-Path $IsoRoot 'limine.conf')
    Copy-Item $limine['limine-bios.sys'] (Join-Path $bootDir 'limine-bios.sys')
    Copy-Item $limine['limine-bios-cd.bin'] (Join-Path $bootDir 'limine-bios-cd.bin')
    Copy-Item $limine['limine-uefi-cd.bin'] (Join-Path $bootDir 'limine-uefi-cd.bin')
    Copy-Item $limine['BOOTX64.EFI'] (Join-Path $efiDir 'BOOTX64.EFI')

    $iso = Join-Path $Artifacts 'MixedOS-x86_64.iso'
    if (Test-Path $iso) { Remove-Item $iso -Force }
    $isoSourceArgument = $IsoRoot
    $isoOutputArgument = $iso
    if (Test-MsysXorriso $xorriso) {
        $isoSourceArgument = ConvertTo-MsysPath $IsoRoot
        $isoOutputArgument = ConvertTo-MsysPath $iso
        Write-Host 'Detected MSYS2 xorriso; using MSYS2 POSIX paths for ISO source/output.' -ForegroundColor Cyan
    }
    Invoke-Checked $xorriso @(
        '-as', 'mkisofs', '-R', '-r', '-J', '-b', 'boot/limine-bios-cd.bin',
        '-no-emul-boot', '-boot-load-size', '4', '-boot-info-table', '-hfsplus',
        '-apm-block-size', '2048', '--efi-boot', 'boot/limine-uefi-cd.bin',
        '-efi-boot-part', '--efi-boot-image', '--protective-msdos-label',
        $isoSourceArgument, '-o', $isoOutputArgument
    )
    $limineExe = $limine['limine.exe']
    Invoke-Checked $limineExe @('bios-install', $iso)
    if (-not (Test-Path $iso) -or (Get-Item $iso).Length -lt 1048576) { Fail 'ISO output is missing or unexpectedly small.' }
    $isoHash = (Get-FileHash -Path $iso -Algorithm SHA256).Hash.ToLowerInvariant()
    Set-Content -Path ($iso + '.sha256') -Value "$isoHash  MixedOS-x86_64.iso"

    Write-Host ''
    Write-Host 'MIXEDOS BUILD SUCCESSFUL' -ForegroundColor Green
    Write-Host "ISO: $iso"
    Write-Host "SHA256: $isoHash"
    Write-Host 'Stage 7 storage/filesystem build complete. MIXFS superblock CRC-32 is supplied by the freestanding Zig component.' -ForegroundColor Green
    Write-Host 'Included hardware groundwork: read-only PCI device inventory, software-only I/O/MMIO reservations, and a bounded DMA32 allocator API.' -ForegroundColor Cyan
    Write-Host 'Not implemented: PCI BAR sizing/assignment, MMIO mapping, PCI bus mastering, xHCI/USB HID, AHCI/NVMe, journaling/full recovery, networking, and desktop.' -ForegroundColor Yellow
}
catch {
    Write-Error $_
    exit 1
}
finally {
    try { Stop-Transcript | Out-Null } catch { }
}
