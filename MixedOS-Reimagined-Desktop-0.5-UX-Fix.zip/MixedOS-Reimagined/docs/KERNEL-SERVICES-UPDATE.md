# Kernel Services Update

This update adds small, real kernel services that are useful before the desktop
exists. It preserves the existing `MixedOS-Reimagined` project directory and
one-click Windows build workflow.

## Bounded kernel log

`kernel/src/log.rs` provides a 64-record, 160-byte-per-record ring buffer. It is
allocation-free, stores records in RAM only, tracks overwritten/truncated
records, and exposes oldest-to-newest inspection and clear operations. The
`kprintln!` macro records informational messages before writing them to COM1.
The ring is not persistent storage and must not be called from NMI context.

Shell commands:

- `log` displays retained kernel records.
- `log clear` clears the in-memory ring.

## Everyday system commands

- `uptime` reports PIT timer ticks and derived elapsed time at 100 Hz.
- `version` reports kernel, ABI, filesystem, and build-channel identifiers.
- `drivers` reports implemented and not-yet-implemented device subsystems.

The driver inventory is descriptive; it does not imply that absent drivers are
available or that read-only discovery has activated hardware.

## Validation

`tools/test_kernel_services.py` checks the source contract. The complete Windows
builder still needs to compile the Rust kernel and boot the resulting ISO.
