# Stage 6 Fix 4 — defer cleanup until the normal kernel stack resumes

Fix 2 showed both demo processes reaching ring-3 EXIT syscalls. Fix 3 added
exit-state and teardown breadcrumbs. Static review found that the old return
path called Rust cleanup callbacks from a synthetic IRETQ-to-ring-0 trampoline.
That made the final transition unnecessarily dependent on callback ABI and
stack handling inside an interrupt-return path.

Fix 4 simplifies the control flow:

1. The final process EXIT changes the interrupt frame RIP/CS/RFLAGS to enter a
   small assembly-only ring-0 return stub.
2. The stub restores kernel data segment selectors.
3. It loads the recorded kernel CR3 and switches back to the original page-table
   root before touching the saved shell stack.
4. It restores the shell call stack and callee-saved registers, then returns
   normally from `mixedos_enter_user()`.
5. `run_demo()` verifies CR3, restores TSS.RSP0, and only then frees process
   code/stack frames, private page-table frames, and process kernel stacks.

No Rust callback is invoked from the synthetic interrupt-return path. This
keeps resource reclamation in an ordinary Rust call context with the kernel CR3
active and interrupts disabled. A CR3 mismatch halts before process memory is
freed.

The host process model, source validator, Clang C runtime compilation, and
Clang interrupt assembly compilation are checks only. A native Windows Rust
build and VirtualBox `proctest` run are still required to verify the complete
kernel behavior.
