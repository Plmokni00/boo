# MixedOS device and driver model

## Goals

A driver must be discoverable, bound to a device, granted only the resources it needs, observable, restartable where possible, and detachable without leaving stale references. The current PCI scanner is read-only discovery; it is not yet this framework.

## Device lifecycle

`Discovered -> ResourcesDescribed -> DriverMatched -> Probing -> Active -> Quiescing -> Detached`.

Any failed probe returns to a safe non-active state and releases only resources acquired by that probe. Hot removal first blocks new requests, cancels or drains outstanding work, unmaps DMA/MMIO, then releases the device object.

## Resource types

- PCI configuration-space identity and topology.
- I/O port ranges and MMIO ranges, with overflow, alignment, and overlap checks.
- Interrupt vectors/lines and routing ownership.
- DMA regions with address mask, alignment, boundary, direction, cache policy, and pin lifetime.
- Power/reset controls and firmware-described dependencies.

No driver may infer a physical address from a virtual pointer. No driver may enable PCI bus mastering until DMA mappings and device state are ready. BAR sizing is a controlled operation: save the original register, quiesce the device, probe, restore on every path, and verify the result. Never perform BAR writes during the current read-only discovery scan.

## Driver interface shape (design only)

A future driver contract should expose `match`, `probe`, `start`, `stop`, `reset`, `remove`, and `diagnostics`, plus typed operations for its class (block, network, HID, audio, display). Requests must be bounded and complete asynchronously or return a documented error. Drivers need a declared maximum transfer size, timeout, supported power states, and recovery strategy.

## Bus order

1. Firmware/ACPI tables and PCI root bridges.
2. PCI topology and resource windows.
3. Safe MMIO mapping and DMA primitives.
4. Interrupt routing and controller abstraction.
5. xHCI and USB core.
6. USB class drivers (HID, storage, hubs; audio later).
7. AHCI/NVMe and network/audio/display drivers.

## Diagnostics

Expose stable device IDs, vendor/device IDs, class, driver binding, resource summary, interrupt count, DMA fault count, reset count, last error, and hotplug state. Avoid exposing raw kernel pointers to user space.
