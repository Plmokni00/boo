# MixedOS bounded PCI device registry

## Purpose

The device registry preserves a bounded snapshot of conventional PCI functions
found by the existing read-only mechanism-#1 scanner. It turns one-off PCI
enumeration into a kernel-owned inventory that later driver matching can use.

## Current behavior

- Scans PCI configuration space once during boot, before the interactive shell.
- Retains up to 64 device identity records.
- Records BDF, vendor/device IDs, class/subclass/programming-interface, revision,
  and interrupt pin.
- Provides stable snapshot iteration and common PCI class/subclass names.
- Exposes `devices` and augments `drivers` with discovered/recorded counts.

## Deliberate limits

A record remains `Discovered`; no PCI driver is bound. The registry does not
probe capabilities, size BARs, map MMIO, change command bits, route interrupts,
enable bus mastering, reset, or power-manage a function. It is not yet a complete
ACPI device tree or hotplug manager. The underlying scanner currently uses
conventional PCI mechanism #1 and keeps its existing output cap.

## Acceptance

After a Windows build and VirtualBox boot:

```text
devices
drivers
pci resources
```

The device count should match the existing read-only `pci` scan. Each record
should be labelled `unbound` until a real driver probe/bind lifecycle exists.
