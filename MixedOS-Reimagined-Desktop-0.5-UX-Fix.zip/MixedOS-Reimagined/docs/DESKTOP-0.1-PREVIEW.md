# MixedOS Desktop 0.1 — Default Boot Desktop

## Status

Desktop 0.1 is now the normal interactive boot destination. After kernel
initialization, MixedOS renders the bundled wallpaper and prototype desktop
chrome instead of entering the kernel console. There is no kernel-console
autostart or desktop countdown. Limine is configured with `timeout: 0`, so the
default MixedOS entry is started immediately without displaying the boot menu.
The desktop draws a black arrow pointer with a gray outline at screen center and
moves it from PS/2 mouse events. The pointer restores only its saved framebuffer
pixels when moved, avoiding full-screen redraws.

Press **F1** or **Ctrl+Alt+T** to open the kernel recovery console. On the
serial input channel, Ctrl+T (byte `0x14`) opens the same recovery console. The
recovery shell's `desktop` command still provides a one-shot preview that
returns to the shell with Escape. If framebuffer setup or wallpaper rendering
fails, boot falls back to the recovery console rather than hanging on a blank
screen.

## Bundled wallpaper

The default wallpaper is the exact 1920x1080 user-provided `MixedOS.png`. It is
kept in `kernel/assets/wallpaper/MixedOS.png` and embedded as a palette/RLE
asset in `kernel/assets/wallpaper/mixedos.rle`. The decoder validates the header,
palette indices, run count, byte length, and expanded pixel count before drawing.
It performs nearest-neighbor scaling while preserving the source aspect ratio.
No heap allocation or runtime PNG decoder is required.

## UI composition

The desktop draws the wallpaper, a restrained translucent top status strip,
and a bottom panel with Terminal, Files, and Settings prototype tiles. The Terminal tile opens the CMD-style shell, and Files/Settings open in-kernel
prototype app surfaces. They are not yet isolated user-space applications. The
framebuffer is not first painted with the kernel console or a separate boot splash.

## Deliberate limitations

This is an early graphical shell, not yet a complete desktop environment or
window manager. The pointer is a software cursor rather than a hardware cursor;
windows are not yet movable/resizable and there is no general compositor or
user-space graphical app model. The kernel console remains available as a recovery
and diagnostic environment.

## Next work

1. Extract a reusable graphics surface and clipping API.
2. Add dirty-rectangle tracking and a backbuffer.
3. Route mouse position/button state to a compositing loop and draw a cursor.
4. Add movable/focusable in-kernel prototype windows.
5. Replace prototype apps with user-space applications after the syscall/ELF
   application environment is ready.
