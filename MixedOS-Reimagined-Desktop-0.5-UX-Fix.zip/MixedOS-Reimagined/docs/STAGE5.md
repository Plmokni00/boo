# Stage 5 — Kernel heap

Stage 5 adds an explicit kernel heap above the Stage 3 physical-frame allocator
and Stage 4 active-root virtual-memory manager. It is intentionally **not** a
Rust `GlobalAlloc` implementation yet: integrating the Rust `alloc` crate before
process scheduling, interrupt-locking rules, and allocator-failure policy are
settled would expand the blast radius of a heap defect.

## Design

- A bounded 16 MiB high-half virtual arena is tried in dedicated PML4 slots
  509, 510, then 508. These are candidates, not assumptions: each new mapping
  must be accepted by the Stage 4 page-table manager. Existing boot mappings
  are never replaced.
- The heap is initialized lazily by the first `heap`/`heaptest` command or
  allocation call. This keeps a Stage 5 mapping defect from blocking the
  previously working Stage 2/3/4 boot path. The arena begins with four 4 KiB
  pages and grows in page multiples as needed, up to the configured cap.
- Every backing page comes from `physical::allocate_zeroed_frame()` and is
  mapped as supervisor, writable, and non-executable through `paging::map_page`.
  Partial growth is rolled back by unmapping before returning frames.
- The allocator uses a 16-byte-aligned, address-sorted intrusive free list.
  Allocation splits a free extent when the remainder can hold a free-block
  header; deallocation inserts the extent in order and coalesces adjacent blocks.
- An allocation header stores the original block start/span and request size.
  Deallocation checks arena bounds, block alignment, metadata bounds, and a
  pointer-specific cookie. A freed marker detects repeat frees while the
  corresponding header bytes have not been reused.
- `heap` prints arena capacity, used/free bytes, largest free block, free-block
  count, active allocations, peak usage, and allocation/free counters.
- `heaptest` exercises seven varied sizes and power-of-two alignments, writes
  and reads data through returned virtual pointers, frees in a fragmented
  order, and verifies that accounting returns to baseline.

## API and constraints

The API is `memory::heap::allocate(size, alignment)` (which lazily initializes
on first use) and unsafe
`memory::heap::deallocate(pointer)`. Convenience wrappers `kmalloc(size)`,
`kmalloc_aligned(size, alignment)`, and unsafe `kfree(pointer)` are also exposed.
`stats()` provides read-only diagnostics.
The first revision is single-core and normal-context only; callers must not use
it from interrupt context. Its spin lock is not an IRQ-safe/SMP lock. The heap
pages remain mapped after blocks are freed; this revision coalesces free blocks
but does not shrink/decommit the arena. The allocator returns explicit errors
and does not panic for normal exhaustion.

## Validation

`tools/test_heap_model.py` runs a host-side behavioral model for splitting,
coalescing, alignment, growth, double-free rejection, invalid alignments, and
bounded exhaustion. `tools/validate_source.py` checks integration and Stage 2
regression markers. These checks do not compile or execute the privileged Rust
implementation. Rust/Cargo are not installed in the authoring environment, so
The user-confirmed Stage 5 Windows build and VirtualBox screenshots show the seven-allocation heap test passed, returned to zero live allocations, coalesced to one free block, and maintained consistent 40 KiB byte accounting with zero free errors.

On a dedicated development machine or disposable emulator configuration, verify keyboard and mouse first, then run:

```text
help
heap
heaptest
heap
frames
paging
```

`heaptest` should report seven aligned allocations written, verified, freed,
and coalesced. `heap` should show the same live `used_bytes` and
`active_allocations` as before the test, while `capacity_bytes` may increase if
the test triggered arena growth. Finally, confirm `free_bytes + used_bytes ==
capacity_bytes`, check that heap free errors did not increase, and confirm the
Stage 2 input indicators are still responsive.
