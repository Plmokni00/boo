# MixedOS security baseline

This document defines requirements, not implemented protections. Keep each control marked pending in `STATUS.md` until code and tests exist.

## Trust boundaries

- Firmware and bootloader inputs are untrusted data and must be bounds-checked.
- User pointers, executable files, filesystem metadata, network packets, and device responses are untrusted.
- Kernel memory, driver memory, DMA buffers, and user memory require explicit ownership and lifetime rules.
- A successful device enumeration does not imply that the device is safe to activate.

## Required controls

1. Validate all lengths, offsets, alignments, integer arithmetic, and address ranges before access.
2. Validate/copy user pointers through dedicated copyin/copyout routines.
3. Enforce user/supervisor permissions at every page-table level; keep executable and writable mappings separate (W^X).
4. Keep kernel stacks non-executable and add guard pages.
5. Keep hard-interrupt paths bounded, allocation-free by default, and free of blocking locks.
6. Use checked lock ordering and distinguish IRQ-safe from sleepable locks.
7. Apply least privilege to device resources and service capabilities.
8. Require signed package metadata and signed update payloads before production distribution.
9. Make update installation atomic with rollback and recovery.
10. Keep secrets out of logs and diagnostics.
11. Never auto-format, overwrite unknown media, or silently modify boot configuration.
12. Provide a recovery boot path when a driver, service, or update fails.

## Threat-model questions

- Can malformed ACPI, ELF, filesystem, USB, PCI, or network input crash or corrupt the kernel?
- Can one process read or modify another process's memory?
- Can an untrusted process exhaust kernel memory, handles, CPU time, or IPC queues?
- Can a device DMA outside its assigned buffer?
- Can a compromised user process load a driver or map MMIO?
- Can an interrupted update leave the machine unbootable or user data inconsistent?

A “secure” label is not appropriate until these questions have tested answers and a documented threat model.
