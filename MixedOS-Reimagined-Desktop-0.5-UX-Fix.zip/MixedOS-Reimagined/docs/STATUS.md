# Implementation and validation status

Status vocabulary:

- **Not started** — no implementation.
- **Foundation** — design, ABI, or early support exists; meaningful functionality is incomplete.
- **Source implemented** — executable source exists, but compilation may not have been verified.
- **Compiled** — successful build recorded for a named toolchain and source version.
- **VM tested** — the actual image was booted and behavior was observed in a named VM configuration.
- **Hardware tested** — behavior was tested on identified physical hardware.

## User-confirmed baseline (2026-11-11)

The user supplied successful Windows build logs for Stage 1, Stage 2, and the unified input subsystem revisions. The user also supplied a VirtualBox screenshot showing the live framebuffer console, keyboard receive counter, mouse receive counter, mouse position/buttons, zero input errors/dropped events, and successful execution of `help`, `mem`, `uptime`, and `input`. This confirms that the Stage 2 interactive input path works in the user's VM. The exact VirtualBox firmware mode, machine profile, virtual CPU model, and VM RAM settings were not recorded.

## Current implementation snapshot

| Subsystem | Status | Evidence / limit |
|---|---|---|
| x86_64 kernel entry and Limine boot | VM tested by user | Stage 1 successful Windows build and VirtualBox boot; later interactive console screenshot confirms the kernel still starts. |
| Architecture API facade | Source implemented | Public x86_64 byte/word/dword port I/O, CPU control, interrupt control, and FPU initialization exports. |
| Serial diagnostics | VM tested by user | COM1 diagnostics; serial input is normalized into the shared event queue. |
| Framebuffer output | VM tested by user | Arimo proportional text is visible in the interactive console; user reports the latest console no longer flickers during mouse movement or typing. Software rendering only; no GPU acceleration. |
| Memory map and HHDM | Compiled in prior release; Stage 3 integration source implemented | Limine memory-map and higher-half direct-map responses are used by the frame allocator. |
| C ABI | Compiled in user-reported build | Freestanding C runtime object linked; kernel checks ABI revision. |
| Zig kernel component | Source implemented; Zig test compile fix applied, Windows recheck pending | Freestanding Zig 0.17.1 CRC-32/ISO-HDLC function is linked into MIXFS superblock encoding/validation. The exported function is also public to Zig importers so the Zig test module can call it; standard test vectors are part of the build. |
| Windows toolchain bootstrap | Source implemented; Windows execution pending | Checks Rust, Clang, Python, and Zig versions before installing; discovers registered Python versions and competing Clang installs, installs sequentially, validates Zig archive and executable hashes, and exposes a single double-click `Build.bat` workflow. |
| IDT and exception reporting | VM tested by user | Stage 2 kernel boots with the IDT; detailed fault-path coverage still needs dedicated tests. |
| MixedOS Kernel Halt (MKH) | Preview VM-observed; source implemented | Fatal panic/CPU-exception screen, bounded register diagnostics, recursion guard, emergency IST stacks, COM1 logging, and non-fatal `mkh preview` with Escape dismissal. The user has seen the preview in VirtualBox; individual fatal exception paths are not all independently fault-injection tested. |
| Legacy timer | VM tested by user | Screenshot shows increasing uptime; PIT nominally 100 Hz, no APIC/high-resolution timer. |
| Unified input subsystem | VM tested by user | Screenshot shows changing keyboard/mouse byte counters, typed shell commands, mouse coordinates/buttons, and zero errors/dropped events. |
| PS/2 keyboard | VM tested by user | Screenshot-confirmed typed `help`, `mem`, `uptime`, and `input` commands. USB HID and international layouts are not implemented. |
| PS/2 mouse | Input path VM-tested by user; desktop pointer source implemented | Standard PS/2 packets and prior input counters were VM-observed. The software desktop pointer is now a black 16x20 arrow with a gray outline and exact framebuffer-region restoration. It is source/regression-tested only; a fresh Windows build and VirtualBox movement test are still required. |
| Kernel command loop | VM tested by user | `help`, `mem`, `uptime`, and `input` visibly executed. This is still a ring-0 debug console, not a user shell. |
| Physical frame allocator | VM tested by user | User supplied a Stage 3 VirtualBox screenshot showing managed/free pages, eight-page `memtest` success, zero free errors, and restored allocation accounting. |
| Page-table manager / virtual mapping | VM tested by user | User supplied a VirtualBox screenshot showing `vmtest` mapped, accessed, translated, unmapped, and reclaimed two pages; zero map failures; 7 TLB invalidations; zero MixedOS-owned page-table pages remaining; active Limine CR3 preserved. Stage 4 build log reports successful Rust compilation and ISO creation. |
| Kernel heap | VM tested by user | User screenshot confirms seven aligned allocations written, verified, freed, and coalesced; zero active allocations, consistent 40 KiB accounting, and no allocator errors. |
| Rust global allocator | Not started | Explicit heap API must pass its VM test before integration with `alloc` or `GlobalAlloc`. |
| GDT/TSS and privilege isolation | VM tested by user | User screenshot for Stage 6 Fix 5 shows the two ring-3 processes entered and exited, and the shell returned with CR3 verified. |
| Processes / scheduling / user mode | VM tested by user | Screenshot shows two processes exited, zero faults, four syscall reports, five context switches, zero cleanup errors, and both private address spaces/stacks reclaimed. General ELF loading and per-process FPU state are not implemented. |
| Legacy IDE ATA PIO block device | Compiled in user-reported Windows build | IDENTIFY, LBA28 512-byte sector PIO read/write, bounded status polling, and optional flush. Physical storage-controller compatibility and safe disk I/O still need dedicated hardware testing. No AHCI/NVMe/USB storage. |
| MIXFS v1 persistent filesystem | Compiled in user-reported Windows build | Dual CRC superblocks, bitmap, fixed inode table, extents, path-based VFS, file/dir operations, fsck consistency check and persistent self-test; dedicated expendable-disk runtime testing remains pending. No journal or full recovery. |
| PCI discovery | User-reported VM enumeration | Read-only conventional config-space scan; user previously reported 11 devices found/listed. No BAR mapping, resource assignment, bus mastering, or drivers. |
| Ethernet / Wi-Fi / TCP/IP | Not started | No network drivers or stack. |
| Clock / timezone service | Not started | PIT tick counter only; no RTC, timezone, or wall clock. |
| Desktop / window manager | Not started | No user-space app model or compositor. |
| Java / Lua application runtimes | Not started | Zig is now used as a freestanding kernel component, but no Zig user-space runtime is present. Java/JVM and Lua runtimes remain future work and will be added when their OS services are ready. |
| SQLite | Not started | No persistent filesystem to support it. |
| Firefox | Not started | No browser binary or engine port. |
| Windows compatibility | Not started | No PE loader or Win32 APIs. |
| Installer / updater | Not started | No partition or recovery tooling. |


## Stage 8.0 — read-only PCI discovery

The kernel now has x86 port-I/O `inl`/`outl` operations and a read-only PCI
configuration-space scanner using mechanism #1. The user reports that MixedOS boots
and the `pci` command finds 11 devices (11 listed). The `pci` shell command scans
conventional bus/device/function space, honors multifunction headers, reports
vendor/device IDs and class codes, and caps printed output at 32 devices. It
does not enable bus mastering, map BARs, assign resources, or load drivers.
This is a discovery foundation for later network, audio, and graphics drivers;
it is not a driver framework and has not yet been compiled or VM-tested.

## Stage 4 validation boundary

The user supplied a successful Windows build log for Stage 4, including a
successful Rust kernel compile, ISO creation, and Limine BIOS installation. A
VirtualBox screenshot then showed `vmtest` mapping, accessing, translating,
unmapping, and reclaiming two pages; the screenshot showed zero map failures,
seven TLB invalidations, zero MixedOS-owned page-table pages remaining, and the
active Limine CR3 preserved. The same screenshot showed keyboard and mouse
input still active. This is VM-test evidence for the specific Stage 4 image the
user booted, not physical-hardware or SMP validation.

## Stage 5 validation boundary

Stage 5 adds an explicit kernel heap API but does not install it as Rust's global
allocator. The heap maps a bounded high-half arena through the Stage 4 page-table
manager, obtains zeroed frames from Stage 3, splits and coalesces address-sorted
free blocks, validates allocation headers, and exposes `heap`/`heaptest` shell
commands. The user's VirtualBox screenshots confirmed seven differently sized
and aligned allocations were written, verified, freed in a fragmented order,
and coalesced. The heap ended with 40 KiB capacity, zero used bytes, zero live
allocations, one free block, and zero free errors. Physical frame accounting
remained consistent.

## Stage 6 validation boundary

Stage 6 source includes a first ring-3 process/scheduler implementation: GDT/TSS,
DPL3 `int 0x80`, cloned process roots with private user pages, round-robin yield,
PIT preemption, per-process kernel stacks, user-fault retirement, and
`proctest`/`procs` commands. The first disposable VirtualBox `proctest` attempt
failed closed before entering ring 3 with `InheritedUserMapping`. The original
check treated any present PML4 parent U/S bit as an inherited user mapping.
However, x86 user access requires U/S at every level, so a bootloader-set U/S bit
on a parent can still lead only to supervisor leaves. Stage 6 Fix 1 clears U/S on
inherited present PML4 entries in each private cloned process root, preserves
the active kernel root, and verifies the clone before adding the process-owned
user subtree. The dedicated user PML4 slot must still be empty. Fix 2's framebuffer output showed both ring-3 tasks reaching report, yield, and
exit syscalls but did not return to the shell. Fix 3 added exit/return-path
breadcrumbs. Fix 4 simplifies final teardown: an assembly-only leaf stub
restores the saved kernel CR3 and shell stack, then returns normally to
`run_demo()`, where Rust verifies CR3, restores TSS.RSP0, and reclaims process
resources. Host source/model checks and Clang assembly/C checks pass; a new
Windows build and disposable VirtualBox `proctest` are still required. The user subsequently
built Stage 6 Fix 5 and supplied a VirtualBox screenshot showing both processes
exited, zero faults, four syscall reports, five context switches, zero cleanup
errors, the kernel CR3 restored/verified, both private address spaces and stacks
reclaimed, and the `MIXEDOS>` prompt returned. Stage 6's built-in demonstration
process lifecycle is therefore VM-tested. This does not validate a general
process API, ELF loader, preemptive multitasking under arbitrary workloads, or
physical SMP.


### Stage 6 Fix 5 validation boundary

The user's VirtualBox screenshot for Fix 5 confirms the built-in process test
completed end-to-end: both ring-3 processes exited, zero faulted, four syscall
reports were received, five context switches occurred, zero cleanup errors
were reported, the kernel CR3 was restored/verified, both private address spaces
and kernel stacks were reclaimed, and the `MIXEDOS>` prompt returned. This
validates the built-in two-process demonstration on that VM image. It does not
validate a general ELF loader, arbitrary workloads, per-process SIMD state,
or SMP.


## Stage 7 validation boundary

Stage 7 source adds a legacy IDE ATA PIO block driver, a block-device contract,
a VFS facade, and MIXFS v1. MIXFS uses dual CRC-protected superblocks, a sector
bitmap, 256 fixed inodes, extents, basic path resolution, directories, file
create/read/explicit-overwrite/bounded-append/same-directory-rename/delete,
structural checks, and a persistent round-trip self-test. The user has booted
the previous Stage 7 safe-target build in VirtualBox, formatted the dedicated
secondary 256 MiB VDI, created nested directories and two files, and confirmed
both files remained readable after a VM reboot. The new file-operation update
in this archive is included in the user-reported successful Windows build; its
new file-operation paths still need dedicated expendable-disk runtime testing. It never formats on mount. Formatting requires an explicit
`format ataN --erase-dedicated-disk` target; the first detected ATA disk is
protected and targets larger than 512 MiB are rejected during this bring-up
stage. Host-side layout/source-model checks pass. The previous safe-target
build has been booted and its basic create/read/reboot-persistence path was
confirmed by the user. This new file-operation revision still needs a Windows
Rust build and a VM test before the added commands are considered verified. It
is not journaled and does not claim power-loss recovery. The future custom MixedOS Windows
compatibility layer is documented as a separate later project that will use
the VFS; no PE loader or Win32 API implementation exists yet.


## Stage 7 safety revision

The original Stage 7 formatter was unsafe: it always targeted the first ATA
hard disk. The revised source enumerates all four legacy IDE positions, lists
them as `ata0`–`ata3`, protects the first detected ATA disk from formatting,
rejects targets above 512 MiB, and requires an explicit target ID plus the
destructive confirmation token.
At boot, MIXFS mount scans detected disks using reads only so a previously
formatted secondary data VDI can be remounted. A fresh Windows build is now confirmed by the supplied log; dedicated expendable-disk runtime testing on a compatible controller remains pending.


## Console usability update

The console has a bounded 256-line framebuffer scrollback buffer, mouse-drag scrollbar, `scroll` command, and 16-entry boot-session command history recalled with Up/Down. The PS/2 input update negotiates IntelliMouse wheel protocol ID 3, falls back to standard three-byte packets for unsupported devices, and normalizes wheel polarity so wheel-up moves toward older output and wheel-down returns toward newer output. Everyday `help` is now compact; `diagnostics` lists internal developer and hardware commands separately. The user has now supplied a successful Windows build log and reports a successful boot with 11 PCI devices found. This follow-up source update still needs a fresh Windows rebuild and physical-hardware wheel-direction check.


## Pre-desktop audit addendum (2026-11-16)

The user reports that the latest MixedOS source boots. Treat that as user-confirmed boot evidence for the user's built image; the exact image hash, toolchain versions, firmware mode, and VM configuration were not supplied in this archive, so do not infer those details.

The current archive's host-side validation was rerun during the audit: `tools/validate_source.py` passed (68 required files), and all 14 `tools/test_*.py` scripts passed. This environment had no `cargo` or `rustc`, so the audited source revision was not compiled here and no new ISO or VM run was performed.

The source has meaningful foundations, but it is not yet a general-purpose desktop OS. ACPI table discovery is VM-observed; PCI discovery is read-only; the current source adds a software-only resource reservation registry and a first DMA32 allocator, but there is still no PCI ECAM path, safe BAR sizing/assignment, MMIO mapping, DMA/cache synchronization or IOMMU path, production driver lifecycle, USB controller or USB class drivers, AHCI/NVMe, NIC/network stack, RTC/timezone service, general ELF loader, production syscall/file-descriptor/IPC model, general user-space init/service manager, package/update/recovery system, or production security model. The ring-3 scheduler is a uniprocessor demonstration; the kernel heap is not a global allocator.

See `PRE-DESKTOP-MASTER-PLAN.md`, `DRIVER-MODEL.md`, `SECURITY-BASELINE.md`, `STORAGE-RECOVERY-PLAN.md`, `NETWORK-ARCHITECTURE.md`, `USERSPACE-ABI-PLAN.md`, `PLATFORM-SERVICES-PLAN.md`, and `VALIDATION-MATRIX.md` for ordered work and acceptance criteria.


## MKH preview and bitmap-font fix (2026-11-16)

The non-fatal MKH preview now remains visible while ordinary keyboard input occurs and dismisses only on Escape (or serial ESC). The framebuffer text renderer preserves lowercase ASCII using added 5x7 lowercase glyphs. The Stage 2 framebuffer source hash was intentionally refreshed and the validator/test contract now verifies Escape-only dismissal and lowercase rendering. See `MKH-PREVIEW-FONT-FIX.md`. A fresh Windows build and VM check are still required for this revision.


## Arimo framebuffer typography integration (2026-11-16)

The source bundles Arimo Regular/Bold TrueType assets and their SIL OFL 1.1
license notice. MKH, boot status, and the complete interactive framebuffer
console use pre-rasterized proportional glyph atlases with grayscale coverage
blending. Shell cursor movement, backspace redraw, and automatic wrapping use
glyph advances rather than fixed character cells. The text path is fixed-memory
and performs no heap allocation. The 5x7 font remains as an emergency fallback;
COM1 serial output is separate. Host source/font and proportional-console
contract tests pass. The proportional-console update still needs a fresh
Windows Rust build and VirtualBox runtime check.


## Current console baseline update (2026-11-16)

The user built and booted the Arimo proportional-console revision in VirtualBox and supplied a screenshot showing the Arimo-rendered interactive shell, help output, and typed input. The subsequent no-flicker revision was also booted by the user; the user explicitly confirmed that mouse movement and typing no longer cause visible flicker. Treat this as user-reported VM evidence for the console behavior in that run. The exact current ISO SHA-256 and full build log have not yet been recorded, so the next build should capture those details before further kernel changes.

The latest no-flicker source archive was rechecked in the development workspace: `tools/validate_source.py` passes (86 required files), and all 21 `tools/test_*.py` scripts pass. These are host-side checks and do not substitute for the user's Windows build or VirtualBox runtime check.

The no-flicker Arimo console is the known-good UI baseline. ACPI discovery and the read-only PCI inventory are now VM-observed by the user. The current source revision adds software-only PCI resource reservations and a first DMA32 allocator; these additions still require a fresh Windows build and VirtualBox testing. Follow `ROADMAP.md` for the next gates: validate the new commands, then finish ECAM/BAR sizing/MMIO mapping and DMA device-lifetime rules before xHCI/USB.

## Pre-desktop engineering pass (2026-11-16)

The current work pass addresses two concrete gaps found in the master-roadmap
archive. First, framebuffer scrollback movement now uses an overlapping,
bounded framebuffer blit for small scroll deltas and redraws only newly exposed
history rows; large jumps retain a full-viewport fallback. Scrollbar dragging
uses the same path. Appending output while the user is scrolled up preserves
the visible history and updates only the scrollbar thumb. This is source- and
host-model-tested; it still requires a fresh Windows build and VirtualBox test.

Second, the existing bounded ACPI table parser was connected to Limine's RSDP
request in read-only mode. The initial implementation contained an incorrect
request ID and physical/virtual address assumption; see the later correction
below. Shell diagnostics `acpi`, `memmap`, and `sysinfo` expose firmware tables,
the bounded memory-map listing, and combined hardware/memory information.


## Toolchain manager and Zig integration update (2026-11-16)

The Windows builder now checks its active language toolchains in sequence: Rustup/Rust/Cargo and the freestanding target, LLVM/Clang, Python, then Zig. It reports detected versions, installs or updates only missing/unsupported requirements, selects the newest registered Python interpreter, compares multiple Clang locations, and reuses a checksum-verified persistent per-user Zig 0.17.1 cache. The user-facing `.bat` launcher is a single double-click entry point: it checks dependencies, installs only what is missing, and builds the complete ISO without requiring command-line switches. Rustup informational stderr is captured as diagnostic output rather than being treated as a fatal PowerShell error. The launcher has a PowerShell preflight, simple status output, and exit-code forwarding.

A freestanding Zig CRC-32/ISO-HDLC module is linked into MIXFS superblock encoding and validation. The builder runs Zig test vectors before creating the kernel object. Host-side source validation now passes with 86 required files and 21 regression scripts. This is source and host-test evidence only: PowerShell execution, Zig compilation, Rust linking, Windows ISO generation, and VM boot of this exact revision remain pending.


## Zig 0.17.1 CRC-32 test visibility correction (2026-11-16)

The first Windows execution of the one-click Zig toolchain build reached the Zig
test phase, then failed because `crc32_test.zig` imports `crc32.zig` and calls
`mixedos_zig_crc32`, while that declaration was `export` but not `pub`. In Zig,
`export` gives the function an external object-file symbol; `pub` makes the
declaration accessible from another Zig module. The function is now declared
`pub export fn mixedos_zig_crc32`, retaining its external C ABI symbol and
making it visible to the test module. The source validator and all 21 Python
regression scripts pass after this correction. The Zig 0.17.1 test and full
Windows kernel link must be rerun by the user; they have not been executed in
this environment.


## ACPI request/address correction and hardware inventory (2026-11-16)

The first VirtualBox `acpi` diagnostic reported `Unavailable`. Source review found
two related Limine integration defects: the second half of the RSDP request ID
was mistyped (`...accdcfc3` instead of the protocol ID `...accdcf3c`), and
`acpi.rs` treated the returned RSDP pointer as physical even though MixedOS
requests Limine base revision 6. Under base revision 4 and later, the RSDP
response address is an HHDM virtual address. The request ID is corrected; ACPI
now uses the RSDP virtual address directly and subtracts the HHDM offset only
for physical memory-map range validation. XSDT/RSDT child table entries remain
physical addresses and are translated through the HHDM when accessed. This
change is protocol-grounded but still needs a fresh Windows build and VirtualBox
`acpi` run to confirm discovery.

The `memmap` display now names Limine memory types rather than showing only
numeric type codes. A new `pci resources` command reports the currently
programmed BAR snapshot categories (I/O, MMIO32, MMIO64, prefetchable, zero
base, reserved) for enumerated devices. This is inventory only: it deliberately
does not size BARs, claim ranges, map MMIO, write PCI configuration, or enable
bus mastering.

The delivery archive is packaged with a top-level `MixedOS-Reimagined` folder
so extraction retains the user's VirtualBox-associated project directory
name. The builder continues to use its script-root-relative paths.


## User-reported integrated VM baseline (2026-11-16)

The user supplied a Windows build log confirming that Rust 1.100.0, Clang
23.1.5, Python 3.12.10, and Zig 0.17.1 were detected; the Zig CRC-32 test
passed; the Zig freestanding object was emitted; the Rust release kernel
compiled and linked; and the BIOS/UEFI ISO was generated. The ISO SHA-256 in
that log was `aa58d3ef6da9847451dbf22a59529b72cd9ecf24be1d84ece7ae6ed80ecf79f2`.
The user then booted that ISO and confirmed that `acpi`, `memmap`, `sysinfo`,
and MKH preview commands ran. Observed diagnostics reported 17 memory-map
entries, 503 MiB usable memory across 3 regions, 128,927 free allocator frames,
and 11 PCI devices. ACPI still reported Unavailable, which led to the Limine
request-ID and HHDM-address correction described above. The corrected ACPI
code, named memory map output, and PCI BAR inventory are not yet built or
boot-tested.


## Kernel services increment

- Added a 64 x 160-byte bounded RAM log ring; `kprintln!` records to it and COM1.
- Added shell `log`, `log clear`, `uptime`, `version`, and `drivers` commands.
- Logging is volatile, bounded, allocation-free, and not NMI-safe.
- New host-side contract test: `tools/test_kernel_services.py`.
- Rust compile and VirtualBox boot verification remain required on Windows.


## Early-entry triple-fault correction (2026-11-16)

The user's VirtualBox log for the prior kernel showed a triple fault at an SSE2 `MOVD` instruction (`movd xmm0, edi`) while CR4 was `0x20` and IDTR was `0:0`. The evidence points to compiler-generated SSE2 executing before OSFXSR/OSXMMEXCPT were enabled; the resulting exception had no valid IDT to dispatch through.

The ELF entry is now an assembly `_start` trampoline. It builds a bootstrap IDT for Limine's current CS and a second bootstrap IDT prebuilt with the kernel code selector, loads the first table, enables CR0.MP / CR4.OSFXSR / CR4.OSXMMEXCPT, initializes x87 and MXCSR, marks `MIXEDOS_FPU_READY`, aligns the stack, and calls `mixedos_rust_entry`. The GDT reload switches IDTR to the kernel-selector bootstrap table. Rust then installs its full diagnostic IDT and verifies CPU state instead of trying to initialize SSE after Rust has already executed.

Validation in this environment: `tools/validate_source.py` passed with 91 required files; all 24 `tools/test_*.py` scripts passed; `interrupts.S` assembled with Clang for `x86_64-unknown-none-elf`. This environment does not have `rustc`/`cargo`, so no full Rust link, ISO build, or VM boot was performed here. The Stage 6 baseline hash for `interrupts.S` was deliberately updated because only the shared assembly entry/IDT handoff changed; Stage 6 process/scheduler source remains unchanged. The next required confirmation is the user's double-click Windows build and VirtualBox boot.

## User-confirmed VirtualBox checkpoint (2026-11-16)

The user supplied two VirtualBox screenshots from the successfully booted
triple-fault-fix image. The interactive console showed keyboard and PS/2 mouse
ready, the disk and MIXFS mounted read/write, `sysinfo` reporting 5,577 MiB of
usable boot memory across four regions and 11 PCI functions, and ACPI reporting
RSDP revision 2 with XSDT and three validated tables. The ACPI screenshot showed
MADT and FADT present, two local-APIC entries, one I/O-APIC entry, and no MCFG or
HPET. The separate MKH screenshot showed the preview-only page-fault layout,
clearly marked as sample data; it did not represent an actual exception. The
user confirmed `mkh preview`, `acpi`, and `sysinfo` worked.

## Stage 5/6 hardware-foundation batch (source implemented; VM test pending)

- A one-time, bounded PCI device registry now stores up to 64 BDF/identity/class
  records and exposes `devices`; records remain discovered/unbound.
- A software-only resource registry supports 64 generation-tagged I/O-port and
  MMIO range claims with overflow, alignment, range-bound, and overlap checks.
  It intentionally does not size BARs, map MMIO, or modify PCI configuration.
- The physical allocator now supports aligned contiguous frame runs and
  whole-run validation/free. Existing single-frame allocation remains the same.
- The DMA32 allocator adds zeroed contiguous buffers below 4 GiB, capped at
  16 MiB, with a checked HHDM pointer and explicit unsafe release after hardware
  quiescence. Dropping a live buffer leaks it safely rather than freeing frames
  that a device might still access.
- New shell diagnostics: `devices`, `resources`, `resources test`, `dma`, and
  `dmatest`. No controller is given a DMA buffer in this release.
- Host source validator and regression tests pass (25 Python `test_*.py`
  scripts); the full Rust/C/Zig kernel build and VirtualBox execution of this
  batch have not yet been performed in the authoring environment.


## Stage 5/6 device and DMA foundation — 2026-11-16 (new source revision)

This source revision adds a 64-entry one-time PCI inventory, a 64-slot
software-only I/O-port/MMIO reservation table, aligned contiguous physical
frame allocation with unique non-copyable ownership tokens, and a zeroed DMA32
buffer API capped at 16 MiB below the 4 GiB boundary. Dropping an unreleased DMA
buffer intentionally keeps its frames allocated; explicit release is unsafe
and requires hardware quiescence. CPU slice access is also explicitly unsafe
and requires the device to remain quiesced, avoiding safe Rust references
while a future device might mutate the memory. The kernel does not hand these
buffers to any controller in this revision.

New shell commands are `devices`, `resources`, `resources test`, `dma`, and
`dmatest`. The resource self-test uses only synthetic software reservations;
the DMA self-test touches only allocator-owned memory and releases it before
returning. The host source validator passes with 99 required files and all 25
Python regression scripts pass. This authoring environment lacks Rust/Cargo/Zig,
so full kernel compilation and VirtualBox runtime validation of this revision
remain pending.


## Desktop 0.1 preview (2026-11-16)

Added a wallpaper-backed framebuffer desktop preview (`desktop` / `desktop preview`)
that returns to the kernel console on Escape. The dock is visual-only; no real
window manager or graphical applications exist yet. Exact user-provided wallpaper
source is stored at `kernel/assets/wallpaper/MixedOS.png`.


## Desktop mouse pointer source pass (2026-11-16)

Desktop 0.1 now draws a visible 16x20 software arrow pointer at the center of the
screen during startup. The pointer body is near-black (RGB 5,6,9) with a medium
gray outline (RGB 154,158,168). Mouse events move the pointer using the normalized
PS/2 coordinates. The renderer saves the exact raw framebuffer pixels beneath
the pointer and restores only that small region before drawing at its new position;
it does not repaint the wallpaper or the whole desktop on movement. The Files and
Settings prototype surfaces share the cursor state. Terminal and recovery console
currently retain their text-focused presentation without the desktop pointer
overlay. Host-side regression tests cover cursor shape, colors, centering, movement,
and pixel restoration. Windows compilation and VirtualBox cursor movement are
not yet verified for this source revision.

## Desktop 0.5 C-composited UI — 2026-11-16

The default desktop shell and decorated window chrome now render through a freestanding C framebuffer compositor, with Rust retaining input, app state, MIXFS operations, and application content. The desktop uses the original SVGPortal icon artwork from Plmokni00/boo plus Lucide window controls for minimize, maximize/restore, and close. The Files window opens centered at a smaller responsive size; title bars are draggable; app windows can minimize to and restore from their dock slots. Pointer acceleration has been reduced to a 2–5 multiplier. The C UI object compiles as freestanding x86-64 C, the source validator passes, and all 34 Python regression tests pass. The Rust kernel/ISO build and VirtualBox boot remain unverified because the authoring environment has no Rust/Cargo toolchain or VM runtime. This is an in-house C framebuffer compositor, not LVGL or a third-party GUI toolkit.

## Desktop 0.4 compile correction (2026-11-16)

The Windows build exposed Rust error E0381 in `kernel/src/desktop.rs`: the Files
application's `count` variable could be read by its Enter-key handler along a
control-flow path where the compiler could not prove that a redraw had assigned
it. The variable is now initialized to zero before the Files event loop and is
refreshed from the MIXFS listing whenever `needs_redraw` is set. This preserves
the existing list/navigation behavior while making every loop iteration's count
well-defined. Also removed redundant parentheses in the Start-menu Escape check
and simplified `join_path` initialization while retaining an explicit buffer
bounds check. Added `tools/test_desktop_file_manager_count_init.py` as a source
regression test. Source validation and host-side regressions do not replace a
Windows Rust kernel build or VirtualBox runtime test.
