# Stage 7 — Safer file operations

This update makes file replacement explicit and adds basic text-file management.

## Commands

- `write /path/name.txt text` creates a new file. It returns `AlreadyExists` if the name is already in use.
- `overwrite /path/name.txt replacement text` replaces an existing file. It returns `NotFound` rather than creating a missing file.
- `append /path/name.txt extra text` keeps the old contents and adds text. The current shell implementation is limited to a 2 KiB resulting file; an over-limit append returns `BufferTooSmall` before making changes.
- `rename /path/old-name.txt new-name.txt` renames a file or directory within the same parent directory. It refuses invalid names and collisions.

`cat`, `mkdir`, `ls`, `sync`, and `fsck` remain available. `rm` now removes files only; `rmdir` removes empty directories only. Both reject the wrong entry type, and `rmdir` never deletes a non-empty tree. All four write/rename operations use the VFS and MIXFS mutation protocol. A failed on-disk mutation leaves the volume fail-closed/read-only until `fsck` can validate it.

## Verification boundary

Host-side validators and Python filesystem/storage models verify source structure and format assumptions; they do not replace a native Rust kernel build or runtime test on the target storage controller. This container has no `rustc` or `cargo`; run `Build.bat` on the configured Windows build machine, then test each operation against the dedicated expendable test disk. Do not run `format` again on the already-populated test volume.


## Directory listing and deletion safeguards

- `ls [path]` lists up to 64 direct children (type, size, and name).
- `rm /path/file` removes a file only; it returns `IsDirectory` for directories.
- `rmdir /path/dir` removes an empty directory only; it returns `NotDirectory` for files and `DirectoryNotEmpty` for non-empty directories.
- The root directory cannot be removed. Recursive deletion is not implemented.
- `fsck` checks reachable inodes, directory parent/type links, extent bounds, bitmap reservations, and free-space accounting. It does not checksum file contents or reconstruct a damaged directory tree.
