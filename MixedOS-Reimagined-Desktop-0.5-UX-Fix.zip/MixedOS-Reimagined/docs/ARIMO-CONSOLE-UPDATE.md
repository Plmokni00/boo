# Proportional Arimo console update

Date: 2026-11-16

## Scope

The interactive framebuffer terminal now uses the same embedded Arimo Regular
coverage atlas as other kernel status text. The boot, MKH, and console title
paths continue to use their existing Regular/Bold atlas calls.

## Terminal behavior

- Shell output, echoed input, status labels, and numeric counters render with
  proportional Arimo glyph advances.
- Cursor X position is advanced by the same per-glyph metrics used by the
  renderer; restored cursor positions after scrollback redraw are measured from
  the stored line contents.
- Automatic wrapping is based on measured pixel width, not a fixed number of
  character cells.
- Backspace updates the stored line and redraws that visual row, clearing old
  glyph coverage before repainting the remaining text.
- The terminal uses a 20-pixel line step with a reserved top area for the
  larger Arimo status header.
- The bounded 256-line scrollback model and shell command history remain intact.
- If the embedded Arimo regular atlas is unavailable, the console Canvas text
  path falls back to the compact 5x7 bitmap renderer.

The console still accepts printable ASCII only. Unicode shaping, kerning,
variable-size runtime font selection, and dynamic TTF parsing remain future
user-space/desktop font-service work. COM1 serial text is independent of the
framebuffer renderer.

## Validation

`tools/test_arimo_console.py` checks the default Arimo text path, proportional
advances, pixel-based wrapping, cursor updates, backspace redraw, and bitmap
fallback. The test is part of the Windows `Build.bat` source-check sequence.
`tools/validate_source.py` also checks the Stage 2 input-source baseline after
this intentional framebuffer change.

Host-side source and model checks pass for this revision. The user must still
run the Windows build and test typing, Backspace, long-line wrapping, scrollback,
and mouse scrolling in VirtualBox. This documentation does not claim that
this revision has been compiled or booted.


## Console repaint behavior

The proportional console renderer now avoids repainting the full scrollback for
ordinary keyboard input when the viewport is already at the bottom. The status
strip displays stable device readiness rather than live packet counters and mouse
coordinates, so mouse motion and typing do not continuously clear and redraw it.
Detailed counters remain available with the `input` command. Scrollback is repainted
only when its visible offset changes or a full-screen operation is requested.
