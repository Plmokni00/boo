# MixedOS first-generation DMA32 allocator

## Purpose

Provide the first real buffer-ownership primitive for future bus-mastering
controllers. The initial policy is intentionally conservative: contiguous
4 KiB physical frames below the 4 GiB address ceiling.

## Physical frame runs

`physical::allocate_contiguous` returns an opaque `FrameRun` only when every
frame is managed, free, adjacent, aligned to the requested power-of-two page
alignment, and below the exclusive physical-address limit. Allocation marks the
whole run under the allocator lock. `free_contiguous` first validates every
frame and then frees the entire run atomically; it never partially frees a bad
run. `run_to_hhdm` validates ownership for every frame before forming a direct-map
pointer.

## DMA32 buffer API

`DmaBuffer::allocate_dma32`:

- rejects zero-length and requests larger than 16 MiB;
- obtains physically contiguous frames below `0x1_0000_0000`;
- verifies the full allocation fits the DMA32 mask;
- requires a valid HHDM mapping;
- clears the complete page-rounded allocation before exposing its address;
- exposes the physical address separately from the kernel virtual mapping;
- provides only explicitly `unsafe` CPU slice accessors named
  `as_slice_when_quiesced` and `as_mut_slice_when_quiesced`. Their caller must
  ensure no device can access the buffer while a Rust slice exists, avoiding
  an aliasing/data-race hazard when hardware later writes the buffer.

A buffer is not implicitly returned to the physical allocator on Drop. It must
be released with the unsafe `release_after_quiesce` method, whose caller must
prove that every device using the buffer is stopped and has no outstanding DMA.
If a buffer is accidentally dropped, the pages intentionally remain allocated
and the orphan counter increments. This trades a visible memory leak for
preventing a use-after-free by a bus-mastering device.

## Commands

- `dma` displays the DMA32 ceiling, active allocations, failures, orphaned
  buffers, and release errors.
- `dmatest` allocates two contiguous pages, verifies they are below 4 GiB,
  checks their zeroed state, writes/reads boundary bytes, clears and explicitly
  releases them, then verifies frame accounting is restored.

## Not yet implemented

There are no DMA-capable device drivers yet. The current allocator does not
implement IOMMU mappings, cache synchronization APIs, pinning against virtual
unmap, scatter/gather lists, boundary constraints, 64-bit address masks,
controller completion/cancellation, or in-flight operation tracking. Drivers
must not enable PCI bus mastering or pass these buffers to hardware until those
contracts and teardown paths are implemented and reviewed.
