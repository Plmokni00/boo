# MKH preview and boot-order audit — 2026-11-14

## Recovered baseline

The supplied `MixedOS-MKH-Kernel-Halt.zip` contains the first fatal Kernel Halt (KH/MKH) implementation. It does not contain a non-fatal preview command. This update adds `mkh preview` as a safe visual test of the same renderer. The command requires the explicit `preview` subcommand.

## New command

- `mkh preview` renders a sample page-fault-style screen with explicit `PREVIEW ONLY` and `KERNEL RUNNING` text.
- It does not call `claim_fatal_path`, set `HALTING`, disable interrupts, or call `halt_forever`.
- A keyboard key dismisses the screen. A COM1 serial session dismisses it with ESC.
- On exit, the existing terminal redraws its chrome and scrollback in place. The command preserves scrollback, cursor, and scroll position, then refreshes the input-status strip.
- If the boot framebuffer is absent or unsupported, the command returns an error immediately rather than waiting forever.

## Boot-order findings and changes

1. **Rust executed SSE before OSFXSR was enabled.** The ELF entry is now an assembly trampoline. Before calling any Rust code, it loads a small bootstrap IDT, clears CR0.EM/TS, sets CR0.MP, enables CR4.OSFXSR/OSXMMEXCPT, initializes x87/MXCSR, and only then marks `MIXEDOS_FPU_READY`. When the kernel installs its GDT, IDTR is switched to a second bootstrap table prebuilt with the new kernel code selector before returning to Rust. Rust verifies the state rather than initializing it late. The full diagnostic IDT then replaces the bootstrap table.
2. **MKH learned about the framebuffer relatively late.** The original sequence checked the C ABI and inspected memory before registering the framebuffer. A fatal failure in those earlier steps could only produce a serial report. The framebuffer is now registered immediately after the Limine base revision is accepted, before FPU, C ABI, memory, and storage initialization.
3. **The timer/PIC were enabled before polled input initialization.** The original sequence enabled interrupts, then initialized the i8042 controller and devices. The input subsystem deliberately polls and disables PS/2 IRQ delivery, so the timer is not needed during that setup. Input now initializes with IF clear; PIC/PIT initialization and `sti` happen afterward.

## Sequencing that remains intentional

- GDT/TSS must precede IDT installation because the IDT uses the GDT selector and TSS IST stacks.
- The Limine base revision is checked before dereferencing/registering the framebuffer response.
- Memory setup precedes ATA/MIXFS initialization because storage code may use memory-backed state; the heap remains lazy and is not forced during boot.
- ATA probing and MIXFS mount remain polling-only and occur before timer interrupts are enabled. Boot discovery performs reads but does not format or write an unrecognized disk.
- `interrupts::initialize()` remains the only point that unmasks PIT IRQ0 and enables interrupts.

## Remaining performance / scheduling issue

The shell is a continuously polling ring-0 loop and can consume a full CPU core. This is documented and currently intentional: PS/2 IRQ delivery is disabled, so an unconditional `hlt` would make keyboard/mouse input appear unresponsive. Before a desktop or long-running user application environment, MixedOS needs an idle task plus an interrupt-driven input strategy (or a carefully designed polling/idle hybrid) so the processor can sleep between events.

## Desktop status

This ZIP contains no compositor, window manager, desktop shell, or application launcher source. Its roadmap still lists desktop/services as a later stage. The package supports treating desktop work as the next planned project milestone, but it is not evidence that desktop implementation had already started in this particular snapshot. A practical desktop needs at least a stable display/input boundary, general user-mode executable loading and syscall interfaces, and a compositor/window protocol; today's framebuffer renderer is a software console, not a desktop graphics stack.

## Validation and limitations

All 14 included host-side regression/model scripts and the repository source validator pass on this updated source snapshot. These checks do not compile Rust, link the kernel, create an ISO, or boot the result. This environment does not have `cargo` or `rustc`; `Build.bat` must be run on the supported Windows build machine, followed by a disposable VM/hardware test of `mkh preview`, normal shell input, timer/uptime, `proctest`, and storage safety.


## Deliberate baseline updates

The Stage 2 framebuffer and Stage 6 interrupt-entry source hashes were intentionally advanced for this patch: the framebuffer gains a history-preserving redraw path, and the common ISR stub now guards FXSAVE/FXRSTOR until the FPU-ready flag is set. The Stage 6 process and scheduler logic itself is unchanged.


## Triple-fault fix verification note

The user's VirtualBox log showed `VINF_EM_TRIPLE_FAULT` at RIP `0xffffffff80022692`, decoding to `movd xmm0, edi`; CR4 was `0x20` (OSFXSR/OSXMMEXCPT clear) and IDTR was `0:0`. The likely sequence is an SSE2 `#UD` before the Rust IDT was installed, followed by an unhandled exception escalation. The assembly entry now enables the required CPU state before the first Rust instruction and installs a bootstrap IDT before that work. This is the source-level correction; the new ISO still needs a Windows build and VirtualBox boot to verify the runtime result.
