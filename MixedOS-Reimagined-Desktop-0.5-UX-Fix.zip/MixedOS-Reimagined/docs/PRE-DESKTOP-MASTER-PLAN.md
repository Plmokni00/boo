# MixedOS pre-desktop master plan

> **Roadmap authority:** [`ROADMAP.md`](ROADMAP.md) is the single ordered project roadmap and defines current priorities and exit gates. This document is supporting architecture detail; if sequencing differs, follow `ROADMAP.md`.

**Purpose:** bring the kernel, hardware layer, user-space contract, core services, and system-management foundations to a coherent state before implementing the desktop shell, compositor, window manager, panel, launcher, or visual settings applications.

This is an engineering plan, not a claim that the listed features already exist. Use `docs/STATUS.md` as the implementation evidence ledger and update it only when the named validation level has actually been reached.

## Product principles

1. **Modern core, compatibility at the edges.** Keep the kernel architecture clean; implement legacy APIs as compatibility services rather than letting old application assumptions dictate kernel internals.
2. **Capability-oriented security.** User processes receive explicit handles/capabilities to resources. A process does not gain hardware or filesystem authority merely by knowing an address or path.
3. **Driver isolation by default.** Hardware drivers should eventually run in user mode where practical. A small trusted kernel core owns scheduling, memory, interrupts, and IPC.
4. **Recoverable state transitions.** Filesystem updates, package installation, and OS updates must be transactional or recoverable. Never auto-format unknown media.
5. **Observable behavior.** Every subsystem has structured diagnostics, counters, timeouts, and failure codes. No infinite hardware polling loops.
6. **Graceful degradation.** Missing framebuffer, disk, network, audio, or USB must not prevent a serial/recovery boot unless the missing device is truly required.
7. **Stable contracts.** User applications target a documented MixedOS ABI and service protocols, not private kernel data structures.
8. **Evidence over checkboxes.** Source, compiled, VM-tested, and physical-hardware-tested are separate states.

## Existing baseline worth preserving

The current source already contains a Limine x86-64 entry path, serial/framebuffer diagnostics, MKH fatal handling and preview, IDT/GDT/TSS, a PIT/PIC path, PS/2 input, physical-frame allocation, four-level page-table operations, an explicit kernel heap, a small ring-3 process/scheduler demonstration, ATA PIO, MIXFS/VFS, and read-only PCI discovery. The user has reported successful boots and VM tests for several stages. See `STATUS.md` for exact boundaries.

Important current limitations: the kernel is uniprocessor-only; the heap is not a Rust global allocator; the scheduler is a small demonstration rather than a general process system; user ELF loading and a full syscall ABI are absent; PCI is discovery-only; USB, AHCI, NVMe, network, Wi-Fi, audio, GPU acceleration, RTC/time service, installer/updater, and a production user-space environment are absent or incomplete.

## Work packages before desktop implementation

### P0 — build reproducibility and boot/recovery contract

- Pin the Rust toolchain, target, linker, Limine version, C compiler, assembler, and host tools.
- Make `Build.bat` fail on the first failed command and preserve complete logs and exit codes.
- Produce deterministic build metadata: source revision, toolchain versions, boot protocol, image hash, and enabled features.
- Verify BIOS and UEFI boot separately in disposable VMs; document RAM, CPU, firmware, and disk settings.
- Add a serial-only recovery path and a safe boot mode that can disable optional drivers/services.
- Define kernel command-line parsing, boot diagnostics, and a panic/reboot policy.
- Keep MKH preview non-fatal and distinct from the actual panic path.

**Exit gate:** clean build from a fresh Windows checkout, repeatable image hash where deterministic, BIOS and UEFI VM boot records, and recoverable failure when optional devices are missing.

### P1 — CPU architecture, interrupts, and concurrency

- Keep a single interrupt/vector ownership table; reserve exception, legacy IRQ, local APIC, and syscall vectors explicitly.
- Replace legacy PIC/PIT-only assumptions with an interrupt-controller abstraction: PIC fallback, IOAPIC routing, and xAPIC/x2APIC support when validated.
- Add HPET or APIC timer support and a monotonic nanosecond clock source; retain PIT fallback.
- Add CPU feature discovery and safe feature policy (NX, SMEP, SMAP, PCID, invariant TSC, XSAVE/AVX only when fully supported).
- Define interrupt-safe spinlocks, sleepable mutexes, wait queues, once initialization, and lock-order rules.
- Introduce SMP only after per-CPU state, AP startup, TLB shootdown, scheduler locking, and interrupt routing are designed.
- Track per-process FPU/SSE state before allowing floating-point user programs or preempting arbitrary user tasks.

**Exit gate:** timer and IRQ tests under load, no allocator use in hard IRQ paths unless explicitly designed, and no SMP enablement until race and TLB tests exist.

### P2 — memory manager hardening

- Add a Rust `GlobalAlloc` integration only after heap locking, interrupt rules, and scheduler interactions are correct.
- Add kernel virtual address-space allocator, guard pages, stack growth policy, and page-fault classification.
- Add demand paging and copy-on-write only after page ownership and teardown are auditable.
- Enforce W^X, NX stacks/heaps, read-only kernel text, user/supervisor separation, and SMEP/SMAP when supported.
- Add memory pressure accounting, allocation tags, leak diagnostics, and fragmentation tests.
- Define DMA memory separately from ordinary heap pages: physical contiguity, alignment, address masks, cache coherency, pinning, and ownership lifetime.
- Add per-process address-space teardown tests, TLB invalidation tests, and allocation-failure injection.

**Exit gate:** repeated allocator/page-table stress, failure rollback, guard-page fault tests, and verified reclamation with no stale mappings.

### P3 — real process, thread, and syscall model

- General ELF64 loader: validate headers, segments, bounds, alignment, entry point, permissions, and stack construction.
- Define process/thread IDs, lifecycle states, parent-child relationships, wait/exit, signal/event delivery, and resource cleanup.
- Replace demo-only `int 0x80` calls with a versioned syscall table and stable ABI; document register conventions and error returns.
- Add safe user-pointer validation/copyin/copyout; never dereference untrusted user pointers directly in kernel code.
- Add file descriptors, per-process handle tables, close-on-exec, pipes, and standard streams.
- Add scheduler policy interfaces, priorities, sleep/wakeup, time slices, starvation protection, and per-thread kernel stacks.
- Add process limits, resource accounting, and crash isolation.
- Add IPC: bounded message queues, shared-memory objects with explicit rights, event objects, and service discovery.

**Exit gate:** launch and exit independent user ELF programs, verify isolation, invalid-pointer rejection, preemption, IPC, and full resource reclamation.

### P4 — driver and bus infrastructure

- Define a device model with bus, device, function, driver, resources, capabilities, power state, and hotplug lifecycle.
- Add driver matching/probing, dependency ordering, timeout, reset, detach, and safe failure rollback.
- PCI: enumerate bridges/topology; add ECAM via ACPI MCFG; parse BAR sizes only with a controlled, quiesced device and restore original values; allocate/map MMIO safely; route interrupts; enable bus mastering only after DMA setup.
- ACPI: parse RSDP/XSDT, MADT, MCFG, FADT, HPET, and power methods with strict bounds and checksums.
- DMA: allocate/map buffers, enforce device address masks, track ownership and cache synchronization, and provide IOMMU support where hardware permits.
- USB: xHCI first, then enumeration, control/bulk/interrupt/isochronous transfers, hubs, HID keyboard/mouse, mass storage, audio, and hotplug. Keep USB-0 PCI/MMIO/DMA prerequisite separate from USB-1 controller bring-up.
- Storage: AHCI and NVMe after PCI/MMIO/DMA; retain ATA PIO as fallback.
- Input: USB HID, PS/2 fallback, gamepad abstraction, keymaps/layouts, repeat, and device hotplug.
- Audio: device enumeration, codec/transport driver, mixer, PCM streams, and user-space audio service.
- Graphics: framebuffer fallback first; then GPU driver boundary, command submission, memory objects, synchronization, and software renderer fallback.

**Exit gate:** device inventory and resource ownership are visible; every driver has timeouts and reset behavior; hot-unplug cannot leave dangling kernel pointers.

### P5 — storage, filesystem, and data integrity

- Preserve MIXFS v1 as an experimental baseline; do not present it as production-safe yet.
- Add a journal or copy-on-write transaction design before claiming crash consistency.
- Add partition table support (GPT first, protective MBR handling), volume discovery, UUIDs, and mount policy.
- Add block I/O queues, request merging, cache/buffer layer, barriers/flush semantics, and device error recovery.
- Add file permissions, ownership, ACL/capability integration, timestamps, symlinks, hardlinks, atomic rename, and cross-directory moves.
- Add a read-only recovery mount and offline checker/repair workflow; repairs must be explicit and logged.
- Add quotas, free-space reservation, sparse files, large-file support, and directory scaling.
- Add removable-media policy and safe eject.
- Integrate SQLite only after filesystem durability and file-locking semantics are stable.

**Exit gate:** destructive tests on disposable virtual disks, power-loss/fault injection, mount/recovery matrix, and no writes to unknown disks without explicit user intent.

### P6 — clock, power, and platform services

- RTC read with stable sampling and CMOS register preservation; store UTC internally.
- Monotonic clock independent of wall-clock changes; wall-clock service, timezone database, daylight-saving rules, and NTP synchronization.
- ACPI power states, reboot/shutdown, sleep/resume, battery reporting, thermal zones, and fan policy where hardware exposes them.
- CPU frequency/idle policy only with measured support and safe defaults.
- Device power management and suspend/resume callbacks.
- Service manager with dependency graph, restart policy, readiness, health, and bounded shutdown.

**Exit gate:** clock correctness across reboot and timezone changes; graceful shutdown/reboot; suspend/resume tested on supported VM/hardware before advertising it.

### P7 — networking foundation

- Network-device API and at least one supported wired NIC driver (choose based on actual VM and target hardware evidence).
- Ethernet framing, ARP, IPv4, ICMP, UDP, TCP, IPv6, NDP, DHCP, DNS, routing, and firewall policy.
- Socket API and user-space network service; kernel networking should not expose raw device internals to apps.
- TLS 1.2/1.3 with certificate validation, trust-store updates, and time validation.
- Wi-Fi only after chipset/firmware inventory; secure authentication and credential storage.
- Bluetooth transport and profiles as a later hardware milestone, not a generic checkbox.
- Network isolation, per-app permissions, diagnostics, and packet counters.

**Exit gate:** loopback and virtual NIC test suite, DHCP/DNS/TCP/TLS interoperability, malformed-packet tests, and no credentials in logs.

### P8 — security model

- Kernel/user separation, syscall validation, W^X, ASLR, stack canaries, hardened allocator checks, and safe panic behavior.
- User identity/session model and capability-based resource access.
- Secure boot/signature verification design; key enrollment and recovery must be user-controlled.
- Signed packages and signed system updates; rollback protection balanced with recovery ability.
- Secrets store for Wi-Fi credentials, tokens, and application secrets.
- Audit events for privilege changes, driver loading, package changes, and security policy decisions.
- Sandboxed application profiles and explicit permissions for camera, microphone, network, removable storage, and input capture.
- Threat model and security review before calling the OS secure.

**Exit gate:** threat model, adversarial syscall tests, package signature verification tests, and recovery tests for invalid signatures or interrupted updates.

### P9 — user-space foundation (still before desktop)

- Native executable format and loader contract; ELF64 is the first native format.
- C runtime/libc subset, Rust target support, stable ABI headers, and system libraries.
- User-space init/service manager, service supervision, logging daemon, device manager, clock service, network service, storage service, and audio service.
- Real terminal process and shell with process groups, pipes, redirection, environment, job control, and scripting.
- IPC and service discovery APIs; file descriptors and poll/event interface.
- Package format, dependency metadata, install/uninstall, signed repository metadata, and atomic upgrades.
- Language runtimes are staged: C/Rust native first; Lua for embedded/service scripting; Python after libc/thread/filesystem support; Java/JVM after threading, memory, files, networking, and runtime dependencies.
- Windows compatibility begins only after the native loader, memory, threading, files, graphics, audio, and process APIs are stable. It must not require Linux underneath.
- Android compatibility remains research until the native ABI and service model are mature; APK parsing alone is not Android support.

**Exit gate:** boot to multi-user-capable user space with a real shell, run independent native programs, install/uninstall a signed package, and recover from a failed service.

## Desktop implementation boundary

Do not begin the full desktop until P0-P9 exit gates are met or any deliberate deferrals are explicitly recorded. At that point the desktop can be built on stable services:

- display server/compositor and window protocol;
- GPU acceleration with software fallback;
- window manager, focus, input routing, clipboard, accessibility;
- panel, launcher, notifications, settings, file manager, terminal app;
- font/text shaping, international input, themes, scaling, multi-monitor;
- screenshot/capture permissions and application portal APIs.

A framebuffer text console is not a desktop. A window demo is not a complete desktop. A shell prompt inside the kernel is not a user-space shell.

## Non-goals for the pre-desktop pass

- Do not attempt all hardware drivers simultaneously.
- Do not enable SMP, AVX, bus mastering, or DMA globally before their ownership and state-save contracts exist.
- Do not auto-format disks, silently overwrite boot entries, or silently replace a known-good image.
- Do not claim Windows, Android, Java, Python, GPU, Wi-Fi, Bluetooth, or USB support from placeholders or documentation.
