# MixedOS Stage 2 — Unified Input Subsystem

## Purpose

Input devices are normalized into a shared kernel event queue. The shell consumes
`Key`, `Mouse`, and `SerialByte` events; future desktop, window-manager, and
application code can consume the same event types without directly accessing
controller ports.

## Implemented sources

- **i8042 primary channel:** PS/2 keyboard. The controller's translation bit is
  enabled, the keyboard is requested to use native scan-code set 2, and the
  translated set-1 stream is decoded into physical key-down/key-up events plus
  US-layout text/control bytes. Shift, Caps Lock, Control, Alt, extended keys,
  Enter, Tab, Backspace, and Escape are represented.
- **i8042 auxiliary channel:** standard three-byte PS/2 mouse packets, with
  optional IntelliMouse wheel negotiation. The driver sends the 200/100/80 Hz
  sample-rate sequence and accepts four-byte packets only when the device
  identifies as wheel protocol ID 3. Unsupported devices remain on the standard
  three-byte format. Relative motion, three button states, and signed wheel
  steps are normalized into the shared event queue. MixedOS normalizes wheel polarity
  so positive events mean physical wheel-up, independent of the raw device sign.
- **COM1:** non-blocking serial input is wrapped as `SerialByte` events and goes
  through the same queue as hardware input.

## Architecture

`input::poll()` is the sole i8042 output-buffer reader. It checks the controller
status before reading port `0x60`, routes primary-channel bytes to the keyboard
decoder and auxiliary-channel bytes to the mouse packet parser, and pushes
normalized events into a bounded single-producer/single-consumer queue. The
shell only consumes `InputEvent`; it does not read PS/2 ports directly.

PS/2 IRQ delivery is disabled in the i8042 command byte and the PIC keeps IRQ1
masked. The PIT IRQ0 remains enabled. This intentionally uses polling during
kernel bring-up, avoiding the earlier split ownership where an interrupt path
could consume a byte before the poller. The busy loop is temporary until an idle
task and scheduler are available.

The framebuffer status strip shows separate keyboard and mouse receive counts,
last raw bytes, pointer coordinates, buttons, and channel readiness. The `input`
command also reports whether IntelliMouse ID 3 was negotiated and the cumulative
wheel delta. The `input`
command prints more detailed controller, device, error, and event-drop counters.

## Limits and compatibility

- This is **PS/2 plus COM1**, not a complete USB input implementation.
- USB HID keyboards, USB tablets, USB mice, xHCI/EHCI/UHCI/OHCI controller
  drivers, hotplug, international layouts, key repeat policy, extra mouse
  buttons, and multi-device enumeration are not implemented. IntelliMouse
  wheel support is limited to devices that negotiate protocol ID 3.
- Mouse coordinates are relative and clamped to a 0–4095 diagnostic coordinate
  space; they are not yet mapped to a desktop or framebuffer cursor. Wheel-up moves toward older console output; wheel-down returns toward newer output,
  three retained lines per step.
- The queue is a single-producer/single-consumer ring for the current one-core
  polling design. SMP support will require revisiting ownership and synchronization.
- `keyboard_ready` and `mouse_ready` mean that the device acknowledged its
  initialization command sequence. They are not claims of USB support or proof
  of physical hardware compatibility.

## Validation

Source validation checks the queue, controller channel split, device command
sequences, keyboard decoding, mouse packet assembly, serial normalization, and
shell event consumption. The assembly entry file is separately assembled by
Clang. Rust compilation requires a fresh Windows `Build.bat` run. Interactive device behavior
should be validated on the intended physical computer; VirtualBox is an optional
repeatable regression environment, not a substitute for hardware validation.

On the target computer, type `diagnostics` then `input`, press and release keys,
and move/click the mouse. Keyboard bytes should increase independently of mouse
bytes. Mouse bytes and coordinates should change without affecting keyboard
text. Test `help`, `diagnostics`, Shift, Caps Lock, Tab, Enter, and Backspace.
Verify wheel-up reveals older output and wheel-down returns toward the prompt. If
the system exposes only USB HID and no legacy i8042-compatible path, the PS/2
channel may be absent; USB HID support remains future work. VirtualBox may be used
as an additional regression environment, not as the sole acceptance target.
