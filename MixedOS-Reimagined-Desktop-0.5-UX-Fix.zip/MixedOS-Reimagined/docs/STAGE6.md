# Stage 6 — processes, privilege, and scheduling

Stage 6 adds the first actual ring-3 execution path and a deliberately small
uniprocessor scheduler. It runs two built-in integer-only test programs; it is
not yet a general executable loader or complete user-space environment.

## Architectural setup

- A dedicated GDT supplies ring-0 code/data, ring-3 code/data, and a 64-bit TSS.
- `TSS.RSP0` is updated to the selected process's kernel interrupt stack before
  each user-mode transition or context switch.
- IDT vector `0x80` is an interrupt gate with DPL 3. The first syscall ABI is:
  - `RAX=1`: report `RDI` as a diagnostic value.
  - `RAX=2`: cooperatively yield to the next ready task.
  - `RAX=3`: exit the current task.
- The built-in user code is copied into allocator-owned physical frames and is
  mapped read/execute. Each user stack is a separate read/write/NX page.

## Address spaces and isolation

Each test process receives a separately allocated PML4 root cloned from the
active kernel root. The code requires the dedicated low-half PML4 slot 1 to be
unused in the kernel root. In each private root clone, it clears the U/S bit
on every inherited present PML4 entry before creating a private user page-table
subtree in slot 1. A U/S bit on a parent entry alone does not prove that a user
mapping exists, because x86 requires the bit at every paging level. Clearing it
in the process-private clone is a conservative boundary: inherited kernel
mappings (kernel image, HHDM, GDT, IDT, TSS, process table, heap, and kernel
stacks) remain accessible at CPL0 but are inaccessible from CPL3. The original
active kernel root and its page tables are not modified.

Each process owns six physical frames: its CR3 root, PDPT, PD, PT, user code
page, and user stack page. It also owns a kernel interrupt stack allocated
from the Stage 5 heap. The process manager never mutates the paging module's
original active-root owner pointer; it switches CR3 only while the Stage 6
scheduler is running and restores the original root before freeing resources.

## Scheduling and return path

The scheduler stores a complete general-purpose interrupt frame in each PCB.
It switches to the next ready task on an explicit yield syscall or a PIT IRQ0
interrupt from CPL3. Before `iretq`, it updates `TSS.RSP0`, writes the target
CR3, and copies the target's saved frame onto the current interrupt stack.
A CPU exception from CPL3 retires only that process and selects another ready
task. When the final process exits, the interrupt frame is redirected to a small
assembly-only return stub. The stub restores kernel data selectors, the original
kernel CR3, and the saved shell stack, then returns normally to `run_demo()`.
That ordinary Rust call context verifies CR3, restores TSS.RSP0, and only then
reclaims process roots, page tables, code/stack frames, and kernel stacks. Rust
cleanup callbacks are not called from the synthetic IRET return path.

The first test programs deliberately use integer instructions only. The ISR
stub saves/restores the interrupted x87/SSE state around kernel dispatch, but
that scratch save is not a per-process context: switching between user tasks
does not preserve independent x87/SSE/AVX register sets. Per-process FPU/SIMD
save/restore is not implemented yet; general FPU/SIMD-using user programs must
wait for that work.

## Commands

- `proctest` builds two private ring-3 tasks, runs report/yield/exit syscalls,
  exercises round-robin switching (and permits PIT preemption), then returns to
  the kernel shell.
- `procs` reports completion, fault, report, switch, timer-preemption, and
  cleanup-error counters from the most recent run.

Expected successful result from `proctest`:

```text
[ok] User-mode test finished: 2 processes exited, 0 faulted, 4 syscall reports.
[ok] Two private user address spaces returned cleanly to the kernel.
```

Timer preemptions may be zero because the short programs often finish between
100 Hz PIT ticks; context switches should be nonzero because the test programs
explicitly yield.

## Known limits

- One CPU only; no SMP, APIC/IOAPIC, or TLB shootdown protocol.
- Two fixed built-in demonstration processes; no ELF loader or dynamic spawn API.
- No user pointer/buffer syscalls; diagnostic syscall arguments are scalar only.
- No wait, signal, thread, shared-memory, or file-descriptor APIs.
- No per-process FPU/SSE/AVX context, kernel-stack guard pages, or user-space
  runtime/library.
- The PIT remains the 100 Hz legacy timer. Keyboard/mouse input remains the
  existing kernel polling subsystem.

## Validation boundary

`tools/test_process_model.py` checks the address-space layout, supervisor/user
permission separation, private roots, round-robin state transitions, frame-layout
boundaries, and resource uniqueness. `tools/validate_source.py` checks the GDT/TSS, DPL3 gate,
user transition, assembly symbols, syscall handlers, and prior-stage regression
baselines. Clang assembly and C runtime checks are host-side checks only. The
Rust kernel must still pass the user's Windows `Build.bat` pipeline, and
`proctest` must run successfully on a dedicated development machine or in an
optional disposable emulator configuration before Stage 6 is considered runtime-validated.

Use this sequence on a dedicated development machine or in an optional disposable emulator configuration:

```text
diagnostics
input
paging
heap
procs
proctest
procs
heap
frames
paging
input
```

Confirm keyboard/mouse first, two task exits, zero task faults, at least four
reports, nonzero context switches, zero cleanup errors, restored heap live-byte
accounting, and responsive input after returning from ring 3.
