# Stage 7.3 — Directory management and deletion safeguards

This update makes shell deletion type-specific while retaining the generic VFS removal primitive for the kernel's controlled self-test.

## Commands

- `ls [path]`: list up to 64 direct child entries, with type, size, and name. Omit the path to list `/`.
- `rm /path/file`: remove a file only. It refuses directories.
- `rmdir /path/directory`: remove an empty directory only. It refuses files, non-empty directories, and the root directory. It never recurses.
- `fsck`: validate reachable inode metadata, directory parent/type relationships, extent bounds, allocation-bitmap reservations, and free-space accounting. A successful check can return a dirty filesystem to clean read/write mode. It is not a journal replay tool and does not verify file payload checksums.

## Suggested isolated-disk test

Use an already-formatted, dedicated test disk with no valuable data. Do not run `format` again. This may be a spare physical disk on a compatible legacy IDE controller or an emulator-created disk; the emulator is not required.

```text
ls /
ls /docs
mkdir /docs/delete-test
write /docs/delete-test/sample.txt temporary
rm /docs/delete-test
rmdir /docs/delete-test
rmdir /docs/delete-test/sample.txt
rm /docs/delete-test/sample.txt
rmdir /docs/delete-test
fsck
sync
```

Expected safeguards: `rm` rejects a directory; `rmdir` rejects a file; `rmdir` rejects a non-empty directory. Then `rm` deletes the file, and `rmdir` deletes the now-empty test directory. The first three expected failures must not change the directory tree.

Run `ls /docs` afterward to confirm the real project files are still present. Then `fsck` should report a successful MIXFS structural check. This test does not need another reboot; the earlier persistence test already established reboot survival.

## Verification boundary

The included Python validators check source wiring and safety contracts. They are not a substitute for the configured Windows Rust build or runtime testing on the target storage controller. MIXFS v1 is not journaled; keep it on an expendable test disk and avoid important data.
