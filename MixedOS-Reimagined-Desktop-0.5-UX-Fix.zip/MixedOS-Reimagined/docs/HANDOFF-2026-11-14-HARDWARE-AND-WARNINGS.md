# MixedOS handoff — hardware usability and compiler-warning cleanup

## User-reported state

The user reports that MixedOS boots and that the `pci` command discovered and
listed 11 devices. The environment used for that report was not specified.
PCI enumeration confirms configuration-space discovery only; it does not mean
that device drivers are implemented or operational.

## Changes in this update

- Normalize the PS/2 IntelliMouse wheel sign in the mouse driver. The shared
  input contract remains `wheel_delta > 0` for physical wheel-up; the shell then
  scrolls toward older console output for positive deltas and toward newer
  output for negative deltas.
- Make everyday `help` intentionally short. Add `diagnostics` for internal
  memory, paging, heap, process, PCI, storage, input, and self-test commands.
  Destructive `format` is omitted from everyday help and explicitly identified
  as destructive in diagnostics.
- Remove unused framebuffer scrollbar locals, unnecessary `unsafe` around
  CPUID intrinsics, the unused `read_inode_sector` superblock parameter, unused
  ATA/block/VFS wrappers and constants, and the unused inode initializer.
- Remove the redundant `.intel_syntax` assembler directive because LLVM's
  integrated assembler already defaults to Intel syntax.
- Keep intentional future-facing interfaces (C allocator entry points,
  architecture hooks, mapping flag builders, process identity, and reserved
  filesystem/paging errors) and annotate those specific items rather than
  deleting APIs that later stages are expected to use.
- Refresh prior-stage source hashes for the narrowly scoped warning cleanups;
  the validator still checks the updated known-good baseline.
- Update testing documentation to make physical x86-64 hardware the primary
  acceptance target. VirtualBox remains optional supplementary regression
  coverage, not a product requirement. Destructive storage tests require a
  separate expendable disk, never a system disk.

## Validation performed for this source package

- All 13 `tools/test_*.py` regression/model scripts pass.
- `tools/validate_source.py` passes and checks 66 required project files.
- The wheel source-contract test verifies the sign normalization and legacy
  three-byte fallback.
- The console source-contract test verifies compact everyday help and the
  separate diagnostics list.

This environment does not have `rustc`, `cargo`, or PowerShell available, so
this package has not been compiled here. The user must run `Build.bat` on the
Windows build host to confirm the compiler warning count reaches zero. The
previous user-supplied build log did compile successfully, but reported 26
warnings before this cleanup. No claim is made that the updated kernel has
already been rebuilt or booted.

## Next hardware check

1. Rebuild with `Build.bat` and inspect the complete build log for warnings.
2. Boot the ISO on the intended x86-64 hardware.
3. Run `help`, then `diagnostics`, then `input`.
4. Verify physical wheel-up reveals older console lines and wheel-down returns
   toward the live prompt.
5. Confirm `pci` still reports the machine's detected devices.
6. Do not run `format` or filesystem self-tests against a primary/system disk.
