# MixedOS master roadmap

**Last updated:** 2026-11-16  
**Scope:** the complete platform foundation up to (but not including) implementation of the desktop environment.  
**Authority:** this is the single ordered roadmap. `STATUS.md` records evidence for existing work; the design documents linked below provide implementation detail.

MixedOS is a new x86-64 operating system, not a Linux distribution. The goal is a maintainable, modern platform with its own kernel, hardware model, user-space ABI, core services, and application environment. We can make architectural choices now that are difficult for mature operating systems to change, but every feature still needs a working implementation and tests—not just a design document.

## 1. Rules for the project

1. **Preserve working milestones.** Keep a known-good bootable archive and ISO before changing kernel, memory, storage, or boot code.
2. **One authoritative source of truth.** Update this roadmap when priorities change; update `STATUS.md` only when evidence changes.
3. **Evidence has levels.** Designed, source-implemented, host-tested, compiled, VM-tested, and physical-hardware-tested are different claims.
4. **Build before claiming.** Host Python tests do not replace the user's Windows Rust build. A successful ISO build does not replace a boot test.
5. **Respect dependency order.** No xHCI before PCI/MMIO/DMA foundations; no general apps before the process/syscall ABI; no desktop before stable user-space services.
6. **Fail safely.** Hardware waits need timeouts; unknown disks are never formatted automatically; device unplug and partial failure must be handled.
7. **Keep fallbacks.** Serial diagnostics, framebuffer console, PS/2 input, ATA PIO, and the bitmap font remain fallback paths while newer implementations mature.
8. **No feature theater.** A detected device is not a driver; an APK parser is not Android support; a PE loader is not Windows compatibility; a framebuffer console is not a desktop.

## 2. Current baseline — what exists today

The current working branch/archive is the **Arimo proportional console + no-flicker update**. The user has reported that this version boots in VirtualBox, displays the Arimo console, accepts input, and no longer visibly flickers during mouse movement or typing.

| Area | Current evidence | Remaining limitation |
|---|---|---|
| x86-64 boot and kernel entry | User has supplied successful Windows Rust/ISO build output and has booted MixedOS in VirtualBox | BIOS and UEFI boot must be recorded separately; physical hardware not yet verified |
| Kernel diagnostics / MKH | Fatal MKH path and non-fatal `mkh preview` exist; preview has been seen in VirtualBox | Latest Arimo MKH presentation should be checked after future renderer changes |
| Console and input | PS/2 keyboard/mouse, shell, scrollback, history, proportional Arimo, and user-confirmed no-flicker behavior | Still a ring-0 bring-up console; no USB HID or user-space terminal |
| Font handling | Bundled Arimo Regular/Bold with OFL notice; bitmap fallback retained | ASCII-focused atlas; no Unicode shaping, bidi, or desktop font service |
| Physical memory | Frame allocator, diagnostics, and `memtest`; user VM-tested | Exhaustion/recovery stress still needed |
| Virtual memory | Four-level active-root mapping and `vmtest`; user VM-tested | No full per-process VM lifecycle, demand paging, COW, or SMP TLB shootdown |
| Kernel heap | Explicit heap API and `heaptest`; user VM-tested | Not installed as Rust `GlobalAlloc`; locking/interrupt policy required first |
| Processes | Two built-in ring-3 demonstration tasks and simple scheduler; user VM-tested | Not a general process environment; no ELF loader or production syscall ABI |
| Storage | IDE ATA PIO, block interface, MIXFS v1/VFS, basic persistent secondary-VDI test | No GPT, AHCI, NVMe, USB storage, journal, or production recovery |
| PCI | Read-only conventional PCI enumeration; user previously reported 11 devices listed | No full ACPI/ECAM resource manager, BAR allocation, MMIO driver framework, or DMA |
| Networking | Not implemented | No NIC driver, TCP/IP, sockets, TLS, Wi-Fi, or Bluetooth |
| Audio / power / clock | Not implemented beyond basic PIT tick and reset path | No audio service, RTC/time service, ACPI power management, or suspend/resume |
| User space / packages | Minimal CPL3 test tasks only | No general init, service manager, native app loader, package manager, or update/recovery system |
| Desktop | Not implemented | Intentionally deferred until the pre-desktop exit gate |

**Current source checks:** this revision passes the source validator (86 required source files) and all 21 host regression scripts. These are source/model/static checks; they do not execute the Windows PowerShell builder, compile the new Zig object, link the kernel, or boot the produced ISO. The user has separately reported a successful Windows build/ISO and a VirtualBox run showing the no-flicker console; the exact current ISO SHA/build log should be recorded at the next build.

## 3. Ordered development stages

Stages are ordered by dependency. Work can overlap only when the dependency is already stable and the relevant source revision is tracked.

### Stage 0 — baseline, build discipline, and regression gate

**Purpose:** make every later change traceable and recoverable.

- [x] Windows-native `Build.bat` / PowerShell build flow exists; no WSL or Docker requirement.
- [x] Rust target and Limine ISO creation work in the user-reported build.
- [x] Source validator and 21 host regression scripts pass for this archive.
- [x] Known-good VirtualBox boot and no-flicker console behavior reported by the user.
- [ ] Record the exact archive/source revision, complete build log, Rust/LLVM/Zig/Python/Limine versions, ISO SHA-256, VM firmware mode, RAM, CPU count, and virtual devices for the current no-flicker build.
- [x] Implement idempotent toolchain bootstrap: detect versions first, install missing requirements sequentially, and cache checksum-verified Zig locally. Source regression tests pass; Windows execution is still pending.
- [ ] Double-click `Build.bat` twice and confirm the second build reuses all installed tools and verified Zig/Limine caches without reinstalling or redownloading them.
- [ ] Confirm a clean build from a freshly extracted directory and verify `Build.bat` returns a truthful nonzero exit code on failure.
- [ ] Verify BIOS and UEFI boot as separate test cases; document any unsupported configuration.
- [ ] Preserve a known-good ISO/archive before each risky kernel change; never silently overwrite the user's working copy.
- [ ] Add a minimal safe/recovery boot option and serial-only diagnostic fallback.

**Exit gate:** fresh Windows build succeeds; build metadata and ISO hash are recorded; BIOS and UEFI VM tests have separate results; a failed optional device does not prevent recovery boot.

### Stage 1 — finish validation of the existing kernel foundations

**Purpose:** close test gaps before adding more subsystems.

- [ ] Repeat `memtest`, `vmtest`, and `heaptest` several times; verify allocator/page-table accounting returns to baseline.
- [ ] Re-run `proctest`; record task exits, faults, context switches, CR3 restoration, and resource cleanup.
- [ ] Test console input, Backspace, proportional wrapping, scrollback, scrollbar dragging, mouse wheel direction, and MKH Escape dismissal on the current image.
- [ ] Test the latest MIXFS file/directory operations on a dedicated disposable secondary VDI only; verify reboot persistence and structural `fsck`.
- [ ] Exercise read-only PCI enumeration and save a device inventory from the current VM.
- [ ] Test fault paths in a disposable VM only; do not trigger deliberate CPU faults on a daily-use machine.
- [ ] Document the current busy-polling console loop and its CPU use as known technical debt.

**Exit gate:** each existing subsystem has a current-image result (pass/fail/not tested), no unexplained regression from the known-good baseline, and storage tests use only an explicitly disposable disk.

### Stage 2 — CPU, interrupt, timer, and idle foundations

**Purpose:** replace bring-up-only assumptions with a reliable execution foundation.

- [ ] Define one interrupt/vector ownership map for exceptions, legacy IRQs, local APIC, and syscalls.
- [ ] Introduce an interrupt-controller abstraction: retain 8259 PIC fallback; add local APIC and IOAPIC routing with ACPI MADT discovery.
- [ ] Add a reliable monotonic clock source and timer abstraction; retain PIT as fallback while adding APIC timer/HPET where validated.
- [ ] Replace the permanent busy-poll loop with event-driven waiting and a scheduler-aware idle path (`HLT` only when interrupts and state make it safe).
- [ ] Define interrupt-safe spinlocks, sleepable mutexes, wait queues, initialization-once primitives, and lock-order rules.
- [ ] Define CPU feature discovery and policy; only enable optional instructions after context-save and exception handling are ready.
- [ ] Save/restore per-task FPU/SSE state before general floating-point user programs or arbitrary preemptive workloads.
- [ ] Keep SMP disabled until per-CPU state, AP startup, scheduler synchronization, TLB shootdown, and race tests are complete.

**Exit gate:** timer/IRQ stress passes, no unbounded polling waits remain in normal paths, idle does not spin at full CPU, and task state survives preemption. SMP is a separate opt-in milestone after these conditions.

### Stage 3 — memory manager hardening

**Purpose:** make allocation and address-space behavior safe for real applications and drivers.

- [ ] Define the kernel virtual address-space allocator and ownership model.
- [ ] Add guard pages for kernel/user stacks and classify page faults with useful diagnostics.
- [ ] Define locking and interrupt rules for the existing heap, then integrate Rust `GlobalAlloc` only after those rules are tested.
- [ ] Enforce W^X, NX stacks/heaps, read-only kernel text, and strict user/supervisor permissions.
- [ ] Add allocation tags, leak/fragmentation accounting, memory pressure reporting, and deterministic failure injection.
- [ ] Add safe per-process address-space creation/destruction and teardown tests.
- [ ] Add demand paging and copy-on-write only after mapping ownership, fault rollback, and TLB invalidation are auditable.
- [ ] Define DMA memory separately from ordinary heap pages: physical-contiguity requirements, alignment, device address masks, cache coherency, pinning, and lifetime.

**Exit gate:** repeated allocator/paging stress, exhaustion/recovery, guard-page tests, allocation-failure rollback, and no stale mappings or leaked frames.

### Stage 4 — general processes, syscall ABI, and IPC

**Purpose:** turn the ring-3 demonstration into a real user-program environment.

- [ ] Implement a bounds-checked ELF64 loader for static native executables; validate headers, segments, alignment, sizes, permissions, entry point, and stack construction.
- [ ] Specify and version the MixedOS syscall ABI: register conventions, error returns, ABI versioning, and stable headers.
- [ ] Implement safe `copyin`/`copyout` and validate all user pointers; never trust a userspace address directly.
- [ ] Add process/thread IDs, lifecycle states, parent-child relationships, wait/exit, cancellation/events, and deterministic cleanup.
- [ ] Add file descriptors, handle tables, standard streams, close-on-exec, pipes, and poll/event notification.
- [ ] Add IPC primitives: bounded message queues, event objects, shared memory with explicit rights, and service discovery.
- [ ] Add scheduling policy interfaces, priorities, blocking/sleep/wakeup, time slices, and starvation protection.
- [ ] Add per-process resource limits and crash isolation.
- [ ] Keep per-process FPU/SIMD context and kernel stack guards as mandatory prerequisites for arbitrary user workloads.

**Exit gate:** launch multiple independent ELF programs, exercise syscalls and IPC, reject invalid pointers, preempt safely, and fully reclaim processes, descriptors, stacks, and address spaces.

### Stage 5 — firmware discovery, PCI resources, and device model

**Purpose:** move from listing devices to owning their resources safely.

- [x] Add bounded ACPI table parsing with checksum validation for RSDP, XSDT/RSDT, MADT, and FADT discovery; MCFG/HPET are reported when present. Runtime discovery is VM-observed; AML execution and APIC activation remain disabled.
- [x] Add conventional PCI mechanism-#1 enumeration, multifunction handling, read-only BAR snapshots, and bridge bus-number fields.
- [ ] Add PCI ECAM access via MCFG while retaining configuration mechanism #1 as a fallback.
- [ ] Implement safe BAR sizing/parsing with a quiesced device and restoration of original config values; do not probe active devices unsafely.
- [x] Add a bounded software-only I/O-port/MMIO reservation registry with alignment, overflow, overlap, and owner checks.
- [ ] Add physical MMIO mapping with checked page alignment and correct cache attributes; no BAR is mapped by the reservation registry.
- [x] Define bounded PCI function identity and a `Discovered`/unbound device-inventory state with stable diagnostics.
- [ ] Add driver matching/probe, dependency ordering, timeouts, reset, detach, hotplug, power states, and error rollback.
- [x] Expose structured device inventory and driver status through `devices` and `drivers` commands.

**Exit gate:** resource conflicts are detected; all mapped ranges have owners; malformed ACPI/PCI data fails closed; driver probe failures cannot corrupt unrelated devices.

### Stage 6 — DMA and core driver framework

**Purpose:** safely permit devices to transfer data without unsafe memory ownership.

- [x] Add first-generation DMA32 allocation: contiguous page runs below 4 GiB, alignment, full-buffer zeroing, checked HHDM access, and explicit quiesced release; `dmatest` verifies allocator ownership and cleanup without exposing memory to a device.
- [ ] Add DMA mapping constraints beyond DMA32: device-specific masks, boundary limits, scatter/gather, cache synchronization, and page pinning.
- [ ] Define safe in-flight completion and cancellation lifetimes; never free memory while a device can still access it.
- [ ] Add IOMMU support where available, without making it a requirement for the first supported controller.
- [ ] Add interrupt routing and completion handling policies for device drivers.
- [ ] Add bounded request queues, timeouts, reset, and unplug/error paths.
- [x] Keep PCI bus mastering disabled; no driver receives DMA memory in this foundation release.

**Exit gate:** DMA model tests cover address masks, alignment, ownership, completion, cancellation, and device reset; no dangling DMA buffers after timeout or unplug.

**2026-11-16 foundation update:** see `STAGE5-6-FOUNDATIONS.md`, `DEVICE-REGISTRY.md`, `RESOURCE-RESERVATIONS.md`, and `DMA32-ALLOCATOR.md`. These source additions are host-model/source-checked only until the Windows kernel build and VirtualBox tests pass. They do not yet provide a working xHCI, AHCI, NVMe, network, or GPU driver.

### Stage 7 — USB stack (xHCI first)

**Purpose:** make common USB input and storage usable through device-neutral MixedOS services.

- [ ] USB-1: identify xHCI controllers; map operational/runtime registers; perform bounded reset and ring bring-up.
- [ ] Implement command/event rings and transfer rings with explicit DMA ownership; start in bounded polling mode if interrupt routing is not ready.
- [ ] USB-2: implement endpoint-zero control transfers and strict device/configuration/interface/endpoint descriptor parsing.
- [ ] Enumerate root ports and hubs with depth/device limits, retry budgets, deadlines, reset, and unplug handling.
- [ ] USB-3: implement boot-protocol HID keyboard and mouse first; translate reports into the existing device-neutral input queue.
- [ ] Add generic HID report parsing only after bounded descriptor parsing is tested; add tablet/gamepad mapping through the same input service.
- [ ] USB-4: implement Mass Storage Bulk-Only Transport and the required SCSI commands; register logical units through the block-device interface.
- [ ] Default newly attached USB storage to read-only; writes and formatting require explicit user action.
- [ ] Add broader USB audio/hubs/hotplug/power management after keyboard, mouse, and storage are reliable.
- [ ] Evaluate EHCI/OHCI/UHCI only when target hardware actually requires legacy controller support; xHCI is the first priority.

**Exit gate:** USB keyboard/mouse work in the console; USB storage passes read-only enumeration and disposable-media read/write tests; malformed descriptors, timeout, and unplug do not hang or corrupt the kernel.

Detailed sequence and safety invariants: `USB-ARCHITECTURE.md`.

### Stage 8 — storage, partitions, and durable filesystem

**Purpose:** turn experimental MIXFS/ATA persistence into reliable system storage.

- [ ] Preserve ATA PIO as a diagnostic/fallback backend.
- [ ] Add GPT partition discovery and protective-MBR handling; never auto-format unknown media.
- [ ] Add AHCI, then NVMe, using the Stage 5–6 PCI/MMIO/DMA/driver contracts.
- [ ] Add block I/O queues, request merging, cache/buffer management, flush/barrier semantics, and device error recovery.
- [ ] Design MIXFS v2 or another filesystem with journaled or copy-on-write transactional metadata; do not claim crash consistency until fault-injection tests pass.
- [ ] Add volume UUIDs, mount policy, permissions/ownership/capabilities, timestamps, atomic rename, symlinks/hardlinks, large files, and scalable directories as supported by the format.
- [ ] Add read-only recovery mount, offline checker, explicit repair workflow, and safe eject/removable-media policy.
- [ ] Add quotas/free-space reservation and file locking semantics.
- [ ] Integrate SQLite only after durable writes, locking, and filesystem recovery are stable.

**Exit gate:** disposable-disk tests cover reboot persistence, interrupted writes, corruption detection, recovery, safe eject, and no writes to unknown or protected disks.

### Stage 9 — networking

**Purpose:** provide a secure, standard network service independent of any one NIC.

- [ ] Define a NIC driver interface and choose the first wired adapter based on the actual VirtualBox/target hardware inventory.
- [ ] Implement Ethernet framing, ARP, IPv4, ICMP, UDP, TCP, IPv6, and NDP in bounded, testable layers.
- [ ] Add routing, DHCP, DNS, socket API, and nonblocking I/O integrated with the event/wait system.
- [ ] Add packet filters/firewall policy and per-process network permissions.
- [ ] Add TLS 1.2/1.3 with certificate-chain and hostname validation, trusted roots, and reliable system time.
- [ ] Add Wi-Fi only after a specific chipset/firmware support target is chosen; secure credential storage is required.
- [ ] Treat Bluetooth as a separate later transport/profile project after USB and network/driver lifecycles are stable.

**Exit gate:** loopback and virtual-NIC tests pass; DHCP/DNS/TCP/TLS interoperate with real endpoints; malformed packets and queue exhaustion are handled safely; secrets never appear in logs.

### Stage 10 — platform services: time, power, audio, and graphics foundations

**Purpose:** provide the platform services that native applications and a later desktop will depend on.

- [ ] Add RTC sampling and a UTC wall-clock service; keep monotonic time independent of wall-clock changes.
- [ ] Add timezone database, daylight-saving transitions, and NTP synchronization after networking/time validation exists.
- [ ] Add ACPI power management, orderly shutdown/reboot, sleep/resume where supported, battery/thermal reporting, and safe CPU idle policy.
- [ ] Add an audio device boundary, at least one target driver, PCM streams, mixer, and user-space audio service.
- [ ] Formalize device-neutral keyboard/mouse/gamepad events, keymaps, repeat, and hotplug notifications.
- [ ] Keep framebuffer/software rendering as a guaranteed fallback; define display surfaces, modes, synchronization, and GPU driver boundaries.
- [ ] Add hardware GPU acceleration only for identified hardware with tested memory and submission contracts; never make it the only display path.

**Exit gate:** clock remains monotonic; shutdown/reboot are reliable; at least one supported audio path works; input and display survive device errors; software rendering remains available.

### Stage 11 — security, identity, and isolation

**Purpose:** make permissions and trust explicit before a real application ecosystem exists.

- [ ] Write a threat model covering kernel, drivers, removable media, services, packages, and user applications.
- [ ] Add user identity/session foundations and capability-based handles for files, devices, IPC, and privileged operations.
- [ ] Enforce file ownership/permissions and service/application privilege boundaries.
- [ ] Add ASLR where address-space layout and loader support are ready; enforce W^X and NX throughout.
- [ ] Add sandbox profiles and explicit permissions for network, audio, removable storage, and input capture.
- [ ] Define secure boot/signature verification and user-controlled key enrollment/recovery; do not lock users out with unrecoverable keys.
- [ ] Add security audit events for privilege changes, device/driver loading, packages, and system updates.
- [ ] Review syscall, parser, driver, and package attack surfaces before making security claims.

**Exit gate:** adversarial syscall and permission tests pass; capability checks are enforced, package signatures are verified, and invalid signatures or policy failures produce recoverable errors.

### Stage 12 — real user space, init, and native application environment

**Purpose:** stop treating the kernel shell as the operating system's everyday interface.

- [ ] Implement a native static ELF program toolchain/ABI with documented headers and libraries.
- [ ] Add a C runtime/libc subset, Rust user target support, process startup/teardown, and standard streams.
- [ ] Add an init process and service manager with dependency ordering, readiness, restart policy, health checks, logging, and graceful shutdown.
- [ ] Move device management, clock, network, audio, storage policy, and logging into stable services where the architecture allows.
- [ ] Implement a real user-space terminal and shell with environment, process groups, pipes, redirection, job control, and scripts.
- [ ] Define service IPC and stable system libraries; applications must not depend on private kernel structures.
- [ ] Stage language support realistically: C/Rust native programs first; Lua for embedded/service scripting; Python after memory/thread/filesystem/network APIs mature; Java/JVM after the broader runtime dependencies exist.
- [ ] Treat Zig as an additional systems-development language/toolchain option, not a required runtime in the kernel.
- [ ] Integrate SQLite only after Stage 8; SQL is provided through the database engine, not as a kernel language.

**Exit gate:** boot into a real user-space init, launch multiple independent native programs, use a user-space shell, supervise services, and recover when a noncritical service crashes.

### Stage 13 — packages, updates, installer, and recovery

**Purpose:** allow the OS to be installed and maintained without risking user data.

- [ ] Define a signed package format, dependency metadata, install/remove scripts with restricted privileges, and package database.
- [ ] Implement atomic install/uninstall and rollback on interruption.
- [ ] Add signed system updates with staged activation, rollback, and clear version/build metadata.
- [ ] Build an installer/partition workflow for GPT/UEFI and BIOS boot arrangements; never modify host disks without explicit target selection.
- [ ] Add recovery environment with read-only disk inspection, backups, offline filesystem checks, and boot repair.
- [ ] Add data-preserving upgrade tests and failure injection for interrupted package/system updates.

**Exit gate:** install/update/rollback/recovery work on disposable VMs and disks; users can recover from a failed update without losing user data.

### Stage 14 — pre-desktop integration and readiness review

**Purpose:** prove that the platform below the desktop is coherent.

- [ ] Boot reproducibly through supported BIOS and UEFI paths.
- [ ] Recover through serial and local recovery paths if optional devices/services fail.
- [ ] Have a documented, tested CPU/interrupt/timer/memory/process/driver/storage/input/network/security model.
- [ ] Have reliable USB keyboard/mouse and a supported storage path; retain safe fallbacks.
- [ ] Have durable filesystem behavior, permissions, package/update rollback, and a recovery workflow.
- [ ] Have stable user-space ABI, init/service manager, native executable loader, terminal, shell, and core system services.
- [ ] Have documented graphics/display and input APIs with software fallback; GPU acceleration may be phased by hardware support.
- [ ] Pass the complete automated regression suite and a defined VM/hardware acceptance matrix.
- [ ] Publish an explicit list of supported hardware and known limitations.

**Exit gate:** all mandatory items are passed, or any deferral is explicitly documented with a safe fallback and a reason. Only then does desktop implementation begin.

## 4. Desktop starts after this roadmap

The desktop is a separate project phase, intentionally not part of the pre-desktop implementation work. Its first milestones will be: display server/compositor, window protocol, window manager, focus/input routing, panel/launcher, notifications, settings, file manager, terminal app, accessibility, scaling/multi-monitor, and app integration. It will consume the stable user-space services and graphics/input APIs above—not kernel-private shortcuts.

## 5. Language and compatibility strategy

| Language/technology | Intended role | Timing |
|---|---|---|
| Rust | Main kernel and trusted system components | Current core |
| C | ABI boundary, low-level libraries, selected drivers/runtime code | Current and ongoing |
| x86-64 Assembly | Boot/interrupt/context-switch primitives | Current and ongoing |
| Zig | Freestanding CRC-32 implementation used by MIXFS; later systems utilities/libraries | Introduced in the pre-desktop kernel build; compiler pinned to 0.17.1 |
| Lua | Small embedded/service scripting | After user-space services exist |
| Python | Higher-level scripting and tools | After filesystem, threads, and runtime support mature |
| Java/JVM | Java application compatibility | Later; not a pre-desktop blocker |
| GLSL/WGSL | Graphics shaders | Once the GPU/display API exists |
| SQLite/SQL | Embedded database and query support | After durable filesystem and locking |
| Arimo | Default proportional UI typeface under SIL OFL 1.1 | Integrated in framebuffer text; desktop text service later |

Windows application compatibility and Android application compatibility are long-term compatibility projects, not prerequisites for the first desktop. They must be implemented by MixedOS itself and must not quietly depend on an installed Linux/Windows OS. APK parsing alone is not Android support; launching a PE file alone is not Windows compatibility. Their detailed designs should start only after the native process, graphics, storage, networking, and service contracts are stable.

## 6. Immediate execution order — current checkpoint

1. **Build and test the current Stage 5/6 foundation batch on Windows.** Run `devices`, `resources test`, `dmatest`, `dma`, `resources`, and `sysinfo`; capture the build log and ISO SHA-256.
2. **Fix any compiler or VM issues before adding hardware activation.** Host-side Python checks do not substitute for the freestanding Rust build or a VirtualBox run.
3. **Complete PCI configuration support.** Add MCFG/ECAM with mechanism #1 fallback, then implement carefully quiesced BAR sizing and restoration of the original configuration values.
4. **Add checked MMIO mapping and device-specific resource constraints.** Keep ownership explicit and keep bus mastering disabled until a driver owns every required resource.
5. **Extend DMA with device address masks, boundaries, synchronization, pinning, and cancellation lifetimes.** The current first-generation DMA32 allocator is a foundation only; it is not yet connected to a controller.
6. **Implement driver matching/probe and interrupt completion policy.** Only after these gates pass should xHCI/USB work begin.

The current coding checkpoint is **Windows build and runtime validation of PCI inventory, software resource reservations, and DMA32 allocation**. Zig remains active through the freestanding MIXFS CRC-32 component; Rust is the main kernel language and C is the stable low-level ABI/runtime boundary.

## 7. Related engineering documents

- `STATUS.md` — evidence ledger for what is currently implemented and tested.
- `PRE-DESKTOP-MASTER-PLAN.md` — deeper architecture notes and subsystem work-package details.
- `DRIVER-MODEL.md` and `USB-ARCHITECTURE.md` — device model, PCI/MMIO/DMA, and USB sequencing.
- `STORAGE-RECOVERY-PLAN.md` — filesystem durability and recovery requirements.
- `NETWORK-ARCHITECTURE.md` — network-layer architecture.
- `USERSPACE-ABI-PLAN.md` — executable, syscall, and service ABI.
- `SECURITY-BASELINE.md` — security requirements and threat-model direction.
- `PLATFORM-SERVICES-PLAN.md` — clock, power, and platform services.
- `VALIDATION-MATRIX.md` — test evidence and acceptance criteria.

## Active implementation batch — 2026-11-16

- [x] Incremental framebuffer scrollback for small scroll deltas; full redraw
      retained only for large jumps or explicit screen reconstruction.
- [x] Preserve the current viewport when new output arrives while scrolled up.
- [x] Request and safely inspect ACPI RSDP/root tables in read-only mode.
- [x] Add `acpi`, `memmap`, and `sysinfo` shell diagnostics.
- [ ] Windows release build and VirtualBox runtime test of this batch.
- [ ] Record ISO SHA-256 and observed ACPI/scroll behavior before starting
      PCI resource assignment or DMA implementation.


## ACPI / hardware inventory correction — 2026-11-16

- [x] Correct Limine RSDP request identifier to the published protocol ID.
- [x] Treat the RSDP response as an HHDM virtual address for the requested
      Limine base revision 6; translate to physical only for memory-map checks.
- [x] Display named memory-map regions.
- [x] Add read-only PCI BAR resource inventory (addresses/types only; no BAR sizing or claims).
- [ ] Rebuild on Windows and confirm `acpi` reports the RSDP and root table.
- [ ] Confirm memory type names match the VirtualBox map and run `pci resources`.
- [ ] Only after ACPI is confirmed, implement MCFG/ECAM discovery and a
      non-overlapping resource registry; BAR sizing and assignment remain gated.


## November 2026 — Kernel services increment

Added a bounded allocation-free in-memory kernel log and shell commands for
`log`, `uptime`, `version`, and `drivers`. These improve observability while
PCI resource management, DMA, the driver model, user-space ABI, and desktop
work continue. This does not claim persistent logging or new device drivers.


## Stage 5/6 implementation checkpoint — 2026-11-16

The current source contains a one-time read-only PCI device snapshot, a bounded
software-only I/O/MMIO reservation registry, unique contiguous frame-run tokens,
and a first DMA32 buffer API. The new `devices`, `resources`, `resources test`,
`dma`, and `dmatest` commands expose this work. `dmatest` does not give memory
to a device; PCI BAR sizing, MMIO mapping, bus mastering, DMA cache/sync policy,
and driver activation remain explicitly deferred. Host validation currently
passes, but the Windows build and VirtualBox checks are still required.


## Desktop track update (2026-11-16)

The project now includes Desktop 0.1 as a framebuffer preview invoked with
`desktop`. It uses the user's bundled 1920x1080 wallpaper, a minimal top status
strip, and a prototype bottom dock. Escape restores the kernel console. This is
not yet a window manager or app launcher; graphics surfaces, backbuffer/damage
tracking, window management, and user-space applications remain future work.
See `docs/DESKTOP-0.1-PREVIEW.md`.


## Desktop-first boot policy (2026-11-16)

MixedOS now boots directly into Desktop 0.1 after hardware initialization.
Limine `timeout: 0`, `quiet: yes`, and `terse: yes` remove the boot-menu
countdown and informational loader messages. The kernel console is no longer
the default framebuffer UI; F1 or Ctrl+Alt+T opens it as a recovery environment.
A serial Ctrl+T byte (`0x14`) also opens recovery. If the framebuffer/wallpaper
path is unavailable, startup falls back to the recovery console. This remains an
early graphical shell with prototype dock tiles, not a window manager.
