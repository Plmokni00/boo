# MixedOS Stage 4 — Virtual memory foundation

## Goal

Add a conservative four-level x86-64 page-table manager on top of the Stage 3
physical frame allocator. The active Limine CR3 root stays in place; Stage 4
must not replace it during initialization or self-test.

## Implemented in source

- Reads the active CR3 and CR4 state and rejects unsupported five-level
  paging rather than interpreting it as a four-level tree.
- Detects the CPU physical-address width and NX capability with extended CPUID.
- Enables and verifies EFER.NXE when the CPU supports it, and enables/verifies
  CR0.WP so supervisor writes respect read-only mappings.
- Walks four-level page tables through the Limine HHDM, including inspection of
  existing 1 GiB and 2 MiB huge-page mappings.
- Maps and unmaps 4 KiB pages using allocator-owned `Frame` tokens.
- Supports supervisor/user, writable/read-only, executable/no-execute, global,
  write-through, and cache-disable leaf bits. x86-64 has no independent
  read-disable bit: a present page is readable at the privilege level allowed
  by its U/S bits.
- Refuses to overwrite existing pages, split huge pages, or widen permissions
  on existing parent entries. User mappings are restricted to the lower
  canonical half.
- Allocates zeroed intermediate tables from Stage 3, tracks their ownership,
  rolls back partial table creation on mapping errors, and reclaims only empty
  tables created by MixedOS. Bootloader-owned tables are never freed.
- Invalidates the local TLB entry after mapping, unmapping, or table pruning.
- Adds `paging` and `vmtest` kernel-console commands.

## `vmtest` acceptance

`vmtest` selects a previously absent PML4 slot in the user half. It allocates
two physical data frames, maps one user-writable/NX page and one supervisor-
writable/NX page beneath the same new subtree, performs a real virtual write
and read through the supervisor alias, checks both translations and effective
permission bits, unmaps both pages, and verifies the temporary page-table
frames and data frames return to the allocator. The user page is inspected via
the page-table walker rather than dereferenced at ring 0, so the test does not
depend on whether CR4.SMAP is enabled. It also checks that the test virtual addresses are not mapped
after cleanup.

This performs real virtual memory accesses in the currently active address
space, so a paging defect can still produce a CPU page fault. Run it first in a
dedicated development machine or disposable emulator configuration after a
successful build and ordinary boot. Do not run it on a daily-use machine; the
emulator is optional and not the only supported test environment.

## Safety boundaries

- No CR3 replacement or full address-space switch is implemented.
- The manager is for the current uniprocessor bring-up kernel. SMP TLB
  shootdowns, per-CPU state, PCID lifecycle, and concurrent address-space
  management are not implemented.
- Only 4 KiB mappings are created. Existing 1 GiB/2 MiB mappings can be queried
  but are not split or rewritten.
- Mapping calls require a frame currently owned by the Stage 3 allocator.
  Callers must keep that frame allocated until it has been unmapped.
- Parent permissions are never widened on an existing table entry. A request
  that would require widening user, write, or execute permissions fails.
- User bits are prepared and tested in the page tables, but ring-3 execution,
  process address spaces, syscalls, and user-copy routines do not exist yet.
- A heap/global allocator was outside Stage 4 scope. Stage 5 now adds an explicit
  heap API on top of this mapping layer; Rust `GlobalAlloc` integration remains
  deferred until heap tests and scheduler/interrupt locking rules exist.

## Tests

Run on the host:

```powershell
python tools/validate_source.py
python tools/test_memory_model.py
python tools/test_paging_model.py
```

Then run `Build.bat` on Windows and boot the resulting ISO on the target
computer. An emulator is an optional additional check. First type `help`,
`diagnostics`, `paging`, `mem`, `frames`, and `input` to confirm the prior
subsystems remain operational. Only then run `vmtest`. After it passes, run
`paging` and `frames` again: `owned_table_pages` and allocated frame counts
should return to their pre-test values, free errors should remain unchanged,
and both test mappings must be gone.

The user subsequently supplied a successful Windows Stage 4 build log and a
VirtualBox screenshot confirming the two-page `vmtest` passed, with the active
Limine CR3 preserved. Host-side model tests and source checks alone do not
compile Rust or prove that the CPU's actual page tables work; the user-provided
build log and screenshot are the evidence for this Stage 4 revision.

### Architecture facade regression
The build validator checks the public x86-64 architecture facade and accepts both
`pub use x86_64::{...}` and `pub use self::x86_64::{...}`. The canonical facade
exports the interrupt, halt, port-I/O, and FPU initialization helpers used by
kernel subsystems. Run `python tools/test_arch_facade.py` for the focused check.
