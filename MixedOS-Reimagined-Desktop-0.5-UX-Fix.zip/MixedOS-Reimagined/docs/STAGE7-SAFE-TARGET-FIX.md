# Stage 7 — Safe ATA format-target fix

## What was wrong

The previous build probed ATA positions until it found the first hard disk,
then stored only that one device. The `format` command always wrote to that
selected device. The explicit confirmation token did not identify or protect
a particular disk. In the November 11 screenshot, the only detected device was
a 14,383 MiB VirtualBox hard disk, so the old format command would have
formatted that entire VM disk.

## What changed

- The ATA driver now retains all four legacy IDE positions (`ata0`–`ata3`).
- The first detected ATA disk is recorded as protected. The MIXFS formatter
  rejects it before issuing any disk write.
- The formatter now requires the target ID and confirmation in one command:
  `format ataN --erase-dedicated-disk`.
- The formatter rejects disks larger than 512 MiB for this Stage 7 bring-up.
  This independently rejects the 14.3 GiB device shown in the screenshot.
- Formatting is refused while another MIXFS volume is mounted.
- Boot-time MIXFS discovery checks the detected devices using reads only, so
  a formatted secondary data VDI can be found again after reboot.
- The shell's `disk` command lists each detected ATA ID, its capacity, and
  whether it is protected or eligible as a test target.

## Required test arrangement

Keep the existing VM hard disk attached and unchanged. Add a separate blank
256 MiB VDI on a legacy IDE controller. Run `disk`; identify the new VDI by
its actual ID and capacity. Only then use that ID in the format command. If
there is no separate device or the identity is unclear, do not format.

Do not attach a host physical disk. The software protection is an extra guard,
not permission to point the formatter at an existing data disk.

## Verification boundary

The host-side source validator, ATA model test, MIXFS model test, dedicated
storage-safety regression, and the existing memory/paging/heap/process model
tests pass. The current editing container does not have `cargo`/`rustc`, so a
native Rust kernel build and VirtualBox boot test have **not** been performed.
Run `Build.bat` on the configured Windows build machine before testing this
ISO in the cloned VM.
