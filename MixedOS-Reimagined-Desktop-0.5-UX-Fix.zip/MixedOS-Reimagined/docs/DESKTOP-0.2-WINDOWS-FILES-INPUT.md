# MixedOS Desktop 0.2 — Window, Files, and Input Foundations

This release upgrades the desktop from static preview panels to interactive kernel-rendered application windows.

## Pointer and taskbar

- Desktop pointer movement now uses relative PS/2 movement deltas rather than mapping small raw deltas through a 0..4095 absolute coordinate range.
- Pointer acceleration is 3x for low deltas, 4x for medium deltas, and 5x for larger deltas. The black arrow and gray outline are retained.
- Pointer drawing still saves and restores the framebuffer pixels underneath it; the full desktop is not repainted on each pointer event.
- The bottom taskbar spans the actual boot framebuffer, with a launcher, pinned Terminal/Files/Settings entries, and system/recovery hint.

## Windowed Terminal

- `Terminal::new_cmd_window` constructs a clipped framebuffer view with screen origin and dimensions.
- All canvas pixel writes and antialias blending translate local window coordinates to the underlying framebuffer.
- Scrollback copies are constrained to the window view; they no longer copy entire framebuffer rows outside the window.
- Terminal is launched in a decorated window. `EXIT`, Escape, or its titlebar close control returns to the desktop.
- F1 still opens the separate full-screen recovery console.

## Files application backed by MIXFS

The Files window calls the existing VFS/MIXFS backend directly:

- Up/Down selects entries; Enter opens directories; Backspace moves to the parent directory.
- `F` or `+ FOLDER` prompts for a name and calls `vfs::mkdir`.
- `N` or `+ FILE` prompts for a name and calls `vfs::write_file` to create an empty file without overwriting an existing item.
- `R` prompts for a new name and calls `vfs::rename_file`.
- Delete removes a selected file or an empty directory through the type-safe removal API.
- Mouse wheel changes selection; mouse clicks select rows and activate toolbar actions.

The Files app never formats a disk. It reports when MIXFS is unavailable or read-only. Files are persistent only when a supported MIXFS volume is mounted read/write. Non-empty directory deletion remains refused by MIXFS.

## Animation and redraw policy

Terminal, Files, and Settings have short slide-in transitions. The Files view renders only when its state changes; it does not repaint the wallpaper continuously while idle. Window opening/closing transitions are brief, finite framebuffer updates. This is an early kernel-rendered desktop: overlapping independently movable/resizable windows, compositing, user-space GUI processes, and USB HID are still future work.

## Build / validation

Run the regular Windows `Build.bat`. Host-side Python regression tests cover cursor geometry and acceleration, clipped terminal framebuffer views, taskbar interactions, Files operations, animations, and no-idle-repaint behavior. A successful source validation is not a substitute for a Rust kernel build or VirtualBox runtime testing.
