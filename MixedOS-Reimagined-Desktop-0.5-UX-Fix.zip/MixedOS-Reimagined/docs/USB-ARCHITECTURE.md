# MixedOS USB architecture and implementation plan

Status: architecture specification; no USB controller or device driver is implemented yet.

## Design goals

USB support must be transport-independent to the rest of MixedOS. A keyboard must
produce the same `input::InputEvent` whether it is attached through PS/2 or USB.
A storage device must appear through the block-device contract rather than being
special-cased by the filesystem. Drivers must be isolated behind checked kernel
interfaces so a malformed device descriptor cannot corrupt unrelated kernel state.

## Layering

1. **PCI/PCIe discovery and resource ownership** — enumerate functions, identify
   class/subclass/programming-interface, parse BARs, and map MMIO only after the
   physical-memory manager can reserve and map the complete range safely. Do not
   enable bus mastering until a controller driver has established DMA buffers,
   address limits, and teardown rules.
2. **USB host-controller core** — a common host-controller interface with separate
   xHCI first, then EHCI and UHCI/OHCI backends where hardware demand justifies them.
   xHCI is the priority for modern PCs; legacy controllers are compatibility work.
3. **Enumeration** — reset port, establish the default control pipe, read the first
   eight device-descriptor bytes, learn the endpoint-zero packet size, fetch the
   full device/configuration descriptors, assign an address, select a configuration,
   and bind interfaces. Every transfer has a deadline, bounded retry count, and
   explicit error result.
4. **Class drivers** — HID boot keyboard/mouse first; USB mass storage (Bulk-Only
   Transport with SCSI transparent command set) next; then hubs, game controllers,
   audio, and other classes. HID report descriptors must be parsed with strict
   length and collection bounds rather than assuming every device is boot protocol.
5. **Existing OS services** — HID reports become device-neutral input events;
   mass-storage logical units become block devices; audio endpoints feed an audio
   service. Applications never access controller registers directly.

## Safety and reliability invariants

- Never trust descriptor lengths, endpoint counts, packet sizes, or configuration
  totals. Validate bounds before every read and reject malformed chains.
- No unbounded waits: port reset, control transfers, bulk transfers, and device
  shutdown all use deadlines and bounded retry policies.
- Do not perform disk writes during discovery. A newly attached USB disk is read-only
  until the user explicitly mounts it; formatting is always a separate confirmed action.
- DMA buffers must be physically contiguous where required, aligned to controller
  constraints, mapped with appropriate cache attributes, and kept alive until the
  controller is proven quiescent. Never free a buffer still reachable by hardware.
- Handle unplug during every phase. Cancel outstanding requests, stop DMA safely,
  invalidate device handles, and notify upper layers without dereferencing stale state.
- Keep controller interrupts masked until the interrupt routing and completion-ring
  handling are ready. Polling bring-up is acceptable only as a bounded diagnostic mode.
- Enforce per-device and global resource limits: device count, configuration size,
  endpoint count, transfer size, queue depth, and memory use.

## Delivery milestones

### USB-0 — prerequisite infrastructure

- Extend PCI discovery beyond configuration mechanism #1 to ACPI MCFG/ECAM where
  firmware supplies it; retain mechanism #1 as a fallback.
- Add checked PCI BAR sizing/resource parsing and a physical MMIO mapping API.
- Define DMA allocation, address-width, alignment, cache-coherency, and ownership APIs.
- Add structured device/driver registration and diagnostics.

### USB-1 — xHCI controller bring-up

- Identify xHCI by PCI class 0x0C, subclass 0x03, programming interface 0x30.
- Parse capabilities and operational/runtime/doorbell regions with bounds checks.
- Reset controller, configure command/event rings and device context structures,
  and bring up one root port at a time.
- Initially support bounded polling for command completion; add MSI/MSI-X or routed
  interrupt delivery only after interrupt infrastructure is ready.

### USB-2 — enumeration and HID

- Implement control endpoint transfers and descriptor parsing.
- Enumerate root ports and hubs with bounded depth and device count.
- Support boot-protocol keyboards and mice, then generic HID report parsing.
- Translate input into the existing shared event queue.

### USB-3 — removable storage

- Implement USB Mass Storage Bulk-Only Transport and SCSI INQUIRY, TEST UNIT READY,
  READ CAPACITY, READ(10), and WRITE(10) with strict transfer bounds.
- Register each logical unit through `storage::block`.
- Default new media to read-only; require explicit user action before writes or format.

### USB-4 — broader device coverage

- Hubs/hotplug hardening, game controllers, audio, printers, cameras, and vendor
  devices according to documented class standards and available test hardware.
- Add suspend/resume and power management after basic lifecycle correctness.

## Compatibility strategy

The kernel owns controller safety and DMA. Class drivers expose stable device services.
The user-space ABI should describe input devices, block devices, and audio streams,
not USB-specific register details. This allows future USB4/Thunderbolt bridges or
new host-controller backends to reuse the same upper layers.

## Current limitations

The current MixedOS snapshot has read-only conventional PCI configuration-space
scanning, PS/2 input, and a legacy IDE ATA PIO block backend. It does not yet have
PCI BAR mapping/resource management, a DMA API, an xHCI/EHCI/UHCI/OHCI driver, USB
enumeration, HID-over-USB, or USB mass storage. This document is a design plan, not
a claim that those features work today.
