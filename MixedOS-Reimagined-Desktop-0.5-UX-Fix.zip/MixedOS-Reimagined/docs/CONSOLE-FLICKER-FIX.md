# Console redraw / flicker fix

## Cause

The interactive shell polled input statistics continuously. Keyboard byte counts,
mouse packet counts, and mouse coordinates changed during ordinary input, so the
shell repainted the status strip on each change. Additionally, the key handler
called `scroll_to_bottom()` for every keypress; that method always cleared and
redrew the complete scrollback viewport even when the terminal was already at
the bottom.

## Changes

- The status strip now displays stable device readiness/configuration rather than
  volatile packet counters and mouse coordinates.
- `set_input_status` compares a stable device-state signature and does nothing
  unless controller/keyboard/mouse readiness or wheel protocol changes.
- Live byte counters, last bytes, mouse coordinates, and error counters remain
  available through the `input` shell command.
- `scroll_to_bottom`, scroll up/down/top, and scrollbar dragging avoid a full
  history redraw when the requested scroll offset has not changed.
- The shell no longer requests status-strip redraws every time input statistics
  change.
- Normal typing draws only the new glyph; backspace redraws only the current line.
  Full history redraws remain intentional for actual scrolling, clearing, or
  restoring a screen after MKH preview.

## Validation

The source regression test checks that ordinary input does not trigger status
or history repaints when nothing visible has changed. A Windows Rust build and
VirtualBox runtime test are still required to confirm behavior on the target.
