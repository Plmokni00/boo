# Stage 6 Fix 5 — direct ISR handoff to kernel return

The Fix 4 VirtualBox screenshot showed the final user process reaching EXIT and
then stopping immediately after the message about redirecting IRETQ to the
kernel trampoline. Both ring-3 test tasks had already executed report/yield/exit
syscalls, so process creation and the round-robin path were working. The stall
was at the last synthetic IRETQ transition.

Fix 5 removes that transition entirely:

1. The final EXIT handler retires the last process and sets the one-shot
   `mixedos_return_to_kernel` handoff flag.
2. The Rust interrupt dispatcher returns normally to the assembly common ISR.
3. The ISR restores the interrupted FPU state, checks the handoff flag, and
   branches directly to the leaf kernel-return stub before restoring the
   retired process frame or executing IRETQ.
4. The leaf stub restores kernel data selectors, loads the saved kernel CR3,
   switches to the saved shell stack, restores the callee-saved registers, and
   returns from `mixedos_enter_user()`.
5. `run_demo()` checks the handoff flag and CR3 before restoring TSS.RSP0 and
   freeing process resources. It clears the one-shot flag before reenabling IRQs.

This avoids a synthetic CPL0 IRETQ frame altogether. The retired process's
interrupt stack is abandoned only after the assembly stub has switched to the
saved shell stack; process stacks and page tables are reclaimed later in normal
Rust context, after CR3 verification.

The user subsequently supplied a successful Windows build log for Fix 5 and a
VirtualBox screenshot showing the complete test result: two processes exited,
zero faulted, four syscall reports, five context switches, zero cleanup errors,
CR3 restoration verified, both address spaces/stacks reclaimed, and the
`MIXEDOS>` prompt returned. This confirms the built-in Stage 6 demonstration in
that VirtualBox configuration, not a general-purpose process environment.
