# Stage 6 Fix 1 — inherited PML4 U/S bits

The first VirtualBox `proctest` attempt stopped before entering ring 3 with `InheritedUserMapping`. The root clone check was too strict: it interpreted any present PML4 entry with U/S=1 as an inherited user mapping. On x86-64, effective user access requires U/S=1 at every paging level; a U/S bit on the PML4 parent alone does not make a leaf accessible to CPL3.

Fix 1 now clears U/S on every inherited present PML4 entry in the *private cloned process root*, then reads the entries back and verifies that the inherited root entries are supervisor-only. It never changes the active kernel PML4. The dedicated user PML4 slot (index 1) must still be completely empty before the process-owned subtree is installed there.

This should address the exact `InheritedUserMapping` failure in the supplied screenshot. It does not prove that ring-3 entry, syscalls, scheduling, or cleanup work; those still require the Windows build and VirtualBox retest.
