# Validation plan

## Source checks

Run:

```powershell
python tools/validate_source.py
```

This checks required source files, architecture API exports, Stage 2 input invariants, Stage 3/4 memory-manager markers, Stage 5 heap baseline, Stage 6 GDT/TSS/interrupt/process invariants, unchanged prior-stage source hashes, and repository hygiene. It is a source-structure check, not a Rust compiler or OS test. `python tools/test_memory_model.py` exercises a host-side frame allocator model. `python tools/test_paging_model.py` exercises a host-side four-level mapping/permission/reclamation model. Neither executes privileged Rust code or the CPU TLB. `python tools/test_heap_model.py` and `python tools/test_process_model.py` provide independent host-side allocator and process/scheduler models; they are not kernel execution.

## Build checks

Run `Build.bat` on the supported Windows build host. Record:

- Windows version and architecture.
- `rustc --version` and `cargo --version`.
- `clang --version`.
- `xorriso -version`.
- Limine archive version and verified SHA-256.
- Build log and resulting ISO SHA-256.

The build is not validated until the kernel ELF and ISO exist and the build script exits with code 0.

## Primary boot and interactive-kernel checks

The primary acceptance target is a real x86-64 computer, not a virtual machine. Boot the ISO from USB or optical media in both BIOS and UEFI modes where available. Record motherboard/chipset, CPU, RAM, firmware mode, graphics adapter, storage controller, and how the keyboard/mouse are connected. A legacy i8042-compatible PS/2 path is required by the current input driver; USB HID is not implemented yet. A USB keyboard may work only if firmware provides legacy PS/2 emulation. COM1 serial output is useful where the board exposes a physical serial port or supported header.

1. Limine displays the MixedOS entry and loads the kernel.
2. COM1 reports the Rust kernel entry and ABI revision.
3. The framebuffer displays the interactive MixedOS console (if the bootloader provides supported RGB output).
4. The IDT installs and the PIC/PIT timer is enabled without an immediate fault.
5. The console accepts `help` and displays the compact everyday command list; `diagnostics` lists developer/hardware tools.
6. `mem` reports boot-map and managed/free/allocated totals. `free + allocated` must equal `managed`.
7. `uptime` increases over time (nominally based on 100 Hz PIT ticks).
8. `clear` clears the framebuffer console.
9. The console shows separate keyboard and PS/2 mouse counters. Type letters and numbers; test Shift, Caps Lock, Tab, Enter, Backspace, and Escape. Move and click the mouse; the mouse byte counter, position, and button field should update independently.
10. Run `diagnostics`, then `input`, to print controller configuration, keyboard/mouse readiness, raw byte counters, last bytes, mouse position/buttons, controller errors, and event-queue drops. Verify wheel-up moves toward older output and wheel-down returns toward newer output.
11. Optional: COM1 serial receive can enter commands at 38400 baud, 8-N-1. Serial bytes are normalized into the same input event queue.
12. `reboot` requests a reset through the legacy keyboard controller; behavior depends on chipset/controller support.
13. Do not trigger deliberate CPU faults on a daily-use or production machine. Exception-path testing belongs on a dedicated development system or disposable emulator configuration after separate review.

VirtualBox is optional and supplementary. A successful VM boot does not prove hardware compatibility, and a VM failure does not automatically mean a physical platform is unsupported. Timer support is currently 8254 PIT + 8259 PIC, and hardware input is legacy PS/2 only. USB HID, APIC, laptop-specific controllers, and other platform support are not implied. The Stage 2 polling loop intentionally busy-spins until a scheduler-aware idle task exists.

## Hardware-specific subsystem checks

Device enumeration is not driver support. The PCI scanner finding a device only confirms that configuration-space identification worked. Test each actual driver on hardware that exposes the required interface. For storage, the current driver is legacy IDE ATA PIO; it does not support AHCI, NVMe, or USB mass storage. Do not attach or format a primary/system disk. Filesystem write/format tests require a separate, expendable disk with no valuable data. Do not mark networking, storage, audio, USB, or GPU support based only on device detection.


## Stage 3 memory acceptance

After boot, run `mem`, `frames`, `memtest`, and `frames` again. The full-page
self-test must pass; managed frame count must not change; allocated frames must
return to their starting value; free-frame count must return to its starting
value; and free errors must remain zero. Repeat `memtest` multiple times. Also
verify keyboard typing and mouse movement/clicks after the memory commands.

## Stage 4 virtual-memory acceptance

Perform this only after the Windows build and a normal boot succeed, on a dedicated development machine or disposable emulator configuration. It exercises page-table operations and a faulty mapping can fault the kernel. First run `help`, `input`, `mem`, `frames`, and `paging` to
confirm earlier functionality remains. Then run `vmtest`. It performs actual
virtual reads/writes through two new 4 KiB mappings; a paging bug can fault the
kernel. A passing result must be followed by `paging` and `frames`: owned page
tables, allocated physical frames, and free frames return to baseline; free
errors are unchanged; the test virtual addresses are not mapped. Repeat the test
several times, then test keyboard typing and mouse motion/clicks again.


## Stage 6 process, scheduler, and user-mode test

Stage 6 adds a dedicated GDT/TSS, a DPL3 `int 0x80` gate, two cloned address
spaces with private user code/stack pages, and a small round-robin scheduler.
Run `procs` before testing to establish counters, then run `proctest`. The test
uses two built-in integer-only ring-3 tasks. Each reports twice, yields twice,
and exits. Verify that both tasks complete, no user task faults, at least four
reports occur, context switches are nonzero, cleanup errors remain zero, and
control returns to the kernel prompt. Run `procs`, `heap`, `frames`, `paging`,
and `input` afterward to verify cleanup and preserve previous milestones.

Use a dedicated development machine or disposable emulator configuration for the first Stage 6 test. This stage
changes GDT/IDT privilege handling, switches CR3 roots, and executes CPL3 code;
a faulty transition can reset or fault the VM. The host-side process model and
assembly/C checks do not replace the Windows Rust build or runtime validation on the target architecture. No general user executable loader, user-pointer syscall, per-task
FPU/AVX state, SMP, or hardware platform support is implied.
