# MixedOS architecture

## Target and boundary

The first target is x86_64 BIOS/UEFI. The kernel is a freestanding Rust ELF loaded by the Limine boot protocol. Limine is a bootloader dependency only; it is not the kernel, userspace, distribution, or runtime base. The kernel is taking ownership incrementally from the environment supplied by the bootloader.

The architectural direction is a privileged kernel plus isolated user-space services and applications. The current command loop is still ring 0. It is a bring-up/debugging interface, not a security boundary or a POSIX shell.

## Current boot and interrupt path

1. Firmware starts the Limine bootloader.
2. Limine loads `boot/mixedos-kernel.elf` and populates the requests retained in `.limine_reqs`.
3. The assembly `_start` trampoline disables interrupts, builds and loads a 256-entry bootstrap IDT using Limine's current CS, and prebuilds a second copy using the kernel code selector `0x08`.
4. Before any Rust/LLVM code can execute, the trampoline clears CR0.EM/TS, sets CR0.MP, enables CR4.OSFXSR/OSXMMEXCPT, initializes x87 and MXCSR, marks `MIXEDOS_FPU_READY`, aligns the stack, and calls `mixedos_rust_entry`.
5. Rust initializes COM1 and installs the kernel/user GDT and 64-bit TSS. The GDT reload switches IDTR to the prebuilt bootstrap table whose gates use the new kernel code selector. The full Rust 256-entry diagnostic IDT then replaces the bootstrap table. Hardware interrupts remain disabled.
6. The kernel confirms the Limine base protocol revision, registers the boot framebuffer with MKH, verifies the early x87/SSE state, and checks the linked C ABI. Early exceptions before the full IDT use the bootstrap halt handler rather than a null IDT.
7. The kernel reads the bootloader memory map, reports usable RAM ranges, initializes the Stage 3 physical frame allocator, and inspects the active four-level CR3 tree through the HHDM. Stage 4 never replaces CR3; only type-0 usable pages at or above 1 MiB and below the 64 GiB tracking limit become allocator-managed frames.
8. The kernel initializes the framebuffer terminal, probes legacy IDE ATA storage, and mounts an existing MIXFS volume read-only or read-write as permitted. It never formats unrecognized media during boot.
9. The i8042 keyboard/mouse subsystem is initialized using bounded polling while interrupts are still disabled. This keeps its controller setup from racing with IRQ delivery.
10. The 8259 PIC is remapped to vectors 32–47. Only IRQ0 is unmasked, and the 8254 PIT is programmed for a nominal 100 Hz tick. This is the point at which the kernel enables hardware interrupts.
11. The shell polls the shared i8042 input manager and COM1 receive path, then consumes normalized keyboard, mouse, and serial events. The current shell is still a ring-0 bring-up loop; it spin-polls because PS/2 IRQ delivery remains disabled and no scheduler-aware idle task exists.

The assembly ELF-entry trampoline initializes the CPU state needed by compiler-generated SSE2 before calling Rust. Its bootstrap IDT handles faults during early bring-up; the GDT reload atomically switches to a prebuilt bootstrap table with the kernel code selector, and Rust later installs the full diagnostic IDT with TSS IST stacks. The interrupt stubs save general-purpose registers before entering Rust and use FXSAVE/FXRSTOR only after `MIXEDOS_FPU_READY` is set. AVX/XSAVE state management is not implemented. Timer support is the legacy PIT/PIC path, not LAPIC/IOAPIC/APIC support.

## Kernel bring-up interfaces

- **Exceptions / MKH:** exception reports include vector number, CPU error code, and saved instruction pointer. Page faults also report CR2. Fatal CPU exceptions are logged to COM1 and halt the CPU. The `mkh preview` shell command displays a sample of the same screen without setting the fatal guard or halting the machine; the Escape key returns to the terminal, while COM1 users send ESC.
- **Input:** the current input path expects an i8042-compatible controller. A shared poller demultiplexes keyboard and auxiliary mouse bytes into one event queue; a US keyboard decoder emits key-down/key-up and text events, while the PS/2 mouse decoder supports standard three-byte packets and optional IntelliMouse ID 3 wheel packets. USB HID, extra mouse buttons, international layouts, and configurable repeat are not implemented.
- **Serial:** COM1 uses 38400 baud, 8-N-1. Transmit is used for diagnostics and shell output; non-blocking receive is normalized into the shared input event queue.
- **PCI:** a read-only conventional configuration mechanism #1 scanner reports device IDs and class codes. It does not map BARs, assign resources, enable bus mastering, or load drivers.
- **Framebuffer:** text output is software-rendered to the bootloader-provided linear RGB framebuffer. It is not a graphics driver, compositor, window manager, or accelerated GPU stack.
- **Memory:** Limine's memory map feeds a 4 KiB physical frame allocator. Stage 4 walks the active four-level page tables through the HHDM, adds/removes checked 4 KiB mappings, tracks owned intermediate tables, and invalidates local TLB entries. Stage 5 adds an explicit bounded heap (not Rust's global allocator). Stage 6 clones the active PML4 root for each built-in test process, shares the existing supervisor-only kernel mappings, and creates private user mappings in an otherwise-unused low-half PML4 slot. The original kernel CR3 remains the page manager's owner root; process roots are explicitly switched only by the Stage 6 scheduler.

## Language boundaries

| Technology | Intended boundary | Current evidence |
|---|---|---|
| Rust | Kernel and core services | Kernel entry, boot requests, interrupt dispatch, timer, unified keyboard/mouse/serial input queue, framebuffer console, kernel command loop |
| C | Freestanding native routines and stable C ABI | C object compiled and linked in the user's successful Windows build |
| x86_64 assembly | Interrupt entry/exit and architecture-specific operations | ISR stubs; Rust `asm!` emits control-register, `cli`, `sti`, `hlt`, `in`, and `out` instructions |
| Zig | Selected native utilities after an ABI and use case are justified | Not started |
| Java | A real managed runtime and application support | Not started |
| Lua | Embedded scripting in a real user-space service | Not started |
| GLSL/WGSL | Shader code through a real GPU API and driver | Not started |
| POSIX shell | Shell after processes, files, pipes, and descriptors exist | Not started; current command loop is a ring-0 debug console |
| SQLite | Embedded structured storage after reliable filesystem I/O exists | Not started |

The C ABI is versioned in `include/mixedos/abi.h`. Cross-language calls must use explicit fixed-width types and documented ownership rules. Do not pass Rust-only data structures across the C boundary.

## Memory and privilege plan

Before running applications, MixedOS still needs:

- Repeated VM validation of physical frame ownership and HHDM read/write access.
- Repeated VirtualBox validation of Stage 4 page-table mappings, permission checks, TLB invalidations, and cleanup.
- Rust global allocator integration only after scheduler-aware IRQ locking and allocation-failure policies are established.
- General user executable loading, syscall pointer validation, per-process FPU/AVX state, and APIC/SMP scheduling are not part of the first Stage 6 test.
- General ELF loading, dynamic process creation, and validated relocation rules.
- Safe copy-in/copy-out routines and a pointer-aware syscall ABI.
- Per-process FPU/SSE/AVX state, wait/signals, synchronization, and SMP support.
- Kernel-stack guard pages and dedicated IST stacks for critical exceptions.

Stage 6 now contains a narrow ring-3 demonstration path with two built-in integer-only tasks. The kernel command loop and current drivers still execute in ring 0; the demo is not a general user-mode application environment.

## Storage and services plan

Storage devices and filesystems will be exposed through kernel driver interfaces. A user-space storage service can later own filesystem policy and persistence, but it must have a working block-device interface, crash-consistent writes, mount semantics, and permissions first. SQLite is an application/service dependency, not the filesystem itself.

Networking is similarly layered: PCI/USB discovery, device drivers, link layer, IP, transport protocols, DHCP/DNS, TLS libraries, and user-facing network management. UI indicators must reflect actual service state.

## Graphics plan

The current framebuffer console is software rendering through a bootloader-provided linear framebuffer. It is not a GPU driver, compositor, window manager, or accelerated graphics stack. Later graphics work needs a driver boundary, memory management, command submission, mode management, a 2D/3D userspace API, a compositor, and validated device support before advertising acceleration or shader effects.

## Kernel heap (Stage 5)

The explicit kernel heap is layered above the physical-frame allocator and the
active-root page-table manager. It reserves a bounded high-half virtual arena,
backs it with zeroed 4 KiB frames, and manages allocations using an address-sorted
intrusive free list with splitting and adjacent-block coalescing. Allocation
headers retain the original block span so deallocation can validate bounds and
reject invalid or repeated frees. The first heap revision is deliberately not
registered as Rust's global allocator and is not callable from interrupt
context; locking and lifecycle rules must be revisited with SMP and scheduling.

## Process and privilege foundation (Stage 6)

Stage 6 adds a dedicated GDT with ring-0/ring-3 descriptors and a 64-bit TSS.
The IDT exposes vector `0x80` as a DPL3 interrupt gate. Two built-in integer-only
user programs run from separate CR3 roots. Each root clones the kernel's active
PML4 entries but clears the USER bit on inherited present PML4 entries in the private clone; PML4
slot 1 must be unused and is populated with private user code (read/execute)
and stack (read/write/NX) mappings. The high-half kernel mappings, IDT, GDT,
TSS, kernel heap, and kernel stacks are shared as supervisor mappings.

The scheduler switches on explicit user `yield` syscalls and PIT IRQ0 timer
preemption. A task's complete ring-3 interrupt frame is copied to its PCB; the
base ring-0 frame type deliberately excludes the extra user RSP/SS words, which
are accessed only through a raw-pointer ring-3 frame view after checking CS.RPL.
The selected task's frame, TSS.RSP0, and CR3 are restored before `iretq`. A user fault retires that
task and selects another ready task. When all test tasks exit, an assembly
trampoline restores the original kernel CR3 and shell stack before freeing
private frames and kernel stacks. This first scheduler is uniprocessor-only.
The tasks do not use floating-point/SIMD instructions; per-process FPU/AVX
context, general ELF loading, user pointer syscalls, and SMP are future work.


## PCI discovery (early Stage 8)

`kernel/src/pci.rs` performs read-only conventional PCI configuration-space
scanning through mechanism #1 (`0xCF8`/`0xCFC`). It reports identities and class
codes only. Device BARs are not mapped, bus mastering is not enabled, resources
are not assigned, and no drivers are loaded. The scanner is synchronous and
assumes the current single-core kernel has one PCI configuration-space caller;
SMP and concurrent device management require a lock and a fuller bus model.
ECAM/ACPI MCFG, PCIe extended configuration space, bridge-topology discovery,
USB enumeration, and hotplug are not implemented.
