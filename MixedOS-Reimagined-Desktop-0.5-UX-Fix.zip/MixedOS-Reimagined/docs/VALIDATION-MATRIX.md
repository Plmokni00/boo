# MixedOS validation matrix

## Evidence labels

- **Source:** code and source-level contract exist.
- **Host-tested:** deterministic model/contract tests pass on the host.
- **Compiled:** the exact source revision compiled with recorded toolchain versions.
- **VM-tested:** the exact image booted and behavior was observed in a named VM configuration.
- **Hardware-tested:** the exact device and hardware revision were exercised.

Do not promote a feature to a higher evidence level based on a neighboring feature or an earlier source revision.

## Required automated suites

- Boot protocol and memory-map fuzz/bounds tests.
- Physical allocator exhaustion, reservation, invalid-free, and recovery tests.
- Page-table permission, collision, rollback, TLB, and teardown tests.
- Heap alignment, fragmentation, corruption, and exhaustion tests.
- Scheduler, syscall, user-pointer, process isolation, and resource reclamation tests.
- PCI topology, BAR decoding, resource overlap, and config-space locking tests.
- DMA address-mask, alignment, lifetime, and cache-coherency model tests.
- USB descriptor parsing, enumeration state machine, transfer timeout, and unplug tests.
- Block-device timeout, partial failure, flush, and fault-injection tests.
- Filesystem corruption, transaction recovery, and read-only fallback tests.
- Network parser fuzzing, retransmission, malformed packet, and queue-exhaustion tests.
- Package signature, interrupted update, rollback, and boot recovery tests.

## Current host checks run during this audit

`tools/validate_source.py` passed (86 required files). All 20 `tools/test_*.py` scripts passed, including architecture facade, ACPI discovery, Arimo font and console contracts, console scrollback, directory/file operations, heap, memory, MIXFS, MKH, paging, PCI discovery, process model, PS/2 wheel, storage models/safety, toolchain bootstrap, and Zig CRC-32 integration.

These are host-side source/model checks. This environment does not have PowerShell, Zig, Cargo, or rustc, so this audit did not execute the Windows builder, compile the Zig object or Rust kernel, produce an ISO, or boot a VM. The user separately reports that MixedOS boots; the next source revision still needs its own build and boot verification.


## Current user-reported runtime evidence (2026-11-16)

The user reports the proportional Arimo console boots in VirtualBox and that the latest no-flicker revision no longer visibly flickers during mouse movement or typing. A screenshot shows the Arimo shell displaying help and accepted text input. The exact no-flicker ISO hash and full build log should be added to the build record at the next baseline build. This evidence is for the console path and does not validate USB, network, modern storage, audio, GPU acceleration, or physical hardware.


## Hardware inventory follow-up (2026-11-16)

The user has booted the Zig-integrated ISO and run `acpi`, `memmap`, and
`sysinfo`. The observed result was 503 MiB usable RAM across three regions,
128,927 free allocator frames, 11 PCI devices, and ACPI unavailable. The
source now corrects the Limine RSDP request ID and treats its response as an
HHDM virtual address for base revision 6. New host regression coverage checks
the corrected request ID, HHDM-to-physical conversion contract, memory-map
labels, and read-only PCI BAR inventory. Windows rebuild and VirtualBox
confirmation remain required.


## Latest source validation — 2026-11-16

After the Limine RSDP request/address correction and read-only PCI resource
inventory were added, the source validator passed with 87 required files and
all 22 `tools/test_*.py` host regression scripts passed. Rust compilation, the
Windows ISO build, and VirtualBox tests for this revision are still pending.
