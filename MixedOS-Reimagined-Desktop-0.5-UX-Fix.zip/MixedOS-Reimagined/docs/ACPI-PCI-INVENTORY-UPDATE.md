# ACPI and PCI inventory update — 2026-11-16

## ACPI: Limine RSDP handoff correction

The user's first integrated VirtualBox run showed `ACPI state: Unavailable`.
Inspection found that the RSDP request identifier was mistyped. The Limine
protocol identifier is:

```text
c5e77b6b397e7b43 27637845accdcf3c
```

The request now uses the corrected second ID word (`0x2763_7845_accd_cf3c`).

MixedOS requests Limine base revision 6. Under base revision 4 and later, the
RSDP response address is already an HHDM virtual address. The parser now reads
that address directly and converts it back to physical only when checking that
the RSDP lies inside an ACPI reclaimable, ACPI NVS, or reserved-mapped memory
region. Addresses stored in the RSDT/XSDT remain physical and are translated
through the HHDM when dereferenced.

The parser remains bounded and read-only. It does not execute AML, enable an
APIC, map PCI MMIO, modify PCI configuration, or activate devices.

## Memory map output

`memmap` now displays readable names for Limine types 0 through 8:

- usable
- reserved
- ACPI reclaimable
- ACPI NVS
- bad memory
- bootloader reclaimable
- kernel/modules
- framebuffer
- reserved mapped

Unknown future values remain visible as `unknown` with the numeric type.

## PCI resource inventory

`pci resources` summarizes currently programmed BAR snapshots from the first
bounded set of enumerated devices. It reports I/O, MMIO32, MMIO64, prefetchable,
zero-base, and reserved BAR counts. This does not establish BAR sizes and does
not claim or map address ranges. It performs no BAR-sizing writes and does not
enable bus mastering. A future resource allocator must add a controlled sizing
phase, conflict checking, ownership records, and safe MMIO mappings before any
driver may use a BAR.

## Stable project location

The release ZIP contains a top-level folder named `MixedOS-Reimagined`. Keep
that folder name when extracting into the same parent directory as the user's
existing project. The ISO path remains:

```text
MixedOS-Reimagined\build\artifacts\MixedOS-x86_64.iso
```

All build scripts use their own project-root location, so the folder can be
moved as a unit while retaining this folder name.

## Verification state

- Source validator: 87 required files passed.
- Python regression scripts: 22/22 passed.
- Rust compilation: not run in this environment (no Rust toolchain installed).
- Windows build and VirtualBox runtime: required for this revision.
