# MixedOS Desktop 0.1 — Terminal and app surfaces

## User-facing behavior

- Desktop remains the normal boot destination after kernel initialization.
- The dock's Terminal tile opens the user-facing CMD-style Terminal app.
- `Ctrl+Alt+T` opens the same Terminal app.
- `EXIT`, `QUIT`, or Escape closes the Terminal app and returns to the desktop.
- `F1` opens the separate kernel recovery console. Recovery remains available if the desktop cannot initialize.
- The obsolete `desktop` shell command and the old `desktop preview` command have been removed.

## Terminal presentation

The Terminal app uses the existing framebuffer scrollback, proportional Arimo glyph renderer, keyboard editing, command history, and mouse-wheel/scrollbar support. It is branded as **MIXEDOS TERMINAL** and presents a CMD-style prompt:

```text
C:\MIXEDOS>
```

The recovery console remains separately branded as **MIXEDOS KERNEL RECOVERY** and uses `MIXEDOS-RECOVERY>`.

## CMD-compatible command aliases

The following aliases map to existing MixedOS implementations:

| CMD-style command | Existing implementation |
|---|---|
| `CLS` | `clear` |
| `DIR` | `ls` |
| `MD` | `mkdir` |
| `TYPE` | `cat` |
| `DEL` | `rm` |
| `RD` | `rmdir` |
| `VER` | `version` |
| `SYSTEMINFO` | `sysinfo` |
| `DRIVERQUERY` | `drivers` |
| `TASKLIST` | `procs` |
| `CHKDSK` | `fsck` |

Commands are case-insensitive. MIXFS paths are still expressed with `/` (for example `/notes.txt`); a full current-directory and Windows drive-path layer has not been implemented. Unknown commands now use a CMD-like “not recognized” message.

## App surfaces

- **Files** opens a styled read-only MIXFS root-directory view. File modification still happens through Terminal commands.
- **Settings** opens a styled system information/preferences surface. Actual setting mutation is not implemented yet.
- **Terminal** is the functional command environment backed by the existing kernel shell command handlers.

These app views are currently synchronous kernel-rendered surfaces, not isolated user-space processes or a general-purpose window manager. The design is a desktop 0.1 foundation; user-space application isolation and movable/resizable windows remain future work.

## Validation

`tools/test_desktop_autoboot.py`, `tools/test_desktop_wallpaper.py`, `tools/test_cmd_terminal.py`, and the full `tools/test_*.py` regression set cover desktop launching, CMD aliases, Terminal exit, app surfaces, and wallpaper rendering. Source validation does not replace a Windows Rust/Clang/Zig build or a VirtualBox runtime test.
