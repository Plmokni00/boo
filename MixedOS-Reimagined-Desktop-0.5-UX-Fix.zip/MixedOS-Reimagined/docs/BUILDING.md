# Windows build and toolchain setup

## Languages and tools needed for the current build

| Language/tool | Role in MixedOS today | Builder behavior |
|---|---|---|
| Rust stable | Main x86-64 kernel | Checks `rustup`, stable compiler version, Cargo, and `x86_64-unknown-none`; adds the toolchain/target only when missing or below the minimum. |
| C via LLVM/Clang | Freestanding native runtime and C ABI boundary | Checks Clang version; installs LLVM only when missing, and only attempts an update if the detected compiler is too old. |
| Zig 0.17.1 | Freestanding CRC-32 implementation linked into MIXFS | Reuses a matching system compiler if present; otherwise downloads the official Windows archive once into `build/deps`, checks its pinned SHA-256, and reuses the cached compiler. |
| Python 3.10+ | Host-side source validator and regression tests only | Detects PATH and common per-user installations; installs Python 3.12 only when no suitable interpreter is found. The guest OS does not run Python yet. |
| x86-64 Assembly | Boot/interrupt/context-switch instructions | Uses Rust's LLVM-backed `global_asm!` and inline assembly; no separate NASM installation is required. |
| xorriso / MSYS2 | Hybrid BIOS/UEFI ISO authoring | Checks the existing xorriso version first; installs MSYS2 and xorriso only if absent. |
| Limine | Third-party BIOS/UEFI bootloader files | Downloads the pinned 12.9.6 binary archive once and verifies SHA-256 before extraction. |
| PowerShell | Windows build orchestration | Uses Windows PowerShell; no WSL or Docker. |

Java/JDK, Lua, GLSL/WGSL toolchains, and SQLite are not installed yet because no implemented MixedOS subsystem uses them. They should be added individually when a real subsystem begins consuming them. Installing every future language now would waste disk space and make the build less reproducible.

## One-click build

Double-click `Build.bat`. The builder checks dependencies in this order, prints the detected versions, and handles one missing tool at a time:

1. Rustup, Rust stable, and the freestanding target.
2. LLVM/Clang for C.
3. Python for mandatory host validation.
4. Zig 0.17.1 for the first Zig kernel component.
5. xorriso only when a full ISO build is requested.
6. Limine only when its verified archive is not already cached.

For the normal workflow, simply double-click `Build.bat`. There are no command-line switches or separate setup step. It checks the installed version first and processes Rust, Clang, Python, and Zig sequentially, installing only a missing or unsupported requirement. Rust stable and its target are installed only when missing; Python is selected from all registered Windows Python installations; Clang discovery compares PATH and common install locations; Zig is reused only when both its pinned archive marker and executable checksum validate. Subsequent builds reuse installed tools and the persistent per-user Zig cache. The script keeps verified compiler and bootloader downloads under `%LOCALAPPDATA%\MixedOS\Toolchains` between project replacements and builds.

## Build pipeline

1. Run `tools/validate_source.py` and every `tools/test_*.py` script. Python is mandatory; validation is not silently skipped.
2. Compile `kernel/native/c/runtime.c` with Clang for `x86_64-unknown-none-elf`.
3. Run the Zig CRC-32 standard-vector test, then compile `kernel/native/zig/crc32.zig` to a freestanding object for `x86_64-freestanding-none`.
4. Export `MIXEDOS_C_OBJECT` and `MIXEDOS_ZIG_OBJECT`; `kernel/build.rs` refuses to link if either object is missing.
5. Build the Rust kernel for `x86_64-unknown-none`. MIXFS calls the Zig CRC-32 object for superblock integrity checks.
6. Download and verify Limine 12.9.6 if it is not already cached.
7. Stage the kernel ELF, Limine BIOS/UEFI files, and configuration; generate the hybrid ISO with xorriso; run Limine's BIOS installation step.
8. Write the ISO SHA-256 sidecar and verify the artifact exists.

## Output

- `build/artifacts/MixedOS-x86_64.iso`
- `build/artifacts/MixedOS-x86_64.iso.sha256`
- `build/logs/build-YYYYMMDD-HHMMSS.log`
- `build/deps/` — cached, verified third-party build tools
- `build/native/` — generated C and Zig object files

## Important constraints

- This is a Windows-hosted build, not a Windows-targeted kernel.
- No WSL or Docker commands are used.
- Zig is used as a small native kernel component; MixedOS does not yet include a Zig application runtime.
- Python runs on the Windows host for tests; it is not part of the booted OS.
- A successful build does not replace VirtualBox or physical-device boot testing.
