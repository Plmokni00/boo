# MixedOS PCI resource reservation registry

## Purpose

This stage adds software ownership and conflict detection for I/O-port and
MMIO ranges. It is a prerequisite for a real PCI resource manager, but it does
not itself assign hardware BARs.

## Contract

- 64 bounded reservation slots.
- I/O-port and MMIO address spaces are tracked independently.
- Requests require a non-zero base/length, checked end arithmetic, and a
  power-of-two alignment satisfied by the base.
- I/O ranges must remain inside the 16-bit port address space.
- Half-open interval checks reject overlaps and permit adjacent ranges.
- Every claim has a PCI BDF/BAR owner (device 0–31, function 0–7, BAR 0–5)
  and a generation-tagged lease.
- A lease dropped without explicit quiesced release leaves the reservation
  active. This intentionally fails closed rather than making a possibly active
  device range available to another driver.
- Explicit release is `unsafe` and must only happen after the owning device is
  stopped and no code can still access the range.

## What is not implemented

The current PCI code only reads firmware-programmed BAR snapshots; it does not
know BAR aperture sizes. Therefore no physical device ranges are inserted into
this registry yet. BAR sizing, bridge-window allocation, MMIO virtual mapping,
cache attributes, and PCI command-register changes remain separate future work.

## Commands

- `resources` displays active software claims and rejection counters.
- `resources test` tests overlap rejection, adjacent-range acceptance, and
  cleanup using synthetic registry entries. It performs no port I/O and does
  not contact PCI hardware.
