# Desktop 0.5 UX correction

This correction addresses the first Desktop 0.5 usability failures reported after testing.

- Desktop UI text now renders the bundled Arimo 16px glyph atlas at 75% (approximately 12px), including the C compositor's title/status text and Rust-rendered app surfaces. Advances, glyph bounds, and baselines are scaled together.
- Closing Settings, Files, Terminal, the Start panel, and the text editor restores the cursor's saved background before repainting the desktop, then draws the cursor over the completed frame. This avoids saving cursor pixels as the new background and prevents stale cursor pixels from surviving a full wallpaper redraw.
- Removed the stepped slide-in/slide-out box animations. Windows and panels now appear/disappear without the old four-frame jump effect. This is intentionally static rather than pretending a poor animation is smooth.
- Added `test_desktop_ui_quality_regressions.py`; updated desktop quality contracts to require compact typography, cursor-safe close redraw, and removal of the old box-slide effects.

Validation performed in this environment:

- `tools/validate_source.py` passed.
- `tools/test_desktop_ui_quality_regressions.py` passed.
- `tools/test_desktop_c_ui.py` passed.
- `tools/test_desktop_mouse_cursor.py` passed.
- `tools/test_desktop_file_manager_windows.py` passed.
- `tools/test_desktop_quality.py` passed.
- `tools/test_desktop_wallpaper.py` passed.
- Freestanding C desktop object compiled with Clang and `-mcmodel=kernel`.

The full Rust kernel/ISO build and VirtualBox runtime test were not available in this environment. These source changes still require a local `Build.bat` run and visual verification.
