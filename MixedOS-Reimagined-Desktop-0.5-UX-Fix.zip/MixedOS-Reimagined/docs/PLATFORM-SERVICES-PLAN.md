# MixedOS platform services plan

## Firmware and platform discovery

Add validated ACPI table parsing for RSDP/XSDT, MADT, MCFG, FADT, and HPET. Validate checksums, lengths, alignment, and table references. Keep firmware-provided addresses untrusted until mapped and range-checked.

## Clock model

Provide a monotonic clock for timeouts/scheduling and a separate UTC wall clock. Read RTC with stable repeated samples and preserve CMOS index/NMI state. Add timezone conversion in a service/library, not in low-level timer code. NTP adjusts wall time without moving the monotonic clock backward.

## Power model

Add orderly shutdown/reboot, ACPI power controls, device suspend/resume callbacks, battery/thermal reporting, and CPU idle policy. Each action needs a bounded timeout and fallback. Do not claim sleep/resume until tested on each supported firmware/device profile.

## Service manager

Services declare dependencies, readiness, health checks, restart policy, privileges, and shutdown order. Critical services have recovery policy; repeated crash loops are rate-limited and surfaced in logs.

## Logging and configuration

Use structured log levels, timestamps from monotonic and wall clocks, bounded ring buffers, persistent log rotation, and privacy filters. Configuration changes are validated and atomically committed; malformed configuration falls back to safe defaults.
