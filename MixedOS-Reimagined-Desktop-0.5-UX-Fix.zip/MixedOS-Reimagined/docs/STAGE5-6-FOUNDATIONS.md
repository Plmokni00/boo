# Stage 5/6 — device, resource, and DMA foundations update

This update adds the first kernel-owned PCI device inventory, a bounded
conflict-checked I/O/MMIO reservation registry, contiguous physical frame runs,
and a conservative DMA32 buffer API. It is a foundation batch, not a completed
PCI driver framework or a working USB controller driver.

## Source additions

- `kernel/src/device.rs`: one-time, read-only PCI inventory (up to 64 records),
  PCI class naming, and stable iteration.
- `kernel/src/resources.rs`: generation-tagged software reservation leases,
  half-open overlap checks, I/O-port bounds, and fail-closed lease lifetime.
- `kernel/src/memory/dma.rs`: zeroed contiguous DMA32 buffers below 4 GiB,
  capped at 16 MiB per buffer, with explicit quiesced release.
- `kernel/src/memory/physical.rs`: aligned contiguous frame allocation,
  whole-run validation/free, and validated HHDM access.

## Shell additions

```text
devices
resources
resources test
dma
dmatest
```

`resources test` uses synthetic ranges and performs no hardware access.
`dmatest` only writes to memory allocated by the physical frame allocator; no
controller is given the buffer's physical address.

## Validation boundary

The host regression test checks source contracts and executable models of
contiguous allocation and interval conflict rules. The normal Windows builder
will execute it automatically with the rest of `tools/test_*.py`.

This authoring environment does not have Rust/Cargo or Zig installed, so the
freestanding kernel has not been compiled here. A successful Windows build and
VirtualBox run of `devices`, `resources test`, `dmatest`, `dma`, `resources`, and
`sysinfo` are still required before the new kernel code is marked compiled or
VM-tested.

## Windows/VirtualBox acceptance sequence

Run these commands from the kernel console after a successful build:

```text
devices
resources test
dmatest
dma
resources
sysinfo
```

Expected outcomes:

- `devices` lists the existing PCI functions as discovered/unbound; count should
  match the earlier read-only `pci` scan, subject to the 64-entry registry cap.
- `resources test` reports three software-only checks and leaves zero active
  reservations. It may increment the overlap-rejection counter by one.
- `dmatest` reports two contiguous pages below 4 GiB tested and released. It
  must return physical allocator free/allocated frame counts to their prior
  values; `dma` should show zero active buffers and zero orphaned buffers.
- `resources` should show zero active claims because the self-test cleans up its
  synthetic ranges. No PCI BAR has been claimed or changed.
- `sysinfo` includes device inventory, resource-claim, and DMA32 counters.

None of these commands initializes an xHCI controller or enables PCI bus
mastering. The existing PS/2 keyboard/mouse path remains unchanged.
