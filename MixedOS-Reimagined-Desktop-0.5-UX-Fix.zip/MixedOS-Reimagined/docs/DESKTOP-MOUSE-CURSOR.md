# Desktop mouse cursor

MixedOS Desktop draws a software mouse pointer directly into the bootloader framebuffer.
The pointer is a 16x20 arrow with a near-black (`RGB 5,6,9`) body and medium-gray
(`RGB 154,158,168`) outline. Its hotspot is the upper-left tip.

The cursor keeps a fixed-size backup of the framebuffer pixels it covers. On a
mouse event, it restores those raw pixels, maps the normalized PS/2 coordinates
(0..4095) to screen coordinates, saves the newly covered pixels, and draws the
pointer. It does not repaint the wallpaper, dock, or desktop on ordinary mouse
movement, which avoids trails and full-screen flicker.

The initial PS/2 pointer coordinate is centered (2048,2048), matching the
pointer's first visible position. A full-screen surface repaint invalidates the
old pixel backup and redraws the pointer over the new surface. Desktop app
surfaces use the same cursor state. Terminal currently keeps its console-style
text interface and does not yet have an integrated mouse pointer overlay.

The cursor is a software-rendered framebuffer pointer; USB HID remains a future
input backend. Current support uses the existing PS/2 mouse decoder.
