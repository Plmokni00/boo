# Final compiler warning cleanup

The 2026-11-14 Windows build log showed one remaining Rust warning in
`kernel/src/storage/mixfs.rs`: `read_dir_entry` accepted a `Superblock`
argument that was not used by its implementation.

The unused argument was removed from the function signature and all four call
sites. This is a parameter-cleanup change only; directory entry validation and
sector reads are unchanged.

Validation performed after the edit:

- All 13 `tools/test_*.py` scripts passed.
- `tools/validate_source.py` passed (66 required files checked).
- A Rust rebuild was not available in the editing environment. Run `Build.bat`
on Windows to confirm the compiler now reports zero warnings.
