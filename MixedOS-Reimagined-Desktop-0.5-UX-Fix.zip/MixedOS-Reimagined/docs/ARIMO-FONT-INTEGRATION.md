# Arimo font integration

Date: 2026-11-16

## What is bundled

MixedOS bundles the Arimo Regular and Arimo Bold TrueType font files in
`kernel/assets/fonts/`. Arimo was designed by Steve Matteson and is metrically
compatible with Arial. The bundled files came from the Google Croscore font
package (`fonts-croscore` 20201225-2). Their font metadata identifies Google as
the copyright holder, and the accompanying notice records the SIL Open Font
License 1.1 terms.

The TTF files are included as source assets for the future user-space font
service and desktop text renderer. They are not loaded or parsed dynamically by
the current kernel.

## Current kernel renderer

The MKH framebuffer, boot status screen, and console title use Arimo-derived
raster glyph atlases:

- Regular 16 px glyph set for diagnostics and status text.
- Bold 22 px glyph set for screen headings and emphasized labels.
- Printable ASCII range U+0020 through U+007E, including proportional
  horizontal advances, left/top bearings, and grayscale coverage.
- A single proportional text path shared by shell output, status counters,
  boot text, and MKH, with pixel-measured cursor advance and wrapping.
- Coverage pixels are alpha blended into the existing framebuffer contents.
- The atlas is embedded at compile time and drawn without heap allocation.

The interactive framebuffer console now uses Arimo Regular for shell output,
scrollback, live keyboard input, numeric counters, and status rows. Terminal
cursor movement, backspace redraw, and automatic line wrapping use the same
per-glyph horizontal advance values as the renderer, so proportional text does
not drift or rely on fixed character cells. The console keeps a fixed-size
256-line scrollback buffer and no heap allocation is required for text output.

The original 5x7 bitmap renderer remains as an emergency fallback if the
embedded Arimo atlas is unavailable. COM1 serial output remains a separate
text path and is not rendered through the framebuffer font.

The MKH renderer uses only static glyph data and direct framebuffer access, so
it does not need the kernel heap, filesystem, scheduler, or a runtime font
parser. That is important because MKH can be invoked before those services are
available.

## Regenerating the atlas

`tools/generate_arimo_bitmap.py` regenerates `font_arimo.rs` and the two `.raw`
coverage atlases from the bundled TTF files. This optional maintainer tool needs
Pillow installed. A normal MixedOS build does not run the generator and does not
need Pillow: all generated sources and raster assets are committed in the
project archive.

Run the integrity check with:

```powershell
python tools/test_arimo_font.py
python tools/test_arimo_console.py
```

## Licensing

The Arimo TTF files and their converted bitmap glyph data are distributed under
the SIL Open Font License, Version 1.1. The full license and font copyright
notice are in `kernel/assets/fonts/OFL-1.1.txt`. They are third-party assets and
are not relicensed under the MixedOS kernel's MIT license. Keep that notice with
the bundled fonts and any redistributed build containing them.

## Deliberate limitations

This is a static, fixed-size kernel font atlas, not a complete TrueType/OpenType
font engine. The kernel renderer currently has two weights and an ASCII glyph set. The future
desktop font service should add runtime font discovery, Unicode coverage,
scalable sizes, font fallback, shaping, kerning, and user-selectable families.
