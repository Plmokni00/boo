# MixedOS Desktop 0.5 — C desktop compositor

## What changed

The default desktop and decorated application-window shell now render through a freestanding C compositor in `kernel/native/c/desktop_ui.c`. The compositor owns the top status rail, desktop launchers, dock, window frame, title text, icon drawing, and the three window controls. The existing Rust kernel continues to own device input, application state, font data, the CMD-style Terminal, the MIXFS file operations, and editor content. Rust and C communicate through the small ABI in `desktop_ui.h`.

The wallpaper remains the existing `MixedOS.png` / `mixedos.rle` asset and is drawn before the C desktop layer. The Arimo atlas remains bundled in the kernel; `mixedos_ui_font_glyph` supplies fixed-size glyph data to the compositor without heap allocation.

## Window controls

Every decorated app window has three SVG controls in its title bar:

- `minus`: minimize the app to its dock slot
- `square`: maximize the window
- `copy`: restore its previous size after maximizing
- `x`: close the window

The controls use the same scaled hit regions as the visible SVG artwork. The behavior is connected for Terminal, Files, Settings, and the MIXFS text editor. Terminal, Files, Settings, and the text editor can also be moved by dragging the title bar. The text editor keeps Save in its own content toolbar so that it does not overlap the title-bar controls.

## Layout and input

Desktop spacing and window dimensions scale from a 1080-pixel reference height. Files opens in a centered window capped at 1120×680 reference pixels rather than expanding to nearly the full display. The pointer acceleration in the PS/2 driver is reduced to a 2–5 multiplier to avoid the large cursor jumps from the prior 28–48 multiplier.

The compositor accepts 24-bit and 32-bit RGB framebuffers, and all drawing is clipped to the active framebuffer. The existing Rust cursor retains its save/restore behavior around redraws; the C code updates title-bar hover feedback while the cursor is temporarily removed and then restored.

## Icon sources and notices

The original SVG artwork already present in `Plmokni00/boo` is retained as SVG source files in `kernel/assets/icons/` with the original attribution and license comments. The title-bar `minus`, `square`, `copy`, and `x` SVGs were selected from the Lucide collection through SVGPortal. All source artwork is preserved; `desktop_icons.h` is the generated 40×40 RGBA atlas used at runtime to keep SVG parsing and allocation out of the kernel.

The icon SVG comments retain the upstream attribution and license references. Keep those comments and the source SVG files if regenerating the atlas.

## Build integration

`build.ps1` compiles `desktop_ui.c` as `build/native/desktop_ui.o`, exports it as `MIXEDOS_UI_OBJECT`, and `kernel/build.rs` links that object with the existing C runtime and Zig CRC object. No new package manager, WSL, Docker, or runtime UI dependency is introduced. The Zig cache/toolchain setup is unchanged.

## Verification limits

The C compositor is syntax-checked as freestanding x86-64 C and has been rendered in host-side framebuffer previews at 1920×1080 and 1280×720. The repository's Python source/regression checks cover the build wiring, icon manifest, layout scaling, and app window controls. This is an in-house C framebuffer compositor, not LVGL or another third-party GUI toolkit. A Rust kernel/ISO build and VirtualBox boot still need to be run on the Windows build machine.


## High-half linker relocation fix

The freestanding C runtime and desktop compositor must be compiled with Clang's `-mcmodel=kernel`, matching `.cargo/config.toml` (`code-model=kernel`) and the high-half linker script base at `0xffffffff80000000`. Without this flag, Clang emits `R_X86_64_32` absolute relocations for `.rodata` references; those cannot represent high-half addresses and fail during the final Rust/LLD link. The kernel code model emits sign-extended `R_X86_64_32S` references instead. Both C compile commands in `build.ps1` now pass this flag, and `test_desktop_c_ui.py` enforces it for both objects.

A local linker reproduction compiled the two C objects with `-mcmodel=kernel` and linked them with `kernel/linker.ld` at `0xffffffff80000000` successfully. This isolated link test uses a stub for the Rust-provided font bridge; it is not a substitute for the full Windows Rust kernel/ISO build.
