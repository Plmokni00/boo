# Future MixedOS Windows compatibility layer

The planned Windows compatibility project is still a future subsystem. It is
not included in Stage 7 and is not a port of Wine. The intent is a custom
MixedOS-native compatibility environment that translates Windows application
interfaces to MixedOS services.

## Architectural direction

The VFS added in Stage 7 is the storage foundation. The later compatibility
layer should avoid bypassing it and should provide:

- DOS/Windows path parsing and normalization (`C:\\`, drive-relative paths,
  UNC paths, case-insensitive lookup rules) mapped onto VFS mount points;
- Win32 handle objects backed by VFS files/directories and process objects;
- Windows file sharing modes, attributes, timestamps, and eventually security
  descriptors mapped to a richer MixedOS permission model;
- PE32 and PE32+ image parsing, section mapping, relocations, import resolution,
  and DLL/module loading;
- Win32 API shims for file, process, thread, synchronization, memory, registry-
  like configuration, environment, and time APIs;
- later graphics/windowing, input, audio, network, and device bridges;
- a compatibility test suite using selected real Windows executables and DLLs;
- installation, update, and per-application compatibility profiles for supported programs;
- common application frameworks and their runtime/library dependencies;
- graphics API translation and audio/input integration;
- a later, separate investigation of Windows game compatibility.

## Dependencies that must exist first

Before attempting to run ordinary Windows applications, MixedOS needs a
stable user-mode process API, syscall entry and validation, thread scheduling,
virtual memory reservations/commit semantics, file descriptors/handles, a
loader, dynamic libraries, synchronization primitives, timers, networking, and
a windowing/graphics service. The Stage 6 demonstration processes are not yet
that API.

## File-system compatibility rules

The native MIXFS v1 stores paths and basic mode/uid/gid metadata, but it is not
yet a Windows filesystem. It currently has case-sensitive names, no symbolic
links or hard links, no cross-directory rename/move operation, no per-user permission enforcement,
and a 55-byte maximum name. The Windows layer should implement its own path
semantics above the VFS and should not silently change the native on-disk
format to imitate NTFS. A later MIXFS revision or separate filesystem backend
may add longer names, extended attributes, ACLs, file IDs, and richer metadata.

The design goal is API compatibility, not binary or kernel compatibility with
Windows itself. No Windows executable should be described as supported until
its PE loader, required API surface, and real application tests pass.


## Explicit long-term requirement

Windows application support is a core MixedOS capability goal, not an optional
launcher feature. The implementation must be developed for MixedOS itself and
must not require an installed Linux distribution or full Windows installation.
It must ultimately support compatible PE `.exe` applications and their supporting
DLLs, API behavior, installation/execution lifecycle, and common frameworks.
Graphics and audio compatibility are part of the intended scope; Windows game
compatibility is a later research milestone after ordinary applications work.
This remains future work: no PE loader, Win32 API layer, or Windows application
compatibility is currently implemented.
