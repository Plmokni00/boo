# MixedOS Desktop 0.3 — Usability and Window Pass

This pass improves the early kernel-rendered desktop without claiming that it is a mature multi-process GUI.

## Display mode

The Limine kernel entry requests `1920x1080x32`. Limine selects that mode when available and falls back to another available mode when the firmware/virtual machine does not expose it. The desktop continues to size its panels and windows from the actual framebuffer dimensions.

## Pointer

- PS/2 deltas use stronger piecewise acceleration: 28x for tiny movement, 34x for small movement, 42x for medium movement, and 48x for larger packets.
- The normalized position is clamped before mapping to framebuffer coordinates.
- Repeated packets that do not change the pixel position no longer restore and redraw the cursor.
- The black pointer and gray outline remain unchanged.

## Taskbar and transitions

- The taskbar is taller, with a dedicated Start button, wider centered app dock, and expanded status tray.
- The tray reports MIXFS state and the detected display class/resolution label.
- App/window transitions are paced against PIT ticks rather than CPU-frequency-dependent spin counts.

## Terminal window

- The CMD Terminal remains a clipped window instead of occupying the whole framebuffer.
- Its titlebar can be dragged, keeping the current transcript and partially typed input when the view is relocated.
- The right titlebar control closes the window; Escape/EXIT still returns to the desktop.
- Recovery remains available with F1.

## Files / MIXFS

- Explorer uses the existing mounted VFS/MIXFS driver, not a fake in-memory list.
- Create folder, create empty file, rename, delete file, remove empty directory, navigate folders, and edit/save text files call VFS/MIXFS operations.
- A double-click opens a directory or file. The double-click interval is 450 ms using the 100 Hz PIT counter.
- Visible row count adapts to framebuffer height, allowing more entries on a 1080p desktop while keeping smaller modes in bounds.
- The editor is intentionally bounded to 2 KiB per file in this early kernel UI.
- File operations are persistent only if a supported MIXFS volume is mounted read/write. The desktop never formats a disk automatically.

## Limits still present

This is still a single active kernel-rendered application surface at a time, not a fully composited multi-window desktop. It does not yet provide independent user-space GUI processes, arbitrary window resizing, a GPU driver, USB HID, or a general-purpose large-file editor. The requested 1920x1080 mode may fall back if VirtualBox does not offer it.

## Validation

Run `Build.bat` on Windows and boot the resulting ISO in VirtualBox. Host-side Python source/regression checks cannot replace a real Rust kernel build or pointer/drag/filesystem runtime test.
