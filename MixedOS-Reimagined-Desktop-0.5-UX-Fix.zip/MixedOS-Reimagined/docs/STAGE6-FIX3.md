# Stage 6 Fix 3 — exit/scheduler/return diagnostics

The Fix 2 VirtualBox screenshot showed both built-in ring-3 tasks reaching their
`EXIT` syscall, but the framebuffer stopped immediately after the second EXIT
message. It did not show the existing `last user task exited` marker. This means
the test had progressed past GDT/TSS setup, private page-table creation, ring-3
entry, report syscalls, and voluntary yields. The remaining uncertainty was in
the exit handler's process-state update / READY-peer selection, or the final
ring-0 return and teardown path.

Fix 3 does not assume which one is broken. It adds explicit framebuffer
breadcrumbs for:

- entering `exit_current` and checking the current task state;
- marking a process exited/faulted and scanning for a READY peer;
- selecting a peer, or finding that no READY process remains;
- entering the ring-0 IRET return path;
- entering the assembly return trampoline and cleanup callback;
- restoring and verifying the original kernel CR3;
- restoring the kernel interrupt stack;
- releasing user code/stack frames, private page-table frames, and each
  process kernel stack.

The ring-0 return trampoline now explicitly reloads SS with the kernel data
selector (`0x10`) before using the restored shell stack. It already reloads DS,
ES, FS, and GS. The saved shell stack is still restored from the value captured
by `mixedos_enter_user`; both Rust callbacks retain the existing SysV stack
alignment discipline.

This revision is diagnostic and includes a defensive SS restoration. The
source/model tests and Clang compilation of the freestanding C runtime and
interrupt assembly pass. The Rust kernel build and VirtualBox run remain
required. The next screenshot should make the last completed phase unambiguous.


Fix 4 supersedes this callback-based teardown path. The assembly return stub
now only restores the kernel CR3 and saved shell stack; `run_demo()` performs
CR3 verification, TSS stack restoration, and process cleanup in its normal
Rust call context.
