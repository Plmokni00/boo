# Storage and recovery plan

MIXFS v1 and the ATA PIO backend are useful bring-up components, not yet a production storage stack.

## Required layers

`device driver -> block request queue -> cache/buffer layer -> partition/volume manager -> filesystem -> VFS -> file descriptors -> user applications`.

Each layer must preserve request bounds, completion status, flush/barrier semantics, and ownership. Filesystem code must not bypass the block interface.

## Before production use

- Add GPT parsing with protective MBR handling and strict CRC/bounds validation.
- Add stable disk/partition identifiers and explicit mount policy.
- Add journal or copy-on-write transactions, atomic metadata updates, and recovery replay.
- Add a read-only recovery mount and a separate explicit repair operation.
- Test interrupted writes at every metadata update boundary using disposable virtual disks.
- Test ATA, AHCI, NVMe, and USB storage independently; retain a fallback path.
- Add file permissions/ownership, symlinks, hardlinks, atomic rename, larger files, and directory scaling.
- Add safe eject and removable-media lifecycle.
- Require explicit target and destructive confirmation for format/repair operations.

## Acceptance tests

1. Unknown disk is never modified during boot or discovery.
2. A power-loss simulation leaves either the old or new committed state, never an unparseable hybrid.
3. Read-only mount works after detecting an unclean volume.
4. Repair reports planned changes and requires explicit confirmation.
5. Repeated create/write/rename/delete/reboot cycles preserve filesystem invariants.
6. Device removal or I/O timeout returns a bounded error and does not hang the kernel.
