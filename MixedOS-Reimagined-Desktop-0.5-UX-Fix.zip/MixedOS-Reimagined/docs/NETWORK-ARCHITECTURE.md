# MixedOS networking architecture

Networking is not implemented in the current baseline. Build it as layered services rather than placing every protocol and policy in the kernel.

## Layers

1. NIC bus driver and DMA/interrupt handling.
2. Ethernet device interface and link state.
3. L2/L3 protocols: Ethernet, ARP, IPv4/IPv6, ICMP/NDP.
4. Transport: UDP and TCP with bounded buffers and congestion/retransmission logic.
5. Configuration: DHCP, DNS, route management, interface configuration.
6. Security: firewall, TLS with certificate validation, trust-store updates.
7. User API: sockets, poll/event integration, per-process network permissions.
8. Services: resolver, network manager, diagnostics, optional Wi-Fi/Bluetooth management.

Choose the first NIC driver from actual hardware inventory, including the VM's emulated NIC and the intended physical test machine. Do not claim generic Ethernet or Wi-Fi support based on one adapter.

## Safety and reliability

All packet parsing is bounds-checked. Queues have explicit limits. Device interrupts do minimal work and defer packet processing. Credentials are stored in a protected secrets service and never printed in logs. Network services must tolerate link loss, DHCP renewal, DNS failure, malformed packets, and device removal.

## Milestones

- NET-0: device model, packet buffers, queue and socket design.
- NET-1: one wired NIC driver and link-state diagnostics.
- NET-2: Ethernet, ARP, IPv4, ICMP, UDP, DHCP, DNS.
- NET-3: TCP, IPv6/NDP, routing, socket API.
- NET-4: TLS and certificate validation, firewall and app permissions.
- NET-5: Wi-Fi chipset/firmware support chosen from hardware evidence.
