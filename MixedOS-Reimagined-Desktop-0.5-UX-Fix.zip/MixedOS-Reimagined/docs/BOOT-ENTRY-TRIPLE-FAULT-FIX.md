# Early-entry triple-fault correction

Date: 2026-11-16

## Evidence from the user's VirtualBox log

The last failing VM run stopped with `VINF_EM_TRIPLE_FAULT` on VCPU 0. The guest RIP was `0xffffffff80022692`; VirtualBox decoded the instruction at that RIP as `66 0f 6e c7  movd xmm0, edi`. The reported CR4 value was `0x20`, so `CR4.OSFXSR` (bit 9) and `CR4.OSXMMEXCPT` (bit 10) were both clear. The reported IDTR was `0000000000000000:0000`.

The evidence indicates that compiler-generated SSE2 code ran before the OS had enabled SSE state management. The resulting invalid-opcode exception had no valid IDT to dispatch through, so exception escalation ended in a triple fault. This is a kernel entry-order defect, not a VirtualBox shared-folder or hardening error.

## Source correction

`kernel/linker.ld` still enters at `_start`, but `_start` is now an assembly trampoline in `kernel/src/arch/x86_64/interrupts.S`:

1. Disable maskable interrupts.
2. Build a 256-entry bootstrap IDT using the currently active Limine code selector, plus a second prebuilt table using the MixedOS kernel code selector `0x08`.
3. Load the Limine-selector bootstrap IDT before running Rust.
4. Clear `CR0.EM` and `CR0.TS`, set `CR0.MP`, and set `CR4.OSFXSR | CR4.OSXMMEXCPT`.
5. Execute `FNINIT`, load the default MXCSR value `0x1F80`, and only then set `MIXEDOS_FPU_READY`.
6. Align the stack to the SysV x86-64 call boundary and call `mixedos_rust_entry`.

When `mixedos_gdt_reload` activates the MixedOS GDT and CS becomes `0x08`, it switches IDTR to the separately prebuilt kernel-selector table. This avoids mutating the currently active table in place while its selector is changing. Rust then installs its full diagnostic IDT, including the TSS IST assignments, and verifies the CPU state with `arch::verify_early_fpu_state()` instead of trying to initialize SSE after Rust has already started executing.

The common interrupt entry continues to guard `FXSAVE`/`FXRSTOR` with `MIXEDOS_FPU_READY`. AVX/XSAVE and per-process FPU state are not implemented by this change.

## Validation performed for this patch

- `tools/validate_source.py`: passed, 90 required files checked.
- All 24 `tools/test_*.py` regression scripts: passed.
- `kernel/src/arch/x86_64/interrupts.S`: assembled successfully with Clang targeting `x86_64-unknown-none-elf`.
- A linker smoke test using temporary stub definitions resolved `_start` as the ELF entry and placed both bootstrap IDTs and their IDTR descriptors in the high-half kernel image. This was not a full Rust kernel link.

This environment does not have `rustc` or `cargo`, so the full kernel build, ISO generation, and VirtualBox boot have not been performed here. The user's Windows `Build.bat` and the next VirtualBox boot are required to confirm the correction at runtime.
