# Stage 7 — Storage, VFS, and MIXFS v1

Status: **source implemented; Windows Rust build and VirtualBox disk test pending**.

Stage 7 adds a real persistent block-device path and a native filesystem. It is
not a RAM disk or a simulated file tree. The first supported device is a legacy
IDE ATA hard disk accessed through polling-only PIO. MIXFS v1 stores its
metadata and file contents on that disk.

## Layering

1. `storage::ata` probes the four legacy IDE ATA positions and implements
   IDENTIFY, LBA28 single-sector reads/writes, bounded BSY/DRQ/error polling,
   and cache flush where supported.
2. `storage::block` defines the `BlockDevice` contract. The current concrete
   backend is ATA PIO; future AHCI, NVMe, and USB mass-storage backends should
   implement this layer without changing MIXFS.
3. `storage::mixfs` implements MIXFS v1 on 512-byte blocks.
4. `storage::vfs` exposes path-based mount, directory, file, metadata-check,
   and synchronization operations to kernel code and, later, syscall services.

Storage probing and mount are polling-only and run before PIT interrupts are
enabled. Missing media or an unrecognized disk is left unchanged. There is no
automatic format path.

## MIXFS v1 disk layout

MIXFS occupies a **whole dedicated disk** in this first revision; there is no
partition table or partition selection yet.

| Region | Contents |
|---|---|
| LBA 0 | Primary MIXFS superblock |
| LBA 1 | Reserved |
| LBA 2 onward | Sector allocation bitmap |
| Following | Fixed inode table: 256 inodes, 256 bytes each |
| `data_start` | Data region; first sector is reserved for the root directory |
| Last LBA | Backup MIXFS superblock |

The bitmap uses one bit per 512-byte sector. Inodes carry file/directory kind,
mode, uid/gid metadata, parent inode, size, timestamps, and up to 12 extents.
Directory entries are 64 bytes with a maximum 55-byte name. Root is inode 0.
Data is allocated in sectors; extents merge when newly allocated sectors are
adjacent.

Superblocks use CRC32, a generation counter, and a clean/dirty state. A
mutation writes dirty superblocks before metadata changes and writes clean
copies only after data and metadata writes complete and the device flush path
returns. The backup is written before the primary. A dirty mount is read-only
until `fsck` validates the reachable inode tree, extents, reserved bitmap bits,
and free-space accounting.

**MIXFS v1 is not journaled.** Dirty/clean superblocks detect an interrupted
mutation; they do not provide a redo/undo journal or guarantee automatic
recovery. `fsck` verifies structure and may clear a dirty state only if the
on-disk structure is already internally consistent. It does not reconstruct
lost metadata or reclaim arbitrary orphaned blocks. Do not use this first
revision for important data.

## Supported operations

The VFS exposes:

- `mount` and explicitly confirmed whole-disk `format ataN`;
- `list`, `mkdir`, `read_file`, create-only `write_file`, explicit `overwrite_file`, bounded `append_file`, same-directory `rename_file`, and `remove`;
- `check` for structural/free-space consistency;
- `sync` for the device flush path;
- `self_test` for a persistent create/write/read/compare/delete round-trip.

The kernel shell commands are `disk`, `fs`, `format ataN --erase-dedicated-disk`, `ls`, `mkdir`, `write`,
`overwrite`, `append`, `rename`, `cat`, `rm`, `rmdir`, `fsck`, `fstest`, and `sync`.
`write` creates a new UTF-8 text file and returns `AlreadyExists` rather than
silently replacing existing data. `overwrite` replaces an existing file and
returns `NotFound` if it does not exist. `append` preserves the existing bytes
and adds new text; the current implementation has a 2 KiB total-size limit for
this operation. `rename` changes a file or directory name within its existing
parent directory and refuses a name collision. `cat` displays UTF-8 text up to
2 KiB; it is not a binary file viewer. The interactive command line is 128
bytes, so shell-entered text is short even though the filesystem API can write
larger buffers.

`ls [path]` lists up to 64 direct children, showing entry type, byte size, and
name. `rm /path/file` removes a file only; it refuses directories. `rmdir
/path/dir` removes an empty directory only; it refuses files, non-empty
directories, and the root. Neither command recursively deletes directory trees.
`fsck` checks the reachable inode tree, parent/type links, extents, allocation
bitmap reservations, and free-space accounting. It can clear a dirty/read-only
mount only when those structural checks pass; it is not a journal replay or a
file-content checksum verifier.

`mode`, `uid`, and `gid` are stored as metadata for future process-level access
checks; this version does not yet enforce per-user file permissions. Symbolic
links, hard links, moving entries between directories, open file descriptors,
concurrent file I/O, sparse files, large directories beyond the shell's
64-entry listing buffer, and a userspace file API are not implemented yet.

## Safe VirtualBox setup

The formatter has a deliberate safety rule: **the first detected ATA hard disk
is protected and cannot be formatted**. A format request must name a different
ATA device explicitly (`ata0` through `ata3`) and include the confirmation
token. This protects the existing VM disk seen in the earlier screenshot.
It is still essential to verify the ID and capacity printed by `disk`.

1. Power off a clone of the working Stage 6 VM. Keep the original Stage 6 VM
   unchanged as a recovery point.
2. In the clone's VirtualBox Storage settings, keep the existing VM hard disk
   attached and unchanged. Keep the MixedOS ISO attached as an optical drive.
   Add a **second, new, blank, disposable VDI** on a legacy IDE controller.
   A 256 MiB dynamically allocated disk is enough for the initial test.
3. Do not attach a host physical disk. Do not replace or detach the existing
   VM disk. The new VDI must appear as a separate ATA device.
4. Boot Stage 7 and run `disk`. It lists detected devices as `ata0` through
   `ata3`. The first detected ATA disk is marked **PROTECTED**. Find the
   separate device whose capacity/model matches the new 256 MiB VDI. If there
   is no second device, or the size/model is unclear, stop; do not format.
5. Run `fs`. An unformatted data disk should be reported as not mounted and
   should remain unchanged.
6. Replace `ataN` with the exact ID printed for the new blank VDI, then run:

   ```text
   format ataN --erase-dedicated-disk
   ```

   The formatter rejects the protected first disk even if its ID is entered.
   It also refuses any target larger than 512 MiB during this initial bring-up.
   MIXFS uses the whole selected device; partition selection is not supported.
7. Exercise persistence:

   ```text
   fs
   ls /
   mkdir /docs
   write /docs/welcome.txt Hello from MixedOS
   cat /docs/welcome.txt
   fstest
   fsck
   sync
   ```

8. Reboot the VM without removing the VDI, then run `cat /docs/welcome.txt` and
   `ls /docs`. At boot, MixedOS scans detected ATA devices for an existing MIXFS
   volume using reads only; it should remount the data VDI automatically.

The optical ISO is ATAPI and is ignored by the ATA hard-disk probe. This first
storage backend uses legacy IDE-compatible ATA PIO ports. It may work only on
physical systems whose chipset exposes compatible legacy IDE mode; SATA/AHCI,
NVMe, and USB storage are not implemented. Device detection and PCI enumeration
do not imply that a storage driver exists. Never point the formatter at a system
disk or any disk containing data you want to keep.

## Limitations and next work

- Legacy ATA PIO only: no PCI-based IDE/AHCI driver, AHCI, NVMe, USB mass storage, DMA,
  interrupt-driven storage, GPT/MBR partition parsing, or hotplug.
- MIXFS v1 has no journal, repair engine, checksummed file data, snapshots,
  quotas, ACL enforcement, or power-loss guarantees.
- ATA LBA28 limits the visible disk range to 128 GiB. The driver uses 512-byte
  sectors and does not yet support 4Kn media.
- The kernel shell calls the VFS in ring 0. Stage 6 processes do not yet have
  file descriptor syscalls or user-pointer validation.
- A persistent, stable VFS contract is now established so later user-mode
  services, a package manager, SQLite, and the future Windows-compatibility
  layer can use the same file namespace.

This source release needs a Windows Rust build and runtime storage testing on
a dedicated expendable disk before Stage 7 file operations are considered
validated. VirtualBox is optional; it is not the only test environment.
