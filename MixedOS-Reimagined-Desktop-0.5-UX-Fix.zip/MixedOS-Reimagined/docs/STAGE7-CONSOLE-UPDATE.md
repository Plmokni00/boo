# Stage 7 console usability update

## Mouse-scrollable console

The framebuffer terminal keeps a bounded 256-line scrollback ring in static memory. A visible scrollbar is drawn at the right edge of the console. Hold the left mouse button on the scrollbar thumb or track and drag vertically to move through retained output. The scrollbar updates as new lines arrive. This is actual mouse-driven scrolling; it does not require PageUp/PageDown.

The `scroll up|down|top|bottom` command remains available as a keyboard-only fallback. IntelliMouse-compatible PS/2 devices also scroll three lines per signed wheel step after ID 3 negotiation. The console returns to the live bottom when the user types a normal key. Serial/COM1 output remains available independently.

The PS/2 driver now negotiates the IntelliMouse wheel extension using the 200/100/80 sample-rate sequence and accepts four-byte packets only when the device reports protocol ID 3. The mouse driver normalizes the wheel sign so physical wheel-up always means scroll toward older output and physical wheel-down means return toward newer output; each step moves three retained lines. This normalization fixes devices that report the opposite raw nibble polarity. Devices that do not support the extension remain on standard three-byte packets. USB HID and extra mouse buttons remain future work.

## Shell usability

- `history`: list the last 16 non-empty commands from this boot session.
- `Up` / `Down`: recall commands from that in-memory history.
- `echo text`: print text.
- `cls`: alias for `clear`.
- `?` and `commands`: aliases for `help`.
- `help`: compact everyday console and file commands only.
- `diagnostics`: developer, hardware, and self-test commands, kept separate from everyday help. Destructive disk formatting is explicitly called out.

Paths remain absolute; there is no current-working-directory implementation yet, so `cd`/relative paths are intentionally not advertised. The everyday `help` list is intentionally short; use `diagnostics` for internal memory, PCI, storage, and test commands.

## Validation boundary

`tools/test_console_scrollback.py` checks the mouse-scrollbar source contract, concise one-line help entries, and bounded ring-buffer model. Run the bundled Python tests and `tools/validate_source.py` before building. Native compilation requires the Windows `Build.bat`. Runtime mouse and wheel behavior should be checked on the intended physical hardware; VirtualBox remains an optional regression target.
