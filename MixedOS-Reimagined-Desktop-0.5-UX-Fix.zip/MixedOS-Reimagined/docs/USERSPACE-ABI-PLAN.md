# MixedOS user-space and ABI plan

The existing ring-3 demo proves an early privilege transition and small syscall path. It is not yet a general application platform.

## Native ABI

- ELF64 is the first executable format.
- Define architecture-independent syscall names and versioned structures; x86-64 register calling convention is an implementation detail.
- Use stable error codes and explicit structure sizes/version fields.
- Provide safe copyin/copyout, handle validation, and capability checks.
- Define process/thread IDs, file descriptors, event handles, clocks, memory mapping, IPC, and resource limits.

## Minimum user-space stack

1. ELF loader and process creation.
2. Init process and service manager.
3. C runtime and a documented subset of libc.
4. File descriptors, pipes, process groups, environment, and signals/events.
5. User-space terminal and shell.
6. Logging, device, storage, clock, and network services.
7. Package format, signed repository metadata, dependency solver, install/remove, rollback.

## Language order

- Rust and C native applications first.
- Shell scripting once the real user-space shell exists.
- Lua embedded for service configuration/customization after IPC and sandboxing.
- Python only after filesystem, threads, dynamic loading, and C ABI support are adequate.
- Java/JVM only after threads, memory, files, networking, signals, and runtime primitives are stable.
- Zig is an additional systems-language target, not a prerequisite for booting the OS.
- GLSL/WGSL require an actual graphics driver/API; shader language support is not itself GPU support.
- SQLite requires reliable filesystem, locking, and durability semantics.

Windows compatibility must be a MixedOS-native PE/Win32 implementation and must not rely on an installed Linux environment. Android support is a separate compatibility project requiring Android framework/runtime services; APK parsing alone is not enough.
