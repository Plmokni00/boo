# MixedOS Windows toolchain bootstrap

`Build.bat` delegates to `build.ps1`, which dot-sources `tools/toolchain-manager.ps1`. Version policy is stored in `tools/toolchain-versions.json`. The builder is designed to be idempotent: check first, report exact versions, install only missing or unsupported requirements, then reuse them. The builder captures native stdout/stderr separately from PowerShell's error policy so normal Rustup informational messages do not abort setup. The updated Windows build still needs a run on the target machine to verify the PowerShell flow end-to-end.

## Current required languages

- **Rust stable** — kernel language; `x86_64-unknown-none` target is required. The builder reports the rustup, rustc, and Cargo versions. The target is added only if `rustup target list --installed` does not include it. Stable is installed only when absent and updated only if it is older than the minimum.
- **C / Clang** — freestanding C runtime and ABI support. LLVM/Clang 16+ is accepted.
- **Zig 0.17.1** — first production Zig module, a no-stdlib CRC-32 implementation used by MIXFS. The official Windows x86-64 bundle is cached under `%LOCALAPPDATA%\MixedOS\Toolchains`; SHA-256 is checked before extraction. A matching system Zig may be used instead. The persistent per-user cache records the pinned archive hash and the extracted `zig.exe` hash; both are checked before reuse.
- **Python 3.10+** — Windows-hosted validation and test tooling only. It is not installed in the MixedOS image.

Assembly is built through LLVM's assembler integrated with Rust/Clang; no separate assembler package is currently required. Java, Lua, GPU shader toolchains, SQLite, and an application scripting runtime are deferred until their subsystems exist.

## How to build

1. Extract the project folder.
2. Double-click `Build.bat`.
3. The builder checks each required tool, installs only anything missing or below the supported minimum, and then builds the complete ISO.
4. Future runs reuse valid installed tools and the verified persistent per-user Zig/Limine caches.

There are no command-line switches or separate setup step required for the normal workflow. `build.ps1` is an internal implementation detail; `Build.bat` is the user-facing entry point.

## Install policy

1. One tool is processed at a time. No multi-language bulk install command is used.
2. Version checks are run before an installation attempt.
3. Existing Rust stable/target, Clang, Python, and a matching Zig compiler are reused.
4. Zig is downloaded into the persistent per-user cache only when no matching compiler is available; the archive is SHA-256 verified and then cached.
5. xorriso and Limine remain build utilities, not programming languages. Their existing detection and checksum-cache behavior is preserved.
6. Build logs show which version was found, installed, reused, or rejected.


## Persistent download cache

Downloaded MixedOS toolchains are stored outside the replaceable project folder:
`%LOCALAPPDATA%\MixedOS\Toolchains`. Zig is cached under `zig\zig-<version>`
and its archive and checksum marker are retained there. Limine is cached under
`limine\limine-<version>`. Deleting or replacing `MixedOS-Reimagined` therefore
does not delete these downloads. The builder verifies pinned archive and executable
checksums before reuse. Build outputs and logs remain inside the project folder.
