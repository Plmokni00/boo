> Historical note: this document describes the initial MKH font patch. The later Arimo integration and proportional-console update supersede its statement that shell output remains 5x7/monospaced. See `ARIMO-FONT-INTEGRATION.md`.

# MKH Preview and Console Font Fix

Date: 2026-11-16

## Behavior

- The non-fatal `mkh preview` remains active while ordinary keys are pressed.
- The preview closes on the dedicated, non-extended Escape make code (`0x01`) or serial ESC (`0x1B`).
- The console is redrawn after dismissal without clearing the scrollback history.
- The 5x7 bitmap font now contains lowercase `a` through `z` glyphs, and framebuffer text rendering no longer uppercases every character before glyph lookup.

## Regression protection

`kernel/src/console/framebuffer.rs` is part of the Stage 2 input baseline because it contains the input-status and framebuffer console rendering path. This update intentionally changes only the preview footer wording and character-to-glyph selection in that file. The SHA-256 entry in `tools/stage2-input-baseline.sha256` was regenerated for this reviewed version; the guard remains enabled for subsequent unintended changes.

The MKH source contract test and source validator were updated to require Escape-only dismissal and lowercase glyph support. They also reject the old broad any-key dismissal condition.

## Validation

Run `python tools/validate_source.py`, followed by every `python tools/test_*.py` script. A successful host-side source check does not replace a Windows Rust build or a VirtualBox boot test.


## MKH typography scale correction

- The complete MKH screen now uses one shared text scale at each framebuffer size.
- At widths of 1050 pixels and above, headings, status lines, diagnostic labels/values, detail text, and footer text are all rendered at 2x. Smaller framebuffers keep the 1x layout.
- Diagnostic value columns and vertical spacing were recalculated for the larger text so labels do not overlap values and the details remain inside the panel.
- The 5x7 bitmap font retains typographic lowercase x-height, ascenders, and descenders; the prior issue was primarily that body text was rendered at half the title's scale.
- The Stage 2 input baseline hash was updated for this reviewed framebuffer change; the baseline validator remains enabled.


## Arimo UI font integration (2026-11-16)

The MKH and boot status screens now use the bundled Arimo family rather than
stretching the compact 5x7 bitmap font. The MKH heading uses Arimo Bold at 22 px;
labels, values, descriptions, and footer text use Arimo Regular at 16 px. The
renderer uses variable glyph advances, glyph bearings, and grayscale coverage
blended into the framebuffer. Detail text wraps using the measured glyph
advances rather than a fixed six-pixel character cell.

The Arimo atlas is generated from the bundled Regular/Bold TTF files and
embedded as fixed byte arrays. This keeps the MKH path allocation-free and
available before heap/filesystem/scheduler initialization. The 5x7 font remains
the monospaced renderer for interactive shell output and fixed-column
telemetry. The full TTF files plus their SIL OFL 1.1 notice are included for the
future user-space font service. See `docs/ARIMO-FONT-INTEGRATION.md`.

The Stage 2 framebuffer hash was intentionally refreshed for the reviewed
font-renderer change. The validator still enforces the baseline. Host-side
checks validate font file signatures, license presence, glyph-table bounds,
coverage data, and preservation of the compact fallback. A Windows kernel build
and VirtualBox screenshot are still required to confirm the rendered result.
