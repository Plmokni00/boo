#!/usr/bin/env python3
"""Integrity checks for the bundled Arimo font and kernel glyph atlases."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
FONT_DIR = ROOT / "kernel/assets/fonts"
SOURCE = (ROOT / "kernel/src/console/font_arimo.rs").read_text(encoding="utf-8")
FRAMEBUFFER = (ROOT / "kernel/src/console/framebuffer.rs").read_text(encoding="utf-8")
LICENSE = (FONT_DIR / "OFL-1.1.txt").read_text(encoding="utf-8")

for filename in ("Arimo-Regular.ttf", "Arimo-Bold.ttf"):
    data = (FONT_DIR / filename).read_bytes()
    assert data[:4] == b"\x00\x01\x00\x00", f"{filename} is not a TrueType font"
    assert len(data) > 100_000, f"{filename} appears truncated"
print("Arimo TrueType assets: passed")

assert "SIL OPEN FONT LICENSE Version 1.1" in LICENSE
assert "Copyright 2010 Google Inc." in LICENSE
assert "can be bundled, embedded," in LICENSE
assert "No Modified Version of the Font Software" in LICENSE
print("Arimo OFL-1.1 notice: passed")

for family, raw_name in (("REGULAR", "arimo-regular-16.raw"), ("BOLD", "arimo-bold-22.raw")):
    raw = (FONT_DIR / raw_name).read_bytes()
    table_match = re.search(rf"pub static {family}_GLYPHS: \[Glyph; 95\] = \[([\s\S]*?)\n\];", SOURCE)
    assert table_match, f"missing {family} glyph table"
    entries = re.findall(r"Glyph \{ offset: (\d+), width: (\d+), height: (\d+), left: (-?\d+), top: (-?\d+), advance: (\d+) \}", table_match.group(1))
    assert len(entries) == 95, f"{family} must contain 95 printable ASCII glyphs"
    end = 0
    for offset, width, height, _left, _top, advance in entries:
        offset, width, height, advance = map(int, (offset, width, height, advance))
        assert offset >= end, f"{family} glyph atlas offsets are not monotonic"
        assert offset + width * height <= len(raw), f"{family} glyph points outside its atlas"
        assert advance > 0, f"{family} glyph has no horizontal advance"
        end = offset + width * height
    assert end == len(raw), f"{family} atlas has unreferenced trailing bytes"
    assert any(0 < value < 255 for value in raw), f"{family} atlas lacks antialiased coverage"
print("Arimo ASCII atlas metrics and coverage: passed")

assert "font_arimo::glyph(byte, weight)" in FRAMEBUFFER
assert "pixel_coverage" in FRAMEBUFFER
assert "font5x7::glyph(character)" in FRAMEBUFFER
assert "self.text_ui(x, y, text, color, font_arimo::Weight::Regular)" in FRAMEBUFFER
assert "fn console_glyph_advance" in FRAMEBUFFER
print("allocation-free antialiased renderer, proportional console path, and bitmap fallback: passed")
