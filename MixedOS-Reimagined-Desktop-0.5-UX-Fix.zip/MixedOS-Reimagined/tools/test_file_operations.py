#!/usr/bin/env python3
"""Regression contract for MIXFS text-file command semantics."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
mixfs = (ROOT / "kernel/src/storage/mixfs.rs").read_text(encoding="utf-8")
vfs = (ROOT / "kernel/src/storage/vfs.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
assert "enum WriteMode { CreateOnly, ReplaceOnly }" in mixfs
assert "(Some(_), WriteMode::CreateOnly) => return Err(FsError::AlreadyExists)" in mixfs
assert "write_file_locked(&mut state, path, data, WriteMode::CreateOnly)" in mixfs
assert "(None, WriteMode::ReplaceOnly) => return Err(FsError::NotFound)" in mixfs
assert "pub fn overwrite_file" in mixfs and "pub fn overwrite_file" in vfs
append = mixfs[mixfs.index("pub fn append_file"):mixfs.index("pub fn rename_file")]
assert "const APPEND_LIMIT: usize = 2048" in append
assert "read_file_locked(state.superblock, path, &mut combined)?" in append
assert "if new_len > combined.len() { return Err(FsError::BufferTooSmall); }" in append
rename = mixfs[mixfs.index("pub fn rename_file"):mixfs.index("pub fn mkdir")]
assert "find_child(sb, parent_index, new_name)?" in rename
assert "return Err(FsError::AlreadyExists)" in rename
assert "pub fn rename_file" in vfs
for command in ("overwrite", "append", "rename"):
    assert f'b"{command}"' in shell
print("MIXFS file-operation contract passed:")
print("  write refuses to overwrite an existing file")
print("  overwrite replaces only an existing file")
print("  append preserves prior contents and enforces the 2 KiB limit")
print("  rename stays inside one directory and refuses name collisions")
