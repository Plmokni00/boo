#!/usr/bin/env python3
"""Contracts for Desktop 0.3 responsive mode, motion, and usability upgrades."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
d = (ROOT / "kernel/src/desktop.rs").read_text(encoding="utf-8")
m = (ROOT / "kernel/src/input/mouse.rs").read_text(encoding="utf-8")
limine = (ROOT / "boot/limine.conf").read_text(encoding="utf-8")
checks = {
    "high response pointer acceleration": "magnitude <= 1 { 2 } else if magnitude <= 4 { 3 } else if magnitude <= 12 { 4 } else { 5 }" in m,
    "cursor avoids redundant repaint": "if self.visible && self.x == next_x && self.y == next_y { return; }" in d,
    "large desktop requested": "resolution: 1920x1080x32" in limine,
    "taskbar has expanded geometry": "fn ui_taskbar_height(framebuffer: Framebuffer) -> usize" in d and "mixedos_ui_taskbar_height" in (ROOT / "kernel/native/c/desktop_ui.c").read_text(encoding="utf-8"),
    "taskbar uses centered wider dock": "fn dock_start(width: usize, height: usize) -> usize" in d and "mixedos_ui_dock_start" in (ROOT / "kernel/native/c/desktop_ui.c").read_text(encoding="utf-8"),
    "file rows adapt to window height": "fn visible_file_rows(window_height: usize) -> usize" in d,
    "files opens in a centered non-fullscreen window": "fn file_window_geometry(framebuffer: Framebuffer)" in d and "sw.saturating_sub(ui_scale(framebuffer, 80)).min(ui_scale(framebuffer, 1120))" in d,
    "file manager has a visible rename control": '"RENAME"' in d and '"Rename selected item"' in d,
    "file explorer has double-click open": "let double_click=last_click_row==Some(row)&&now.wrapping_sub(last_click_tick)<=45;" in d,
    "box-slide animations removed": "fn wait_animation_frame()" not in d and "animate_files_close" not in d,
    "compact desktop typography": "Compact desktop typography" in d,
    "MIXFS create folder and file remain enabled": "vfs::mkdir(" in d and "vfs::write_file(" in d,
    "MIXFS read/edit/save remain enabled": "vfs::read_file(" in d and "vfs::overwrite_file(" in d,
}
for label, passed in checks.items():
    if not passed:
        raise SystemExit(f"Desktop quality contract failed: {label}")
print("Desktop quality contracts passed: pointer response, redraw suppression, 1920x1080 mode request, expanded taskbar, adaptive Explorer rows, double-click navigation, compact typography, no box-slide animations, and persistent MIXFS operations.")
