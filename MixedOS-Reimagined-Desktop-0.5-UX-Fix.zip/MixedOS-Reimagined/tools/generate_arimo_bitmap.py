#!/usr/bin/env python3
"""Generate the allocation-free Arimo glyph atlases used by the early framebuffer UI.

Requires Pillow only when regenerating assets. Normal MixedOS builds consume the
committed `.raw` atlases and generated Rust metrics, so the target build has no
Python imaging dependency.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
FONT_DIR = ROOT / "kernel/assets/fonts"
SOURCE = ROOT / "kernel/src/console/font_arimo.rs"
CHARS = "".join(chr(codepoint) for codepoint in range(32, 127))
SPECS = [
    ("Arimo-Regular.ttf", 16, "arimo-regular-16.raw", "REGULAR"),
    ("Arimo-Bold.ttf", 22, "arimo-bold-22.raw", "BOLD"),
]


def rasterize(font_path: Path, size: int):
    font = ImageFont.truetype(str(font_path), size)
    ascent, descent = font.getmetrics()
    blob = bytearray()
    glyphs = []
    for character in CHARS:
        left, top, right, bottom = font.getbbox(character, anchor="ls")
        width = max(0, right - left)
        height = max(0, bottom - top)
        if width and height:
            image = Image.new("L", (width, height), 0)
            ImageDraw.Draw(image).text((-left, -top), character, font=font, fill=255, anchor="ls")
            pixels = image.tobytes()
        else:
            pixels = b""
        offset = len(blob)
        blob.extend(pixels)
        advance = max(1, round(font.getlength(character)))
        if not (-128 <= left <= 127 and -128 <= top <= 127 and width <= 255 and height <= 255 and advance <= 255):
            raise ValueError(f"glyph metrics exceed packed format for {character!r}")
        glyphs.append((offset, width, height, left, top, advance))
    return ascent, descent, glyphs, bytes(blob)


def main():
    rendered = {}
    for filename, size, raw_name, family in SPECS:
        metrics = rasterize(FONT_DIR / filename, size)
        rendered[family] = metrics
        (FONT_DIR / raw_name).write_bytes(metrics[3])

    lines = [
        "//! Generated from the bundled Arimo font files by tools/generate_arimo_bitmap.py.",
        "//! The font data and these converted glyph atlases are distributed under OFL-1.1.",
        "//! Rendering is fixed-memory and does not allocate from the kernel heap.",
        "",
        "#[derive(Clone, Copy)]",
        "pub struct Glyph {",
        "    pub offset: u32,",
        "    pub width: u8,",
        "    pub height: u8,",
        "    pub left: i8,",
        "    pub top: i8,",
        "    pub advance: u8,",
        "}",
        "",
    ]
    for family, raw_name in (("REGULAR", "arimo-regular-16.raw"), ("BOLD", "arimo-bold-22.raw")):
        ascent, descent, glyphs, _ = rendered[family]
        lines += [
            f"pub const {family}_ASCENT: usize = {ascent};",
            f'pub static {family}_BITMAPS: &[u8] = include_bytes!("../../assets/fonts/{raw_name}");',
            f"pub static {family}_GLYPHS: [Glyph; 95] = [",
        ]
        for offset, width, height, left, top, advance in glyphs:
            lines.append(
                f"    Glyph {{ offset: {offset}, width: {width}, height: {height}, "
                f"left: {left}, top: {top}, advance: {advance} }},"
            )
        lines.append("];\n")
    lines += [
        "#[derive(Clone, Copy)]",
        "pub enum Weight { Regular, Bold }",
        "",
        "pub fn ascent(weight: Weight) -> usize {",
        "    match weight { Weight::Regular => REGULAR_ASCENT, Weight::Bold => BOLD_ASCENT }",
        "}",
        "pub fn glyph(character: u8, weight: Weight) -> (Glyph, &'static [u8]) {",
        "    let byte = if (32..=126).contains(&character) { character } else { b'?' };",
        "    let index = (byte - 32) as usize;",
        "    let (value, bitmaps) = match weight {",
        "        Weight::Regular => (REGULAR_GLYPHS[index], REGULAR_BITMAPS),",
        "        Weight::Bold => (BOLD_GLYPHS[index], BOLD_BITMAPS),",
        "    };",
        "    let start = value.offset as usize;",
        "    let length = value.width as usize * value.height as usize;",
        "    (value, &bitmaps[start..start + length])",
        "}",
        "pub fn advance(character: u8, weight: Weight) -> usize { glyph(character, weight).0.advance as usize }",
        "",
    ]
    SOURCE.write_text("\n".join(lines), encoding="utf-8")
    print(f"Generated {SOURCE.relative_to(ROOT)} and two raster atlases")


if __name__ == "__main__":
    main()
