#!/usr/bin/env python3
"""Source-contract and decoding checks for read-only PCI discovery."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
pci = (ROOT / "kernel/src/pci.rs").read_text(encoding="utf-8")
port = (ROOT / "kernel/src/arch/x86_64/port.rs").read_text(encoding="utf-8")
facade = (ROOT / "kernel/src/arch/mod.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")

for token in (
    "for bus in 0u16..=255", "for device in 0u8..32", "header_type & 0x80",
    "MAX_REPORTED_DEVICES: usize = 32", "arch::outl(CONFIG_ADDRESS, address)",
    "arch::inl(CONFIG_DATA)", "truncated: found > reported",
    "pub enum PciBar", "Memory64 { base: u64", "pub struct PciBridgeInfo",
    "revision_id: u8", "subsystem_vendor_id: Option<u16>",
    "interrupt_line: u8", "interrupt_pin: u8", "fn read_bars(",
    "if normalized_header_type == 0",
    "read_config_u32(bus as u8, device, function, 0x2C)",
    "CardBus uses a different header layout",
    "read_config_u32(bus as u8, device, function, 0x3C)",
    "read_config_u32(bus as u8, device, function, 0x18)",
    "BAR sizing requires writing all ones and is intentionally not done here.",
):
    assert token in pci, f"missing PCI device-model behavior: {token}"
assert '"out dx, eax"' in port and '"in eax, dx"' in port
assert "    inl," in facade and "    outl," in facade
assert 'verb.eq_ignore_ascii_case(b"pci")' in shell
assert 'args.eq_ignore_ascii_case(b"resources")' in shell
assert "crate::pci::resource_summary()" in shell
assert 'crate::pci::PciBar::Memory64' in shell
assert 'let details = args.eq_ignore_ascii_case(b\"detail\")' in shell
assert "Use 'pci detail' for BAR, interrupt, subsystem, and bridge information." in shell
assert "BAR values are read-only snapshots; no BAR sizing, mapping, or drivers were activated." in shell
for forbidden in ("arch::outb", "arch::inb", "write_config", "bus_master", "CONFIG_DATA, "):
    assert forbidden not in pci, f"PCI scan unexpectedly modifies configuration: {forbidden}"

# Conventional PCI mechanism #1 address encoding.
def config_address(bus: int, device: int, function: int, offset: int) -> int:
    return (0x80000000 | (bus << 16) | (device << 11) |
            (function << 8) | (offset & 0xFC))
assert config_address(0, 0, 0, 0) == 0x80000000
assert config_address(2, 3, 1, 0x0A) == 0x80021908
assert config_address(255, 31, 7, 0xFC) == 0x80FFFFFC

# Model the standard BAR encodings used by the Rust decoder.
def decode_bar(low: int, high: int | None = None):
    if low in (0, 0xFFFFFFFF):
        return ("unused",)
    if low & 1:
        return ("io", low & 0xFFFFFFFC)
    mem_type = (low >> 1) & 3
    prefetch = bool(low & 8)
    if mem_type == 0:
        return ("mem32", low & 0xFFFFFFF0, prefetch)
    if mem_type == 2 and high is not None:
        return ("mem64", (high << 32) | (low & 0xFFFFFFF0), prefetch)
    return ("reserved", low)

assert decode_bar(0) == ("unused",)
assert decode_bar(0xFFFFFFFF) == ("unused",)
assert decode_bar(0x0000C001) == ("io", 0x0000C000)
assert decode_bar(0xFEBF0008) == ("mem32", 0xFEBF0000, True)
assert decode_bar(0x0000000C, 0x00000012) == ("mem64", 0x0000001200000000, True)
assert decode_bar(0x00000002) == ("reserved", 0x00000002)

# Function-zero multifunction header enables probes 1..7.
assert (0x80 & 0x80) != 0
assert (0x00 & 0x80) == 0
print("PCI discovery contract passed: identity, subsystem IDs, IRQ fields, bridge buses, read-only BAR decoding and address encoding.")
