#!/usr/bin/env python3
"""Contracts for windowed Terminal, responsive taskbar, and real MIXFS Files UI."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
d = (ROOT / "kernel/src/desktop.rs").read_text(encoding="utf-8")
s = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
f = (ROOT / "kernel/src/console/framebuffer.rs").read_text(encoding="utf-8")
for token in ("run_files_app", "vfs::mkdir(", "vfs::write_file(", "vfs::remove_file(", "vfs::remove_dir(", "vfs::rename_file(", "fn join_path(", "fn go_parent(", "fn prompt_name(", "fn edit_file(", "vfs::read_file(", "vfs::overwrite_file(", "InputEvent::Mouse(m)", "m.wheel_delta", "fn taskbar_hit(", "fn draw_window_frame("):
    assert token in d, f"desktop file/window feature missing: {token}"
for token in ("pub fn new_cmd_window(", "Canvas::new_view(framebuffer, x, y, width, height)", "self.origin_x", "self.origin_y", "window_close: Option<(", "pub fn move_cmd_window("):
    assert token in (s + f), f"windowed terminal/canvas feature missing: {token}"
assert "dragging_window = true" in s and "draw_window_frame_state(fb,new_x,new_y" in s, "Terminal titlebar drag/move path missing"
assert "pub(crate) fn invalidate(&mut self)" in d, "Shell must be allowed to invalidate the desktop pointer before redraws"
assert "self.canvas = canvas;" in f and "self.redraw();" in f, "Terminal relocation must preserve and repaint existing scrollback"
assert "run_terminal_desktop_window(framebuffer, memory, client_x, client_y, client_w, client_h, close_rect, cursor)" in d
assert "pub fn taskbar_hit" not in d and "fn dock_start(width: usize, height: usize)" in d
assert "CTRL+S SAVE   ESC CLOSE" in d
assert "needs_redraw = false" in d
assert "let mut needs_redraw=true" in d, "Files view must not repaint continuously while idle"
assert "pub(crate) fn move_to(&mut self" in d and "m.x,m.y" in d
print("Desktop file/window contracts passed: windowed/draggable Terminal, MIXFS create/rename/delete/double-click navigation, taskbar, cursor-safe close redraw, and idle-safe redraw.")
