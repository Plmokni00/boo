#!/usr/bin/env python3
"""Regression checks for the user-facing CMD-style Terminal app."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
fb = (ROOT / "kernel/src/console/framebuffer.rs").read_text(encoding="utf-8")
desktop = (ROOT / "kernel/src/desktop.rs").read_text(encoding="utf-8")
for token in ('b"dir"', 'b"md"', 'b"type"', 'b"del"', 'b"rd"', 'b"ver"', 'b"driverquery"', 'b"systeminfo"', 'b"chkdsk"'):
    assert token in shell, f"CMD alias missing: {token}"
for token in ('"C:\\\\MIXEDOS> "', 'Type EXIT to return to the desktop.', 'run_loop(&mut terminal, memory, true,', 'return true;'):
    assert token in shell, f"Terminal CMD behavior missing: {token}"
assert "pub fn new_cmd" in fb and "pub fn new_cmd_window" in fb and "MIXEDOS TERMINAL" in fb and "cmd_mode" in fb
assert "fn new_view(fb: Framebuffer" in fb and "origin_x" in fb and "origin_y" in fb
assert "pub fn run_terminal_desktop_window(" in shell and "Some((framebuffer, cursor))," in shell and "Some((framebuffer, (x.saturating_sub(1)" in shell
assert "dragging_window = true" in shell and "move_cmd_window" in shell
assert "Closing Terminal and returning to MixedOS Desktop" in shell
assert 'verb.eq_ignore_ascii_case(b"desktop")' not in shell
assert "Terminal::new_cmd_window(framebuffer" in shell
assert "F1" in desktop and "Ctrl+Alt+T" in desktop
print("CMD Terminal contract passed: new terminal styling, C:\\MIXEDOS prompt, CMD aliases, EXIT/Escape return, no Desktop command.")
