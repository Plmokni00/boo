from pathlib import Path

root = Path(__file__).resolve().parents[1]
desktop = (root / "kernel/src/desktop.rs").read_text()
c_ui = (root / "kernel/native/c/desktop_ui.c").read_text()

# Desktop text is deliberately scaled below the bundled 16px console atlas.
assert "Compact desktop typography" in desktop
assert "let out_w = (gw * 3 + 3) / 4" in desktop
assert "(advance*3+3)/4" in c_ui

# Window destruction must restore the cursor background before repainting.
assert "if close{cursor.remove(framebuffer);let _=render_desktop(Some(framebuffer));cursor.draw(framebuffer);return;}" in desktop
assert "cursor.remove(framebuffer);\n    let _ = render_desktop(Some(framebuffer));\n    cursor.draw(framebuffer);" in desktop

# Remove the old slide-based open/close effects; they caused boxy jumps.
assert "wait_animation_frame" not in desktop
assert "animate_files_close" not in desktop
assert "for slide in [24usize, 16, 8, 0]" not in desktop
print("Desktop UX regression passed: compact 12px typography, cursor-safe close redraw, and no box-slide window animations.")
