#!/usr/bin/env python3
"""Regression checks for accelerated desktop pointer and damage restoration."""
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
desktop = (ROOT / "kernel/src/desktop.rs").read_text(encoding="utf-8")
mouse = (ROOT / "kernel/src/input/mouse.rs").read_text(encoding="utf-8")
for token in (
    "const CURSOR_WIDTH: usize = 20", "const CURSOR_HEIGHT: usize = 26",
    "const CURSOR_ROWS: [&str; CURSOR_HEIGHT]", "rgb(154, 158, 168)",
    "rgb(5, 6, 9)", "fn read_raw(&self, x: usize, y: usize) -> u32",
    "fn write_raw(&mut self, x: usize, y: usize, pixel: u32)",
    "fn restore(&mut self, canvas: &mut DesktopCanvas)",
    "fn save_and_draw(&mut self, canvas: &mut DesktopCanvas)",
    "pub(crate) fn move_to(&mut self, framebuffer: Framebuffer, logical_x: i32, logical_y: i32)",
    "let next_x = (logical_x.clamp(0, 4095) as usize).saturating_mul(canvas.width) / 4096",
    "let next_y = (logical_y.clamp(0, 4095) as usize).saturating_mul(canvas.height) / 4096",
    "if self.visible && self.x == next_x && self.y == next_y { return; }",
):
    assert token in desktop, f"desktop cursor implementation missing: {token}"
for token in (
    "let accelerate = |delta: i16| -> i32",
    "let multiplier = if magnitude <= 1 { 2 } else if magnitude <= 4 { 3 } else if magnitude <= 12 { 4 } else { 5 }",
    ".clamp(0, 4095)",
):
    assert token in mouse, f"PS/2 pointer acceleration missing: {token}"
rows_block = desktop.split("const CURSOR_ROWS: [&str; CURSOR_HEIGHT] = [", 1)[1].split("] ;", 1)[0] if "] ;" in desktop else desktop.split("const CURSOR_ROWS: [&str; CURSOR_HEIGHT] = [", 1)[1].split("];", 1)[0]
rows = re.findall(r'^\s*"([.ox]+)"\s*,?$', rows_block, re.MULTILINE)
assert len(rows) == 26, f"cursor has {len(rows)} rows, expected 26"
assert all(len(row) == 20 for row in rows), "cursor bitmap rows must be exactly 20 pixels wide"
assert any("x" in row for row in rows) and any("o" in row for row in rows)
assert "cursor.move_to(info, mouse.x, mouse.y)" in desktop
assert "pub(crate) fn draw(&mut self, framebuffer: Framebuffer)" in desktop
print("Desktop pointer passed: 20x26 black/gray arrow, conservative normalized acceleration, redundant-position redraw suppression, and background restoration.")
