#!/usr/bin/env python3
"""Host-side model checks for Stage 6 user roots and round-robin scheduling.

This is not execution of privileged Rust code or the x86-64 CPU. It verifies
address layout, user/kernel permission separation, process isolation, scheduler
state transitions, and resource-accounting invariants independently.
"""
from dataclasses import dataclass
from pathlib import Path

PRESENT = 1 << 0
WRITABLE = 1 << 1
USER = 1 << 2
NX = 1 << 63
USER_SLOT = 1
USER_BASE = USER_SLOT << 39
USER_CODE = USER_BASE + 0x1000
USER_STACK = USER_BASE + 0x3000


def indices(virtual: int) -> tuple[int, int, int, int]:
    return ((virtual >> 39) & 0x1FF,
            (virtual >> 30) & 0x1FF,
            (virtual >> 21) & 0x1FF,
            (virtual >> 12) & 0x1FF)


@dataclass
class Process:
    pid: int
    state: str
    cr3: int
    code_frame: int
    stack_frame: int
    context: int = 0
    reports: int = 0


def clone_root(kernel_entries: list[int], private_root: int) -> list[int]:
    if len(kernel_entries) != 512:
        raise ValueError("PML4 must have 512 entries")
    if kernel_entries[USER_SLOT] != 0:
        raise ValueError("reserved user PML4 slot is occupied")
    root = kernel_entries.copy()
    # A U/S bit on a PML4 parent is not by itself a user mapping: every level
    # must permit user access. Still, clearing it in the private clone is the
    # simplest safe boundary for all inherited kernel subtrees.
    for index, entry in enumerate(root):
        if index != USER_SLOT and entry & PRESENT:
            root[index] = entry & ~USER
    if any((entry & PRESENT) and (entry & USER) for index, entry in enumerate(root)
           if index != USER_SLOT):
        raise ValueError("failed to sanitize inherited supervisor mappings")
    root[USER_SLOT] = private_root | PRESENT | WRITABLE | USER
    return root


def check_permissions(parent: int, leaf: int) -> bool:
    effective_user = bool(parent & USER and leaf & USER)
    effective_write = bool(parent & WRITABLE and leaf & WRITABLE)
    effective_nx = bool(parent & NX or leaf & NX)
    return effective_user, effective_write, effective_nx


def scheduler_round_robin(processes: list[Process], current: int, reason: str) -> int | None:
    if reason == "exit":
        processes[current].state = "exited"
    else:
        processes[current].state = "ready"
    for offset in range(1, len(processes)):
        candidate = (current + offset) % len(processes)
        if processes[candidate].state == "ready":
            processes[candidate].state = "running"
            return candidate
    if reason != "exit":
        processes[current].state = "running"
        return None
    return None


def main() -> None:
    # The user code/stack must share the dedicated private PML4 slot but occupy
    # separate 4 KiB PTEs in the same PT.
    assert indices(USER_CODE) == (1, 0, 0, 1)
    assert indices(USER_STACK) == (1, 0, 0, 3)
    assert USER_CODE != USER_STACK

    # Inherited kernel mappings are supervisor-only; slot 1 is private per task.
    kernel = [0] * 512
    kernel[511] = 0x1000 | PRESENT | WRITABLE | USER
    kernel[509] = 0x2000 | PRESENT | WRITABLE
    root_a = clone_root(kernel, 0xA000)
    root_b = clone_root(kernel, 0xB000)
    assert root_a[511] == root_b[511] == (kernel[511] & ~USER)
    assert root_a[509] == root_b[509] == kernel[509]
    assert kernel[511] & USER  # original kernel root is not modified
    assert all(not ((entry & PRESENT) and (entry & USER))
               for index, entry in enumerate(root_a) if index != USER_SLOT)
    assert root_a[USER_SLOT] != root_b[USER_SLOT]
    try:
        occupied = kernel.copy()
        occupied[USER_SLOT] = 0x3000 | PRESENT | WRITABLE
        clone_root(occupied, 0xC000)
        raise AssertionError("occupied user slot was accepted")
    except ValueError as error:
        assert "occupied" in str(error)

    # Code is user-readable/executable but not writable; stack is user RW/NX.
    parent = PRESENT | WRITABLE | USER
    code = PRESENT | USER
    stack = PRESENT | WRITABLE | USER | NX
    assert check_permissions(parent, code) == (True, False, False)
    assert check_permissions(parent, stack) == (True, True, True)
    assert check_permissions(PRESENT | WRITABLE, stack)[0] is False

    # Round-robin yield order for two independent tasks.
    tasks = [Process(1, "running", 0x1000, 0x5000, 0x6000),
             Process(2, "ready", 0x2000, 0x7000, 0x8000)]
    schedule = []
    current = 0
    for action in ("yield", "yield", "yield", "yield", "exit", "exit"):
        next_task = scheduler_round_robin(tasks, current, action)
        schedule.append((tasks[current].pid, action))
        if next_task is None:
            break
        current = next_task
    assert schedule == [(1, "yield"), (2, "yield"), (1, "yield"),
                        (2, "yield"), (1, "exit"), (2, "exit")]
    assert [task.state for task in tasks] == ["exited", "exited"]

    # A task yielding when no peer is READY continues itself; it must not be
    # counted as a context switch to the same PCB.
    alone = [Process(3, "running", 0x3000, 0x9000, 0xA000),
             Process(4, "exited", 0x4000, 0xB000, 0xC000)]
    assert scheduler_round_robin(alone, 0, "yield") is None
    assert alone[0].state == "running"

    # Faulting one process retires only that task and permits the next to run.
    tasks = [Process(1, "running", 0x1000, 0x5000, 0x6000),
             Process(2, "ready", 0x2000, 0x7000, 0x8000)]
    assert scheduler_round_robin(tasks, 0, "exit") == 1
    assert tasks[0].state == "exited" and tasks[1].state == "running"

    # Stage 6 refuses unsupported five-level paging and a CR3 that no longer
    # matches the page manager's preserved Limine root.
    paging_features = {"initialized": True, "la57": False, "root": 0x1000}
    assert paging_features["initialized"] and not paging_features["la57"]
    assert paging_features["root"] == 0x1000
    assert paging_features["la57"] is False

    # Process page tables must never be reclaimed until the original kernel
    # root has been reloaded and read back successfully.
    kernel_root_restored = True
    may_reclaim_process_roots = kernel_root_restored and paging_features["root"] == 0x1000
    assert may_reclaim_process_roots
    kernel_root_restored = False
    may_reclaim_process_roots = kernel_root_restored and paging_features["root"] == 0x1000
    assert not may_reclaim_process_roots

    process_source = (Path(__file__).resolve().parents[1] / "kernel/src/process.rs").read_text(encoding="utf-8")
    asm_source = (Path(__file__).resolve().parents[1] / "kernel/src/arch/x86_64/interrupts.S").read_text(encoding="utf-8")

    # The x86 interrupt entry has a 20-qword base frame at CPL0. Hardware
    # appends user RSP/SS only on a CPL3->CPL0 transition, so the kernel's base
    # InterruptFrame must not claim those extra words for ring-0 interrupts.
    base_frame_qwords = 15 + 2 + 3
    user_frame_qwords = base_frame_qwords + 2
    assert base_frame_qwords == 20 and user_frame_qwords == 22

    # The common ISR checks a one-shot direct-return flag after restoring the
    # interrupted FPU state but before restoring the retired process frame or
    # executing IRETQ. The leaf stub restores kernel CR3 and the shell stack.
    fxrestore_at = asm_source.index("fxrstor64 [rsp]")
    handoff_check_at = asm_source.index("cmp qword ptr [rip + mixedos_return_to_kernel], 0")
    handoff_branch_at = asm_source.index("jne .Lmixedos_return_to_kernel")
    normal_frame_restore_at = asm_source.index("mov rsp, rbx", handoff_branch_at)
    restore_cr3_at = asm_source.index("mov cr3, rax")
    restore_rsp_at = asm_source.index("mov rsp, qword ptr [rip + mixedos_kernel_return_rsp]")
    assert fxrestore_at < handoff_check_at < handoff_branch_at < normal_frame_restore_at
    assert restore_cr3_at < restore_rsp_at
    assert "iretq" not in asm_source[asm_source.index(".Lmixedos_return_to_kernel:"):restore_rsp_at]
    assert "call mixedos_user_session_finished" not in asm_source

    # All six per-process frames are unique and reclaimed once per task.
    resources_a = {0xA000, 0xA100, 0xA200, 0xA300, 0xA400, 0xA500}
    resources_b = {0xB000, 0xB100, 0xB200, 0xB300, 0xB400, 0xB500}
    assert len(resources_a) == len(resources_b) == 6
    assert resources_a.isdisjoint(resources_b)
    assert len(resources_a | resources_b) == 12

    assert "exit handler entered; updating current process state" in process_source
    assert "scanning for another READY process" in process_source
    assert "no READY processes remain; requesting direct ISR return" in process_source
    assert "request_kernel_return()" in process_source
    assert "mixedos_return_to_kernel" in process_source
    assert "ptr::write_volatile(ptr::addr_of_mut!(mixedos_return_to_kernel), 1)" in process_source
    assert "mixedos_return_to_kernel = 0" in process_source
    # Final exit restores CR3 and the suspended shell stack in a leaf assembly
    # stub; resource cleanup runs only after control has returned normally to
    # run_demo() on the kernel root.
    assert "mixedos_kernel_return_cr3" in process_source
    assert "if arch::read_cr3() != kernel_root" in process_source
    assert "returned from user mode; verifying restored kernel CR3" in process_source
    assert "cleanup: releasing private page-table frames" in process_source
    assert "mixedos_user_session_finished" not in process_source
    assert "mov ss, ax" in asm_source
    assert "mov cr3, rax" in asm_source
    assert "mixedos_kernel_return_cr3" in asm_source
    assert "call mixedos_user_session_finished" not in asm_source

    print("Stage 6 process/scheduler model passed:")
    print("  reserved per-process PML4 slot and sanitized supervisor-only inherited mappings")
    print("  private user code (RO/X) and stack (RW/NX) permission checks")
    print("  round-robin yield order, idle-peer continuation, and fault/exit retirement")
    print("  unique per-process roots, tables, code pages, and stack pages")
    print("  4-level paging, active-CR3 preconditions, and verified-CR3-before-reclaim rule")
    print("  correct 20-qword ring-0 / 22-qword ring-3 interrupt-frame layouts")
    print("  one-shot ISR handoff bypasses final IRETQ; leaf return restores CR3/stack before Rust cleanup")


if __name__ == "__main__":
    main()
