#!/usr/bin/env python3
"""Static safety/idempotency checks for the Windows toolchain bootstrap."""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
manager = (ROOT / "tools/toolchain-manager.ps1").read_text(encoding="utf-8")
build = (ROOT / "build.ps1").read_text(encoding="utf-8")
bat = (ROOT / "Build.bat").read_text(encoding="utf-8")
versions = json.loads((ROOT / "tools/toolchain-versions.json").read_text(encoding="utf-8"))

assert versions["python"]["minimum_version"] == "3.10.0"
assert versions["zig"]["version"] == "0.17.1"
assert re.fullmatch(r"[0-9a-f]{64}", versions["zig"]["sha256"])

# Rustup's informational stderr must not be promoted into a terminating
# PowerShell error. The actual compiler version is queried separately.
assert "function Invoke-MixedOSCapture" in manager
assert "$ErrorActionPreference = 'Continue'" in manager
assert "Invoke-MixedOSCapture $rustup @('--version')" in manager
assert "^rustup\\s+" in manager
assert "Invoke-MixedOSCapture $rustup @('toolchain', 'list')" in manager
assert "if (-not $hasStable)" in manager
assert "@('target', 'list', '--installed', '--toolchain', $rustChannel)" in manager
assert "'target', 'add', [string]$rustConfig.target, '--toolchain', $rustChannel" in manager
assert "@('run', $rustChannel, 'rustc', '--version')" in manager
assert "'toolchain', 'install', $rustChannel" in manager

# Existing language tools are version checked; Zig and Limine are checksum-cached in the persistent per-user cache.
for token in ("clang version", "Get-MixedOSPythonCandidate", "-0p", "zig version", "Get-FileHash", "Expand-Archive", "Using persistent cached Zig", "markerExeOk", "zig=$installedExeHash", "Get-MixedOSPersistentToolchainRoot", "MixedOS\\Toolchains"):
    assert token in manager, token
assert "Python $($pythonConfig.minimum_version)+ was not found after setup" in manager
assert "build\\deps" not in manager
assert "Join-Path $env:LOCALAPPDATA 'MixedOS\\Toolchains'" in manager
assert "persistent user cache" in manager
# Limine is cached beside Zig, outside the disposable project tree.
assert "Join-Path $env:LOCALAPPDATA 'MixedOS\\Toolchains'" in build
assert "limineCache" in build

# Python checks are mandatory and all test modules are discovered automatically.
assert "if (-not $python -or $python.Version -lt [version]$pythonConfig.minimum_version)" in manager
assert "Get-ChildItem" in build and "-Filter 'test_*.py'" in build
assert "Python validation failed" in build
# The normal user workflow is one double-click. No CLI switch parsing or
# argument forwarding is exposed by the BAT entry point.
assert "param(" not in build[:500]
assert "Ensure-MixedOSToolchains -Root $Root -Build $Build" in build
assert "-Syu" in build  # only used in the missing-xorriso installation path
assert "MIXEDOS_NO_PAUSE" in bat
assert '-File "%~dp0build.ps1"' in bat
assert "%*" not in bat
assert "SetupOnly" not in bat and "KernelOnly" not in bat
assert "You only need to double-click this file." in bat

print("Toolchain manager checks passed: stderr-safe Rustup detection, version-first checks, sequential installs, pinned persistent Zig/Limine cache, mandatory Python tests, and one-click builder entrypoint.")
