#!/usr/bin/env python3
"""Regression: pre-existing Cargo output must not fail source validation."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
validator = (ROOT / "tools/validate_source.py").read_text(encoding="utf-8")
builder = (ROOT / "build.ps1").read_text(encoding="utf-8")

# The root target/ tree is ignored as Cargo output, but remains forbidden in
# nested source/vendor trees because target stays in FORBIDDEN_DIRS.
assert 'relative.parts[0] in {"build", "target"}' in validator
assert 'FORBIDDEN_DIRS = {"target"' in validator

# New builds must write Cargo artifacts under the already-ignored build/ tree.
assert "'--target-dir', $CargoTarget" in builder
assert "$CargoTarget = Join-Path $Build 'cargo-target'" in builder
assert "$kernel = Join-Path $Build 'cargo-target\\x86_64-unknown-none\\release\\mixedos-kernel'" in builder

print("Cargo target regression passed: existing root target is ignored and new builds stay under build/cargo-target.")
