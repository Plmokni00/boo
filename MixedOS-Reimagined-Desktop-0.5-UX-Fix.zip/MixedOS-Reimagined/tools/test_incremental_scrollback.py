#!/usr/bin/env python3
"""Regression tests for incremental scrollback viewport movement."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "kernel/src/console/framebuffer.rs").read_text(encoding="utf-8")

start = source.index("fn set_scroll_offset(&mut self, next_offset: usize)")
end = source.index("fn draw_history_row", start)
impl = source[start:end]
assert "core::ptr::copy(source, destination, byte_count)" in impl
assert "self.draw_history_row" in impl
assert "delta >= visible" in impl
assert "self.draw_scrollbar()" in impl
assert "self.render_history()" in impl  # large jumps retain a safe full-render fallback

# Model the exact logical viewport mapping used by Scrollback's offset model.
def viewport(history, visible, offset):
    end = max(0, len(history) - offset)
    start = max(0, end - visible)
    return history[start:end]

history = [f"line-{i}" for i in range(120)]
visible = 18
old = viewport(history, visible, 0)
for delta in (1, 2, 3):
    newer_offset = delta
    newer = viewport(history, visible, newer_offset)
    # Scrolling toward older history inserts delta rows at the top; the
    # previous viewport's first visible rows shift down unchanged.
    assert newer[delta:] == old[:-delta]
    # Returning to the bottom shifts rows up and reveals the same tail rows.
    assert newer[delta:] == viewport(history, visible, 0)[:-delta]

# While the user is scrolled up, a newly appended line advances the offset
# by one so the same logical lines remain in view without a content repaint.
old_offset = 12
old_view = viewport(history, visible, old_offset)
appended = history + ["line-new"]
new_view = viewport(appended, visible, old_offset + 1)
assert old_view == new_view

# Source contract: the scrolled-output path updates only the scrollbar.
newline_start = source.index("fn newline(&mut self)")
newline_end = source.index("\n    }\n}", newline_start)
newline = source[newline_start:newline_end]
scrolled = newline.split("if self.scroll_offset != 0", 1)[1].split("self.cursor_x", 1)[0]
assert "self.draw_scrollbar()" in scrolled
assert "self.render_history()" not in scrolled
print("Incremental scrollback tests passed: 1-3 line blits and stable viewport during new output.")
