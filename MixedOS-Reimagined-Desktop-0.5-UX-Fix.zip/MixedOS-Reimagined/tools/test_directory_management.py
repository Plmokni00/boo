#!/usr/bin/env python3
"""Source-contract tests for MIXFS listing, safe deletion, and fsck."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
mixfs = (ROOT / "kernel/src/storage/mixfs.rs").read_text(encoding="utf-8")
vfs = (ROOT / "kernel/src/storage/vfs.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")

# Listing must resolve a directory, reject non-directories, and report bounded output.
listing = mixfs[mixfs.index("pub fn list("):mixfs.index("pub fn read_file(")]
assert "resolve(sb, path.as_bytes())?" in listing
assert "directory.kind != KIND_DIR" in listing
assert "FsError::TooManyEntries" in listing
assert "ListEntry { name, name_len, kind, size: child.size }" in listing
assert "pub fn list" in vfs and 'b"ls"' in shell

# Shell-level rm/rmdir must call different type-checked VFS methods.
assert "pub fn remove_file(path: &str)" in mixfs
assert "pub fn remove_dir(path: &str)" in mixfs
assert "mixfs::remove_file(path)" in vfs and "mixfs::remove_dir(path)" in vfs
rm_branch = shell[shell.index('} else if verb.eq_ignore_ascii_case(b"rm")'):shell.index('} else if verb.eq_ignore_ascii_case(b"rmdir")')]
rmdir_branch = shell[shell.index('} else if verb.eq_ignore_ascii_case(b"rmdir")'):shell.index('} else if verb.eq_ignore_ascii_case(b"fsck")')]
assert "vfs::remove_file(path)" in rm_branch
assert "vfs::remove_dir(path)" in rmdir_branch
assert 'b"rmdir"' in shell

# The common mutation path enforces expected type, protects root, and refuses non-empty dirs.
remove_entry = mixfs[mixfs.index("fn remove_entry("):mixfs.index("fn check_inode_tree(")]
assert "if child_index == ROOT_INODE" in remove_entry
assert "if child.kind != expected" in remove_entry
assert "FsError::IsDirectory" in remove_entry and "FsError::NotDirectory" in remove_entry
assert "FsError::DirectoryNotEmpty" in remove_entry
assert "if has_entries" in remove_entry

# fsck must validate reachability, parent/type linkage, extents, bitmap and free-space.
check = mixfs[mixfs.index("pub fn check()"):mixfs.index("pub fn sync()")]
for token in ("check_inode_tree", "child.parent != index", "bitmap_is_set", "count_free_data_sectors", "state.superblock.free_sectors"):
    assert token in mixfs
assert "pub fn check" in vfs and 'b"fsck"' in shell

print("MIXFS directory-management contracts passed:")
print("  ls lists directory entries with a hard 64-entry output bound")
print("  rm removes files only; rmdir removes empty directories only")
print("  non-empty directories and the root cannot be removed")
print("  fsck checks inode reachability, extents, bitmap and free-space accounting")
