#!/usr/bin/env python3
"""Regression check for the Desktop 0.4 Files app count initialization bug."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "kernel/src/desktop.rs").read_text(encoding="utf-8")

assert "let mut count: usize = 0;" in source, (
    "Files app listing count must be initialized before the event loop"
)
assert "if (!k.extended && k.scancode==0x01)" not in source, (
    "unnecessary parentheses warning reintroduced"
)
join_path = source[source.index("fn join_path("):source.index("\nfn notice_from_text")]
assert "let mut n=0" not in join_path, (
    "join_path should not assign a value that is immediately overwritten"
)
assert "n+name.len()>out.len()" in join_path, (
    "join_path must retain an explicit output-buffer bounds check"
)

print("Desktop Files compile regression passed: initialized entry count, clean condition, and bounded path construction.")
