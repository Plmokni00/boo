#!/usr/bin/env python3
"""Regression checks for proportional Arimo rendering in the interactive console."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
FRAMEBUFFER = (ROOT / "kernel/src/console/framebuffer.rs").read_text(encoding="utf-8")
FONT = (ROOT / "kernel/src/console/font_arimo.rs").read_text(encoding="utf-8")

# The default Canvas text path must use Arimo, while preserving the bitmap fallback.
text_start = FRAMEBUFFER.index("fn text(&mut self, x: usize, y: usize, text: &str, color: u32, scale: usize)")
text_end = FRAMEBUFFER.index("fn text_bitmap_fallback", text_start)
text_impl = FRAMEBUFFER[text_start:text_end]
assert "font_arimo::available()" in text_impl
assert "self.text_ui(x, y, text, color, font_arimo::Weight::Regular)" in text_impl
assert "self.text_bitmap_fallback" in text_impl
assert "fn text_bitmap_fallback" in FRAMEBUFFER and "font5x7::glyph(character)" in FRAMEBUFFER

# Cursor advance and line wrapping must use the same proportional glyph metrics.
assert "font_arimo::advance(byte, font_arimo::Weight::Regular)" in FRAMEBUFFER
assert "line_width.saturating_add(advance) > available" in FRAMEBUFFER
assert "self.cursor_x = self.cursor_x.saturating_add(advance)" in FRAMEBUFFER
assert "self.redraw_current_line()" in FRAMEBUFFER
assert "self.cursor_x = self.text_left + console_text_width(&bytes[..len])" in FRAMEBUFFER
assert "const CONSOLE_LINE_HEIGHT: usize = 20" in FRAMEBUFFER
assert "self.canvas.text(self.text_left, CONTENT_TOP + row * self.line_height, text, CONSOLE_FOREGROUND, 1)" in FRAMEBUFFER

# Read the generated Arimo table and verify that glyphs are genuinely proportional.
match = re.search(r"pub static REGULAR_GLYPHS: \[Glyph; 95\] = \[([\s\S]*?)\n\];", FONT)
assert match, "regular Arimo glyph table missing"
entries = re.findall(
    r"Glyph \{ offset: (\d+), width: (\d+), height: (\d+), left: (-?\d+), top: (-?\d+), advance: (\d+) \}",
    match.group(1),
)
assert len(entries) == 95
advances = {chr(index + 32): int(entry[5]) for index, entry in enumerate(entries)}
assert advances["i"] < advances["W"], "Arimo advances must be proportional, not fixed-cell"
assert advances[" "] > 0 and advances["M"] > advances["."]

# A pixel-based wrap model should fit more narrow glyphs than wide glyphs.
def wrapped_rows(value: str, available: int) -> int:
    rows, used = 1, 0
    for char in value:
        width = advances.get(char, advances["?"])
        if used and used + width > available:
            rows += 1
            used = 0
        used += width
    return rows

assert wrapped_rows("iiiiiiii", 32) == 1
assert wrapped_rows("WWWWWWWW", 32) > 1
print("Arimo console contract passed: proportional rendering, cursor advance, backspace redraw, pixel wrapping, and bitmap fallback.")

# Input activity must not force full-screen/history repaints.
SHELL = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
scroll_bottom_start = FRAMEBUFFER.index("pub fn scroll_to_bottom(&mut self)")
scroll_bottom_end = FRAMEBUFFER.index("\n    fn render_history", scroll_bottom_start)
scroll_bottom_impl = FRAMEBUFFER[scroll_bottom_start:scroll_bottom_end]
assert "if self.scroll_offset == 0" in scroll_bottom_impl
assert "return;" in scroll_bottom_impl

# The status strip is only repainted when stable device state changes. Per-packet
# byte counters and mouse coordinates stay available through the `input` command.
status_start = FRAMEBUFFER.index("pub fn set_input_status(&mut self, status: InputStats)")
status_end = FRAMEBUFFER.index("\n    /// Scroll by dragging", status_start)
status_impl = FRAMEBUFFER[status_start:status_end]
assert "self.status_signature == Some(signature)" in status_impl
status_draw_start = FRAMEBUFFER.index("fn draw_status_bar(&mut self, status: Option<InputStats>)")
status_draw_end = FRAMEBUFFER.index("\n    fn status_label", status_draw_start)
status_draw_impl = FRAMEBUFFER[status_draw_start:status_draw_end]
assert "value.keyboard_ready" in status_draw_impl
assert "value.mouse_ready" in status_draw_impl
assert "value.mouse_x" not in status_draw_impl
assert "value.keyboard_bytes" not in status_draw_impl

# The polling loop must not request a status repaint for every keyboard/mouse
# statistics change. Key input while already at bottom must not redraw history.
assert "last_stats" not in SHELL
assert "set_input_status(current_stats)" not in SHELL
assert "view.scroll_to_bottom()" in SHELL
print("Console redraw contract passed: input events update only changed glyphs; stable status and unchanged scroll position do not repaint the screen.")
