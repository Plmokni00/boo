# MixedOS Windows toolchain manager.
# Installs only missing/incompatible tools. Downloaded MixedOS toolchains are
# cached per-user outside the replaceable project directory; Rust, Clang and
# Python are detected on PATH or in their usual install paths.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Find-MixedOSExecutable([string]$Name) {
    $command = Get-Command $Name -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    return $null
}

function Invoke-MixedOSCapture([string]$Executable, [string[]]$Arguments) {
    # Rustup (and several other native tools) writes normal informational
    # messages to stderr. With build.ps1's Stop preference, PowerShell can
    # otherwise turn those messages into terminating errors when 2>&1 is used.
    # Temporarily use Continue while capturing; the native exit code remains
    # authoritative and is checked by the caller.
    $previousErrorAction = $ErrorActionPreference
    $nativePreference = Get-Variable -Name 'PSNativeCommandUseErrorActionPreference' -Scope Global -ErrorAction SilentlyContinue
    try {
        $ErrorActionPreference = 'Continue'
        if ($nativePreference) {
            Set-Variable -Name 'PSNativeCommandUseErrorActionPreference' -Value $false -Scope Global
        }
        $captured = @(& $Executable @Arguments 2>&1)
        $exitCode = $LASTEXITCODE
        $lines = @($captured | ForEach-Object {
            if ($_ -is [System.Management.Automation.ErrorRecord]) { $_.ToString() }
            else { [string]$_ }
        })
        return [pscustomobject]@{
            ExitCode = $exitCode
            Lines = $lines
            Text = ($lines -join "`n")
        }
    }
    finally {
        $ErrorActionPreference = $previousErrorAction
        if ($nativePreference) {
            Set-Variable -Name 'PSNativeCommandUseErrorActionPreference' -Value $nativePreference.Value -Scope Global
        }
    }
}

function Invoke-MixedOSChecked([string]$Executable, [string[]]$Arguments) {
    Write-Host ("    > {0} {1}" -f $Executable, ($Arguments -join ' ')) -ForegroundColor DarkGray
    $result = Invoke-MixedOSCapture $Executable $Arguments
    foreach ($line in $result.Lines) { Write-Host "      $line" }
    if ($result.ExitCode -ne 0) { throw "Command failed with exit code $($result.ExitCode): $Executable" }
}

function Get-MixedOSWinget {
    $winget = Find-MixedOSExecutable 'winget.exe'
    if (-not $winget) { throw 'WinGet is required to install missing Windows tools. Install/enable App Installer, then rerun Build.bat.' }
    return $winget
}

function Install-MixedOSWingetPackage([string]$Id) {
    $winget = Get-MixedOSWinget
    Write-Host "    Installing $Id (one-time setup)..." -ForegroundColor Cyan
    Invoke-MixedOSChecked $winget @('install', '--id', $Id, '--exact', '--source', 'winget', '--silent', '--accept-package-agreements', '--accept-source-agreements')
}

function Upgrade-MixedOSWingetPackage([string]$Id) {
    $winget = Get-MixedOSWinget
    Write-Host "    Updating $Id because the detected version is below the minimum..." -ForegroundColor Cyan
    Invoke-MixedOSChecked $winget @('upgrade', '--id', $Id, '--exact', '--source', 'winget', '--silent', '--accept-package-agreements', '--accept-source-agreements')
}

function Get-MixedOSVersion([string]$Text, [string]$Pattern, [string]$ToolName) {
    $match = [regex]::Match($Text, $Pattern)
    if (-not $match.Success) { throw "Could not parse $ToolName version from: $Text" }
    return [version]$match.Groups[1].Value
}

function Ensure-MixedOSRust([switch]$NoInstall) {
    $rustConfig = $script:MixedOSToolchainConfig.rust
    $rustChannel = [string]$rustConfig.channel
    Write-Host '[1/4] Rust toolchain' -ForegroundColor Cyan
    $cargoBin = Join-Path $env:USERPROFILE '.cargo\bin'
    if (Test-Path $cargoBin) { $env:PATH = $cargoBin + ';' + $env:PATH }
    $rustup = Join-Path $cargoBin 'rustup.exe'
    if (-not (Test-Path $rustup)) { $rustup = Find-MixedOSExecutable 'rustup.exe' }
    if (-not $rustup) {
        if ($NoInstall) { throw 'Rustup is missing (-NoInstall was selected).' }
        Install-MixedOSWingetPackage ([string]$rustConfig.winget_id)
        if (Test-Path $cargoBin) { $env:PATH = $cargoBin + ';' + $env:PATH }
        $rustup = Join-Path $cargoBin 'rustup.exe'
    }
    if (-not (Test-Path $rustup)) { throw 'rustup.exe was not found after installation. Reopen the terminal and retry.' }
    $rustupResult = Invoke-MixedOSCapture $rustup @('--version')
    if ($rustupResult.ExitCode -ne 0) { throw 'rustup --version failed.' }
    # The 'info: This is the version for the rustup toolchain manager...' line
    # is expected rustup stderr, not a failure and not the rustc version.
    $rustupVersion = [string](@($rustupResult.Lines | Where-Object { [string]$_ -match '^rustup\s+' } | Select-Object -First 1)[0])
    if (-not $rustupVersion) { throw "Could not identify rustup's own version. Output: $($rustupResult.Text)" }

    $toolchainResult = Invoke-MixedOSCapture $rustup @('toolchain', 'list')
    if ($toolchainResult.ExitCode -ne 0) { throw "Unable to query Rust toolchains: $($toolchainResult.Text)" }
    $toolchains = $toolchainResult.Lines
    $hasStable = @($toolchains | Where-Object { [string]$_ -match '^stable(?:-|\s|$)' }).Count -gt 0
    if (-not $hasStable) {
        if ($NoInstall) { throw 'Rust stable is missing (-NoInstall was selected).' }
        Write-Host '    Stable toolchain missing; installing it now.' -ForegroundColor Yellow
        Invoke-MixedOSChecked $rustup @('toolchain', 'install', $rustChannel, '--profile', 'minimal')
    } else {
        Write-Host '    Found Rust stable; checking its version and target.' -ForegroundColor Green
    }

    $rustcResult = Invoke-MixedOSCapture $rustup @('run', $rustChannel, 'rustc', '--version')
    if ($rustcResult.ExitCode -ne 0) { throw "Rust stable compiler is not runnable: $($rustcResult.Text)" }
    $rustVersionText = [string](@($rustcResult.Lines | Where-Object { [string]$_ -match '^rustc\s+\d+\.\d+\.\d+' } | Select-Object -First 1)[0])
    if (-not $rustVersionText) { throw "Could not identify rustc version. Output: $($rustcResult.Text)" }
    $rustVersion = Get-MixedOSVersion $rustVersionText '^rustc\s+(\d+\.\d+\.\d+)' 'Rust'
    if ($rustVersion -lt [version]$rustConfig.minimum_version) {
        if ($NoInstall) { throw "Rust $($rustConfig.minimum_version) or newer is required; found $rustVersionText." }
        Write-Host '    Rust stable is too old; updating once to satisfy the minimum.' -ForegroundColor Yellow
        Invoke-MixedOSChecked $rustup @('update', $rustChannel)
        $rustcResult = Invoke-MixedOSCapture $rustup @('run', $rustChannel, 'rustc', '--version')
        if ($rustcResult.ExitCode -ne 0) { throw "Rust compiler version check failed after update: $($rustcResult.Text)" }
        $rustVersionText = [string](@($rustcResult.Lines | Where-Object { [string]$_ -match '^rustc\s+\d+\.\d+\.\d+' } | Select-Object -First 1)[0])
        if (-not $rustVersionText) { throw "Could not identify rustc version after update. Output: $($rustcResult.Text)" }
        $rustVersion = Get-MixedOSVersion $rustVersionText '^rustc\s+(\d+\.\d+\.\d+)' 'Rust'
        if ($rustVersion -lt [version]$rustConfig.minimum_version) { throw "Rust update did not provide the required version; found $rustVersionText." }
    }

    $targetResult = Invoke-MixedOSCapture $rustup @('target', 'list', '--installed', '--toolchain', $rustChannel)
    if ($targetResult.ExitCode -ne 0) { throw "Unable to query installed Rust targets: $($targetResult.Text)" }
    $targets = $targetResult.Lines
    if (-not (@($targets | ForEach-Object { ([string]$_).Trim() }) -contains [string]$rustConfig.target)) {
        if ($NoInstall) { throw "Rust target $($rustConfig.target) is missing (-NoInstall was selected)." }
        Write-Host '    Freestanding x86-64 target missing; adding it once.' -ForegroundColor Yellow
        Invoke-MixedOSChecked $rustup @('target', 'add', [string]$rustConfig.target, '--toolchain', $rustChannel)
    } else {
        Write-Host ("    Target {0} already installed." -f $rustConfig.target) -ForegroundColor Green
    }
    $cargoResult = Invoke-MixedOSCapture $rustup @('run', $rustChannel, 'cargo', '--version')
    if ($cargoResult.ExitCode -ne 0) { throw "Cargo is unavailable in the stable toolchain: $($cargoResult.Text)" }
    $cargoVersionText = [string](@($cargoResult.Lines | Where-Object { [string]$_ -match '^cargo\s+\d+\.\d+\.\d+' } | Select-Object -First 1)[0])
    if (-not $cargoVersionText) { throw "Could not identify Cargo version. Output: $($cargoResult.Text)" }
    Write-Host "    $rustupVersion | $rustVersionText | $cargoVersionText" -ForegroundColor Green
    return [pscustomobject]@{ Rustup = $rustup; RustupVersion = $rustupVersion; Version = $rustVersionText }
}

function Find-MixedOSClang {
    # Check PATH and common installer locations, then choose the newest
    # usable compiler rather than accidentally preferring an older PATH copy.
    $candidates = @()
    $pathClang = Find-MixedOSExecutable 'clang.exe'
    if ($pathClang) { $candidates += $pathClang }
    foreach ($candidate in @(
        (Join-Path $env:ProgramFiles 'LLVM\bin\clang.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\LLVM\bin\clang.exe')
    )) {
        if ((Test-Path $candidate) -and -not ($candidates -contains $candidate)) { $candidates += $candidate }
    }

    $bestPath = $null
    $bestVersion = $null
    foreach ($candidate in $candidates) {
        $output = (& $candidate --version 2>&1) -join "`n"
        if ($LASTEXITCODE -ne 0) { continue }
        $match = [regex]::Match($output, 'clang version\s+(\d+\.\d+\.\d+)')
        if (-not $match.Success) { continue }
        $version = [version]$match.Groups[1].Value
        if (-not $bestVersion -or $version -gt $bestVersion) {
            $bestPath = $candidate
            $bestVersion = $version
        }
    }
    return $bestPath
}

function Ensure-MixedOSClang([switch]$NoInstall) {
    $clangConfig = $script:MixedOSToolchainConfig.clang
    Write-Host '[2/4] C compiler (LLVM/Clang)' -ForegroundColor Cyan
    $clang = Find-MixedOSClang
    if (-not $clang) {
        if ($NoInstall) { throw 'LLVM/Clang is missing (-NoInstall was selected).' }
        Install-MixedOSWingetPackage ([string]$clangConfig.winget_id)
        $clang = Find-MixedOSClang
    }
    if (-not $clang) { throw 'clang.exe was not found after setup. Expected LLVM\bin or PATH.' }
    $output = (& $clang --version 2>&1) -join "`n"
    if ($LASTEXITCODE -ne 0) { throw 'clang.exe failed its version check.' }
    $version = Get-MixedOSVersion $output 'clang version\s+(\d+\.\d+\.\d+)' 'Clang'
    if ($version.Major -lt [int]$clangConfig.minimum_major) {
        if ($NoInstall) { throw "Clang $($clangConfig.minimum_major)+ is required; found $version." }
        Upgrade-MixedOSWingetPackage ([string]$clangConfig.winget_id)
        $clang = Find-MixedOSClang
        $output = (& $clang --version 2>&1) -join "`n"
        if ($LASTEXITCODE -ne 0) { throw 'clang.exe failed after the update attempt.' }
        $version = Get-MixedOSVersion $output 'clang version\s+(\d+\.\d+\.\d+)' 'Clang'
        if ($version.Major -lt [int]$clangConfig.minimum_major) { throw "Clang update did not satisfy the minimum; found $version." }
    }
    Write-Host "    clang $version ($clang)" -ForegroundColor Green
    return $clang
}

function Get-MixedOSPythonCandidate {
    $candidates = @()
    $pathPython = Find-MixedOSExecutable 'python.exe'
    if ($pathPython) { $candidates += [pscustomobject]@{ Path = $pathPython; Prefix = @() } }
    foreach ($candidatePath in @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'),
        (Join-Path $env:ProgramFiles 'Python312\python.exe'),
        (Join-Path $env:ProgramFiles 'Python313\python.exe')
    )) {
        if ((Test-Path $candidatePath) -and -not (@($candidates | Where-Object { $_.Path -eq $candidatePath }).Count)) {
            $candidates += [pscustomobject]@{ Path = $candidatePath; Prefix = @() }
        }
    }
    $launcher = Find-MixedOSExecutable 'py.exe'
    if ($launcher) {
        # Enumerate every Python registered with the Windows launcher. This
        # avoids installing 3.12 just because only a newer side-by-side build
        # (or a build outside PATH) is available.
        $launcherList = (& $launcher -0p 2>&1) -join "`n"
        if ($LASTEXITCODE -eq 0) {
            foreach ($line in ($launcherList -split "`r?`n")) {
                $match = [regex]::Match($line, '([A-Za-z]:\\[^\r\n]*?python(?:\d+)?\.exe)\s*$')
                if ($match.Success) {
                    $candidatePath = $match.Groups[1].Value.Trim('"')
                    if (-not (@($candidates | Where-Object { $_.Path -eq $candidatePath }).Count)) {
                        $candidates += [pscustomobject]@{ Path = $candidatePath; Prefix = @() }
                    }
                }
            }
        }
    }

    $best = $null
    foreach ($candidate in $candidates) {
        $arguments = @($candidate.Prefix) + @('--version')
        $output = (& $candidate.Path @arguments 2>&1) -join ' '
        if ($LASTEXITCODE -ne 0) { continue }
        $match = [regex]::Match($output, 'Python\s+(\d+\.\d+\.\d+)')
        if (-not $match.Success) { continue }
        $version = [version]$match.Groups[1].Value
        $info = [pscustomobject]@{ Path = $candidate.Path; Prefix = @($candidate.Prefix); Version = $version; VersionText = $output }
        if (-not $best -or $version -gt $best.Version) { $best = $info }
    }
    return $best
}

function Ensure-MixedOSPython([switch]$NoInstall) {
    $pythonConfig = $script:MixedOSToolchainConfig.python
    Write-Host '[3/4] Python host tooling and regression tests' -ForegroundColor Cyan
    $python = Get-MixedOSPythonCandidate
    if (-not $python -or $python.Version -lt [version]$pythonConfig.minimum_version) {
        if ($NoInstall) { throw "Python $($pythonConfig.minimum_version) or newer is required for mandatory source validation (-NoInstall was selected)." }
        Install-MixedOSWingetPackage ([string]$pythonConfig.winget_id)
        $pythonInstallDir = 'Python' + ([string]$pythonConfig.setup_version -replace '[^0-9]', '')
        $python312 = Join-Path $env:LOCALAPPDATA ('Programs\Python\' + $pythonInstallDir)
        if (Test-Path $python312) { $env:PATH = $python312 + ';' + (Join-Path $python312 'Scripts') + ';' + $env:PATH }
        $python = Get-MixedOSPythonCandidate
    }
    if (-not $python -or $python.Version -lt [version]$pythonConfig.minimum_version) { throw "Python $($pythonConfig.minimum_version)+ was not found after setup. Reopen the terminal and retry." }
    Write-Host "    $($python.VersionText) ($($python.Path))" -ForegroundColor Green
    return $python
}

function Get-MixedOSZigVersion([string]$Path) {
    $output = (& $Path version 2>&1) -join ' '
    if ($LASTEXITCODE -ne 0) { return $null }
    $match = [regex]::Match($output, '^\s*(\d+\.\d+\.\d+)')
    if (-not $match.Success) { return $null }
    return [pscustomobject]@{ Version = $match.Groups[1].Value; Text = $output }
}

function Get-MixedOSPersistentToolchainRoot {
    # This location deliberately survives deleting/re-extracting MixedOS-Reimagined.
    # LOCALAPPDATA is user-scoped and does not require administrator privileges.
    if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
        return (Join-Path $env:LOCALAPPDATA 'MixedOS\Toolchains')
    }
    return (Join-Path $env:USERPROFILE 'AppData\Local\MixedOS\Toolchains')
}

function Ensure-MixedOSZig([string]$Build, [switch]$NoInstall) {
    Write-Host '[4/4] Zig systems-language compiler' -ForegroundColor Cyan
    $zigConfig = $script:MixedOSToolchainConfig.zig
    $requiredVersion = [string]$zigConfig.version
    $expectedHash = [string]$zigConfig.sha256
    $url = [string]$zigConfig.url
    $external = Find-MixedOSExecutable 'zig.exe'
    if ($external) {
        $externalVersion = Get-MixedOSZigVersion $external
        if ($externalVersion) {
            Write-Host "    Found system Zig $($externalVersion.Version) ($external)" -ForegroundColor Green
            if ($externalVersion.Version -eq $requiredVersion) { return $external }
        }
    }

    # Never put this cache under $Root or $Build: users replace the project ZIP
    # by deleting MixedOS-Reimagined, and that must not remove downloaded tools.
    $toolchainRoot = Get-MixedOSPersistentToolchainRoot
    $deps = Join-Path $toolchainRoot 'zig'
    $installRoot = Join-Path $deps "zig-$requiredVersion"
    $marker = Join-Path $installRoot '.verified-sha256'
    $archive = Join-Path $deps "zig-x86_64-windows-$requiredVersion.zip"
    $zig = $null
    if (Test-Path $installRoot) {
        $cachedExe = Get-ChildItem -Path $installRoot -Filter 'zig.exe' -File -Recurse | Select-Object -First 1
        if ($cachedExe) { $zig = $cachedExe.FullName }
    }
    if ($zig -and (Test-Path $marker)) {
        $markerLines = @(Get-Content $marker)
        $localVersion = Get-MixedOSZigVersion $zig
        $cachedExeHash = (Get-FileHash -Path $zig -Algorithm SHA256).Hash.ToLowerInvariant()
        $markerArchiveOk = $markerLines -contains "archive=$expectedHash"
        $markerExeOk = $markerLines -contains "zig=$cachedExeHash"
        if ($markerArchiveOk -and $markerExeOk -and $localVersion -and $localVersion.Version -eq $requiredVersion) {
            Write-Host "    Using persistent cached Zig $($localVersion.Version); checksum verified, no download needed." -ForegroundColor Green
            return $zig
        }
        Write-Host '    Persistent Zig cache failed its version/checksum marker; reinstalling from the verified archive.' -ForegroundColor Yellow
    }
    if ($NoInstall) { throw "Zig $requiredVersion is not available in the persistent cache and -NoInstall was selected." }

    New-Item -ItemType Directory -Force -Path $deps | Out-Null
    if (-not (Test-Path $archive) -or (Get-FileHash -Path $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) {
        if (Test-Path $archive) { Remove-Item $archive -Force }
        Write-Host "    Downloading official Zig $requiredVersion archive to the persistent user cache (one-time) ..." -ForegroundColor Cyan
        $previousProgress = $ProgressPreference
        $ProgressPreference = 'SilentlyContinue'
        try { Invoke-WebRequest -Uri $url -OutFile $archive -UseBasicParsing }
        finally { $ProgressPreference = $previousProgress }
    }
    $actualHash = (Get-FileHash -Path $archive -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualHash -ne $expectedHash) { throw "Zig archive SHA-256 mismatch. Expected $expectedHash, received $actualHash." }
    if (Test-Path $installRoot) { Remove-Item $installRoot -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $installRoot | Out-Null
    Expand-Archive -LiteralPath $archive -DestinationPath $installRoot -Force
    $installedExe = Get-ChildItem -Path $installRoot -Filter 'zig.exe' -File -Recurse | Select-Object -First 1
    if (-not $installedExe) { throw "Zig archive extracted, but zig.exe was not found under $installRoot." }
    $zig = $installedExe.FullName
    $installedExeHash = (Get-FileHash -Path $zig -Algorithm SHA256).Hash.ToLowerInvariant()
    Set-Content -Path $marker -Value @("archive=$expectedHash", "zig=$installedExeHash")
    $installedVersion = Get-MixedOSZigVersion $zig
    if (-not $installedVersion -or $installedVersion.Version -ne $requiredVersion) { throw "Expected Zig $requiredVersion after installation; found '$($installedVersion.Text)'." }
    Write-Host "    Installed and checksum-verified Zig $($installedVersion.Version) in $toolchainRoot; it survives project-folder replacement." -ForegroundColor Green
    return $zig
}

function Ensure-MixedOSToolchains([string]$Root, [string]$Build, [switch]$NoInstall) {
    $configPath = Join-Path $Root 'tools\toolchain-versions.json'
    if (-not (Test-Path $configPath)) { throw "Toolchain version manifest is missing: $configPath" }
    $script:MixedOSToolchainConfig = Get-Content -Path $configPath -Raw | ConvertFrom-Json
    Write-Host ''
    Write-Host 'MixedOS toolchain check (each tool is checked before installation)' -ForegroundColor White
    $rust = Ensure-MixedOSRust -NoInstall:$NoInstall
    $clang = Ensure-MixedOSClang -NoInstall:$NoInstall
    $python = Ensure-MixedOSPython -NoInstall:$NoInstall
    $zig = Ensure-MixedOSZig -Build $Build -NoInstall:$NoInstall
    Write-Host ''
    Write-Host 'Toolchain summary' -ForegroundColor White
    Write-Host ("  Rust   {0} | {1}" -f $rust.RustupVersion, $rust.Version)
    Write-Host ("  Clang  {0}" -f ((& $clang --version | Select-Object -First 1) -join ' '))
    Write-Host ("  Python {0}" -f $python.VersionText)
    Write-Host ("  Zig    {0}" -f ((& $zig version) -join ' '))
    Write-Host ''
    return [pscustomobject]@{ Rustup = $rust.Rustup; Clang = $clang; Python = $python; Zig = $zig }
}
