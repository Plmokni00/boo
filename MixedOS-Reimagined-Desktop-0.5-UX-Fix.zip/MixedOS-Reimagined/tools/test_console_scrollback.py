#!/usr/bin/env python3
"""Source-contract tests for mouse-scrollable console and concise command help."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
framebuffer = (ROOT / "kernel/src/console/framebuffer.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")

assert "const HISTORY_LINES: usize = 256" in framebuffer
assert "static SCROLLBACK" in framebuffer
assert "fn draw_scrollbar" in framebuffer
assert "pub fn scrollbar_pointer" in framebuffer
assert "pub fn scrollbar_drag_to" in framebuffer
assert "scrollbar_drag_to(mouse.y)" in shell
assert "mouse.wheel_delta > 0" in shell
assert "view.scroll_up" in shell
assert "view.scroll_down" in shell
assert "let mut scrollbar_dragging = false" in shell
assert "PageUp/PageDown" not in shell

help_start = shell.index('if verb.eq_ignore_ascii_case(b"help")')
help_end = shell.index('} else if verb.eq_ignore_ascii_case(b"diagnostics")', help_start)
help_text = shell[help_start:help_end]
diag_end = shell.index('} else if verb.eq_ignore_ascii_case(b"clear")', help_end)
diag_text = shell[help_end:diag_end]
commands = (
    "help", "diagnostics", "clear", "echo", "history", "scroll", "ls", "mkdir",
    "write", "overwrite", "append", "rename", "cat", "rm", "rmdir", "mkh", "reboot",
)
for command in commands:
    assert command in help_text, f"everyday help is missing {command}"
assert "memtest" not in help_text and "proctest" not in help_text and "format" not in help_text
assert "memtest" in diag_text and "proctest" in diag_text and "format" in diag_text
assert 'verb.eq_ignore_ascii_case(b"diagnostics")' in shell

for source_line in (help_text + diag_text).splitlines():
    if 'emit_line(terminal, "' in source_line:
        message = source_line.split('emit_line(terminal, "', 1)[1].split('");', 1)[0]
        assert len(message) <= 88, f"help entry may wrap: {message}"

# Verify bounded ring-buffer retention model.
rows = []
for number in range(300):
    rows.append(number)
    if len(rows) > 256:
        rows.pop(0)
assert len(rows) == 256 and rows[0] == 44 and rows[-1] == 299
print("MixedOS console contract passed: mouse scrollbar, wheel scrolling, bounded history, compact everyday help, and separate diagnostics.")
