#!/usr/bin/env python3
"""Source-level contract tests for MixedOS Kernel Halt (MKH)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
mkh = (ROOT / "kernel/src/mkh.rs").read_text(encoding="utf-8")
gdt = (ROOT / "kernel/src/arch/x86_64/gdt.rs").read_text(encoding="utf-8")
interrupts = (ROOT / "kernel/src/interrupts/mod.rs").read_text(encoding="utf-8")
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
framebuffer = (ROOT / "kernel/src/console/framebuffer.rs").read_text(encoding="utf-8")

# Early exception gates are loaded before memory, storage, and the boot checks.
assert main.index("interrupts::install_exception_handlers()") < main.index("if !boot::limine::base_revision_supported()")
assert "fn panic(info: &PanicInfo<'_>) -> !" in main
assert "mkh::rust_panic(info)" in main
print("early exception gate installation: passed")

# Dedicated TSS IST stacks protect the critical exceptions from a damaged RSP.
for name in ("DOUBLE_FAULT_STACK", "NMI_STACK", "MACHINE_CHECK_STACK"):
    assert name in gdt
assert "ptr::addr_of_mut!((*tss_pointer).ist)" in gdt
assert "vector { 8 => 1, 2 => 2, 18 => 3" in interrupts
print("double-fault IST: passed")

# Fatal reporting is bounded, register-aware, and does not write to disk.
for token in ("pub fn rust_panic", "pub fn cpu_exception", "pub fn fatal_message",
              "struct FixedText", "frame.r15", "frame.r14", "frame.r13", "frame.r12",
              "frame.r11", "frame.r10", "frame.r9", "frame.r8", "frame.rax",
              "frame.rbx", "frame.rcx", "frame.rdx", "frame.rsi", "frame.rdi",
              "frame.rbp", "frame.instruction_pointer", "frame.error_code",
              "No filesystem or disk writes were attempted"):
    assert token in mkh, f"missing MKH behavior: {token}"
assert "crate::mkh::cpu_exception" in interrupts
assert "crate::mkh::fatal_message" in interrupts
print("register dump coverage: passed")

# The framebuffer renderer avoids the mutable shell terminal and can wrap details.
for token in ("pub fn render_mkh_screen", "CRASH CODE:", "fn draw_wrapped_text", "fn text_hex64"):
    assert token in framebuffer
assert "screen::render_mkh_screen" in mkh
assert "HALTING.swap(true" in mkh

# The visual preview is deliberately separate from the fatal/halt path.
preview = mkh[mkh.index("pub fn preview_screen"):mkh.index("fn render(")]
assert "pub fn preview_screen" in preview
assert "key.pressed && !key.extended && key.scancode == 0x01" in preview
assert "Only the dedicated Escape key dismisses it" in preview
assert "InputEvent::Key(key) if key.pressed" not in preview
assert "InputEvent::SerialByte(0x1B)" in preview
assert "view.redraw()" in preview
assert "screen::Terminal::new(framebuffer)" not in preview
assert "claim_fatal_path" not in preview
assert "HALTING.swap" not in preview
assert "halt_forever" not in preview
assert "true,\n    );" in preview
# The console font preserves lowercase ASCII glyphs rather than forcing uppercase.
font = (ROOT / "kernel/src/console/font5x7.rs").read_text(encoding="utf-8")
for glyph in ("b'a'", "b'm'", "b'z'"):
    assert glyph in font, f"missing lowercase font glyph: {glyph}"
assert "font5x7::glyph(character)" in framebuffer
assert "to_ascii_uppercase()" not in framebuffer
assert "view.redraw()" in preview
assert "screen::Terminal::new(framebuffer)" not in preview
redraw = framebuffer[framebuffer.index("pub fn redraw(&mut self)"):framebuffer.index("fn draw_chrome(&mut self)")]
assert "self.render_history()" in redraw
assert "self.history().reset()" not in redraw
arch = (ROOT / "kernel/src/arch/x86_64/mod.rs").read_text(encoding="utf-8")
asm = (ROOT / "kernel/src/arch/x86_64/interrupts.S").read_text(encoding="utf-8")
assert "MIXEDOS_FPU_READY" in arch
assert "read_volatile(core::ptr::addr_of!(MIXEDOS_FPU_READY))" in arch
assert "verify_early_fpu_state" in arch
assert "cmp byte ptr [rip + MIXEDOS_FPU_READY], 0" in asm
assert asm.index("MIXEDOS_FPU_READY") < asm.index("fxsave64")
assert "je .Lmixedos_skip_fxrstor" in asm
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
assert "mkh preview" in shell
assert "mkh preview" in (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
print("non-fatal MKH preview command and return-to-console path: passed")

# Boot sequencing: assembly initializes FPU/SSE before Rust; Rust installs
# the full exception gates before fallible initialization; enable IRQs last.
assert main.index("arch::initialize_gdt_tss()") < main.index("interrupts::install_exception_handlers()")
entry_start = main.index("pub extern \"C\" fn mixedos_rust_entry")
assert main.index("interrupts::install_exception_handlers()", entry_start) < main.index("if !boot::limine::base_revision_supported()", entry_start)
assert main.index("if !boot::limine::base_revision_supported()", entry_start) < main.index("mkh::set_framebuffer(info)", entry_start)
assert main.index("mkh::set_framebuffer(info)", entry_start) < main.index("arch::verify_early_fpu_state()", entry_start)
assert main.index("arch::verify_early_fpu_state()", entry_start) < main.index("mixedos_c_abi_revision()", entry_start)
assert main.index("input::initialize()") < main.index("interrupts::initialize()")
print("MKH/boot initialization order: passed")
# Fatal handling must not allocate or risk writing to a possibly failing disk.
fatal_path = mkh[:mkh.index("pub fn preview_screen")]
for forbidden in ("crate::memory::heap", "crate::storage", "crate::process", "crate::input"):
    assert forbidden not in fatal_path, f"fatal MKH path must not depend on {forbidden}"
assert "AtomicU64" in mkh and "Ordering::Acquire" in mkh
assert "#[repr(align(16))]" in gdt and "EXCEPTION_STACK_BYTES: usize = 16 * 1024" in gdt
print("MKH crash screen, recursion guard, and emergency-path isolation: passed")

# MKH uses proportional, antialiased Arimo text with fixed-memory rendering.
renderer = framebuffer[framebuffer.index("pub fn render_mkh_screen"):framebuffer.index("fn draw_wrapped_text")]
assert "let line_step = 26;" in renderer
assert "let value_x = 220;" in renderer
assert '"MIXEDOS KERNEL HALT", bright, font_arimo::Weight::Bold' in renderer
assert "font_arimo::Weight::Regular" in renderer
assert "canvas.measure_ui_text(footer, font_arimo::Weight::Bold)" in renderer
assert "draw_wrapped_text(&mut canvas" in renderer
assert "fn pixel_coverage" in framebuffer
assert "font_arimo::glyph(byte, weight)" in framebuffer
assert "text_ui" in framebuffer and "fn text(&mut self, x: usize, y: usize, text: &str, color: u32, scale: usize)" in framebuffer
print("MKH Arimo typography, alpha blending, and bitmap emergency fallback: passed")
