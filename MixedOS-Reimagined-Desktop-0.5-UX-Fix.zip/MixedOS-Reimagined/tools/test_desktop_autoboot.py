#!/usr/bin/env python3
"""Verify desktop-first boot, app launching, and separate recovery console."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
desktop = (ROOT / "kernel/src/desktop.rs").read_text(encoding="utf-8")
limine = (ROOT / "boot/limine.conf").read_text(encoding="utf-8").lower()
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")

assert "desktop::run(framebuffer, memory_summary)" in main
assert "pub fn run_terminal_desktop_window(" in shell and "Terminal::new_cmd_window(framebuffer" in shell
assert "crate::shell::run_terminal_desktop_window(framebuffer, memory" in desktop
assert "key.scancode == 0x3B" in desktop, "F1 recovery shortcut missing"
assert "MOD_CONTROL | MOD_ALT" in desktop, "Ctrl+Alt+T Terminal shortcut missing"
assert "taskbar_hit(" in desktop and "dock_start(width: usize, height: usize)" in desktop, "responsive taskbar click handling missing"
assert "run_files_app(info, &mut cursor)" in desktop
assert "run_settings_app(info, &mut cursor)" in desktop
assert "cursor.move_to(info, mouse.x, mouse.y)" in desktop
assert "cursor.draw(info)" in desktop
assert "timeout: 0" in limine
assert "quiet: yes" in limine and "terse: yes" in limine
assert "pub fn run(terminal: &mut Option<Terminal>, memory: Option<MemorySummary>) -> !" in shell
assert 'verb.eq_ignore_ascii_case(b"desktop")' not in shell, "Desktop command must be removed"
assert 'emit_line(terminal, "desktop -' not in shell
assert 'if verb.eq_ignore_ascii_case(b"exit")' in shell
assert 'prompt(terminal, can_exit)' in shell
assert "render_boot_screen(info)" not in main

print("Desktop app contract passed: desktop-first boot, interactive Terminal app, app surfaces, F1 recovery, and no Desktop command.")
