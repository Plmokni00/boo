#!/usr/bin/env python3
"""Host-side format/layout/integrity model for the Stage 7 MIXFS v1 disk format."""
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "kernel/src/storage/mixfs.rs").read_text(encoding="utf-8")

SECTOR = 512
INODES = 256
INODE_SIZE = 256
INODE_SECTORS = INODES * INODE_SIZE // SECTOR
SUPER_HEADER = 80
CRC_OFFSET = 76
MAX_EXTENTS = 12
NAME_MAX = 55

def crc32(data: bytes) -> int:
    crc = 0xFFFFFFFF
    for value in data:
        crc ^= value
        for _ in range(8):
            crc = (crc >> 1) ^ (0xEDB88320 & (-(crc & 1) & 0xFFFFFFFF))
    return (~crc) & 0xFFFFFFFF

def geometry(total_sectors: int) -> dict[str, int]:
    bitmap_sectors = (total_sectors + 4095) // 4096
    inode_start = 2 + bitmap_sectors
    data_start = inode_start + INODE_SECTORS
    if total_sectors < 8192 or data_start + 2 >= total_sectors:
        raise ValueError("volume too small")
    return {
        "bitmap_start": 2,
        "bitmap_sectors": bitmap_sectors,
        "inode_start": inode_start,
        "inode_sectors": INODE_SECTORS,
        "data_start": data_start,
        "backup_super": total_sectors - 1,
        "root_data": data_start,
        "free": total_sectors - data_start - 2,
    }

for sectors in (8192, 16384, 524288, 2_097_152):
    g = geometry(sectors)
    assert g["bitmap_sectors"] == (sectors + 4095) // 4096
    assert g["inode_start"] == 2 + g["bitmap_sectors"]
    assert g["data_start"] == g["inode_start"] + INODE_SECTORS
    assert g["root_data"] >= g["data_start"]
    assert g["free"] == sectors - g["data_start"] - 2

# A valid superblock covers its header with CRC at the end; corruption is rejected.
raw = bytearray(SECTOR)
raw[:8] = b"MIXFS1\0\0"
# Match the on-disk offsets in encode_super() exactly.
struct.pack_into("<I", raw, 8, 1)                  # version
struct.pack_into("<I", raw, 12, SUPER_HEADER)    # header length
struct.pack_into("<Q", raw, 16, 524288)           # total sectors
struct.pack_into("<I", raw, 24, 2)                # bitmap start
struct.pack_into("<I", raw, 28, 128)              # bitmap sectors
struct.pack_into("<I", raw, 32, 130)              # inode start
struct.pack_into("<I", raw, 36, INODE_SECTORS)    # inode sectors
struct.pack_into("<I", raw, 40, 130 + INODE_SECTORS) # data start
struct.pack_into("<I", raw, 44, 0)                # root inode
struct.pack_into("<I", raw, 48, INODES)            # inode count
struct.pack_into("<Q", raw, 52, 7)                # generation
struct.pack_into("<I", raw, 60, 1)                # clean
struct.pack_into("<I", raw, 68, 524288 - (130 + INODE_SECTORS) - 2) # free sectors
struct.pack_into("<I", raw, CRC_OFFSET, 0)
checksum = crc32(raw[:SUPER_HEADER])
struct.pack_into("<I", raw, CRC_OFFSET, checksum)
copy = bytearray(raw)
struct.pack_into("<I", copy, CRC_OFFSET, 0)
assert crc32(copy[:SUPER_HEADER]) == struct.unpack_from("<I", raw, CRC_OFFSET)[0]
copy[24] ^= 0x01
struct.pack_into("<I", copy, CRC_OFFSET, 0)
assert crc32(copy[:SUPER_HEADER]) != checksum

# Bitmap bit numbering and extent-to-file-sector translation.
def bitmap_bit(lba: int) -> tuple[int, int, int]:
    bit = lba % 4096
    return lba // 4096, bit // 8, 1 << (bit % 8)
assert bitmap_bit(0) == (0, 0, 1)
assert bitmap_bit(7) == (0, 0, 128)
assert bitmap_bit(8) == (0, 1, 1)
assert bitmap_bit(4096) == (1, 0, 1)

def merge_extent(extents: list[tuple[int, int]], lba: int) -> None:
    if extents and extents[-1][0] + extents[-1][1] == lba:
        start, count = extents[-1]
        extents[-1] = (start, count + 1)
    else:
        if len(extents) >= MAX_EXTENTS:
            raise ValueError("too fragmented")
        extents.append((lba, 1))

def map_sector(extents: list[tuple[int, int]], index: int) -> int:
    for start, count in extents:
        if index < count:
            return start + index
        index -= count
    raise IndexError(index)

extents: list[tuple[int, int]] = []
for lba in (100, 101, 102, 200, 201, 202, 300):
    merge_extent(extents, lba)
assert extents == [(100, 3), (200, 3), (300, 1)]
assert [map_sector(extents, i) for i in range(7)] == [100, 101, 102, 200, 201, 202, 300]
try:
    too_fragmented: list[tuple[int, int]] = []
    for lba in range(0, MAX_EXTENTS * 2 + 2, 2):
        merge_extent(too_fragmented, lba)
    raise AssertionError("fragment limit should fail closed")
except ValueError:
    pass

# Crash protocol: two copies are written dirty before metadata, then clean only after flush.
assert source.index("block::write(backup, &encoded)?") < source.index("block::write(0, &encoded)?")
assert "sb.clean = false" in source and "sb.clean = true" in source
assert "state_store(MountState { mounted: true, read_only: true, superblock: sb });" in source
assert "All metadata sectors, the root directory's first data sector" in source
assert "if !sb.clean" in source or "read_only = !sb.clean" in source
assert 'confirmation != b"--erase-dedicated-disk"' in source
assert "root.extents[0] = Extent { start: data_start, count: 1 }" in source
assert "fn crc32" in source and "SUPER_CRC_OFFSET" in source
assert "sb.total_sectors.checked_add(4095)?.checked_div(4096)?" in source
assert "sb.total_sectors > u64::from(u32::MAX)" in source
assert "KIND_FILE" in source and "KIND_DIR" in source and "mode: u16" in source
assert "pub fn mkdir" in source and "pub fn write_file" in source and "pub fn read_file" in source and "pub fn remove" in source
assert "enum WriteMode { CreateOnly, ReplaceOnly }" in source
assert "(Some(_), WriteMode::CreateOnly) => return Err(FsError::AlreadyExists)" in source
assert "pub fn overwrite_file" in source and "pub fn append_file" in source and "pub fn rename_file" in source
assert "const APPEND_LIMIT: usize = 2048" in source
assert "fn count_free_data_sectors" in source and "pub fn check" in source

print("Stage 7 MIXFS format model passed:")
print("  dual-superblock layout, CRC32, bitmap and fixed-inode geometry")
print("  root-directory reservation, extents, fragmentation cap and file-sector translation")
print("  dirty/clean generation protocol, fail-closed formatter, and explicit whole-disk confirmation")
print("  directory/file operations, reachable-inode check and safe read-only mount policy")
