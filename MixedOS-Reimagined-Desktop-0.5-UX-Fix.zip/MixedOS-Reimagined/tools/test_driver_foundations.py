#!/usr/bin/env python3
"""Source contracts and host-side models for PCI, resource, and DMA foundations.

These tests do not execute privileged Rust code or prove hardware behavior. They
cover the intended allocation/range rules and verify that kernel source keeps
resource discovery separate from device activation.
"""
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
physical = (ROOT / "kernel/src/memory/physical.rs").read_text(encoding="utf-8")
dma = (ROOT / "kernel/src/memory/dma.rs").read_text(encoding="utf-8")
resources = (ROOT / "kernel/src/resources.rs").read_text(encoding="utf-8")
device = (ROOT / "kernel/src/device.rs").read_text(encoding="utf-8")
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")

# Source contracts: contiguous runs are owned, HHDM-checked, and freed atomically.
for token in (
    "pub struct FrameRun", "pub fn allocate_contiguous(", "pub fn free_contiguous(",
    "fn find_contiguous_run(", "pub(crate) fn run_to_hhdm(",
    "bit_get(&MANAGED, index)", "bit_get(&ALLOCATED, index)",
    "FREE_FRAMES.fetch_sub(frame_count as u64", "FREE_FRAMES.fetch_add(run.count as u64",
):
    assert token in physical, f"physical frame-run contract missing: {token}"
assert "for index in start_index..(start_index + run.count)" in physical
assert "return Err(FreeError::AlreadyFree)" in physical

# DMA32 allocations are bounded, zeroed, and not implicitly returned on Drop.
for token in (
    "pub const DMA32_LIMIT_EXCLUSIVE: u64 = 0x1_0000_0000",
    "pub const MAX_DMA_BUFFER_BYTES: usize = 16 * 1024 * 1024",
    "pub fn allocate_dma32(", "physical::allocate_contiguous(pages, 1, DMA32_LIMIT_EXCLUSIVE)",
    "write_bytes(0, allocation_len)", "pub unsafe fn release_after_quiesce(",
    "pub unsafe fn as_slice_when_quiesced(", "pub unsafe fn as_mut_slice_when_quiesced(",
    "ORPHANED_BUFFERS.fetch_add(1", "pub fn self_test()",
):
    assert token in dma, f"DMA implementation missing: {token}"
assert "free_contiguous(run)" in dma
assert "run: Option<FrameRun>" in dma
assert "self.run.take()" in dma
assert "#[derive(Debug, Eq, PartialEq)]\npub struct FrameRun" in physical
assert "#[derive(Clone, Copy, Debug, Eq, PartialEq)]\npub struct FrameRun" not in physical
assert "Drop for DmaBuffer" in dma

# Resource registry rejects overlap/overflow and only changes software state.
for token in (
    "pub const MAX_RESERVATIONS: usize = 64", "pub fn reserve(",
    "ResourceError::AddressOverflow", "ResourceError::IoPortOutOfRange",
    "ResourceError::Overlap", "ResourceError::InvalidOwner", "owner.device >= 32", "owner.function >= 8", "owner.bar >= 6",
    "start < record.end_exclusive", "record.start < end_exclusive", "pub unsafe fn release_after_quiesce(",
    "pub fn self_test()", "pub fn visit(",
):
    assert token in resources, f"resource registry contract missing: {token}"
for forbidden in ("arch::outb", "arch::outl", "CONFIG_DATA", "enable_bus_master"):
    assert forbidden not in resources, f"resource bookkeeping must not touch hardware: {forbidden}"

# PCI inventory is captured once and explicitly leaves all functions unbound.
for token in (
    "pub fn discover_pci()", "pub const MAX_DEVICES: usize = 64",
    "DeviceState::Discovered", "pub const fn class_name(", "pub const fn subclass_name(",
):
    assert token in device, f"device registry feature missing: {token}"
assert "device::discover_pci()" in main
for command in ("b\"devices\"", "b\"resources\"", "b\"dma\"", "b\"dmatest\""):
    assert command in shell, f"missing shell command route: {command}"
assert "resources::self_test()" in shell and "memory::dma::self_test()" in shell

PAGE = 4096
DMA32_LIMIT = 1 << 32

@dataclass
class Run:
    first: int
    count: int

class FrameModel:
    def __init__(self, managed):
        self.managed = set(managed)
        self.allocated = set()

    def allocate(self, count, alignment_pages, max_exclusive):
        assert count > 0 and alignment_pages > 0 and alignment_pages & (alignment_pages - 1) == 0
        limit = max_exclusive // PAGE
        for first in range(1, limit - count + 1):
            if first % alignment_pages:
                continue
            frames = set(range(first, first + count))
            if frames <= self.managed and not frames & self.allocated:
                self.allocated |= frames
                return Run(first, count)
        return None

    def free(self, run):
        frames = set(range(run.first, run.first + run.count))
        if not frames <= self.allocated or not frames <= self.managed:
            return False
        self.allocated -= frames
        return True

# Contiguous run must not cross the 4 GiB DMA mask and must honor alignment.
model = FrameModel(range(1, 1_100_000))
run = model.allocate(4, 4, DMA32_LIMIT)
assert run is not None and run.first % 4 == 0
assert (run.first + run.count) * PAGE <= DMA32_LIMIT
assert model.free(run)
assert not model.free(run), "double-free must be rejected"

# Fragmentation can prevent a run even where the aggregate free count is large.
fragmented = FrameModel(range(1, 64))
fragmented.allocated.update({2, 4, 6, 8, 10, 12, 14, 16})
assert fragmented.allocate(2, 1, 64 * PAGE) is not None
near_dma32_end = FrameModel(range((DMA32_LIMIT // PAGE) - 3, (DMA32_LIMIT // PAGE) + 4))
assert near_dma32_end.allocate(4, 1, DMA32_LIMIT) is None, "allocation must not cross the DMA32 ceiling"

# Resource range model: half-open intervals overlap, adjacent intervals do not.
def overlaps(a0, a1, b0, b1):
    return a0 < b1 and b0 < a1
assert overlaps(0x1000, 0x2000, 0x1800, 0x2800)
assert not overlaps(0x1000, 0x2000, 0x2000, 0x3000)
assert overlaps(0x1000, 0x2000, 0x1000, 0x2000)
# I/O ranges are bounded to the 16-bit port space; 0xFFF0 + 0x10 is valid.
assert 0xFFF0 + 0x10 == 0x10000
assert 0xFFF0 + 0x11 > 0x10000
assert (0x2000 & (0x1000 - 1)) == 0
assert (0x2800 & (0x1000 - 1)) != 0

print("PCI/device/resource/DMA foundations passed:")
print("  one-time bounded PCI device snapshot and explicit unbound state")
print("  aligned contiguous frame allocation, atomic free, and DMA32 ceiling")
print("  zeroed DMA buffers with quiesced explicit release and safe-leak fallback")
print("  half-open range conflict rules, adjacency, overflow, and I/O-port bounds")
print("  shell diagnostics for devices, resources, DMA, and dmatest")
