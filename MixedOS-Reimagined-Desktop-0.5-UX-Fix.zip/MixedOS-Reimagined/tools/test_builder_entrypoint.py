#!/usr/bin/env python3
"""Ensure the supported Windows build workflow is a simple double-click."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
bat = (ROOT / "Build.bat").read_text(encoding="utf-8")
build = (ROOT / "build.ps1").read_text(encoding="utf-8")

assert 'powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"' in bat
assert "%*" not in bat
assert "SetupOnly" not in bat and "NoInstall" not in bat and "KernelOnly" not in bat
assert "You only need to double-click this file." in bat
assert "Ensure-MixedOSToolchains -Root $Root -Build $Build" in build
assert "All required language toolchains are ready" not in build

print("Builder entrypoint tests passed: double-click performs dependency checks and the full ISO build automatically.")
