#!/usr/bin/env python3
"""Host-side model checks for the Stage 7 legacy ATA PIO block layer."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "kernel/src/storage/ata.rs").read_text(encoding="utf-8")
ports = (ROOT / "kernel/src/arch/x86_64/port.rs").read_text(encoding="utf-8")
block = (ROOT / "kernel/src/storage/block.rs").read_text(encoding="utf-8")
filesystem = (ROOT / "kernel/src/storage/mixfs.rs").read_text(encoding="utf-8")

SECTOR_SIZE = 512
MAX_LBA28 = 0x10000000

def lba_registers(lba: int) -> tuple[int, int, int, int]:
    if not 0 <= lba < MAX_LBA28:
        raise ValueError("outside LBA28")
    return (lba & 0xFF, (lba >> 8) & 0xFF, (lba >> 16) & 0xFF, (lba >> 24) & 0x0F)

assert lba_registers(0) == (0, 0, 0, 0)
assert lba_registers(0x1234567) == (0x67, 0x45, 0x23, 0x1)
assert lba_registers(MAX_LBA28 - 1) == (0xFF, 0xFF, 0xFF, 0xF)
try:
    lba_registers(MAX_LBA28)
    raise AssertionError("LBA28 upper bound must be exclusive")
except ValueError:
    pass

required = (
    "MAX_LBA28_SECTORS", "0xEC", "0x20", "0x30", "0xE7",
    "wait_data_request", "STATUS_BSY", "STATUS_ERR", "STATUS_DF",
    "words[49]", "words[60]", "words[61]", "flush_supported",
    "pub fn read_sector", "pub fn write_sector", "NoDevice", "OutOfRange",
)
for token in required:
    assert token in source, f"ATA source missing {token}"
assert "pub unsafe fn inw" in ports and "pub unsafe fn outw" in ports
assert "pub const SECTOR_SIZE: usize = 512" in source
assert "pub trait BlockDevice" in block and "AtaPioBlockDevice" in block
assert "ata::read_sector" not in filesystem and "ata::write_sector" not in filesystem
assert "(words[83] & 0xC000) == 0x4000" in source  # Word 83 validity bits must be 01b.
assert "(words[83] & (1 << 12)) != 0" in source  # FLUSH CACHE is word 83 bit 12.
assert "pub fn initialize()" not in filesystem or "format(" not in filesystem[filesystem.find("pub fn initialize()"):]  # Mount never formats.

print("Stage 7 ATA PIO model passed:")
print("  512-byte sectors, LBA28 register encoding, and upper-bound rejection")
print("  IDENTIFY capability/capacity checks and bounded BSY/DRQ/error polling")
print("  read/write/flush command paths and 16-bit port I/O helpers")
print("  polling-only operation; storage is behind a reusable block-device trait")
print("  filesystem I/O cannot bypass the block layer or auto-format a disk")
