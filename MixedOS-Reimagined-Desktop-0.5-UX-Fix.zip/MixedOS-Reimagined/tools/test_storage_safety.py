#!/usr/bin/env python3
"""Regression checks for explicit MIXFS target selection and boot-disk protection."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ata = (ROOT / "kernel/src/storage/ata.rs").read_text(encoding="utf-8")
block = (ROOT / "kernel/src/storage/block.rs").read_text(encoding="utf-8")
filesystem = (ROOT / "kernel/src/storage/mixfs.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
storage = (ROOT / "kernel/src/storage/mod.rs").read_text(encoding="utf-8")
docs = (ROOT / "docs/STAGE7.md").read_text(encoding="utf-8")

# ATA enumeration must retain each physical position rather than overwriting one slot.
assert "UnsafeCell<[Option<AtaDevice>; DEVICE_SLOTS]>" in ata
assert "pub const DEVICE_SLOTS: usize = 4" in ata
assert "for (index, (io, control, slave)) in positions.into_iter().enumerate()" in ata
assert "PROTECTED_INDEX.store(chosen, Ordering::Release)" in ata
assert "pub fn disk_info(index: usize)" in ata
assert "pub fn is_safe_format_target(index: usize)" in ata
assert "index < DEVICE_SLOTS && Some(index) != protected_index() && disk_info(index).is_some()" in ata

# The destructive formatter must validate the exact requested target before any write.
protect = filesystem.index("if !block::is_safe_format_target(target_index)")
first_write = filesystem.index("block::write(0, &zero)")
assert protect >= 0 and protect < first_write
assert "let candidate = block::disk_info(target_index).ok_or(FsError::NoDisk)?;" in filesystem
assert "block::select_device(target_index)?" in filesystem
assert "if state_copy().mounted { return Err(FsError::AlreadyMounted); }" in filesystem
assert "pub fn format(target_index: usize, confirmation: &[u8])" in filesystem
assert "const MAX_FORMAT_SECTORS: u64 = 1_048_576" in filesystem
assert "if candidate.sectors > MAX_FORMAT_SECTORS { return Err(FsError::TargetTooLarge); }" in filesystem
assert "candidate.sectors > MAX_FORMAT_SECTORS" in filesystem
max_format_bytes = 1_048_576 * 512
screenshot_disk_bytes = 14_383 * 1024 * 1024
assert max_format_bytes == 512 * 1024 * 1024
assert screenshot_disk_bytes > max_format_bytes
assert "pub fn is_safe_format_target(index: usize) -> bool" in block

# Shell cannot invoke the formatter without a concrete ataN and the exact confirmation.
assert 'b"ata0" => Some(0)' in shell and 'b"ata3" => Some(3)' in shell
assert "let (target, confirmation) = split_first_argument(args);" in shell
assert 'confirmation != b"--erase-dedicated-disk"' in shell
assert "format ataN --erase-dedicated-disk" in shell
assert "The first detected ATA disk is protected" in shell

# At boot, mount scanning only tries reads; it does not format unidentified media.
assert "for index in 0..ata::DEVICE_SLOTS" in storage
assert "if Some(index) == protected || ata::disk_info(index).is_none()" in storage
assert "format(" not in storage
assert "The first detected ATA disk" in docs
assert "format ataN --erase-dedicated-disk" in docs

print("Stage 7 storage safety regression passed:")
print("  four ATA positions enumerated independently")
print("  first detected ATA disk protected from formatting")
print("  512 MiB Stage 7 format ceiling rejects the 14.3 GiB screenshot disk")
print("  formatter requires an explicit ataN target and destructive confirmation")
print("  active filesystem mount cannot be replaced by a format request")
print("  boot-time MIXFS discovery performs no writes to unrecognized disks")
