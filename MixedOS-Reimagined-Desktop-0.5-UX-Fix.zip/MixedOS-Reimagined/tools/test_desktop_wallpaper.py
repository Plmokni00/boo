#!/usr/bin/env python3
"""Validate wallpaper asset and interactive desktop composition."""
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]
PNG = ROOT / "kernel/assets/wallpaper/MixedOS.png"
RLE = ROOT / "kernel/assets/wallpaper/mixedos.rle"
DESKTOP = (ROOT / "kernel/src/desktop.rs").read_text(encoding="utf-8")
assert PNG.is_file() and RLE.is_file()
png = PNG.read_bytes()
assert png[:8] == b"\x89PNG\r\n\x1a\n" and png[12:16] == b"IHDR"
png_w, png_h = struct.unpack(">II", png[16:24])
blob = RLE.read_bytes()
assert blob[:8] == b"MIXWALL1"
width, height, palette_count, run_count = struct.unpack_from("<IIHI", blob, 8)
assert (width, height) == (png_w, png_h) == (1920, 1080)
assert 1 <= palette_count <= 256 and run_count > 0
runs_start = 22 + palette_count * 3
assert len(blob) == runs_start + run_count * 3
actual = 0
for index in range(run_count):
    length, color_index = struct.unpack_from("<HB", blob, runs_start + index * 3)
    assert length > 0 and color_index < palette_count
    actual += length
assert actual == width * height
for token in ("draw_wallpaper", "draw_ui_desktop", "taskbar_hit", "run_files_app", "run_settings_app", "run_terminal_desktop_window"):
    assert token in DESKTOP, f"desktop feature missing: {token}"
print(f"Desktop wallpaper passed: {width}x{height}, {palette_count} colors, {run_count} RLE runs.")
print("Desktop composition passed: wallpaper, polished dock, Terminal launcher, Files and Settings surfaces.")
