#!/usr/bin/env python3
"""Host-side model for Stage 4 four-level page-table invariants.

This is deliberately not a test of the privileged Rust implementation or the
CPU's real TLB. The VM acceptance test (`vmtest`) performs real virtual loads
and stores after the Windows kernel build.
"""
from dataclasses import dataclass

PAGE = 4096
USER_LIMIT = 0x0000_8000_0000_0000
MASK64 = (1 << 64) - 1


def canonical48(address: int) -> bool:
    if not 0 <= address <= MASK64:
        return False
    upper = address >> 48
    sign = (address >> 47) & 1
    return upper == (0 if sign == 0 else 0xFFFF)


def indices(address: int) -> tuple[int, int, int, int]:
    return (
        (address >> 39) & 0x1FF,
        (address >> 30) & 0x1FF,
        (address >> 21) & 0x1FF,
        (address >> 12) & 0x1FF,
    )


@dataclass(frozen=True)
class Mapping:
    physical: int
    writable: bool
    user: bool
    no_execute: bool


class PagingModel:
    def __init__(self):
        self.mappings: dict[int, Mapping] = {}
        self.parent_permissions: dict[int, tuple[bool, bool, bool]] = {}
        self.huge_slots: set[int] = set()
        self.owned_tables = 0

    def map(self, virtual: int, physical: int, *, writable: bool, user: bool, nx: bool):
        if not canonical48(virtual):
            return "noncanonical"
        if virtual % PAGE or physical % PAGE:
            return "unaligned"
        if user and virtual >= USER_LIMIT:
            return "user-high-half"
        if virtual in self.mappings:
            return "already-mapped"
        pml4 = indices(virtual)[0]
        if pml4 in self.huge_slots:
            return "huge-conflict"
        parent = self.parent_permissions.get(pml4)
        requested = (writable, user, not nx)
        if parent is not None:
            parent_w, parent_u, parent_exec = parent
            if writable and not parent_w or user and not parent_u or not nx and not parent_exec:
                return "permission-conflict"
        else:
            self.parent_permissions[pml4] = (True, user, True)
            self.owned_tables += 3
        self.mappings[virtual] = Mapping(physical, writable, user, nx)
        return "ok"

    def unmap(self, virtual: int):
        mapping = self.mappings.pop(virtual, None)
        if mapping is None:
            return None
        pml4 = indices(virtual)[0]
        if not any(indices(address)[0] == pml4 for address in self.mappings):
            self.parent_permissions.pop(pml4, None)
            self.owned_tables -= 3
        return mapping.physical


def check(condition: bool, message: str):
    if not condition:
        raise AssertionError(message)


def main():
    check(canonical48(0x0000_7FFF_FFFF_FFFF), "maximum lower canonical address must be accepted")
    check(canonical48(0xFFFF_8000_0000_0000), "minimum upper canonical address must be accepted")
    check(not canonical48(0x0000_8000_0000_0000), "lower-half sign-bit boundary must be rejected")
    check(not canonical48(0xFFFF_0000_0000_0000), "noncanonical upper gap must be rejected")
    check(indices(0x0000_4000_0020_1000) == (128, 0, 1, 1), "four-level index extraction is incorrect")

    model = PagingModel()
    base = 0x0000_4000_0020_0000
    check(model.map(base, 0x0200_0000, writable=True, user=True, nx=True) == "ok", "user mapping failed")
    check(model.owned_tables == 3, "first mapping should allocate exactly three intermediate tables")
    check(model.map(base + PAGE, 0x0200_1000, writable=True, user=False, nx=True) == "ok", "supervisor mapping in same subtree failed")
    check(model.owned_tables == 3, "adjacent mapping should reuse the same intermediate tables")
    check(model.mappings[base].user, "user leaf permission was lost")
    check(not model.mappings[base + PAGE].user, "supervisor leaf was accidentally made user-accessible")
    check(model.map(base, 0x0200_2000, writable=True, user=True, nx=True) == "already-mapped", "existing mapping must not be overwritten")
    check(model.unmap(base) == 0x0200_0000, "unmap must return the original physical address")
    check(model.owned_tables == 3, "one remaining leaf must keep its intermediate tables")
    check(model.unmap(base + PAGE) == 0x0200_1000, "second unmap must return its physical address")
    check(model.owned_tables == 0, "empty owned intermediate tables must be reclaimed")
    check(model.unmap(base) is None, "unmapping an absent page must be rejected")

    restricted = PagingModel()
    restricted.parent_permissions[indices(base)[0]] = (False, False, True)
    check(restricted.map(base, 0x0300_0000, writable=True, user=False, nx=True) == "permission-conflict", "manager must not widen a pre-existing read-only parent")
    check(restricted.map(base, 0x0300_0000, writable=False, user=False, nx=False) == "ok", "mapping within existing parent permissions should succeed")

    huge = PagingModel()
    huge.huge_slots.add(indices(base)[0])
    check(huge.map(base, 0x0400_0000, writable=True, user=False, nx=True) == "huge-conflict", "huge-page conflict must be detected")
    high_half = PagingModel()
    check(high_half.map(0xFFFF_8000_0000_0000, 0x0500_0000, writable=True, user=True, nx=True) == "user-high-half", "user mapping into upper half must be rejected")

    print("Stage 4 page-table model passed:")
    print("  48-bit canonical-address validation and 4-level indices")
    print("  user/supervisor leaf permissions and parent-permission checks")
    print("  collision and huge-page conflict handling")
    print("  adjacent-page table reuse, unmap, and intermediate-table reclamation")
    print("  high-half user mapping rejection")


if __name__ == "__main__":
    main()
