#!/usr/bin/env python3
"""Source-contract tests for bounded, read-only ACPI discovery."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
acpi = (ROOT / "kernel/src/acpi.rs").read_text(encoding="utf-8")
limine = (ROOT / "kernel/src/boot/limine.rs").read_text(encoding="utf-8")
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")

for token in (
    "pub fn inspect()", "MAX_ROOT_ENTRIES: usize = 256",
    "MAX_TABLE_LENGTH: u64 = 1024 * 1024",
    "MAX_TOTAL_TABLE_BYTES: u64 = 4 * 1024 * 1024",
    "checksum_ok", "validate_sdt", "inspect_madt", "inspect_mcfg",
    "AcpiState::Unavailable", "AcpiState::InvalidRsdp", "AcpiState::InvalidRoot",
    "canonical_48", "checked_add", "tables_rejected",
):
    assert token in acpi, f"ACPI safety marker absent: {token}"
for token in (
    "RSDP_REQUEST", "pub fn rsdp_virtual_address()", "pub fn hhdm_to_physical", "pub fn acpi_region_contains",
    "0xc5e7_7b6b_397e_7b43", "0x2763_7845_accd_cf3c",
    "region.entry_type != 2", "region.entry_type != 3", "region.entry_type != 8",
    "virtual_address.checked_sub(offset)", "pub const fn memory_type_name",
):
    assert token in limine, f"Limine ACPI request marker absent: {token}"
assert "mod acpi;" in main
assert 'verb.eq_ignore_ascii_case(b"acpi")' in shell
assert 'verb.eq_ignore_ascii_case(b"memmap")' in shell
assert 'verb.eq_ignore_ascii_case(b"sysinfo")' in shell
assert "Read-only discovery only" in shell
assert "let Some(rsdp_virtual_value) = limine::rsdp_virtual_address()" in acpi
assert "let Some(rsdp_physical) = limine::hhdm_to_physical(rsdp_virtual_value)" in acpi
assert "hhdm.checked_add(rsdp_physical)" not in acpi, "RSDP is virtual under requested Limine base revision 6; do not add HHDM twice"
assert "HHDM virtual address" in limine
assert "0x2763_7845_accd_cf3c" in limine

# Exercise the same canonical/subtraction contract used by hhdm_to_physical.
def hhdm_to_physical_model(virtual_address: int, offset: int):
    upper = virtual_address >> 48
    sign = (virtual_address >> 47) & 1
    canonical = upper == (0 if sign == 0 else 0xFFFF)
    if not canonical or virtual_address < offset:
        return None
    return virtual_address - offset

assert hhdm_to_physical_model(0xFFFF800000001234, 0xFFFF800000000000) == 0x1234
assert hhdm_to_physical_model(0xFFFF7FFFFFFFFFFF, 0xFFFF800000000000) is None
assert hhdm_to_physical_model(0x0001000000000000, 0xFFFF800000000000) is None
# The ACPI parser must not configure PCI, APIC, or execute firmware AML.
for forbidden in ("arch::outb", "arch::outl", "write_config", "enable_bus_master", "execute_aml"):
    assert forbidden not in acpi, f"ACPI discovery unexpectedly performs hardware action: {forbidden}"
print("ACPI discovery contract passed: bounded RSDP/XSDT/RSDT and table validation, no hardware activation.")
