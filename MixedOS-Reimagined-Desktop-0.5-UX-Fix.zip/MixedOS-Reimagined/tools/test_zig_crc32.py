#!/usr/bin/env python3
"""Checks the first freestanding Zig component and its MIXFS integration."""
from pathlib import Path
import re
import zlib
import json

ROOT = Path(__file__).resolve().parents[1]
zig = (ROOT / "kernel/native/zig/crc32.zig").read_text(encoding="utf-8")
zig_test = (ROOT / "kernel/native/zig/crc32_test.zig").read_text(encoding="utf-8")
mixfs = (ROOT / "kernel/src/storage/mixfs.rs").read_text(encoding="utf-8")
build = (ROOT / "build.ps1").read_text(encoding="utf-8")
manager = (ROOT / "tools/toolchain-manager.ps1").read_text(encoding="utf-8")
versions = json.loads((ROOT / "tools/toolchain-versions.json").read_text(encoding="utf-8"))
linker = (ROOT / "kernel/build.rs").read_text(encoding="utf-8")

assert "pub export fn mixedos_zig_crc32" in zig
assert "crc.mixedos_zig_crc32" in zig_test, "Zig test module must import the public function"
assert "callconv(.c) u32" in zig
assert "while (index < length)" in zig
assert "0xedb8_8320" in zig
assert "@import(\"std\")" not in zig, "kernel Zig checksum must not depend on Zig stdlib"
assert "mixedos_zig_crc32" in mixfs and "unsafe extern \"C\"" in mixfs
assert "fn crc32(bytes: &[u8]) -> u32" in mixfs
assert "MIXEDOS_ZIG_OBJECT" in linker
assert "MIXEDOS_ZIG_OBJECT" in build
assert "build-obj" in build and "x86_64-freestanding-none" in build
assert versions["zig"]["version"] == "0.17.1" and versions["zig"]["sha256"] == "b03f477a1943673e02aca0f570e8030dffd536ce1f45cbc4d3326ec31159562e"
assert "zig test" in build or "crc32_test.zig" in build

vectors = (
    (b"", 0x00000000),
    (b"123456789", 0xCBF43926),
    (b"The quick brown fox jumps over the lazy dog", 0x414FA339),
)
for value, expected in vectors:
    assert zlib.crc32(value) & 0xFFFFFFFF == expected
    assert f"0x{expected:08x}" in zig_test.lower()

# Catch accidental drift from a duplicated Rust CRC loop back into MIXFS.
crc_body = re.search(r"fn crc32\(bytes: &\[u8\]\) -> u32\s*\{(.*?)\n\}", mixfs, re.S)
assert crc_body and "mixedos_zig_crc32" in crc_body.group(1)
print("Zig CRC-32 integration checks passed (3 standard vectors; linked into MIXFS).")
