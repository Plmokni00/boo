#!/usr/bin/env python3
"""Host-side behavioral model for the Stage 5 free-list heap policy."""
from dataclasses import dataclass
from pathlib import Path
import re

PAGE = 4096
ALIGN = 16
MIN_USER = 64
HEADER = 32
FREE_HEADER = 32
MAX_PAGES = 4096

@dataclass
class Block:
    start: int
    size: int

class HeapModel:
    def __init__(self, pages=4):
        self.capacity = pages * PAGE
        self.pages = pages
        self.base = 0x10000000
        self.free = [Block(self.base, self.capacity)]
        self.alloc = {}
        self.freed = set()
        self.used = 0
        self.peak = 0
        self.failures = 0
        self.free_errors = 0

    @staticmethod
    def up(value, alignment):
        return (value + alignment - 1) & ~(alignment - 1)

    def grow(self, pages):
        if self.pages + pages > MAX_PAGES:
            return False
        start = self.base + self.capacity
        self.capacity += pages * PAGE
        self.pages += pages
        self.free.append(Block(start, pages * PAGE))
        self.free.sort(key=lambda b: b.start)
        self.coalesce()
        return True

    def coalesce(self):
        merged = []
        for block in self.free:
            if merged and merged[-1].start + merged[-1].size == block.start:
                merged[-1].size += block.size
            else:
                merged.append(Block(block.start, block.size))
        self.free = merged

    def allocate(self, size, alignment):
        if alignment <= 0 or alignment & (alignment - 1) or alignment > 2 * 1024 * 1024:
            self.failures += 1
            return None
        alignment = max(alignment, ALIGN)
        effective = max(size, 1)
        for _ in range(2):
            for i, block in enumerate(self.free):
                user = self.up(block.start + MIN_USER, alignment)
                end = user + effective
                used_span = self.up(end - block.start, ALIGN)
                if used_span <= block.size:
                    remainder = block.size - used_span
                    span = used_span if remainder >= FREE_HEADER + ALIGN else block.size
                    if span == block.size:
                        self.free.pop(i)
                    else:
                        self.free[i] = Block(block.start + span, block.size - span)
                    self.alloc[user] = (block.start, span, size)
                    self.freed.discard(user)
                    self.used += span
                    self.peak = max(self.peak, self.used)
                    return user
            need = effective + MIN_USER + alignment - 1
            pages = max(4, (need + PAGE - 1) // PAGE)
            if not self.grow(pages):
                self.failures += 1
                return None
        self.failures += 1
        return None

    def free_pointer(self, pointer):
        if pointer in self.freed:
            self.free_errors += 1
            return "double-free"
        entry = self.alloc.pop(pointer, None)
        if entry is None:
            self.free_errors += 1
            return "invalid-pointer"
        start, size, _requested = entry
        self.freed.add(pointer)
        self.free.append(Block(start, size))
        self.free.sort(key=lambda b: b.start)
        self.used -= size
        # Reject overlaps before merging.
        for left, right in zip(self.free, self.free[1:]):
            if left.start + left.size > right.start:
                self.free_errors += 1
                return "overlap"
        self.coalesce()
        return "ok"

    @property
    def free_bytes(self):
        return sum(block.size for block in self.free)


def main():
    source = (Path(__file__).resolve().parents[1] / "kernel/src/memory/heap.rs").read_text(encoding="utf-8")
    candidates = [int(value, 16) for value in re.findall(r"0x(FFFF_[A-F0-9_]+)", source.split("const HEAP_BASE_CANDIDATES", 1)[1].split("];", 1)[0])]
    assert len(candidates) == 3
    slots = [(address >> 39) & 0x1FF for address in candidates]
    assert slots == [509, 510, 508]
    assert all((address >> 48) == 0xFFFF and ((address >> 47) & 1) == 1 for address in candidates)

    heap = HeapModel()
    sizes = [1, 37, 255, 1024, 4095, 8192, 16384]
    aligns = [16, 32, 64, 128, 256, 512, PAGE]
    pointers = []
    for size, alignment in zip(sizes, aligns):
        pointer = heap.allocate(size, alignment)
        assert pointer is not None and pointer % alignment == 0
        pointers.append(pointer)
    assert heap.pages > 4, "large requests should trigger on-demand heap growth"
    assert heap.used > 0
    for index in [3, 0, 6, 2, 5, 1, 4]:
        assert heap.free_pointer(pointers[index]) == "ok"
    assert heap.used == 0
    assert heap.free_bytes == heap.capacity
    assert len(heap.free) == 1, "adjacent free extents should coalesce into one block"

    assert heap.allocate(10, 3) is None, "non-power-of-two alignment must be rejected"
    probe = heap.allocate(128, 64)
    assert probe is not None
    assert heap.free_pointer(probe) == "ok"
    assert heap.free_pointer(probe) == "double-free"
    assert heap.free_errors == 1
    assert heap.used == 0
    assert heap.free_bytes == heap.capacity

    before = heap.capacity
    huge = heap.allocate(MAX_PAGES * PAGE, 16)
    assert huge is None and heap.capacity == before, "arena exhaustion must fail without corrupting state"
    assert heap.free_bytes + heap.used == heap.capacity
    print("Stage 5 kernel-heap model passed:")
    print("  variable-size allocation and 16..4096-byte alignment")
    print("  on-demand page growth and split/coalesce behavior")
    print("  fragmented free order, invalid alignment, and double-free detection")
    print("  bounded-arena exhaustion and byte-accounting consistency")
    print("  canonical high-half heap virtual-address candidates")

if __name__ == "__main__":
    main()
