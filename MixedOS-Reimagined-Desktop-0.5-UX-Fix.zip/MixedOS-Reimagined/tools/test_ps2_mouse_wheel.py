#!/usr/bin/env python3
"""Source-contract and protocol-model tests for PS/2 IntelliMouse wheel input."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
ps2 = (ROOT / "kernel/src/input/ps2.rs").read_text(encoding="utf-8")
mouse = (ROOT / "kernel/src/input/mouse.rs").read_text(encoding="utf-8")
input_mod = (ROOT / "kernel/src/input/mod.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
docs = (ROOT / "docs/INPUT-SUBSYSTEM.md").read_text(encoding="utf-8")

for token in ("[200u8, 100u8, 80u8]", "send_device_command(true, 0xF3)",
              "send_device_command(true, 0xF2)", "read_auxiliary_response() == Some(0x03)",
              "mouse::set_wheel_protocol(wheel_enabled)"):
    assert token in ps2, f"missing PS/2 wheel negotiation: {token}"
for token in ("static PACKET: [AtomicU8; 4]", "let packet_len = if WHEEL_PROTOCOL",
              "PACKET[3]", "nibble & 0x08", "wheel_delta: wheel", "-raw_steps"):
    assert token in mouse, f"missing wheel packet decoder behavior: {token}"
assert "pub wheel_delta: i8" in input_mod
assert "pub mouse_wheel_delta: i32" in input_mod
assert "view.scroll_up((mouse.wheel_delta as usize).saturating_mul(3))" in shell
assert "positive events always mean physical wheel-up" in mouse
assert "view.scroll_down" in shell
assert "wheel-up" in docs and "wheel-down" in docs

# IntelliMouse wheel data is a signed four-bit two's-complement value.
def signed_nibble(value: int) -> int:
    nibble = value & 0x0F
    return nibble - 16 if nibble & 8 else nibble
assert -signed_nibble(0x01) == -1
assert -signed_nibble(0x07) == -7
assert -signed_nibble(0x0F) == 1
assert -signed_nibble(0x08) == 8
# Unsupported IDs must not select the four-byte packet mode.
for device_id in (0x00, 0x04, 0xFF):
    assert device_id != 0x03
print("PS/2 IntelliMouse wheel contract passed: ID3 negotiation, normalized wheel polarity, signed nibble decoding, legacy fallback, and shell scrolling.")
