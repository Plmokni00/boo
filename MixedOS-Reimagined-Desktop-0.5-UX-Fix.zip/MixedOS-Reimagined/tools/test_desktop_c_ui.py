#!/usr/bin/env python3
"""Contracts for the C desktop compositor, SVG assets, and window behavior."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
d = (ROOT / "kernel/src/desktop.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
c = (ROOT / "kernel/native/c/desktop_ui.c").read_text(encoding="utf-8")
h = (ROOT / "kernel/native/c/desktop_ui.h").read_text(encoding="utf-8")
build = (ROOT / "build.ps1").read_text(encoding="utf-8")
link = (ROOT / "kernel/build.rs").read_text(encoding="utf-8")
mouse = (ROOT / "kernel/src/input/mouse.rs").read_text(encoding="utf-8")

# The new C layer must be the actual default desktop and decorated-window path.
for token in ("mixedos_ui_init", "mixedos_ui_draw_desktop", "mixedos_ui_draw_window", "mixedos_ui_draw_window_controls", "mixedos_ui_draw_minimized_hint"):
    assert token in c and token in h, f"C compositor API missing: {token}"
for token in ("mixedos_ui_draw_desktop", "mixedos_ui_font_glyph", "draw_ui_desktop", "draw_window_frame_state"):
    assert token in d, f"Rust/C desktop bridge missing: {token}"
assert "fn draw_shell_chrome" not in d, "obsolete Rust-painted desktop chrome should not remain"

# SVGPortal originals plus Lucide window actions are bundled and keep notices.
svg_dir = ROOT / "kernel/assets/icons"
icons = {
    "terminal.svg": "terminal", "files.svg": "Material Symbols", "settings.svg": "Tabler",
    "wifi.svg": "Material Symbols", "wifi-off.svg": "Material Symbols", "ethernet.svg": "Lucide",
    "volume-on.svg": "Iconoir", "volume-off.svg": "Iconoir",
    "window-minimize.svg": "minus", "window-maximize.svg": "square",
    "window-restore.svg": "copy", "window-close.svg": "x",
}
for filename, attribution in icons.items():
    body = (svg_dir / filename).read_text(encoding="utf-8")
    assert "<svg" in body and "svgportal.com" in body, f"SVGPortal source or attribution missing: {filename}"
    assert attribution in body, f"wrong/missing source icon attribution: {filename}"
atlas = (svg_dir / "desktop_icons.h").read_text(encoding="utf-8")
assert "MIXUI_ICON_SIZE 40" in atlas
for symbol in ("mixui_terminal", "mixui_files", "mixui_settings", "mixui_wifi", "mixui_wifi_off", "mixui_ethernet", "mixui_volume_on", "mixui_volume_off", "mixui_window_minimize", "mixui_window_maximize", "mixui_window_restore", "mixui_window_close"):
    assert symbol in atlas, f"icon atlas is missing {symbol}"

# One consistent set of title-bar hitboxes maps to minimize, maximize/restore, close.
assert "Some((x-controls)/button)" in d
assert "0=>{minimized" in d or "0 => { minimized" in d
assert "minimized=true" in shell and "maximized=true" in shell and "return true" in shell
for title in ("Terminal", "Files", "Settings", "Text Editor"):
    assert title in d or title in shell, f"window type missing: {title}"
assert "taskbar_hit(sw, sh, mx, my) == Some(1)" in d
assert "taskbar_hit(sw,sh,mx,my)==Some(2)" in d
assert "taskbar_hit(fb.width as usize, fb.height as usize, px, py) == Some(0)" in shell

# Compact, centered Files window and lower pointer gain than the old 28..48 profile.
assert "min(ui_scale(framebuffer, 1120))" in d and "min(ui_scale(framebuffer, 680))" in d
assert "magnitude <= 1 { 2 } else if magnitude <= 4 { 3 } else if magnitude <= 12 { 4 } else { 5 }" in mouse

# C objects must use the kernel code model and be compiled/linked by the existing no-WSL/No-Docker build flow.
assert "desktop_ui.c" in build and "MIXEDOS_UI_OBJECT" in build
assert build.count("'-mcmodel=kernel'") == 2, "both freestanding C objects must use the kernel code model for high-half linking"
assert '"MIXEDOS_UI_OBJECT"' in link and 'required_object("MIXEDOS_UI_OBJECT"' in link
assert "MIXEDOS_C_OBJECT" in link and "MIXEDOS_ZIG_OBJECT" in link

print("Desktop 0.5 C UI contracts passed: SVGPortal assets, title-bar controls, responsive Files window, app minimize/restore, pointer gain, kernel code model, and native C build wiring.")
