#!/usr/bin/env python3
"""Regression checks for CPU-state and bootstrap-IDT setup before Rust entry."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
asm = (ROOT / "kernel/src/arch/x86_64/interrupts.S").read_text(encoding="utf-8")
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
arch = (ROOT / "kernel/src/arch/x86_64/mod.rs").read_text(encoding="utf-8")
linker = (ROOT / "kernel/linker.ld").read_text(encoding="utf-8")

assert "ENTRY(_start)" in linker
assert ".global _start" in asm and ".type _start, @function" in asm
entry = asm[asm.index("_start:"):asm.index(".size _start")]
ordered = (
    "cli",
    "lea rdi, [rip + mixedos_early_idt]",
    "mov ecx, 256",
    "lidt [rip + mixedos_early_idtr]",
    "mov rax, cr0",
    "and rax, -13",
    "or rax, 2",
    "mov cr0, rax",
    "mov rax, cr4",
    "or rax, 0x600",
    "mov cr4, rax",
    "fninit",
    "ldmxcsr [rsp]",
    "mov byte ptr [rip + MIXEDOS_FPU_READY], 1",
    "and rsp, -16",
    "call mixedos_rust_entry",
)
positions = [entry.find(token) for token in ordered]
assert all(position >= 0 for position in positions), f"missing early entry instruction: {[(t, p) for t, p in zip(ordered, positions) if p < 0]}"
assert positions == sorted(positions), "bootstrap IDT and FPU/SSE setup must precede the Rust call"
assert "mixedos_early_fault:" in asm and "mixedos_early_fault_halt:" in asm
assert "    hlt\n    jmp .Lmixedos_early_fault_halt" in asm
assert "mixedos_kernel_early_idt:" in asm
assert asm.count(".zero 4096") == 2

# Once the GDT changes, bootstrap gate selectors must be rebased to kernel CS.
gdt_reload = asm[asm.index("mixedos_gdt_reload:"):asm.index(".global mixedos_enter_user")]
assert "mixedos_kernel_early_idt" in gdt_reload
assert "lidt [rip + mixedos_kernel_early_idtr]" in gdt_reload
assert "mov word ptr [rdi + 2], 0x08" not in gdt_reload

assert '#[unsafe(no_mangle)]\npub extern "C" fn mixedos_rust_entry() -> !' in main
assert 'fn _start()' not in main
assert "pub static mut MIXEDOS_FPU_READY: u8 = 0" in arch
assert "pub fn verify_early_fpu_state()" in arch
assert "cr4_required = (1 << 9) | (1 << 10)" in arch
assert "arch::verify_early_fpu_state()" in main
print("Early entry regression passed: bootstrap IDT + x87/SSE initialized before Rust; kernel-selector bootstrap IDT switched.")
