#!/usr/bin/env python3
"""Contracts for bounded kernel logging and everyday shell diagnostics."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "kernel/src/main.rs").read_text(encoding="utf-8")
log = (ROOT / "kernel/src/log.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
assert "mod log;" in main
assert "$crate::log::record($crate::log::Level::Info" in main
for token in ("pub const CAPACITY: usize = 64", "pub const LINE_CAPACITY: usize = 160",
              "pub enum Level", "pub fn record", "pub fn visit", "pub fn clear",
              "AtomicBool", "UnsafeCell", "from_utf8(bytes)"):
    assert token in log, f"kernel log missing {token}"
assert "alloc::" not in log and "Vec<" not in log and "String" not in log
for command in ("log", "uptime", "version", "drivers"):
    assert f'verb.eq_ignore_ascii_case(b"{command}")' in shell, f"missing {command} command"
assert "interrupts::ticks()" in shell
assert "crate::log::visit" in shell
assert "crate::log::clear()" in shell
print("Kernel services contract passed: bounded RAM log, uptime, version, and driver inventory commands.")
