#!/usr/bin/env python3
"""Read-only hardware inventory and memory-map display contracts."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
limine = (ROOT / "kernel/src/boot/limine.rs").read_text(encoding="utf-8")
shell = (ROOT / "kernel/src/shell/mod.rs").read_text(encoding="utf-8")
pci = (ROOT / "kernel/src/pci.rs").read_text(encoding="utf-8")
for token in (
    '0 => "usable"', '1 => "reserved"', '2 => "ACPI reclaimable"',
    '3 => "ACPI NVS"', '4 => "bad memory"',
    '5 => "bootloader reclaimable"', '6 => "kernel/modules"',
    '7 => "framebuffer"', '8 => "reserved mapped"',
    'pub const fn memory_type_name',
):
    assert token in limine, f"missing memory map name: {token}"
assert "memory_type_name(region.entry_type)" in shell
for token in (
    'pub struct PciResourceSummary', 'pub fn resource_summary()',
    'devices_truncated', 'prefetchable_mmio_bars', 'zero_base_bars',
    'BAR sizes are unknown',
):
    assert token in pci, f"missing safe PCI resource inventory marker: {token}"
assert 'args.eq_ignore_ascii_case(b"resources")' in shell
assert "crate::pci::resource_summary()" in shell
# Resource inventory must stay read-only and must not size BARs or enable bus mastering.
for forbidden in ("write_config", "enable_bus_master", "arch::outl(CONFIG_DATA,"):
    assert forbidden not in pci, f"PCI resource inventory must not modify hardware: {forbidden}"
print("Hardware inventory contract passed: named Limine memory regions and read-only PCI BAR summary.")
