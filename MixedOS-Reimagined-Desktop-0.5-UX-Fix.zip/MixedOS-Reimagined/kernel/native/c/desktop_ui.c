/*
 * MixedOS Desktop UI runtime.
 * The kernel keeps device, filesystem, and input ownership in Rust; this C
 * module owns desktop composition, scalable layout, and decorated windows.
 */
#include <stdint.h>
#include <stddef.h>
#include "desktop_ui.h"
#include "../../assets/icons/desktop_icons.h"

typedef struct {
    uint8_t *address;
    uint32_t width, height, pitch;
    uint16_t bpp;
    uint8_t red_size, red_shift, green_size, green_shift, blue_size, blue_shift;
    uint8_t valid;
} MixUiFramebuffer;

static MixUiFramebuffer g_fb;
static int32_t g_pointer_x, g_pointer_y;


static uint32_t scale_px(uint32_t value) {
    uint32_t scaled = (value * g_fb.height + 540u) / 1080u;
    return scaled ? scaled : 1u;
}
static uint32_t channel(uint8_t value, uint8_t size, uint8_t shift) {
    if (!size || size > 8 || shift >= 32 || size + shift > 32) return 0;
    uint32_t max = (1u << size) - 1u;
    return (((uint32_t)value * max + 127u) / 255u) << shift;
}
static uint8_t unchannel(uint32_t pixel, uint8_t size, uint8_t shift) {
    if (!size || size > 8 || shift >= 32 || size + shift > 32) return 0;
    uint32_t max = (1u << size) - 1u;
    return (uint8_t)((((pixel >> shift) & max) * 255u + max / 2u) / max);
}
static uint32_t pack_rgb(uint8_t r, uint8_t g, uint8_t b) {
    return channel(r,g_fb.red_size,g_fb.red_shift) |
           channel(g,g_fb.green_size,g_fb.green_shift) |
           channel(b,g_fb.blue_size,g_fb.blue_shift);
}
static void raw_pixel(uint32_t x, uint32_t y, uint32_t value) {
    if (!g_fb.valid || x >= g_fb.width || y >= g_fb.height) return;
    uint8_t *p = g_fb.address + (size_t)y * g_fb.pitch + (size_t)x * (g_fb.bpp / 8u);
    if (g_fb.bpp == 32) *(volatile uint32_t *)p = value;
    else if (g_fb.bpp == 24) { p[0]=(uint8_t)value; p[1]=(uint8_t)(value>>8); p[2]=(uint8_t)(value>>16); }
}
static uint32_t read_pixel(uint32_t x, uint32_t y) {
    if (!g_fb.valid || x >= g_fb.width || y >= g_fb.height) return 0;
    uint8_t *p = g_fb.address + (size_t)y * g_fb.pitch + (size_t)x * (g_fb.bpp / 8u);
    if (g_fb.bpp == 32) return *(volatile uint32_t *)p;
    return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16);
}
static void pixel(uint32_t x, uint32_t y, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    if (!a) return;
    if (a == 255) { raw_pixel(x,y,pack_rgb(r,g,b)); return; }
    uint32_t old=read_pixel(x,y);
    uint8_t br=unchannel(old,g_fb.red_size,g_fb.red_shift);
    uint8_t bg=unchannel(old,g_fb.green_size,g_fb.green_shift);
    uint8_t bb=unchannel(old,g_fb.blue_size,g_fb.blue_shift);
    uint32_t ia=255u-a;
    r=(uint8_t)(((uint32_t)r*a+(uint32_t)br*ia+127u)/255u);
    g=(uint8_t)(((uint32_t)g*a+(uint32_t)bg*ia+127u)/255u);
    b=(uint8_t)(((uint32_t)b*a+(uint32_t)bb*ia+127u)/255u);
    raw_pixel(x,y,pack_rgb(r,g,b));
}
static void rect(int32_t x,int32_t y,int32_t w,int32_t h,uint32_t rgb,uint8_t alpha) {
    if (w<=0 || h<=0) return;
    int32_t x0=x<0?0:x, y0=y<0?0:y;
    int32_t x1=x+w>(int32_t)g_fb.width?(int32_t)g_fb.width:x+w;
    int32_t y1=y+h>(int32_t)g_fb.height?(int32_t)g_fb.height:y+h;
    uint8_t r=(uint8_t)(rgb>>16),g=(uint8_t)(rgb>>8),b=(uint8_t)rgb;
    for(int32_t py=y0;py<y1;py++) for(int32_t px=x0;px<x1;px++) pixel((uint32_t)px,(uint32_t)py,r,g,b,alpha);
}
static void rounded_rect(int32_t x,int32_t y,int32_t w,int32_t h,int32_t radius,uint32_t color,uint8_t alpha) {
    if(w<=0||h<=0)return;
    if(radius<0)radius=0;
    if(radius>w/2)radius=w/2;
    if(radius>h/2)radius=h/2;
    uint8_t r=(uint8_t)(color>>16),g=(uint8_t)(color>>8),b=(uint8_t)color;
    int32_t rr=radius*radius;
    for(int32_t py=0;py<h;py++) for(int32_t px=0;px<w;px++) {
        int32_t cx=px<radius?radius:(px>=w-radius?w-radius-1:px);
        int32_t cy=py<radius?radius:(py>=h-radius?h-radius-1:py);
        int32_t dx=px-cx,dy=py-cy;
        if((px<radius||px>=w-radius)&&(py<radius||py>=h-radius)) {
            if(dx*dx+dy*dy>rr)continue;
        }
        int32_t ax=x+px,ay=y+py;
        if(ax>=0&&ay>=0)pixel((uint32_t)ax,(uint32_t)ay,r,g,b,alpha);
    }
}
static void line(int32_t x0,int32_t y0,int32_t x1,int32_t y1,uint32_t color,uint8_t alpha,int32_t thickness) {
    int32_t dx=x1>x0?x1-x0:x0-x1, sx=x0<x1?1:-1;
    int32_t dy=y1>y0?y0-y1:y1-y0, sy=y0<y1?1:-1;
    int32_t err=dx+dy;
    for(;;){
        int32_t half=thickness/2;
        rect(x0-half,y0-half,thickness,thickness,color,alpha);
        if(x0==x1&&y0==y1)break;
        int32_t e2=2*err;
        if(e2>=dy){err+=dy;x0+=sx;}
        if(e2<=dx){err+=dx;y0+=sy;}
    }
}
static int text_width(const char *str,int bold) {
    int w=0; if(!str)return 0;
    for(;*str;str++){uint8_t tmp[512];int32_t gw,gh,l,t,a,asc;mixedos_ui_font_glyph((uint8_t)*str,(uint8_t)bold,tmp,sizeof(tmp),&gw,&gh,&l,&t,&a,&asc);w+=(a*3+3)/4;}
    return w;
}
static void text(int32_t x,int32_t y,const char *str,uint32_t color,int bold) {
    if(!str)return;
    int32_t cx=x;
    uint8_t bitmap[512];
    uint8_t r=(uint8_t)(color>>16),g=(uint8_t)(color>>8),b=(uint8_t)color;
    for(;*str;str++){
        int32_t w=0,h=0,left=0,top=0,advance=0,ascent=0;
        mixedos_ui_font_glyph((uint8_t)*str,(uint8_t)bold,bitmap,sizeof(bitmap),&w,&h,&left,&top,&advance,&ascent);
        if(w>0&&h>0&&w*h<=(int32_t)sizeof(bitmap)){
            int32_t out_w=(w*3+3)/4, out_h=(h*3+3)/4;
            int32_t scaled_left=(left*3)/4, scaled_top=(top*3)/4;
            for(int32_t gy=0;gy<out_h;gy++)for(int32_t gx=0;gx<out_w;gx++){
                int32_t sx=gx*4/3, sy=gy*4/3;
                int32_t dx=cx+scaled_left+gx,dy=y+(ascent*3)/4+scaled_top+gy;
                if(dx>=0&&dy>=0&&dx<(int32_t)g_fb.width&&dy<(int32_t)g_fb.height){uint8_t a=bitmap[sy*w+sx];if(a)pixel((uint32_t)dx,(uint32_t)dy,r,g,b,a);}
            }
        }
        cx+=(advance*3+3)/4;
        if(cx>(int32_t)g_fb.width)break;
    }
}
static void icon(const uint8_t *data,int32_t x,int32_t y,int32_t size,uint32_t tint,uint8_t alpha) {
    if(!data||size<=0)return;
    uint8_t tr=(uint8_t)(tint>>16),tg=(uint8_t)(tint>>8),tb=(uint8_t)tint;
    for(int32_t py=0;py<size;py++)for(int32_t px=0;px<size;px++){
        int32_t sx=px*MIXUI_ICON_SIZE/size,sy=py*MIXUI_ICON_SIZE/size;
        uint8_t a=data[((size_t)sy*MIXUI_ICON_SIZE+(size_t)sx)*4u+3u];
        if(a){uint32_t aa=(uint32_t)a*alpha/255u;int32_t dx=x+px,dy=y+py;if(dx>=0&&dy>=0)pixel((uint32_t)dx,(uint32_t)dy,tr,tg,tb,(uint8_t)aa);}
    }
}
static int inside(int32_t x,int32_t y,int32_t rx,int32_t ry,int32_t rw,int32_t rh){return x>=rx&&y>=ry&&x<rx+rw&&y<ry+rh;}

int mixedos_ui_init(uint8_t *address,uint32_t width,uint32_t height,uint32_t pitch,uint16_t bpp,
                    uint8_t rs,uint8_t rsh,uint8_t gs,uint8_t gsh,uint8_t bs,uint8_t bsh) {
    g_fb.address=address;g_fb.width=width;g_fb.height=height;g_fb.pitch=pitch;g_fb.bpp=bpp;
    g_fb.red_size=rs;g_fb.red_shift=rsh;g_fb.green_size=gs;g_fb.green_shift=gsh;g_fb.blue_size=bs;g_fb.blue_shift=bsh;
    g_fb.valid=(uint8_t)(address&&width&&height&&pitch&&((bpp==24)||(bpp==32))&&rs&&gs&&bs);
    return g_fb.valid?1:0;
}
void mixedos_ui_set_pointer(int32_t x,int32_t y,uint8_t buttons){g_pointer_x=x;g_pointer_y=y;(void)buttons;}
uint32_t mixedos_ui_taskbar_height(void){return scale_px(76);}
uint32_t mixedos_ui_topbar_height(void){return scale_px(42);}
uint32_t mixedos_ui_dock_start(void){uint32_t dw=scale_px(252);return g_fb.width>dw?(g_fb.width-dw)/2u:0u;}

void mixedos_ui_draw_desktop(int preview) {
    if(!g_fb.valid)return;
    uint32_t top=mixedos_ui_topbar_height(),bar=mixedos_ui_taskbar_height();
    int32_t margin=(int32_t)scale_px(18), dock_h=(int32_t)bar-(int32_t)scale_px(12), dock_y=(int32_t)g_fb.height-(int32_t)bar+(int32_t)scale_px(6);
    uint32_t cream=0xf1eaf2u,muted=0xbdb0c9u,accent=0xe28c88u;
    /* Slim top status rail, not a full-width heavy panel. */
    rect(0,0,(int32_t)g_fb.width,(int32_t)top,0x171421u,222);
    rect(0,(int32_t)top-1,(int32_t)g_fb.width,1,0x76506fu,180);
    rounded_rect(margin,(int32_t)(top-scale_px(30))/2,(int32_t)scale_px(25),(int32_t)scale_px(25), (int32_t)scale_px(8),accent,255);
    text(margin+(int32_t)scale_px(7),(int32_t)(top-scale_px(20))/2,"M",cream,1);
    text(margin+(int32_t)scale_px(36),(int32_t)(top-scale_px(18))/2,"MIXEDOS",cream,1);
    text(margin+(int32_t)scale_px(126),(int32_t)(top-scale_px(17))/2,preview?"DESKTOP PREVIEW":"DESKTOP",muted,0);
    int32_t status_x=(int32_t)g_fb.width-(int32_t)scale_px(218);
    icon(mixui_wifi_off,status_x,(int32_t)(top-scale_px(20))/2,(int32_t)scale_px(18),0xd3a6a8u,255);
    icon(mixui_volume_off,status_x+(int32_t)scale_px(28),(int32_t)(top-scale_px(20))/2,(int32_t)scale_px(18),0xc9bdd2u,255);
    text(status_x+(int32_t)scale_px(58),(int32_t)(top-scale_px(17))/2,"OFFLINE",0xd3a6a8u,0);
    /* Desktop launchers: genuine SVGPortal artwork, with labels separated from it. */
    int32_t ix=margin,iy=(int32_t)top+(int32_t)scale_px(38),isz=(int32_t)scale_px(44),step=(int32_t)scale_px(112);
    const uint8_t *imgs[3]={mixui_terminal,mixui_files,mixui_settings};
    const char *labels[3]={"Terminal","Files","Settings"};
    for(int i=0;i<3;i++){
        int32_t hit_x=ix,hit_y=iy+i*step;
        if(inside(g_pointer_x,g_pointer_y,hit_x-(int32_t)scale_px(8),hit_y-(int32_t)scale_px(6),isz+(int32_t)scale_px(16),step-(int32_t)scale_px(8)))
            rounded_rect(hit_x-(int32_t)scale_px(8),hit_y-(int32_t)scale_px(6),isz+(int32_t)scale_px(16),step-(int32_t)scale_px(8),(int32_t)scale_px(10),0x3a2b43u,118);
        icon(imgs[i],hit_x,hit_y,isz,cream,255);
        int tw=text_width(labels[i],0);
        text(hit_x+(isz-tw)/2,hit_y+isz+(int32_t)scale_px(8),labels[i],cream,0);
    }
    /* Soft translucent dock, proportioned to the screen rather than oversized. */
    uint32_t dock_x=mixedos_ui_dock_start();
    rounded_rect((int32_t)dock_x,dock_y,(int32_t)scale_px(252),dock_h,(int32_t)scale_px(18),0x171421u,232);
    rect((int32_t)dock_x+(int32_t)scale_px(24),dock_y,(int32_t)scale_px(204),1,0x8e6687u,150);
    const uint8_t *dock_icons[3]={mixui_terminal,mixui_files,mixui_settings};
    for(int i=0;i<3;i++){
        int32_t cell_x=(int32_t)dock_x+(int32_t)scale_px(14+i*76);
        int32_t icon_size=(int32_t)scale_px(28),icon_y=dock_y+(dock_h-icon_size)/2-(int32_t)scale_px(3);
        if(inside(g_pointer_x,g_pointer_y,cell_x-(int32_t)scale_px(8),dock_y,(int32_t)scale_px(64),dock_h))
            rounded_rect(cell_x-(int32_t)scale_px(8),dock_y+(int32_t)scale_px(4),(int32_t)scale_px(52),dock_h-(int32_t)scale_px(8),(int32_t)scale_px(11),0x59425fu,130);
        icon(dock_icons[i],cell_x+(int32_t)scale_px(10),icon_y,icon_size,cream,255);
        rounded_rect(cell_x+(int32_t)scale_px(21),dock_y+dock_h-(int32_t)scale_px(7),(int32_t)scale_px(6),(int32_t)scale_px(3),(int32_t)scale_px(2),i==0?accent:0x9e8aa9u,230);
    }
    /* Start control and the right-side system tray are compact edge anchors. */
    int32_t start_x=margin,start_y=dock_y+(dock_h-(int32_t)scale_px(40))/2;
    rounded_rect(start_x,start_y,(int32_t)scale_px(44),(int32_t)scale_px(40),(int32_t)scale_px(12),0x4b334eu,245);
    rounded_rect(start_x+(int32_t)scale_px(11),start_y+(int32_t)scale_px(9),(int32_t)scale_px(22),(int32_t)scale_px(22),(int32_t)scale_px(7),accent,255);
    text(start_x+(int32_t)scale_px(17),start_y+(int32_t)scale_px(11),"M",cream,1);
    int32_t tray_w=(int32_t)scale_px(132),tray_x=(int32_t)g_fb.width-tray_w-margin;
    rounded_rect(tray_x,start_y,tray_w,(int32_t)scale_px(40),(int32_t)scale_px(12),0x211a2bu,228);
    text(tray_x+(int32_t)scale_px(12),start_y+(int32_t)scale_px(7),"MIXFS",cream,1);
    text(tray_x+(int32_t)scale_px(12),start_y+(int32_t)scale_px(23),"READY",muted,0);
    text(tray_x+(int32_t)scale_px(72),start_y+(int32_t)scale_px(15),g_fb.width>=1920?"FHD":(g_fb.width>=1280?"HD":"FB"),0x9ed7c4u,0);
}

static void draw_window_controls(int32_t x,int32_t y,int32_t width,int maximized) {
    int32_t title_h=(int32_t)scale_px(43),button_w=(int32_t)scale_px(40);
    int32_t controls_x=x+width-button_w*3;
    for(int i=0;i<3;i++){
        int32_t bx=controls_x+i*button_w;
        int hover=inside(g_pointer_x,g_pointer_y,bx,y,button_w,title_h);
        uint32_t bg=hover?((i==2)?0xb84f5du:0x55445fu):0x2a2232u;
        rect(bx,y,button_w,title_h,bg,255);
        int32_t isz=(int32_t)scale_px(17),cx=bx+(button_w-isz)/2,cy=y+(title_h-isz)/2;
        const uint8_t *img=i==0?mixui_window_minimize:(i==1?(maximized?mixui_window_restore:mixui_window_maximize):mixui_window_close);
        icon(img,cx,cy,isz,hover?0xffffffu:0xded4e3u,255);
    }
}

void mixedos_ui_draw_window_controls(int32_t x,int32_t y,int32_t width,int maximized) {
    if(!g_fb.valid||width<120)return;
    draw_window_controls(x,y,width,maximized);
}

void mixedos_ui_draw_window(int32_t x,int32_t y,int32_t width,int32_t height,const char *title,uint32_t accent,int maximized) {
    if(!g_fb.valid||width<120||height<70)return;
    int32_t title_h=(int32_t)scale_px(43),r=(int32_t)scale_px(13);
    if(width>=(int32_t)g_fb.width-(int32_t)scale_px(22)&&y<=(int32_t)scale_px(50))r=(int32_t)scale_px(8);
    rounded_rect(x+(int32_t)scale_px(4),y+(int32_t)scale_px(7),width,height,r+2,0x000000u,86);
    rounded_rect(x,y,width,height,r,0x181521u,248);
    rounded_rect(x,y,width,title_h,r,0x2a2232u,255);
    rect(x+1,y+title_h-2,width-2,2,0x2a2232u,255);
    rect(x+1,y,width-2,(int32_t)scale_px(3),accent&0xffffffu,255);
    text(x+(int32_t)scale_px(20),y+(title_h-(int32_t)scale_px(18))/2,title?title:"Window",0xf2eaf2u,1);
    draw_window_controls(x,y,width,maximized);
    rect(x,y+height-1,width,1,0x745773u,220);
    for(int i=0;i<3;i++)line(x+width-(int32_t)scale_px(8+i*4),y+height-2,x+width-2,y+height-(int32_t)scale_px(8+i*4),0x95829au,190,(int32_t)scale_px(1));
}

void mixedos_ui_draw_minimized_hint(const char *title) {
    uint32_t bar=mixedos_ui_taskbar_height(),y=g_fb.height-bar;
    uint32_t index=0;
    const uint8_t *img=mixui_terminal;
    if(title&&title[0]=='F'){img=mixui_files;index=1;}
    else if(title&&title[0]=='S'){img=mixui_settings;index=2;}
    else if(title&&title[0]=='T'&&title[1]=='e'&&title[2]=='x'){img=mixui_files;index=1;}
    uint32_t x=mixedos_ui_dock_start()+(uint32_t)scale_px(14u+index*76u);
    rounded_rect((int32_t)x,y+(int32_t)scale_px(3),(int32_t)scale_px(60),bar-(int32_t)scale_px(6),(int32_t)scale_px(10),0x65506bu,250);
    icon(img,(int32_t)x+(int32_t)scale_px(19),(int32_t)y+(int32_t)scale_px(14),(int32_t)scale_px(22),0xf3eaf2u,255);
}
