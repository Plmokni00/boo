#ifndef MIXEDOS_DESKTOP_UI_H
#define MIXEDOS_DESKTOP_UI_H
#include <stdint.h>

int mixedos_ui_init(uint8_t *address, uint32_t width, uint32_t height,
                    uint32_t pitch, uint16_t bpp,
                    uint8_t red_size, uint8_t red_shift,
                    uint8_t green_size, uint8_t green_shift,
                    uint8_t blue_size, uint8_t blue_shift);
void mixedos_ui_set_pointer(int32_t x, int32_t y, uint8_t buttons);
void mixedos_ui_draw_desktop(int preview);
void mixedos_ui_draw_window(int32_t x, int32_t y, int32_t width, int32_t height,
                            const char *title, uint32_t accent, int maximized);
void mixedos_ui_draw_minimized_hint(const char *title);
void mixedos_ui_draw_window_controls(int32_t x, int32_t y, int32_t width, int maximized);
uint32_t mixedos_ui_taskbar_height(void);
uint32_t mixedos_ui_dock_start(void);
uint32_t mixedos_ui_topbar_height(void);

/* Supplied by the Rust Arimo font bridge. */
void mixedos_ui_font_glyph(uint8_t character, uint8_t bold, uint8_t *bitmap,
                           uint32_t bitmap_capacity, int32_t *width,
                           int32_t *height, int32_t *left, int32_t *top,
                           int32_t *advance, int32_t *ascent);
#endif
