const std = @import("std");
const crc = @import("crc32.zig");

test "CRC-32/ISO-HDLC standard vectors" {
    const empty: []const u8 = "";
    const numeric: []const u8 = "123456789";
    const sentence: []const u8 = "The quick brown fox jumps over the lazy dog";

    try std.testing.expectEqual(@as(u32, 0x00000000), crc.mixedos_zig_crc32(empty.ptr, empty.len));
    try std.testing.expectEqual(@as(u32, 0xcbf43926), crc.mixedos_zig_crc32(numeric.ptr, numeric.len));
    try std.testing.expectEqual(@as(u32, 0x414fa339), crc.mixedos_zig_crc32(sentence.ptr, sentence.len));
}
