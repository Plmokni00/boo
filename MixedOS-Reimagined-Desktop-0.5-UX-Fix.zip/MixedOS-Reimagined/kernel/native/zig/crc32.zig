//! Freestanding CRC-32/ISO-HDLC implementation used by MIXFS metadata.
//! This module intentionally uses no standard-library or allocator services.

pub export fn mixedos_zig_crc32(data: [*]const u8, length: usize) callconv(.c) u32 {
    var crc: u32 = 0xffff_ffff;
    var index: usize = 0;

    while (index < length) : (index += 1) {
        crc ^= @as(u32, data[index]);
        var bit: u8 = 0;
        while (bit < 8) : (bit += 1) {
            if ((crc & 1) != 0) {
                crc = (crc >> 1) ^ 0xedb8_8320;
            } else {
                crc >>= 1;
            }
        }
    }

    return ~crc;
}
