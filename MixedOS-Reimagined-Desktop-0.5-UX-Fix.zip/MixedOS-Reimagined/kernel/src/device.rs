//! Bounded read-only device inventory built from PCI discovery.
//!
//! This is a device model foundation, not a driver loader: entries are snapshots
//! of PCI identities and remain in the `Discovered` state until a real driver
//! matching/probe contract is implemented. No device configuration is changed.

use core::cell::UnsafeCell;
use core::hint::spin_loop;
use core::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

use crate::pci;

pub const MAX_DEVICES: usize = 64;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DeviceState {
    Discovered,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DeviceInfo {
    pub bus: u8,
    pub device: u8,
    pub function: u8,
    pub vendor_id: u16,
    pub device_id: u16,
    pub class_code: u8,
    pub subclass: u8,
    pub programming_interface: u8,
    pub revision_id: u8,
    pub interrupt_pin: u8,
    pub state: DeviceState,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct DeviceSummary {
    pub discovered: usize,
    pub recorded: usize,
    pub truncated: bool,
    pub initialized: bool,
}

struct Registry(UnsafeCell<[Option<DeviceInfo>; MAX_DEVICES]>);
unsafe impl Sync for Registry {}
static REGISTRY: Registry = Registry(UnsafeCell::new([None; MAX_DEVICES]));
static LOCKED: AtomicBool = AtomicBool::new(false);
static INITIALIZED: AtomicBool = AtomicBool::new(false);
static DISCOVERED: AtomicUsize = AtomicUsize::new(0);
static RECORDED: AtomicUsize = AtomicUsize::new(0);
static TRUNCATED: AtomicBool = AtomicBool::new(false);

struct LockGuard;
fn lock() -> LockGuard {
    while LOCKED.compare_exchange_weak(false, true, Ordering::Acquire, Ordering::Relaxed).is_err() {
        spin_loop();
    }
    LockGuard
}
impl Drop for LockGuard {
    fn drop(&mut self) { LOCKED.store(false, Ordering::Release); }
}

/// Perform one read-only PCI scan and retain a bounded device inventory.
/// Repeated calls return the first snapshot instead of rescanning hardware.
pub fn discover_pci() -> DeviceSummary {
    if INITIALIZED.load(Ordering::Acquire) { return stats(); }
    let _guard = lock();
    if INITIALIZED.load(Ordering::Relaxed) { return stats(); }
    let entries = unsafe { &mut *REGISTRY.0.get() };
    let mut recorded = 0usize;
    let scan = pci::enumerate(|device| {
        if recorded >= MAX_DEVICES { return; }
        entries[recorded] = Some(DeviceInfo {
            bus: device.bus,
            device: device.device,
            function: device.function,
            vendor_id: device.vendor_id,
            device_id: device.device_id,
            class_code: device.class_code,
            subclass: device.subclass,
            programming_interface: device.programming_interface,
            revision_id: device.revision_id,
            interrupt_pin: device.interrupt_pin,
            state: DeviceState::Discovered,
        });
        recorded += 1;
    });
    DISCOVERED.store(scan.devices_found, Ordering::Release);
    RECORDED.store(recorded, Ordering::Release);
    TRUNCATED.store(scan.devices_found > recorded || scan.truncated, Ordering::Release);
    INITIALIZED.store(true, Ordering::Release);
    DeviceSummary {
        discovered: scan.devices_found,
        recorded,
        truncated: scan.devices_found > recorded || scan.truncated,
        initialized: true,
    }
}

pub fn stats() -> DeviceSummary {
    DeviceSummary {
        discovered: DISCOVERED.load(Ordering::Acquire),
        recorded: RECORDED.load(Ordering::Acquire),
        truncated: TRUNCATED.load(Ordering::Acquire),
        initialized: INITIALIZED.load(Ordering::Acquire),
    }
}

/// Visit a stable copy of all retained device records.
pub fn visit(mut callback: impl FnMut(DeviceInfo)) {
    let mut snapshot = [None; MAX_DEVICES];
    {
        let _guard = lock();
        let entries = unsafe { &*REGISTRY.0.get() };
        snapshot.copy_from_slice(entries);
    }
    for entry in snapshot.into_iter().flatten() { callback(entry); }
}

pub const fn class_name(class: u8) -> &'static str {
    match class {
        0x01 => "mass-storage",
        0x02 => "network",
        0x03 => "display",
        0x04 => "multimedia",
        0x05 => "memory-controller",
        0x06 => "bridge",
        0x07 => "serial-communication",
        0x08 => "system-peripheral",
        0x09 => "input-device",
        0x0A => "docking-station",
        0x0B => "processor",
        0x0C => "serial-bus",
        0x0D => "wireless",
        0x0E => "intelligent-I/O",
        0x0F => "satellite-communication",
        0x10 => "encryption",
        0x11 => "signal-processing",
        0x12 => "processing-accelerator",
        0x13 => "non-essential-instrumentation",
        0x40 => "co-processor",
        0xFF => "vendor-specific",
        _ => "other",
    }
}

pub const fn subclass_name(class: u8, subclass: u8) -> &'static str {
    match (class, subclass) {
        (0x01, 0x01) => "IDE",
        (0x01, 0x06) => "SATA",
        (0x01, 0x08) => "NVMe",
        (0x02, 0x00) => "Ethernet",
        (0x03, 0x00) => "VGA-compatible",
        (0x06, 0x00) => "host-bridge",
        (0x06, 0x01) => "ISA-bridge",
        (0x06, 0x04) => "PCI-bridge",
        (0x0C, 0x03) => "USB-controller",
        (0x0C, 0x05) => "SMBus",
        (0x0C, 0x06) => "InfiniBand",
        _ => "generic",
    }
}
