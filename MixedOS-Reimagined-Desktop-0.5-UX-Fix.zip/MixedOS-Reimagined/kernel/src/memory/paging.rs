//! Safe, conservative four-level x86-64 page-table manager.
//!
//! Stage 4 deliberately keeps Limine's active CR3 root in place. It can inspect
//! existing mappings and add/remove 4 KiB mappings only after checking every
//! level. New intermediate tables come from the Stage 3 frame allocator and
//! are tracked separately so unmap can reclaim only tables MixedOS owns.
//! The manager is uniprocessor-only until an SMP shootdown protocol exists.

use core::arch::asm;
use core::hint::spin_loop;
use core::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};

use super::physical::{self, Frame, PAGE_SIZE};

const ENTRIES_PER_TABLE: usize = 512;
const PRESENT: u64 = 1 << 0;
const WRITABLE: u64 = 1 << 1;
const USER: u64 = 1 << 2;
#[allow(dead_code)] // Reserved for cache-policy mappings used by future device drivers.
const WRITE_THROUGH: u64 = 1 << 3;
#[allow(dead_code)] // Reserved for cache-policy mappings used by future device drivers.
const CACHE_DISABLE: u64 = 1 << 4;
const HUGE_PAGE: u64 = 1 << 7;
const GLOBAL: u64 = 1 << 8;
const NO_EXECUTE: u64 = 1 << 63;
const ADDRESS_LOW_MASK: u64 = 0x000f_ffff_ffff_f000;
const ADDRESS_BITS_FALLBACK: u8 = 36;
const MAX_PHYSICAL_ADDRESS_BITS: u8 = 52;
const MAX_OWNED_TABLES: usize = 256;
const TEST_SLOT_FIRST: usize = 128;
const TEST_SLOT_END: usize = 256;
const TEST_OFFSET: u64 = 0x20_0000;
const EFER_MSR: u32 = 0xC000_0080;
const EFER_NXE: u64 = 1 << 11;
const CR0_WP: u64 = 1 << 16;
const CR4_LA57: u64 = 1 << 12;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct PageFlags(u64);

#[allow(dead_code)] // Complete mapping-flag builder; additional device mappings will use these options.
impl PageFlags {
    /// Kernel read-only, non-executable mapping.
    pub const KERNEL_READ_ONLY: Self = Self(NO_EXECUTE);
    /// Kernel writable, non-executable mapping.
    pub const KERNEL_READ_WRITE: Self = Self(WRITABLE | NO_EXECUTE);
    /// Kernel read-only, executable mapping.
    pub const KERNEL_READ_EXECUTE: Self = Self(0);
    /// User-readable, non-executable mapping.
    pub const USER_READ_ONLY: Self = Self(USER | NO_EXECUTE);
    /// User-readable and writable, non-executable mapping.
    pub const USER_READ_WRITE: Self = Self(USER | WRITABLE | NO_EXECUTE);

    pub const fn writable(self) -> bool { self.0 & WRITABLE != 0 }
    pub const fn user_accessible(self) -> bool { self.0 & USER != 0 }
    pub const fn no_execute(self) -> bool { self.0 & NO_EXECUTE != 0 }
    pub const fn write_through(self) -> bool { self.0 & WRITE_THROUGH != 0 }
    pub const fn cache_disable(self) -> bool { self.0 & CACHE_DISABLE != 0 }
    pub const fn global(self) -> bool { self.0 & GLOBAL != 0 }
    pub const fn with_writable(self, enabled: bool) -> Self {
        if enabled { Self(self.0 | WRITABLE) } else { Self(self.0 & !WRITABLE) }
    }
    pub const fn with_user_accessible(self, enabled: bool) -> Self {
        if enabled { Self(self.0 | USER) } else { Self(self.0 & !USER) }
    }
    pub const fn with_no_execute(self, enabled: bool) -> Self {
        if enabled { Self(self.0 | NO_EXECUTE) } else { Self(self.0 & !NO_EXECUTE) }
    }
    pub const fn with_global(self, enabled: bool) -> Self {
        if enabled { Self(self.0 | GLOBAL) } else { Self(self.0 & !GLOBAL) }
    }
    pub const fn with_write_through(self, enabled: bool) -> Self {
        if enabled { Self(self.0 | WRITE_THROUGH) } else { Self(self.0 & !WRITE_THROUGH) }
    }
    pub const fn with_cache_disable(self, enabled: bool) -> Self {
        if enabled { Self(self.0 | CACHE_DISABLE) } else { Self(self.0 & !CACHE_DISABLE) }
    }

    const fn entry_bits(self) -> u64 { self.0 }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[allow(dead_code)] // Variants describe validated failure modes not reached by the current boot path.
pub enum PagingError {
    NotInitialized,
    PhysicalAllocatorUnavailable,
    HhdmUnavailable,
    FiveLevelPagingActive,
    InvalidRootTable,
    InvalidPhysicalAddress,
    UnalignedVirtualAddress,
    NonCanonicalVirtualAddress,
    UserMappingOutsideUserHalf,
    FrameNotOwned,
    NxUnavailable,
    NotMapped,
    AlreadyMapped,
    NonPresentEntryConflict,
    HugePageConflict,
    PermissionConflict,
    WriteProtectUnavailable,
    OutOfFrames,
    OwnedTableRegistryFull,
    TableAccessFailed,
    TestRangeUnavailable,
    TranslationMismatch,
    CleanupFailed,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Translation {
    pub physical_address: u64,
    pub page_size: u64,
    pub writable: bool,
    pub user_accessible: bool,
    pub no_execute: bool,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct PagingStats {
    pub initialized: bool,
    pub root_physical_address: u64,
    pub physical_address_bits: u8,
    pub nx_supported: bool,
    pub nx_enabled: bool,
    pub write_protect_enabled: bool,
    pub la57_enabled: bool,
    pub owned_table_pages: usize,
    pub map_calls: u64,
    pub unmap_calls: u64,
    pub map_failures: u64,
    pub tlb_invalidations: u64,
}

struct LockGuard;
static LOCKED: AtomicBool = AtomicBool::new(false);
static INITIALIZED: AtomicBool = AtomicBool::new(false);
static ROOT_PHYSICAL: AtomicU64 = AtomicU64::new(0);
static PHYSICAL_BITS: AtomicUsize = AtomicUsize::new(ADDRESS_BITS_FALLBACK as usize);
static NX_SUPPORTED: AtomicBool = AtomicBool::new(false);
static NX_ENABLED: AtomicBool = AtomicBool::new(false);
static WP_ENABLED: AtomicBool = AtomicBool::new(false);
static LA57_ENABLED: AtomicBool = AtomicBool::new(false);
static OWNED_TABLE_COUNT: AtomicUsize = AtomicUsize::new(0);
static MAP_CALLS: AtomicU64 = AtomicU64::new(0);
static UNMAP_CALLS: AtomicU64 = AtomicU64::new(0);
static MAP_FAILURES: AtomicU64 = AtomicU64::new(0);
static TLB_INVALIDATIONS: AtomicU64 = AtomicU64::new(0);

struct OwnedTables(UnsafeOwnedTables);
struct UnsafeOwnedTables(core::cell::UnsafeCell<[u64; MAX_OWNED_TABLES]>);
unsafe impl Sync for OwnedTables {}
static OWNED_TABLES: OwnedTables = OwnedTables(UnsafeOwnedTables(core::cell::UnsafeCell::new([0; MAX_OWNED_TABLES])));

#[derive(Clone, Copy)]
struct CreatedTable {
    parent_entry: *mut u64,
    frame: Frame,
}

fn lock() -> LockGuard {
    while LOCKED.compare_exchange_weak(false, true, Ordering::Acquire, Ordering::Relaxed).is_err() {
        spin_loop();
    }
    LockGuard
}

impl Drop for LockGuard {
    fn drop(&mut self) { LOCKED.store(false, Ordering::Release); }
}

/// Inspect Limine's live page-table root and enable only architectural support
/// bits needed by this manager. CR3 is never replaced during initialization.
pub fn initialize() -> bool {
    if INITIALIZED.load(Ordering::Acquire) { return true; }
    if !physical::stats().initialized { return false; }
    if !physical::stats().hhdm_ready { return false; }

    let _guard = lock();
    if INITIALIZED.load(Ordering::Relaxed) { return true; }

    let cr3: u64;
    let cr4: u64;
    unsafe {
        asm!("mov {}, cr3", out(reg) cr3, options(nostack, preserves_flags));
        asm!("mov {}, cr4", out(reg) cr4, options(nostack, preserves_flags));
    }
    let la57 = cr4 & CR4_LA57 != 0;
    LA57_ENABLED.store(la57, Ordering::Release);
    if la57 { return false; }

    let (physical_bits, nx_supported) = cpu_memory_features();
    PHYSICAL_BITS.store(physical_bits as usize, Ordering::Release);
    NX_SUPPORTED.store(nx_supported, Ordering::Release);

    let physical_mask = address_mask();
    let root = cr3 & physical_mask;
    if root == 0 || root & (PAGE_SIZE - 1) != 0 || table_pointer(root).is_err() {
        return false;
    }

    let nx_enabled = if nx_supported { enable_nx() } else { false };
    NX_ENABLED.store(nx_enabled, Ordering::Release);

    let mut cr0: u64;
    unsafe { asm!("mov {}, cr0", out(reg) cr0, options(nostack, preserves_flags)); }
    cr0 |= CR0_WP;
    unsafe { asm!("mov cr0, {}", in(reg) cr0, options(nostack, preserves_flags)); }
    let verified_cr0: u64;
    unsafe { asm!("mov {}, cr0", out(reg) verified_cr0, options(nostack, preserves_flags)); }
    WP_ENABLED.store(verified_cr0 & CR0_WP != 0, Ordering::Release);

    ROOT_PHYSICAL.store(root, Ordering::Release);
    INITIALIZED.store(true, Ordering::Release);
    true
}

fn cpu_memory_features() -> (u8, bool) {
    let max = core::arch::x86_64::__cpuid(0x8000_0000).eax;
    if max < 0x8000_0001 { return (ADDRESS_BITS_FALLBACK, false); }
    let extended = core::arch::x86_64::__cpuid(0x8000_0001);
    let nx = extended.edx & (1 << 20) != 0;
    let bits = if max >= 0x8000_0008 {
        let reported = (core::arch::x86_64::__cpuid(0x8000_0008).eax & 0xff) as u8;
        if (32..=MAX_PHYSICAL_ADDRESS_BITS).contains(&reported) { reported } else { ADDRESS_BITS_FALLBACK }
    } else {
        ADDRESS_BITS_FALLBACK
    };
    (bits, nx)
}

fn enable_nx() -> bool {
    let low: u32;
    let high: u32;
    unsafe {
        asm!("rdmsr", in("ecx") EFER_MSR, out("eax") low, out("edx") high, options(nostack));
    }
    let current = ((high as u64) << 32) | low as u64;
    let desired = current | EFER_NXE;
    if desired != current {
        unsafe {
            asm!(
                "wrmsr",
                in("ecx") EFER_MSR,
                in("eax") desired as u32,
                in("edx") (desired >> 32) as u32,
                options(nostack)
            );
        }
    }
    let verify_low: u32;
    let verify_high: u32;
    unsafe {
        asm!("rdmsr", in("ecx") EFER_MSR, out("eax") verify_low, out("edx") verify_high, options(nostack));
    }
    (((verify_high as u64) << 32) | verify_low as u64) & EFER_NXE != 0
}

fn address_mask() -> u64 {
    let bits = PHYSICAL_BITS.load(Ordering::Acquire).clamp(32, MAX_PHYSICAL_ADDRESS_BITS as usize) as u32;
    ((1u64 << bits) - 1) & ADDRESS_LOW_MASK
}

fn table_pointer(physical_address: u64) -> Result<*mut u64, PagingError> {
    if physical_address & (PAGE_SIZE - 1) != 0 || physical_address & !address_mask() != 0 {
        return Err(PagingError::InvalidPhysicalAddress);
    }
    let pointer = physical::hhdm_pointer_for_page_table(physical_address)
        .ok_or(PagingError::HhdmUnavailable)?;
    Ok(pointer.cast::<u64>().as_ptr())
}

#[inline]
unsafe fn read_entry(table: *mut u64, index: usize) -> u64 {
    unsafe { table.add(index).read_volatile() }
}

#[inline]
unsafe fn write_entry(table: *mut u64, index: usize, value: u64) {
    unsafe { table.add(index).write_volatile(value); }
}

#[inline]
fn indices(address: u64) -> [usize; 4] {
    [
        ((address >> 39) & 0x1ff) as usize,
        ((address >> 30) & 0x1ff) as usize,
        ((address >> 21) & 0x1ff) as usize,
        ((address >> 12) & 0x1ff) as usize,
    ]
}

#[inline]
fn is_canonical(address: u64) -> bool {
    let upper = address >> 48;
    let sign = (address >> 47) & 1;
    if sign == 0 { upper == 0 } else { upper == 0xffff }
}

#[inline]
fn invalidate(address: u64) {
    unsafe { asm!("invlpg [{}]", in(reg) address, options(nostack, preserves_flags)); }
    TLB_INVALIDATIONS.fetch_add(1, Ordering::Relaxed);
}

fn register_owned_table(frame: Frame) -> Result<(), PagingError> {
    let tables = unsafe { &mut *OWNED_TABLES.0.0.get() };
    for existing in tables.iter() {
        if *existing == frame.physical_address() { return Ok(()); }
    }
    for slot in tables.iter_mut() {
        if *slot == 0 {
            *slot = frame.physical_address();
            OWNED_TABLE_COUNT.fetch_add(1, Ordering::Relaxed);
            return Ok(());
        }
    }
    Err(PagingError::OwnedTableRegistryFull)
}

fn unregister_owned_table(physical_address: u64) -> bool {
    let tables = unsafe { &mut *OWNED_TABLES.0.0.get() };
    for slot in tables.iter_mut() {
        if *slot == physical_address {
            *slot = 0;
            OWNED_TABLE_COUNT.fetch_sub(1, Ordering::Relaxed);
            return true;
        }
    }
    false
}

fn is_owned_table(physical_address: u64) -> bool {
    let tables = unsafe { &*OWNED_TABLES.0.0.get() };
    tables.iter().any(|entry| *entry == physical_address)
}

fn validate_parent_permissions(entry: u64, flags: PageFlags) -> Result<(), PagingError> {
    if flags.user_accessible() && entry & USER == 0 { return Err(PagingError::PermissionConflict); }
    if flags.writable() && entry & WRITABLE == 0 { return Err(PagingError::PermissionConflict); }
    if !flags.no_execute() && NX_ENABLED.load(Ordering::Acquire) && entry & NO_EXECUTE != 0 {
        return Err(PagingError::PermissionConflict);
    }
    Ok(())
}

fn next_table(
    parent: *mut u64,
    index: usize,
    flags: PageFlags,
    created: &mut [Option<CreatedTable>; 3],
    created_count: &mut usize,
) -> Result<*mut u64, PagingError> {
    let entry = unsafe { read_entry(parent, index) };
    if entry & PRESENT != 0 {
        if entry & HUGE_PAGE != 0 { return Err(PagingError::HugePageConflict); }
        validate_parent_permissions(entry, flags)?;
        let child_physical = entry & address_mask();
        return table_pointer(child_physical);
    }
    if entry != 0 { return Err(PagingError::NonPresentEntryConflict); }

    let frame = physical::allocate_zeroed_frame().ok_or(PagingError::OutOfFrames)?;
    let child_pointer = match physical::frame_to_hhdm(frame) {
        Some(pointer) => pointer.cast::<u64>().as_ptr(),
        None => {
            let _ = physical::free_frame(frame);
            return Err(PagingError::HhdmUnavailable);
        }
    };
    if let Err(error) = register_owned_table(frame) {
        let _ = physical::free_frame(frame);
        return Err(error);
    }

    let mut new_entry = frame.physical_address() | PRESENT | WRITABLE;
    if flags.user_accessible() { new_entry |= USER; }
    core::sync::atomic::fence(Ordering::Release);
    unsafe { write_entry(parent, index, new_entry); }
    created[*created_count] = Some(CreatedTable { parent_entry: unsafe { parent.add(index) }, frame });
    *created_count += 1;
    Ok(child_pointer)
}

fn rollback_created_tables(
    created: &[Option<CreatedTable>; 3],
    count: usize,
    address: u64,
) -> Result<(), PagingError> {
    let mut cleanup_ok = true;
    for item in created.iter().take(count).rev().flatten() {
        // Remove the parent link and invalidate the address before returning
        // the child table frame to the allocator. This avoids even a brief
        // stale paging-structure/TLB reference to memory that can be reused.
        unsafe { item.parent_entry.write_volatile(0); }
        invalidate(address);
        let physical_address = item.frame.physical_address();
        if !unregister_owned_table(physical_address) { cleanup_ok = false; }
        // The parent link is now detached, so returning this frame is safe
        // even if the ownership registry itself has become inconsistent.
        if physical::free_frame(item.frame).is_err() { cleanup_ok = false; }
    }
    if cleanup_ok { Ok(()) } else { Err(PagingError::CleanupFailed) }
}

/// Add one 4 KiB mapping in the currently active Limine page-table tree.
/// `frame` must remain allocated while mapped; the caller retains ownership and
/// may free it only after a successful `unmap_page`.
pub fn map_page(address: u64, frame: Frame, flags: PageFlags) -> Result<(), PagingError> {
    MAP_CALLS.fetch_add(1, Ordering::Relaxed);
    let result = map_page_inner(address, frame, flags);
    if result.is_err() { MAP_FAILURES.fetch_add(1, Ordering::Relaxed); }
    result
}

fn map_page_inner(address: u64, frame: Frame, flags: PageFlags) -> Result<(), PagingError> {
    if !INITIALIZED.load(Ordering::Acquire) { return Err(PagingError::NotInitialized); }
    if address & (PAGE_SIZE - 1) != 0 { return Err(PagingError::UnalignedVirtualAddress); }
    if !is_canonical(address) { return Err(PagingError::NonCanonicalVirtualAddress); }
    if flags.user_accessible() && address >= 0x0000_8000_0000_0000 {
        return Err(PagingError::UserMappingOutsideUserHalf);
    }
    if flags.user_accessible() && flags.global() {
        return Err(PagingError::PermissionConflict);
    }
    if flags.no_execute() && !NX_ENABLED.load(Ordering::Acquire) {
        return Err(PagingError::NxUnavailable);
    }
    if !flags.writable() && !WP_ENABLED.load(Ordering::Acquire) {
        return Err(PagingError::WriteProtectUnavailable);
    }
    let physical_address = frame.physical_address();
    if physical_address & (PAGE_SIZE - 1) != 0 || physical_address & !address_mask() != 0 {
        return Err(PagingError::InvalidPhysicalAddress);
    }
    if physical::frame_to_hhdm(frame).is_none() { return Err(PagingError::FrameNotOwned); }

    let _guard = lock();
    let root = table_pointer(ROOT_PHYSICAL.load(Ordering::Acquire))?;
    let ix = indices(address);
    let mut created = [None; 3];
    let mut created_count = 0usize;

    let pdpt = match next_table(root, ix[0], flags, &mut created, &mut created_count) {
        Ok(value) => value,
        Err(error) => {
            if rollback_created_tables(&created, created_count, address).is_err() {
                return Err(PagingError::CleanupFailed);
            }
            return Err(error);
        }
    };
    let pd = match next_table(pdpt, ix[1], flags, &mut created, &mut created_count) {
        Ok(value) => value,
        Err(error) => {
            if rollback_created_tables(&created, created_count, address).is_err() {
                return Err(PagingError::CleanupFailed);
            }
            return Err(error);
        }
    };
    let pt = match next_table(pd, ix[2], flags, &mut created, &mut created_count) {
        Ok(value) => value,
        Err(error) => {
            if rollback_created_tables(&created, created_count, address).is_err() {
                return Err(PagingError::CleanupFailed);
            }
            return Err(error);
        }
    };

    let existing = unsafe { read_entry(pt, ix[3]) };
    if existing & PRESENT != 0 {
        if rollback_created_tables(&created, created_count, address).is_err() {
            return Err(PagingError::CleanupFailed);
        }
        return Err(PagingError::AlreadyMapped);
    }
    if existing != 0 {
        if rollback_created_tables(&created, created_count, address).is_err() {
            return Err(PagingError::CleanupFailed);
        }
        return Err(PagingError::NonPresentEntryConflict);
    }

    let mut entry = physical_address | PRESENT | flags.entry_bits();
    if flags.no_execute() { entry |= NO_EXECUTE; }
    core::sync::atomic::fence(Ordering::Release);
    unsafe { write_entry(pt, ix[3], entry); }
    invalidate(address);
    Ok(())
}

/// Remove a 4 KiB mapping and return its physical address. Empty intermediate
/// tables are reclaimed only when they are in this manager's ownership list.
pub fn unmap_page(address: u64) -> Result<u64, PagingError> {
    if !INITIALIZED.load(Ordering::Acquire) { return Err(PagingError::NotInitialized); }
    if address & (PAGE_SIZE - 1) != 0 { return Err(PagingError::UnalignedVirtualAddress); }
    if !is_canonical(address) { return Err(PagingError::NonCanonicalVirtualAddress); }

    let _guard = lock();
    let root = table_pointer(ROOT_PHYSICAL.load(Ordering::Acquire))?;
    let ix = indices(address);
    let pml4_entry_ptr = unsafe { root.add(ix[0]) };
    let pml4_entry = unsafe { pml4_entry_ptr.read_volatile() };
    if pml4_entry & PRESENT == 0 { return Err(PagingError::NotMapped); }
    if pml4_entry & HUGE_PAGE != 0 { return Err(PagingError::HugePageConflict); }
    let pdpt_physical = pml4_entry & address_mask();
    let pdpt = table_pointer(pdpt_physical)?;

    let pdpt_entry_ptr = unsafe { pdpt.add(ix[1]) };
    let pdpt_entry = unsafe { pdpt_entry_ptr.read_volatile() };
    if pdpt_entry & PRESENT == 0 { return Err(PagingError::NotMapped); }
    if pdpt_entry & HUGE_PAGE != 0 { return Err(PagingError::HugePageConflict); }
    let pd_physical = pdpt_entry & address_mask();
    let pd = table_pointer(pd_physical)?;

    let pd_entry_ptr = unsafe { pd.add(ix[2]) };
    let pd_entry = unsafe { pd_entry_ptr.read_volatile() };
    if pd_entry & PRESENT == 0 { return Err(PagingError::NotMapped); }
    if pd_entry & HUGE_PAGE != 0 { return Err(PagingError::HugePageConflict); }
    let pt_physical = pd_entry & address_mask();
    let pt = table_pointer(pt_physical)?;

    let pte = unsafe { read_entry(pt, ix[3]) };
    if pte & PRESENT == 0 { return Err(PagingError::NotMapped); }
    let mapped_physical = pte & address_mask();
    if !physical::is_allocated_frame_address(mapped_physical) {
        return Err(PagingError::FrameNotOwned);
    }
    unsafe { write_entry(pt, ix[3], 0); }
    invalidate(address);
    UNMAP_CALLS.fetch_add(1, Ordering::Relaxed);

    // Prune in leaf-to-root order. Bootloader-owned tables are never freed or
    // detached; only empty tables registered by MixedOS are reclaimed.
    let candidates = [
        (pd_entry_ptr, pt_physical),
        (pdpt_entry_ptr, pd_physical),
        (pml4_entry_ptr, pdpt_physical),
    ];
    for (parent_entry, child_physical) in candidates {
        if !is_owned_table(child_physical) { break; }
        if !table_is_empty(child_physical)? { break; }
        unsafe { parent_entry.write_volatile(0); }
        invalidate(address);
        if !unregister_owned_table(child_physical) { return Err(PagingError::CleanupFailed); }
        physical::free_allocated_frame_at(child_physical).map_err(|_| PagingError::CleanupFailed)?;
    }

    Ok(mapped_physical)
}

fn table_is_empty(physical_address: u64) -> Result<bool, PagingError> {
    let table = table_pointer(physical_address)?;
    for index in 0..ENTRIES_PER_TABLE {
        if unsafe { read_entry(table, index) } != 0 { return Ok(false); }
    }
    Ok(true)
}

/// Translate an address using the active four-level tree. Existing 1 GiB and
/// 2 MiB bootloader huge pages are reported without modifying or splitting them.
pub fn translate(address: u64) -> Result<Translation, PagingError> {
    if !INITIALIZED.load(Ordering::Acquire) { return Err(PagingError::NotInitialized); }
    if !is_canonical(address) { return Err(PagingError::NonCanonicalVirtualAddress); }
    let _guard = lock();
    let root = table_pointer(ROOT_PHYSICAL.load(Ordering::Acquire))?;
    let ix = indices(address);
    let mut writable = true;
    let mut user_accessible = true;
    let mut no_execute = false;

    let pml4e = unsafe { read_entry(root, ix[0]) };
    if pml4e & PRESENT == 0 { return Err(PagingError::NotMapped); }
    if pml4e & HUGE_PAGE != 0 { return Err(PagingError::HugePageConflict); }
    writable &= pml4e & WRITABLE != 0;
    user_accessible &= pml4e & USER != 0;
    no_execute |= pml4e & NO_EXECUTE != 0;
    let pdpt = table_pointer(pml4e & address_mask())?;

    let pdpte = unsafe { read_entry(pdpt, ix[1]) };
    if pdpte & PRESENT == 0 { return Err(PagingError::NotMapped); }
    writable &= pdpte & WRITABLE != 0;
    user_accessible &= pdpte & USER != 0;
    no_execute |= pdpte & NO_EXECUTE != 0;
    if pdpte & HUGE_PAGE != 0 {
        let size = 1u64 << 30;
        let base = (pdpte & address_mask()) & !(size - 1);
        return Ok(Translation {
            physical_address: base | (address & (size - 1)),
            page_size: size,
            writable,
            user_accessible,
            no_execute,
        });
    }
    let pd = table_pointer(pdpte & address_mask())?;

    let pde = unsafe { read_entry(pd, ix[2]) };
    if pde & PRESENT == 0 { return Err(PagingError::NotMapped); }
    writable &= pde & WRITABLE != 0;
    user_accessible &= pde & USER != 0;
    no_execute |= pde & NO_EXECUTE != 0;
    if pde & HUGE_PAGE != 0 {
        let size = 1u64 << 21;
        let base = (pde & address_mask()) & !(size - 1);
        return Ok(Translation {
            physical_address: base | (address & (size - 1)),
            page_size: size,
            writable,
            user_accessible,
            no_execute,
        });
    }
    let pt = table_pointer(pde & address_mask())?;

    let pte = unsafe { read_entry(pt, ix[3]) };
    if pte & PRESENT == 0 { return Err(PagingError::NotMapped); }
    writable &= pte & WRITABLE != 0;
    user_accessible &= pte & USER != 0;
    no_execute |= pte & NO_EXECUTE != 0;
    Ok(Translation {
        physical_address: (pte & address_mask()) | (address & (PAGE_SIZE - 1)),
        page_size: PAGE_SIZE,
        writable,
        user_accessible,
        no_execute,
    })
}

fn find_unused_user_slot() -> Option<u64> {
    let root = table_pointer(ROOT_PHYSICAL.load(Ordering::Acquire)).ok()?;
    for index in (TEST_SLOT_FIRST..TEST_SLOT_END).chain(1..TEST_SLOT_FIRST) {
        if unsafe { read_entry(root, index) } == 0 {
            let address = ((index as u64) << 39) | TEST_OFFSET;
            if is_canonical(address) { return Some(address); }
        }
    }
    None
}

/// Real mapping/TLB test. It maps two allocator-owned frames into a previously
/// unused PML4 slot, performs volatile accesses through the new virtual aliases,
/// checks user/supervisor and NX bits, unmaps both pages, and verifies that all
/// temporary page-table pages and data frames were returned.
pub fn self_test() -> Result<usize, PagingError> {
    if !INITIALIZED.load(Ordering::Acquire) { return Err(PagingError::NotInitialized); }
    if !NX_ENABLED.load(Ordering::Acquire) { return Err(PagingError::NxUnavailable); }
    let before = stats();
    let base = {
        let _guard = lock();
        find_unused_user_slot().ok_or(PagingError::TestRangeUnavailable)?
    };
    let before_physical = physical::stats();
    let first = physical::allocate_zeroed_frame().ok_or(PagingError::OutOfFrames)?;
    let second = match physical::allocate_zeroed_frame() {
        Some(frame) => frame,
        None => { let _ = physical::free_frame(first); return Err(PagingError::OutOfFrames); }
    };

    if let Err(error) = map_page(base, first, PageFlags::USER_READ_WRITE) {
        let _ = physical::free_frame(first);
        let _ = physical::free_frame(second);
        return Err(error);
    }
    if let Err(error) = map_page(base + PAGE_SIZE, second, PageFlags::KERNEL_READ_WRITE) {
        match unmap_page(base) {
            Ok(mapped) if mapped == first.physical_address() => {
                if physical::free_frame(first).is_err() { return Err(PagingError::CleanupFailed); }
            }
            _ => {
                // Do not return a frame to the allocator while a mapping might
                // still reference it. The test reports the incomplete cleanup.
                let _ = physical::free_frame(second);
                return Err(PagingError::CleanupFailed);
            }
        }
        let _ = physical::free_frame(second);
        return Err(error);
    }

    let second_pattern = 0x4D49_5845_4456_4D32u64;
    // Use the supervisor-only alias for hardware loads/stores. The first page
    // is user-accessible in its leaf permissions; we inspect it via the walker
    // without depending on whether the bootloader enabled CR4.SMAP.
    unsafe { ((base + PAGE_SIZE) as *mut u64).write_volatile(second_pattern); }
    let second_readback = unsafe { ((base + PAGE_SIZE) as *const u64).read_volatile() };
    let first_translation = translate(base);
    let second_translation = translate(base + PAGE_SIZE);

    let verification_ok = second_readback == second_pattern
        && first_translation.is_ok_and(|t| {
            t.physical_address & !(PAGE_SIZE - 1) == first.physical_address()
                && t.page_size == PAGE_SIZE && t.writable && t.user_accessible && t.no_execute
        })
        && second_translation.is_ok_and(|t| {
            t.physical_address & !(PAGE_SIZE - 1) == second.physical_address()
                && t.page_size == PAGE_SIZE && t.writable && !t.user_accessible && t.no_execute
        });

    let unmap_first = unmap_page(base);
    let unmap_second = unmap_page(base + PAGE_SIZE);
    if unmap_first == Ok(first.physical_address()) {
        if physical::free_frame(first).is_err() { return Err(PagingError::CleanupFailed); }
    } else {
        // Keep the frame allocated if a mapping may still reference it.
        return Err(PagingError::CleanupFailed);
    }
    if unmap_second == Ok(second.physical_address()) {
        if physical::free_frame(second).is_err() { return Err(PagingError::CleanupFailed); }
    } else {
        return Err(PagingError::CleanupFailed);
    }

    let after = stats();
    let physical_after = physical::stats();
    if !verification_ok { return Err(PagingError::TranslationMismatch); }
    if after.owned_table_pages != before.owned_table_pages
        || physical_after.allocated_frames != before_physical.allocated_frames
        || physical_after.free_frames != before_physical.free_frames
        || physical_after.free_errors != before_physical.free_errors
    {
        return Err(PagingError::CleanupFailed);
    }
    if translate(base) != Err(PagingError::NotMapped)
        || translate(base + PAGE_SIZE) != Err(PagingError::NotMapped)
    {
        return Err(PagingError::CleanupFailed);
    }
    Ok(2)
}

pub fn stats() -> PagingStats {
    PagingStats {
        initialized: INITIALIZED.load(Ordering::Acquire),
        root_physical_address: ROOT_PHYSICAL.load(Ordering::Relaxed),
        physical_address_bits: PHYSICAL_BITS.load(Ordering::Relaxed) as u8,
        nx_supported: NX_SUPPORTED.load(Ordering::Acquire),
        nx_enabled: NX_ENABLED.load(Ordering::Acquire),
        write_protect_enabled: WP_ENABLED.load(Ordering::Acquire),
        la57_enabled: LA57_ENABLED.load(Ordering::Acquire),
        owned_table_pages: OWNED_TABLE_COUNT.load(Ordering::Relaxed),
        map_calls: MAP_CALLS.load(Ordering::Relaxed),
        unmap_calls: UNMAP_CALLS.load(Ordering::Relaxed),
        map_failures: MAP_FAILURES.load(Ordering::Relaxed),
        tlb_invalidations: TLB_INVALIDATIONS.load(Ordering::Relaxed),
    }
}
