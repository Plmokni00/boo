//! Kernel heap backed by Stage 3 physical frames and Stage 4 virtual mappings.
//!
//! This is an explicit kernel allocation API (not Rust's global allocator yet).
//! It is single-core / non-interrupt-context only until the scheduler and IRQ
//! locking rules are in place. Every heap page is mapped into a reserved
//! high-half arena; free blocks are address-sorted and coalesced on release.

use core::cell::UnsafeCell;
use core::hint::spin_loop;
use core::ptr::NonNull;
use core::sync::atomic::{AtomicBool, Ordering};

use super::{paging::{self, PageFlags}, physical};

const PAGE_SIZE: usize = physical::PAGE_SIZE as usize;
const BLOCK_MAGIC: u64 = 0x4D49_5848_4652_4545; // "MIXHFREE"
const ALLOC_MAGIC: u64 = 0x4D49_5848_414C_4C4F; // "MIXHALLO"
const FREED_MAGIC: u64 = 0x4D49_5848_4652_4544; // "MIXHFRED"
const ALIGNMENT: usize = 16;
const MIN_USER_OFFSET: usize = 64; // Keep allocation header clear of FreeBlock metadata.
const INITIAL_GROW_PAGES: usize = 4;
const MAX_HEAP_PAGES: usize = 4096; // 16 MiB virtual arena; grows only on demand.
const MAX_ALIGNMENT: usize = 2 * 1024 * 1024;
const MAX_LIST_STEPS: usize = (MAX_HEAP_PAGES * PAGE_SIZE) / core::mem::size_of::<FreeBlock>() + 1;
const HEAP_BASE_CANDIDATES: [u64; 3] = [
    0xFFFF_FE80_0000_0000, // PML4 slot 509
    0xFFFF_FF00_0000_0000, // PML4 slot 510
    0xFFFF_FE00_0000_0000, // PML4 slot 508
];

#[repr(C, align(16))]
struct FreeBlock {
    magic: u64,
    size: usize,
    previous: *mut FreeBlock,
    next: *mut FreeBlock,
}

#[repr(C)]
#[derive(Clone, Copy)]
struct AllocationHeader {
    magic: u64,
    block_start: u64,
    block_size: u64,
    requested_size: u64,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum HeapError {
    NotInitialized,
    InvalidAlignment,
    OutOfMemory,
    AddressOverflow,
    MappingFailed,
    UnmappingFailed,
    CorruptFreeList,
    InvalidPointer,
    DoubleFree,
    OverlappingFreeBlock,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct HeapStats {
    pub initialized: bool,
    pub base: u64,
    pub mapped_pages: usize,
    pub capacity_bytes: usize,
    pub used_bytes: usize,
    pub free_bytes: usize,
    pub largest_free_block: usize,
    pub free_blocks: usize,
    pub active_allocations: usize,
    pub peak_used_bytes: usize,
    pub allocation_calls: u64,
    pub allocation_failures: u64,
    pub free_calls: u64,
    pub free_errors: u64,
}

struct HeapState {
    initialized: bool,
    base: u64,
    mapped_pages: usize,
    free_head: *mut FreeBlock,
    used_bytes: usize,
    peak_used_bytes: usize,
    active_allocations: usize,
    allocation_calls: u64,
    allocation_failures: u64,
    free_calls: u64,
    free_errors: u64,
}

impl HeapState {
    const fn new() -> Self {
        Self {
            initialized: false,
            base: 0,
            mapped_pages: 0,
            free_head: core::ptr::null_mut(),
            used_bytes: 0,
            peak_used_bytes: 0,
            active_allocations: 0,
            allocation_calls: 0,
            allocation_failures: 0,
            free_calls: 0,
            free_errors: 0,
        }
    }
}

struct StateCell(UnsafeCell<HeapState>);
unsafe impl Sync for StateCell {}
static STATE: StateCell = StateCell(UnsafeCell::new(HeapState::new()));
static LOCKED: AtomicBool = AtomicBool::new(false);

struct LockGuard;
fn lock() -> LockGuard {
    while LOCKED.compare_exchange_weak(false, true, Ordering::Acquire, Ordering::Relaxed).is_err() {
        spin_loop();
    }
    LockGuard
}
impl Drop for LockGuard {
    fn drop(&mut self) { LOCKED.store(false, Ordering::Release); }
}

#[inline]
fn state_mut() -> &'static mut HeapState {
    // All callers hold LOCKED. The heap is currently a single-core subsystem.
    unsafe { &mut *STATE.0.get() }
}

#[inline]
fn align_up(value: usize, alignment: usize) -> Option<usize> {
    value.checked_add(alignment - 1).map(|v| v & !(alignment - 1))
}

#[inline]
fn block_ptr(address: usize) -> *mut FreeBlock { address as *mut FreeBlock }

unsafe fn block_size(block: *mut FreeBlock) -> Result<usize, HeapError> {
    if block.is_null() { return Err(HeapError::CorruptFreeList); }
    let value = unsafe { &*block };
    if value.magic != BLOCK_MAGIC || value.size < core::mem::size_of::<FreeBlock>() || value.size & (ALIGNMENT - 1) != 0 {
        return Err(HeapError::CorruptFreeList);
    }
    Ok(value.size)
}

/// Initialize the heap after the physical allocator and paging manager.
/// Candidate regions are tried only when a prior candidate collides with a
/// bootloader mapping. Existing mappings are never replaced.
pub fn initialize() -> bool {
    if !physical::stats().initialized || !physical::stats().hhdm_ready || !paging::stats().initialized {
        return false;
    }

    let _guard = lock();
    let state = state_mut();
    if state.initialized { return true; }

    for base in HEAP_BASE_CANDIDATES {
        state.base = base;
        state.mapped_pages = 0;
        state.free_head = core::ptr::null_mut();
        match grow_locked(state, INITIAL_GROW_PAGES) {
            Ok(()) => {
                state.initialized = true;
                return true;
            }
            Err(HeapError::UnmappingFailed | HeapError::CorruptFreeList | HeapError::OverlappingFreeBlock) => {
                // A failed rollback or allocator invariant is not a recoverable
                // address collision. Stop rather than trying another arena.
                state.base = 0;
                return false;
            }
            Err(_) => {
                // Address collision / unavailable frame: try another reserved slot.
                state.mapped_pages = 0;
                state.free_head = core::ptr::null_mut();
            }
        }
    }
    state.base = 0;
    false
}

fn rollback_pages(base: u64, mapped: usize) -> Result<(), HeapError> {
    let mut ok = true;
    for index in (0..mapped).rev() {
        let address = base + (index * PAGE_SIZE) as u64;
        match paging::unmap_page(address) {
            Ok(physical_address) => {
                if physical::free_allocated_frame_at(physical_address).is_err() { ok = false; }
            }
            Err(_) => ok = false,
        }
    }
    if ok { Ok(()) } else { Err(HeapError::UnmappingFailed) }
}

fn grow_locked(state: &mut HeapState, requested_pages: usize) -> Result<(), HeapError> {
    if requested_pages == 0 { return Ok(()); }
    if state.base == 0 || state.mapped_pages.checked_add(requested_pages).is_none_or(|n| n > MAX_HEAP_PAGES) {
        return Err(HeapError::OutOfMemory);
    }
    let pages = requested_pages;
    let bytes = pages.checked_mul(PAGE_SIZE).ok_or(HeapError::AddressOverflow)?;
    let bytes_u64 = u64::try_from(bytes).map_err(|_| HeapError::AddressOverflow)?;
    let start = state.base.checked_add((state.mapped_pages * PAGE_SIZE) as u64).ok_or(HeapError::AddressOverflow)?;
    let _end = start.checked_add(bytes_u64).ok_or(HeapError::AddressOverflow)?;
    let start_pointer = usize::try_from(start).map_err(|_| HeapError::AddressOverflow)?;
    let mut mapped = 0usize;

    for index in 0..pages {
        let frame = match physical::allocate_zeroed_frame() {
            Some(value) => value,
            None => {
                rollback_pages(start, mapped)?;
                return Err(HeapError::OutOfMemory);
            }
        };
        // The complete range was checked above, so this cannot overflow.
        let address = start + (index * PAGE_SIZE) as u64;
        if paging::map_page(address, frame, PageFlags::KERNEL_READ_WRITE).is_err() {
            let frame_released = physical::free_frame(frame).is_ok();
            let rollback = rollback_pages(start, mapped);
            if !frame_released || rollback.is_err() { return Err(HeapError::UnmappingFailed); }
            return Err(HeapError::MappingFailed);
        }
        mapped += 1;
    }

    let new_block = block_ptr(start_pointer);
    unsafe {
        new_block.write(FreeBlock {
            magic: BLOCK_MAGIC,
            size: bytes,
            previous: core::ptr::null_mut(),
            next: core::ptr::null_mut(),
        });
    }
    if let Err(error) = insert_free_block(state, new_block) {
        rollback_pages(start, mapped)?;
        return Err(error);
    }
    state.mapped_pages += pages;
    Ok(())
}

fn insert_free_block(state: &mut HeapState, block: *mut FreeBlock) -> Result<(), HeapError> {
    let start = block as usize;
    let size = unsafe { block_size(block)? };
    let end = start.checked_add(size).ok_or(HeapError::AddressOverflow)?;
    let mut previous: *mut FreeBlock = core::ptr::null_mut();
    let mut current = state.free_head;
    let mut steps = 0usize;

    while !current.is_null() && (current as usize) < start {
        steps += 1;
        if steps > MAX_LIST_STEPS { return Err(HeapError::CorruptFreeList); }
        unsafe { block_size(current)?; }
        previous = current;
        current = unsafe { (*current).next };
    }

    if !previous.is_null() {
        let previous_end = (previous as usize).checked_add(unsafe { block_size(previous)? }).ok_or(HeapError::AddressOverflow)?;
        if previous_end > start { return Err(HeapError::OverlappingFreeBlock); }
    }
    if !current.is_null() && end > current as usize { return Err(HeapError::OverlappingFreeBlock); }

    unsafe {
        (*block).previous = previous;
        (*block).next = current;
        if previous.is_null() { state.free_head = block; } else { (*previous).next = block; }
        if !current.is_null() { (*current).previous = block; }
    }

    let mut merged = block;
    if !previous.is_null() {
        let previous_size = unsafe { block_size(previous)? };
        if (previous as usize).checked_add(previous_size) == Some(block as usize) {
            unsafe {
                (*previous).size = previous_size.checked_add(size).ok_or(HeapError::AddressOverflow)?;
                (*previous).next = (*block).next;
                if !(*block).next.is_null() { (*(*block).next).previous = previous; }
            }
            merged = previous;
        }
    }

    let next = unsafe { (*merged).next };
    if !next.is_null() {
        let merged_size = unsafe { block_size(merged)? };
        if (merged as usize).checked_add(merged_size) == Some(next as usize) {
            let next_size = unsafe { block_size(next)? };
            unsafe {
                (*merged).size = merged_size.checked_add(next_size).ok_or(HeapError::AddressOverflow)?;
                (*merged).next = (*next).next;
                if !(*next).next.is_null() { (*(*next).next).previous = merged; }
            }
        }
    }
    Ok(())
}

/// Allocate `size` bytes with a power-of-two alignment. Zero-byte requests
/// return a unique one-byte allocation. This API is not IRQ-safe or SMP-safe.
pub fn allocate(size: usize, requested_alignment: usize) -> Result<NonNull<u8>, HeapError> {
    if requested_alignment == 0 || !requested_alignment.is_power_of_two() || requested_alignment > MAX_ALIGNMENT {
        return Err(HeapError::InvalidAlignment);
    }
    if !stats().initialized && !initialize() { return Err(HeapError::NotInitialized); }
    let alignment = requested_alignment.max(ALIGNMENT);

    let _guard = lock();
    let state = state_mut();
    if !state.initialized { return Err(HeapError::NotInitialized); }
    state.allocation_calls = state.allocation_calls.saturating_add(1);
    let effective_size = size.max(1);

    for _ in 0..2 {
        match allocate_from_free_list(state, size, effective_size, alignment) {
            Ok(Some(pointer)) => return Ok(pointer),
            Ok(None) => {
                let need = effective_size
                    .checked_add(MIN_USER_OFFSET)
                    .and_then(|n| n.checked_add(alignment - 1))
                    .ok_or(HeapError::AddressOverflow)?;
                let requested_pages = need.checked_add(PAGE_SIZE - 1).ok_or(HeapError::AddressOverflow)? / PAGE_SIZE;
                let grow_pages = requested_pages.max(INITIAL_GROW_PAGES);
                if let Err(error) = grow_locked(state, grow_pages) {
                    state.allocation_failures = state.allocation_failures.saturating_add(1);
                    return Err(error);
                }
            }
            Err(error) => {
                state.allocation_failures = state.allocation_failures.saturating_add(1);
                return Err(error);
            }
        }
    }

    state.allocation_failures = state.allocation_failures.saturating_add(1);
    Err(HeapError::OutOfMemory)
}

fn allocate_from_free_list(
    state: &mut HeapState,
    requested_size: usize,
    effective_size: usize,
    alignment: usize,
) -> Result<Option<NonNull<u8>>, HeapError> {
    let mut current = state.free_head;
    let mut steps = 0usize;
    while !current.is_null() {
        steps += 1;
        if steps > MAX_LIST_STEPS { return Err(HeapError::CorruptFreeList); }
        let free_size = unsafe { block_size(current)? };
        let block_start = current as usize;
        let minimum_user = block_start.checked_add(MIN_USER_OFFSET).ok_or(HeapError::AddressOverflow)?;
        let user = align_up(minimum_user, alignment).ok_or(HeapError::AddressOverflow)?;
        let header_start = user.checked_sub(core::mem::size_of::<AllocationHeader>()).ok_or(HeapError::AddressOverflow)?;
        let requested_end = user.checked_add(effective_size).ok_or(HeapError::AddressOverflow)?;
        let used_span = align_up(requested_end.checked_sub(block_start).ok_or(HeapError::AddressOverflow)?, ALIGNMENT)
            .ok_or(HeapError::AddressOverflow)?;

        if used_span <= free_size {
            let remainder = free_size - used_span;
            let allocation_span = if remainder >= core::mem::size_of::<FreeBlock>() + ALIGNMENT { used_span } else { free_size };
            let new_used_bytes = state.used_bytes.checked_add(allocation_span).ok_or(HeapError::AddressOverflow)?;
            let previous = unsafe { (*current).previous };
            let next = unsafe { (*current).next };
            if remainder >= core::mem::size_of::<FreeBlock>() + ALIGNMENT {
                let remainder_block = block_ptr(block_start + used_span);
                unsafe {
                    remainder_block.write(FreeBlock { magic: BLOCK_MAGIC, size: remainder, previous, next });
                    if previous.is_null() { state.free_head = remainder_block; } else { (*previous).next = remainder_block; }
                    if !next.is_null() { (*next).previous = remainder_block; }
                }
            } else {
                unsafe {
                    if previous.is_null() { state.free_head = next; } else { (*previous).next = next; }
                    if !next.is_null() { (*next).previous = previous; }
                }
            }

            let header = header_start as *mut AllocationHeader;
            unsafe {
                header.write(AllocationHeader {
                    magic: ALLOC_MAGIC ^ user as u64,
                    block_start: block_start as u64,
                    block_size: allocation_span as u64,
                    requested_size: requested_size as u64,
                });
            }
            state.used_bytes = new_used_bytes;
            state.peak_used_bytes = state.peak_used_bytes.max(state.used_bytes);
            state.active_allocations = state.active_allocations.saturating_add(1);
            return NonNull::new(user as *mut u8).map(Some).ok_or(HeapError::AddressOverflow);
        }
        current = unsafe { (*current).next };
    }
    Ok(None)
}

/// C-style convenience entry point using the heap's default 16-byte alignment.
#[allow(dead_code)] // Exported for the native C runtime integration stage.
pub fn kmalloc(size: usize) -> Result<NonNull<u8>, HeapError> {
    allocate(size, ALIGNMENT)
}

/// C-style convenience entry point for explicitly aligned kernel allocations.
#[allow(dead_code)] // Exported for the native C runtime integration stage.
pub fn kmalloc_aligned(size: usize, alignment: usize) -> Result<NonNull<u8>, HeapError> {
    allocate(size, alignment)
}

/// Release a pointer returned by `allocate`, `kmalloc`, or `kmalloc_aligned`.
/// A second free is detected while the freed header remains in the arena;
/// invalid/out-of-range pointers fail closed rather than entering the free list.
pub unsafe fn deallocate(pointer: NonNull<u8>) -> Result<(), HeapError> {
    let _guard = lock();
    let state = state_mut();
    if !state.initialized { return Err(HeapError::NotInitialized); }
    let user = pointer.as_ptr() as usize;
    let arena_start = usize::try_from(state.base).map_err(|_| HeapError::AddressOverflow)?;
    let arena_end = arena_start.checked_add(state.mapped_pages.checked_mul(PAGE_SIZE).ok_or(HeapError::AddressOverflow)?)
        .ok_or(HeapError::AddressOverflow)?;
    if user < arena_start + MIN_USER_OFFSET || user >= arena_end {
        state.free_errors = state.free_errors.saturating_add(1);
        return Err(HeapError::InvalidPointer);
    }
    let header_address = user.checked_sub(core::mem::size_of::<AllocationHeader>()).ok_or(HeapError::InvalidPointer)?;
    let header = unsafe { &mut *(header_address as *mut AllocationHeader) };
    if header.magic == (FREED_MAGIC ^ user as u64) {
        state.free_errors = state.free_errors.saturating_add(1);
        return Err(HeapError::DoubleFree);
    }
    if header.magic != (ALLOC_MAGIC ^ user as u64) {
        state.free_errors = state.free_errors.saturating_add(1);
        return Err(HeapError::InvalidPointer);
    }

    let block_start = usize::try_from(header.block_start).map_err(|_| HeapError::InvalidPointer)?;
    let block_size = usize::try_from(header.block_size).map_err(|_| HeapError::InvalidPointer)?;
    let block_end = block_start.checked_add(block_size).ok_or(HeapError::AddressOverflow)?;
    if block_start < arena_start || block_start & (ALIGNMENT - 1) != 0
        || block_size < MIN_USER_OFFSET || block_size & (ALIGNMENT - 1) != 0
        || block_end > arena_end || header_address < block_start + core::mem::size_of::<FreeBlock>()
        || header_address.checked_add(core::mem::size_of::<AllocationHeader>()).is_none_or(|end| end > block_end)
        || user.checked_add((header.requested_size as usize).max(1)).is_none_or(|end| end > block_end)
    {
        state.free_errors = state.free_errors.saturating_add(1);
        return Err(HeapError::InvalidPointer);
    }
    if state.active_allocations == 0 || state.used_bytes < block_size {
        state.free_errors = state.free_errors.saturating_add(1);
        return Err(HeapError::CorruptFreeList);
    }

    let block = block_ptr(block_start);
    unsafe {
        block.write(FreeBlock {
            magic: BLOCK_MAGIC,
            size: block_size,
            previous: core::ptr::null_mut(),
            next: core::ptr::null_mut(),
        });
    }
    if let Err(error) = insert_free_block(state, block) {
        state.free_errors = state.free_errors.saturating_add(1);
        return Err(error);
    }
    // The header is deliberately placed after the FreeBlock metadata so a
    // freed pointer can be diagnosed as a double-free until this area is reused.
    header.magic = FREED_MAGIC ^ user as u64;
    state.used_bytes -= block_size;
    state.active_allocations -= 1;
    state.free_calls = state.free_calls.saturating_add(1);
    Ok(())
}

/// C-style convenience name for releasing a heap allocation.
#[allow(dead_code)] // Exported for the native C runtime integration stage.
pub unsafe fn kfree(pointer: NonNull<u8>) -> Result<(), HeapError> {
    unsafe { deallocate(pointer) }
}

pub fn stats() -> HeapStats {
    let _guard = lock();
    let state = state_mut();
    let mut free_bytes = 0usize;
    let mut largest = 0usize;
    let mut free_blocks = 0usize;
    let mut current = state.free_head;
    while !current.is_null() && free_blocks < MAX_LIST_STEPS {
        let size = unsafe { (*current).size };
        free_bytes = free_bytes.saturating_add(size);
        largest = largest.max(size);
        free_blocks += 1;
        current = unsafe { (*current).next };
    }
    HeapStats {
        initialized: state.initialized,
        base: state.base,
        mapped_pages: state.mapped_pages,
        capacity_bytes: state.mapped_pages.saturating_mul(PAGE_SIZE),
        used_bytes: state.used_bytes,
        free_bytes,
        largest_free_block: largest,
        free_blocks,
        active_allocations: state.active_allocations,
        peak_used_bytes: state.peak_used_bytes,
        allocation_calls: state.allocation_calls,
        allocation_failures: state.allocation_failures,
        free_calls: state.free_calls,
        free_errors: state.free_errors,
    }
}

/// Allocate, align, write/read, free in fragmented order, and prove that the
/// heap returns to its original live-allocation accounting. May grow the arena.
pub fn self_test() -> Result<usize, HeapError> {
    const SIZES: [usize; 7] = [1, 37, 255, 1024, 4095, 8192, 16384];
    const ALIGNS: [usize; 7] = [16, 32, 64, 128, 256, 512, PAGE_SIZE];
    const FREE_ORDER: [usize; 7] = [3, 0, 6, 2, 5, 1, 4];

    let before = stats();
    if !before.initialized { return Err(HeapError::NotInitialized); }
    let mut pointers: [Option<NonNull<u8>>; 7] = [None; 7];
    let mut allocated = 0usize;

    for index in 0..SIZES.len() {
        match allocate(SIZES[index], ALIGNS[index]) {
            Ok(pointer) => {
                if pointer.as_ptr() as usize % ALIGNS[index] != 0 {
                    for item in pointers.iter().take(allocated).flatten() { let _ = unsafe { deallocate(*item) }; }
                    let _ = unsafe { deallocate(pointer) };
                    return Err(HeapError::InvalidAlignment);
                }
                unsafe {
                    for offset in 0..SIZES[index] {
                        pointer.as_ptr().add(offset).write_volatile((index as u8).wrapping_mul(29).wrapping_add(offset as u8));
                    }
                    for offset in 0..SIZES[index] {
                        let actual = pointer.as_ptr().add(offset).read_volatile();
                        let expected = (index as u8).wrapping_mul(29).wrapping_add(offset as u8);
                        if actual != expected {
                            for item in pointers.iter().take(allocated).flatten() { let _ = deallocate(*item); }
                            let _ = deallocate(pointer);
                            return Err(HeapError::CorruptFreeList);
                        }
                    }
                }
                pointers[index] = Some(pointer);
                allocated += 1;
            }
            Err(error) => {
                for item in pointers.iter().take(allocated).flatten() { let _ = unsafe { deallocate(*item) }; }
                return Err(error);
            }
        }
    }

    for index in FREE_ORDER {
        if let Some(pointer) = pointers[index] {
            if unsafe { deallocate(pointer) }.is_err() { return Err(HeapError::CorruptFreeList); }
            pointers[index] = None;
        }
    }

    let after = stats();
    let added_capacity = after.capacity_bytes.saturating_sub(before.capacity_bytes);
    if after.used_bytes != before.used_bytes || after.active_allocations != before.active_allocations
        || after.free_errors != before.free_errors
        || after.free_bytes != before.free_bytes.saturating_add(added_capacity)
        || after.free_bytes + after.used_bytes != after.capacity_bytes
    {
        return Err(HeapError::CorruptFreeList);
    }
    Ok(SIZES.len())
}
