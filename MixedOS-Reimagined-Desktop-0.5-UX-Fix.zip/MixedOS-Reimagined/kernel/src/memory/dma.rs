//! Bounded first-generation DMA buffer support.
//!
//! Buffers are physically contiguous, page-aligned, zeroed, and allocated below
//! the 4 GiB DMA32 ceiling. This is suitable as a conservative foundation for
//! controllers whose 64-bit DMA capability has not yet been established.
//!
//! IMPORTANT: a device driver must stop/quiesce its controller before calling
//! `release_after_quiesce`. If a buffer is dropped without an explicit release,
//! its frames intentionally remain allocated (a safe leak) rather than being
//! returned while a device might still be able to DMA into them.

use core::ptr::NonNull;
use core::slice;
use core::sync::atomic::{AtomicU64, Ordering};

use super::physical::{self, FrameRun, PAGE_SIZE};

pub const DMA32_LIMIT_EXCLUSIVE: u64 = 0x1_0000_0000;
pub const MAX_DMA_BUFFER_BYTES: usize = 16 * 1024 * 1024;

static ACTIVE_BUFFERS: AtomicU64 = AtomicU64::new(0);
static ACTIVE_BYTES: AtomicU64 = AtomicU64::new(0);
static TOTAL_ALLOCATIONS: AtomicU64 = AtomicU64::new(0);
static ALLOCATION_FAILURES: AtomicU64 = AtomicU64::new(0);
static ORPHANED_BUFFERS: AtomicU64 = AtomicU64::new(0);
static RELEASE_ERRORS: AtomicU64 = AtomicU64::new(0);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DmaError {
    ZeroLength,
    TooLarge,
    AllocatorUnavailable,
    OutOfMemory,
    HhdmUnavailable,
    AddressConstraint,
    DataMismatch,
    AccountingMismatch,
    FrameReleaseFailed,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DmaStats {
    pub active_buffers: u64,
    pub active_bytes: u64,
    pub total_allocations: u64,
    pub allocation_failures: u64,
    pub orphaned_buffers: u64,
    pub release_errors: u64,
}

/// Owns a DMA32 buffer. This type is intentionally not `Copy` or `Clone`.
#[must_use = "DMA buffers must be retained while a device may access them"]
pub struct DmaBuffer {
    // Option lets release_after_quiesce consume the unique frame-run token even
    // though this type has a Drop implementation.
    run: Option<FrameRun>,
    virtual_base: NonNull<u8>,
    requested_len: usize,
    allocation_len: usize,
}

impl DmaBuffer {
    /// Allocate up to 16 MiB of contiguous, zeroed memory below 4 GiB.
    /// The requested length is rounded up to whole 4 KiB frames internally.
    pub fn allocate_dma32(requested_len: usize) -> Result<Self, DmaError> {
        if requested_len == 0 {
            ALLOCATION_FAILURES.fetch_add(1, Ordering::Relaxed);
            return Err(DmaError::ZeroLength);
        }
        if requested_len > MAX_DMA_BUFFER_BYTES {
            ALLOCATION_FAILURES.fetch_add(1, Ordering::Relaxed);
            return Err(DmaError::TooLarge);
        }
        if !physical::stats().initialized {
            ALLOCATION_FAILURES.fetch_add(1, Ordering::Relaxed);
            return Err(DmaError::AllocatorUnavailable);
        }

        let Some(rounded) = requested_len.checked_add(PAGE_SIZE as usize - 1) else {
            ALLOCATION_FAILURES.fetch_add(1, Ordering::Relaxed);
            return Err(DmaError::TooLarge);
        };
        let pages = rounded / PAGE_SIZE as usize;
        let Some(allocation_len) = pages.checked_mul(PAGE_SIZE as usize) else {
            ALLOCATION_FAILURES.fetch_add(1, Ordering::Relaxed);
            return Err(DmaError::TooLarge);
        };
        let run = physical::allocate_contiguous(pages, 1, DMA32_LIMIT_EXCLUSIVE)
            .ok_or_else(|| {
                ALLOCATION_FAILURES.fetch_add(1, Ordering::Relaxed);
                DmaError::OutOfMemory
            })?;
        let Some(physical_end) = run.physical_address().checked_add(allocation_len as u64) else {
            return_unexposed_run(run);
            ALLOCATION_FAILURES.fetch_add(1, Ordering::Relaxed);
            return Err(DmaError::AddressConstraint);
        };
        if run.physical_address() & (PAGE_SIZE - 1) != 0 || physical_end > DMA32_LIMIT_EXCLUSIVE {
            return_unexposed_run(run);
            ALLOCATION_FAILURES.fetch_add(1, Ordering::Relaxed);
            return Err(DmaError::AddressConstraint);
        }
        let Some(virtual_base) = physical::run_to_hhdm(&run) else {
            return_unexposed_run(run);
            ALLOCATION_FAILURES.fetch_add(1, Ordering::Relaxed);
            return Err(DmaError::HhdmUnavailable);
        };

        // The allocator owns every page in the run; clear the full allocation,
        // not merely the caller-visible length, before exposing it to a driver.
        unsafe { virtual_base.as_ptr().write_bytes(0, allocation_len); }
        ACTIVE_BUFFERS.fetch_add(1, Ordering::Relaxed);
        ACTIVE_BYTES.fetch_add(allocation_len as u64, Ordering::Relaxed);
        TOTAL_ALLOCATIONS.fetch_add(1, Ordering::Relaxed);
        Ok(Self { run: Some(run), virtual_base, requested_len, allocation_len })
    }

    pub fn physical_address(&self) -> u64 { self.run.as_ref().map_or(0, FrameRun::physical_address) }
    pub const fn len(&self) -> usize { self.requested_len }
    pub const fn capacity(&self) -> usize { self.allocation_len }
    pub const fn is_empty(&self) -> bool { self.requested_len == 0 }
    pub fn frame_count(&self) -> usize { self.run.as_ref().map_or(0, FrameRun::frame_count) }

    /// Read the caller-visible portion while the device is quiesced.
    ///
    /// # Safety
    /// The buffer must not be accessible to any device for the entire lifetime
    /// of the returned slice, and no concurrent CPU writer may access it.
    pub unsafe fn as_slice_when_quiesced(&self) -> &[u8] {
        unsafe { slice::from_raw_parts(self.virtual_base.as_ptr(), self.requested_len) }
    }

    /// Mutably access the caller-visible portion while the device is quiesced.
    ///
    /// # Safety
    /// The buffer must not be accessible to any device for the returned borrow,
    /// and the caller must ensure no other CPU reference aliases this buffer.
    pub unsafe fn as_mut_slice_when_quiesced(&mut self) -> &mut [u8] {
        unsafe { slice::from_raw_parts_mut(self.virtual_base.as_ptr(), self.requested_len) }
    }

    /// Release the pages after the caller has stopped every device that could
    /// access this buffer. The caller must guarantee the device is quiesced and
    /// no DMA transaction is outstanding; otherwise freed RAM could be corrupted.
    pub unsafe fn release_after_quiesce(mut self) -> Result<(), DmaError> {
        unsafe { self.virtual_base.as_ptr().write_bytes(0, self.allocation_len); }
        let Some(run) = self.run.take() else {
            RELEASE_ERRORS.fetch_add(1, Ordering::Relaxed);
            return Err(DmaError::FrameReleaseFailed);
        };
        match physical::free_contiguous(run) {
            Ok(()) => {
                ACTIVE_BUFFERS.fetch_sub(1, Ordering::Relaxed);
                ACTIVE_BYTES.fetch_sub(self.allocation_len as u64, Ordering::Relaxed);
                Ok(())
            }
            Err(_) => {
                RELEASE_ERRORS.fetch_add(1, Ordering::Relaxed);
                ORPHANED_BUFFERS.fetch_add(1, Ordering::Relaxed);
                Err(DmaError::FrameReleaseFailed)
            }
        }
    }
}

impl Drop for DmaBuffer {
    fn drop(&mut self) {
        if self.run.is_some() {
            // Fail closed: never return memory to the allocator implicitly.
            ORPHANED_BUFFERS.fetch_add(1, Ordering::Relaxed);
        }
    }
}


fn return_unexposed_run(run: FrameRun) {
    if physical::free_contiguous(run).is_err() {
        // The run was never exposed to a controller, but a failed allocator
        // return still means its pages must remain counted as orphaned.
        RELEASE_ERRORS.fetch_add(1, Ordering::Relaxed);
        ORPHANED_BUFFERS.fetch_add(1, Ordering::Relaxed);
    }
}

pub fn stats() -> DmaStats {
    DmaStats {
        active_buffers: ACTIVE_BUFFERS.load(Ordering::Relaxed),
        active_bytes: ACTIVE_BYTES.load(Ordering::Relaxed),
        total_allocations: TOTAL_ALLOCATIONS.load(Ordering::Relaxed),
        allocation_failures: ALLOCATION_FAILURES.load(Ordering::Relaxed),
        orphaned_buffers: ORPHANED_BUFFERS.load(Ordering::Relaxed),
        release_errors: RELEASE_ERRORS.load(Ordering::Relaxed),
    }
}

/// Exercise two real allocator-owned contiguous pages below 4 GiB. The test
/// only touches memory returned by the physical allocator and explicitly
/// releases it because no DMA-capable controller is given the address.
pub fn self_test() -> Result<usize, DmaError> {
    let before_frames = physical::stats();
    if !before_frames.initialized { return Err(DmaError::AllocatorUnavailable); }
    if !before_frames.hhdm_ready { return Err(DmaError::HhdmUnavailable); }
    let before_dma = stats();

    let mut buffer = DmaBuffer::allocate_dma32((PAGE_SIZE as usize) * 2)?;
    let address = buffer.physical_address();
    if buffer.is_empty() || buffer.len() != (PAGE_SIZE as usize) * 2 {
        unsafe { let _ = buffer.release_after_quiesce(); }
        return Err(DmaError::DataMismatch);
    }
    if address & (PAGE_SIZE - 1) != 0
        || address.checked_add(buffer.capacity() as u64).filter(|end| *end <= DMA32_LIMIT_EXCLUSIVE).is_none()
        || buffer.frame_count() != 2
    {
        unsafe { let _ = buffer.release_after_quiesce(); }
        return Err(DmaError::AddressConstraint);
    }

    let verified = unsafe {
        let bytes = buffer.as_slice_when_quiesced();
        bytes.iter().all(|byte| *byte == 0)
    };
    if !verified {
        unsafe { let _ = buffer.release_after_quiesce(); }
        return Err(DmaError::DataMismatch);
    }

    unsafe {
        let bytes = buffer.as_mut_slice_when_quiesced();
        bytes[0] = 0x4D;
        let last = bytes.len() - 1;
        bytes[last] = 0x58;
    }
    let readback_ok = unsafe {
        let bytes = buffer.as_slice_when_quiesced();
        bytes.first() == Some(&0x4D) && bytes.last() == Some(&0x58)
    };
    // This self-test has not exposed the address to hardware; the unsafe
    // release precondition is therefore satisfied.
    let released = unsafe { buffer.release_after_quiesce() };
    if released.is_err() { return Err(DmaError::FrameReleaseFailed); }
    if !readback_ok { return Err(DmaError::DataMismatch); }

    let after_frames = physical::stats();
    let after_dma = stats();
    if after_frames.free_frames != before_frames.free_frames
        || after_frames.allocated_frames != before_frames.allocated_frames
        || after_frames.free_errors != before_frames.free_errors
        || after_dma.active_buffers != before_dma.active_buffers
        || after_dma.active_bytes != before_dma.active_bytes
    {
        return Err(DmaError::AccountingMismatch);
    }
    Ok(2)
}
