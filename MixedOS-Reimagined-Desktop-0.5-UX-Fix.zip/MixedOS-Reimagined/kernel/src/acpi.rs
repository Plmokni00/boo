//! Read-only, bounded ACPI discovery through Limine's RSDP request.
//!
//! This module validates the RSDP, root-table header/checksum, child table
//! ranges, and checksums before inspecting known signatures. It never executes
//! AML, changes firmware state, maps MMIO, or configures an interrupt controller.

use crate::boot::limine;

const RSDP_SIGNATURE: &[u8; 8] = b"RSD PTR ";
const RSDP_V1_LENGTH: u64 = 20;
const RSDP_V2_MIN_LENGTH: u64 = 36;
const SDT_HEADER_LENGTH: u64 = 36;
const MAX_RSDP_LENGTH: u64 = 4096;
const MAX_TABLE_LENGTH: u64 = 1024 * 1024;
const MAX_TOTAL_TABLE_BYTES: u64 = 4 * 1024 * 1024;
const MAX_ROOT_ENTRIES: usize = 256;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum AcpiState {
    Unavailable,
    InvalidRsdp,
    InvalidRoot,
    Ready,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct AcpiInfo {
    pub state: AcpiState,
    pub rsdp_revision: u8,
    pub root_signature: [u8; 4],
    pub tables_validated: u16,
    pub tables_rejected: u16,
    pub entries_truncated: bool,
    pub has_madt: bool,
    pub has_mcfg: bool,
    pub has_fadt: bool,
    pub has_hpet: bool,
    pub local_apic_entries: u16,
    pub io_apic_entries: u16,
    pub mcfg_segments: u16,
}

impl AcpiInfo {
    const fn empty(state: AcpiState) -> Self {
        Self {
            state,
            rsdp_revision: 0,
            root_signature: [0; 4],
            tables_validated: 0,
            tables_rejected: 0,
            entries_truncated: false,
            has_madt: false,
            has_mcfg: false,
            has_fadt: false,
            has_hpet: false,
            local_apic_entries: 0,
            io_apic_entries: 0,
            mcfg_segments: 0,
        }
    }
}

struct Sdt {
    address: *const u8,
    signature: [u8; 4],
    length: u32,
}

/// Inspect ACPI using only bounded reads from firmware-reserved ACPI regions.
/// The bootloader's RSDP request is optional; absence never prevents boot.
pub fn inspect() -> AcpiInfo {
    let Some(rsdp_virtual_value) = limine::rsdp_virtual_address() else {
        return AcpiInfo::empty(AcpiState::Unavailable);
    };
    let Some(hhdm) = limine::hhdm_offset() else {
        return AcpiInfo::empty(AcpiState::InvalidRsdp);
    };
    let Some(rsdp_physical) = limine::hhdm_to_physical(rsdp_virtual_value) else {
        return AcpiInfo::empty(AcpiState::InvalidRsdp);
    };
    if !canonical_48(rsdp_virtual_value)
        || !limine::acpi_region_contains(rsdp_physical, RSDP_V1_LENGTH)
    {
        return AcpiInfo::empty(AcpiState::InvalidRsdp);
    }
    let rsdp_virtual = rsdp_virtual_value as *const u8;

    let signature = unsafe { core::ptr::read_unaligned(rsdp_virtual.cast::<[u8; 8]>()) };
    if &signature != RSDP_SIGNATURE || !checksum_ok(rsdp_virtual, RSDP_V1_LENGTH as usize) {
        return AcpiInfo::empty(AcpiState::InvalidRsdp);
    }

    let revision = unsafe { rsdp_virtual.add(15).read_volatile() };
    let rsdt_physical = read_u32(rsdp_virtual, 16) as u64;
    let mut info = AcpiInfo::empty(AcpiState::InvalidRoot);
    info.rsdp_revision = revision;

    let (root_physical, entry_width) = if revision >= 2 {
        if !limine::acpi_region_contains(rsdp_physical, RSDP_V2_MIN_LENGTH) {
            info.state = AcpiState::InvalidRsdp;
            return info;
        }
        let rsdp_length = read_u32(rsdp_virtual, 20) as u64;
        if !(RSDP_V2_MIN_LENGTH..=MAX_RSDP_LENGTH).contains(&rsdp_length)
            || !limine::acpi_region_contains(rsdp_physical, rsdp_length)
            || !checksum_ok(rsdp_virtual, rsdp_length as usize)
        {
            info.state = AcpiState::InvalidRsdp;
            return info;
        }
        let xsdt = read_u64(rsdp_virtual, 24);
        if xsdt != 0 { (xsdt, 8usize) } else { (rsdt_physical, 4usize) }
    } else {
        (rsdt_physical, 4usize)
    };

    let Some(root) = validate_sdt(root_physical, hhdm) else { return info; };
    if (entry_width == 8 && root.signature != *b"XSDT")
        || (entry_width == 4 && root.signature != *b"RSDT")
    {
        return info;
    }
    info.root_signature = root.signature;

    let payload_length = (root.length as u64).saturating_sub(SDT_HEADER_LENGTH);
    if payload_length % entry_width as u64 != 0 {
        return info;
    }
    let advertised_entries = (payload_length / entry_width as u64) as usize;
    let entry_count = advertised_entries.min(MAX_ROOT_ENTRIES);
    info.entries_truncated = advertised_entries > MAX_ROOT_ENTRIES;
    let mut total_bytes = root.length as u64;

    for index in 0..entry_count {
        let offset = SDT_HEADER_LENGTH as usize + index * entry_width;
        let table_physical = if entry_width == 8 {
            read_u64(root.address, offset)
        } else {
            read_u32(root.address, offset) as u64
        };
        if table_physical == 0 { continue; }
        let Some(table) = validate_sdt(table_physical, hhdm) else {
            info.tables_rejected = info.tables_rejected.saturating_add(1);
            continue;
        };
        let next_total = total_bytes.saturating_add(table.length as u64);
        if next_total > MAX_TOTAL_TABLE_BYTES {
            info.entries_truncated = true;
            break;
        }
        total_bytes = next_total;
        info.tables_validated = info.tables_validated.saturating_add(1);
        match &table.signature {
            b"APIC" => {
                info.has_madt = true;
                inspect_madt(&table, &mut info);
            }
            b"MCFG" => {
                info.has_mcfg = true;
                info.mcfg_segments = inspect_mcfg(&table);
            }
            b"FACP" => info.has_fadt = true,
            b"HPET" => info.has_hpet = true,
            _ => {}
        }
    }

    info.state = AcpiState::Ready;
    info
}

fn validate_sdt(physical: u64, hhdm: u64) -> Option<Sdt> {
    if physical == 0 || !limine::acpi_region_contains(physical, SDT_HEADER_LENGTH) {
        return None;
    }
    let virtual_address = hhdm.checked_add(physical)?;
    if !canonical_48(virtual_address) { return None; }
    let address = virtual_address as *const u8;
    let signature = unsafe { core::ptr::read_unaligned(address.cast::<[u8; 4]>()) };
    let length = read_u32(address, 4);
    let length_u64 = u64::from(length);
    if !(SDT_HEADER_LENGTH..=MAX_TABLE_LENGTH).contains(&length_u64)
        || !limine::acpi_region_contains(physical, length_u64)
        || !checksum_ok(address, length as usize)
    {
        return None;
    }
    Some(Sdt { address, signature, length })
}

fn inspect_madt(table: &Sdt, info: &mut AcpiInfo) {
    // MADT's fixed header is 36-byte SDT header + 8-byte LAPIC/flags fields.
    if table.length < 44 { info.tables_rejected = info.tables_rejected.saturating_add(1); return; }
    let mut offset = 44usize;
    let total = table.length as usize;
    while offset < total {
        if total.saturating_sub(offset) < 2 { info.tables_rejected = info.tables_rejected.saturating_add(1); return; }
        let kind = unsafe { table.address.add(offset).read_volatile() };
        let length = unsafe { table.address.add(offset + 1).read_volatile() } as usize;
        if length < 2 || length > total.saturating_sub(offset) {
            info.tables_rejected = info.tables_rejected.saturating_add(1);
            return;
        }
        match kind {
            0 if length >= 8 => info.local_apic_entries = info.local_apic_entries.saturating_add(1),
            1 if length >= 12 => info.io_apic_entries = info.io_apic_entries.saturating_add(1),
            9 if length >= 16 => info.local_apic_entries = info.local_apic_entries.saturating_add(1),
            _ => {}
        }
        offset += length;
    }
}

fn inspect_mcfg(table: &Sdt) -> u16 {
    // MCFG has 8 reserved bytes after its 36-byte SDT header, then 16-byte
    // allocation records. Count only structurally complete records.
    if table.length < 44 { return 0; }
    let payload = (table.length as usize) - 44;
    if payload % 16 != 0 { return 0; }
    (payload / 16).min(u16::MAX as usize) as u16
}

fn read_u32(address: *const u8, offset: usize) -> u32 {
    unsafe { core::ptr::read_unaligned(address.add(offset).cast::<u32>()) }
}

fn read_u64(address: *const u8, offset: usize) -> u64 {
    unsafe { core::ptr::read_unaligned(address.add(offset).cast::<u64>()) }
}

fn checksum_ok(address: *const u8, length: usize) -> bool {
    let mut sum = 0u8;
    for offset in 0..length {
        sum = sum.wrapping_add(unsafe { address.add(offset).read_volatile() });
    }
    sum == 0
}

fn canonical_48(address: u64) -> bool {
    let upper = address >> 48;
    let sign = (address >> 47) & 1;
    if sign == 0 { upper == 0 } else { upper == 0xFFFF }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn canonical_address_check_rejects_noncanonical_values() {
        assert!(canonical_48(0x0000_7fff_ffff_ffff));
        assert!(canonical_48(0xffff_8000_0000_0000));
        assert!(!canonical_48(0x0001_0000_0000_0000));
        assert!(!canonical_48(0xffff_0000_0000_0000));
    }

    #[test]
    fn empty_state_is_explicit() {
        let info = AcpiInfo::empty(AcpiState::Unavailable);
        assert_eq!(info.state, AcpiState::Unavailable);
        assert_eq!(info.tables_validated, 0);
    }
}
