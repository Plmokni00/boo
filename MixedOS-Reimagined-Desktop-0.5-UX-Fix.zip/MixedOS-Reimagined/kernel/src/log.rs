//! Fixed-capacity, allocation-free kernel log ring.
//!
//! Records are intentionally bounded and kept in RAM only. The log is a
//! diagnostic aid, not persistent storage and not safe for use from NMI context.
use core::cell::UnsafeCell;
use core::fmt::{self, Write};
use core::hint::spin_loop;
use core::sync::atomic::{AtomicBool, Ordering};

pub const CAPACITY: usize = 64;
pub const LINE_CAPACITY: usize = 160;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Level { Trace, Info, Warn, Error }

impl Level {
    const fn label(self) -> &'static str {
        match self { Self::Trace => "TRACE", Self::Info => "INFO", Self::Warn => "WARN", Self::Error => "ERROR" }
    }
}

struct Ring {
    lines: [[u8; LINE_CAPACITY]; CAPACITY],
    lengths: [usize; CAPACITY],
    levels: [Level; CAPACITY],
    next: usize,
    count: usize,
    dropped: u64,
}

impl Ring {
    const fn new() -> Self {
        Self { lines: [[0; LINE_CAPACITY]; CAPACITY], lengths: [0; CAPACITY], levels: [Level::Info; CAPACITY], next: 0, count: 0, dropped: 0 }
    }
    fn push(&mut self, level: Level, bytes: &[u8]) {
        let index = self.next;
        self.lines[index].fill(0);
        let len = bytes.len().min(LINE_CAPACITY);
        self.lines[index][..len].copy_from_slice(&bytes[..len]);
        self.lengths[index] = len;
        self.levels[index] = level;
        if bytes.len() > LINE_CAPACITY { self.dropped = self.dropped.saturating_add(1); }
        if self.count == CAPACITY { self.dropped = self.dropped.saturating_add(1); } else { self.count += 1; }
        self.next = (self.next + 1) % CAPACITY;
    }
}

struct SharedRing(UnsafeCell<Ring>);
unsafe impl Sync for SharedRing {}
static RING: SharedRing = SharedRing(UnsafeCell::new(Ring::new()));
static LOCKED: AtomicBool = AtomicBool::new(false);
struct Guard;
fn lock() -> Guard {
    while LOCKED.compare_exchange_weak(false, true, Ordering::Acquire, Ordering::Relaxed).is_err() { spin_loop(); }
    Guard
}
impl Drop for Guard { fn drop(&mut self) { LOCKED.store(false, Ordering::Release); } }

struct Buffer { bytes: [u8; LINE_CAPACITY], len: usize }
impl Buffer { const fn new() -> Self { Self { bytes: [0; LINE_CAPACITY], len: 0 } } }
impl Write for Buffer {
    fn write_str(&mut self, text: &str) -> fmt::Result {
        let available = LINE_CAPACITY.saturating_sub(self.len);
        let count = text.len().min(available);
        // Formatting strings are UTF-8. Truncate only at a character boundary.
        let mut end = count;
        while !text.is_char_boundary(end) { end -= 1; }
        self.bytes[self.len..self.len + end].copy_from_slice(&text.as_bytes()[..end]);
        self.len += end;
        Ok(())
    }
}

pub fn record(level: Level, args: fmt::Arguments<'_>) {
    let mut buffer = Buffer::new();
    let _ = buffer.write_fmt(args);
    let _guard = lock();
    unsafe { (*RING.0.get()).push(level, &buffer.bytes[..buffer.len]); }
}

pub fn count() -> usize { let _guard = lock(); unsafe { (*RING.0.get()).count } }
pub fn dropped() -> u64 { let _guard = lock(); unsafe { (*RING.0.get()).dropped } }
pub fn clear() { let _guard = lock(); unsafe { *RING.0.get() = Ring::new(); } }

/// Visit oldest-to-newest records while holding the ring lock. The callback
/// must not recursively log or call clear().
pub fn visit(mut callback: impl FnMut(Level, &str)) {
    let _guard = lock();
    let ring = unsafe { &*RING.0.get() };
    let first = (ring.next + CAPACITY - ring.count) % CAPACITY;
    for age in 0..ring.count {
        let index = (first + age) % CAPACITY;
        let bytes = &ring.lines[index][..ring.lengths[index]];
        let text = core::str::from_utf8(bytes).unwrap_or("<invalid log record>");
        callback(ring.levels[index], text);
    }
}

pub const fn level_name(level: Level) -> &'static str { level.label() }
