//! Bounded, conflict-checked PCI I/O-port and MMIO reservation registry.
//!
//! This module tracks software ownership only. It does not size PCI BARs, map
//! MMIO, change PCI command bits, enable bus mastering, or activate devices.
//! A future driver may reserve a range only after a separate safe BAR-sizing
//! and device-quiescence phase has established the exact base and length.

use core::cell::UnsafeCell;
use core::hint::spin_loop;
use core::sync::atomic::{AtomicBool, AtomicU64, Ordering};

pub const MAX_RESERVATIONS: usize = 64;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ResourceSpace {
    IoPort,
    Mmio,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct PciOwner {
    pub bus: u8,
    pub device: u8,
    pub function: u8,
    pub bar: u8,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ReservationInfo {
    pub space: ResourceSpace,
    pub start: u64,
    pub length: u64,
    pub owner: PciOwner,
    pub generation: u64,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ResourceError {
    ZeroLength,
    ZeroBase,
    InvalidAlignment,
    AddressOverflow,
    IoPortOutOfRange,
    Overlap,
    RegistryFull,
    StaleLease,
    InvalidOwner,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct ResourceStats {
    pub reservations: usize,
    pub io_port_reservations: usize,
    pub mmio_reservations: usize,
    pub rejected_requests: u64,
    pub overlap_rejections: u64,
    pub orphaned_leases: u64,
}

#[derive(Clone, Copy)]
struct Record {
    space: ResourceSpace,
    start: u64,
    end_exclusive: u64,
    owner: PciOwner,
    generation: u64,
}

struct Table(UnsafeCell<[Option<Record>; MAX_RESERVATIONS]>);
unsafe impl Sync for Table {}
static TABLE: Table = Table(UnsafeCell::new([None; MAX_RESERVATIONS]));
static LOCKED: AtomicBool = AtomicBool::new(false);
static NEXT_GENERATION: AtomicU64 = AtomicU64::new(1);
static REJECTED: AtomicU64 = AtomicU64::new(0);
static OVERLAPS: AtomicU64 = AtomicU64::new(0);
static ORPHANED: AtomicU64 = AtomicU64::new(0);

struct LockGuard;
fn lock() -> LockGuard {
    while LOCKED.compare_exchange_weak(false, true, Ordering::Acquire, Ordering::Relaxed).is_err() {
        spin_loop();
    }
    LockGuard
}
impl Drop for LockGuard {
    fn drop(&mut self) { LOCKED.store(false, Ordering::Release); }
}

/// A non-copyable claim. Dropping it without an explicit quiesced release
/// intentionally leaves the reservation active, preventing accidental reuse.
#[must_use = "keep the resource lease alive for the lifetime of the device claim"]
pub struct ResourceLease {
    slot: usize,
    generation: u64,
    released: bool,
}

/// Reserve a range already established by a trusted discovery/sizing path.
/// Alignment must be a non-zero power of two and the base must satisfy it.
pub fn reserve(
    space: ResourceSpace,
    start: u64,
    length: u64,
    alignment: u64,
    owner: PciOwner,
) -> Result<ResourceLease, ResourceError> {
    if owner.device >= 32 || owner.function >= 8 || owner.bar >= 6 {
        REJECTED.fetch_add(1, Ordering::Relaxed);
        return Err(ResourceError::InvalidOwner);
    }
    if length == 0 {
        REJECTED.fetch_add(1, Ordering::Relaxed);
        return Err(ResourceError::ZeroLength);
    }
    if start == 0 {
        REJECTED.fetch_add(1, Ordering::Relaxed);
        return Err(ResourceError::ZeroBase);
    }
    if alignment == 0 || !alignment.is_power_of_two() || start & (alignment - 1) != 0 {
        REJECTED.fetch_add(1, Ordering::Relaxed);
        return Err(ResourceError::InvalidAlignment);
    }
    let Some(end_exclusive) = start.checked_add(length) else {
        REJECTED.fetch_add(1, Ordering::Relaxed);
        return Err(ResourceError::AddressOverflow);
    };
    if space == ResourceSpace::IoPort && end_exclusive > 0x1_0000 {
        REJECTED.fetch_add(1, Ordering::Relaxed);
        return Err(ResourceError::IoPortOutOfRange);
    }

    let _guard = lock();
    let slots = unsafe { &mut *TABLE.0.get() };
    let mut free_slot = None;
    for (index, existing) in slots.iter().enumerate() {
        match existing {
            Some(record) if record.space == space
                && start < record.end_exclusive
                && record.start < end_exclusive =>
            {
                REJECTED.fetch_add(1, Ordering::Relaxed);
                OVERLAPS.fetch_add(1, Ordering::Relaxed);
                return Err(ResourceError::Overlap);
            }
            None if free_slot.is_none() => free_slot = Some(index),
            _ => {}
        }
    }
    let Some(index) = free_slot else {
        REJECTED.fetch_add(1, Ordering::Relaxed);
        return Err(ResourceError::RegistryFull);
    };
    let mut generation = NEXT_GENERATION.fetch_add(1, Ordering::Relaxed);
    if generation == 0 { generation = NEXT_GENERATION.fetch_add(1, Ordering::Relaxed); }
    slots[index] = Some(Record { space, start, end_exclusive, owner, generation });
    Ok(ResourceLease { slot: index, generation, released: false })
}

impl ResourceLease {
    /// Release a resource claim only after the device has been stopped and no
    /// driver path can still access the range. This API is unsafe by design so
    /// later drivers must make their hardware-quiescence guarantee explicit.
    pub unsafe fn release_after_quiesce(mut self) -> Result<(), ResourceError> {
        let result = release_slot(self.slot, self.generation);
        if result.is_ok() { self.released = true; }
        result
    }
}

impl Drop for ResourceLease {
    fn drop(&mut self) {
        if !self.released {
            // Preserve the active reservation rather than permitting an unsafe
            // second owner after a lease is accidentally discarded.
            ORPHANED.fetch_add(1, Ordering::Relaxed);
        }
    }
}

fn release_slot(slot: usize, generation: u64) -> Result<(), ResourceError> {
    if slot >= MAX_RESERVATIONS { return Err(ResourceError::StaleLease); }
    let _guard = lock();
    let slots = unsafe { &mut *TABLE.0.get() };
    match slots[slot] {
        Some(record) if record.generation == generation => {
            slots[slot] = None;
            Ok(())
        }
        _ => Err(ResourceError::StaleLease),
    }
}

pub fn stats() -> ResourceStats {
    let _guard = lock();
    let slots = unsafe { &*TABLE.0.get() };
    let mut result = ResourceStats {
        rejected_requests: REJECTED.load(Ordering::Relaxed),
        overlap_rejections: OVERLAPS.load(Ordering::Relaxed),
        orphaned_leases: ORPHANED.load(Ordering::Relaxed),
        ..ResourceStats::default()
    };
    for record in slots.iter().flatten() {
        result.reservations += 1;
        match record.space {
            ResourceSpace::IoPort => result.io_port_reservations += 1,
            ResourceSpace::Mmio => result.mmio_reservations += 1,
        }
    }
    result
}

/// Visit a consistent snapshot of active reservations without holding the
/// registry lock while invoking the caller's display/diagnostic callback.
pub fn visit(mut callback: impl FnMut(ReservationInfo)) {
    let mut snapshot = [None; MAX_RESERVATIONS];
    {
        let _guard = lock();
        let slots = unsafe { &*TABLE.0.get() };
        snapshot.copy_from_slice(slots);
    }
    for record in snapshot.into_iter().flatten() {
        callback(ReservationInfo {
            space: record.space,
            start: record.start,
            length: record.end_exclusive - record.start,
            owner: record.owner,
            generation: record.generation,
        });
    }
}

/// Verify overlap rejection and adjacent-range acceptance using synthetic
/// registry entries. This never performs port I/O or touches a PCI device.
pub fn self_test() -> Result<usize, ResourceError> {
    let before = stats();
    let owner = PciOwner { bus: 0xFF, device: 31, function: 7, bar: 5 };
    let mut candidate = 0xFFE0u64;
    let first = loop {
        if candidate < 0xE000 { return Err(ResourceError::RegistryFull); }
        match reserve(ResourceSpace::IoPort, candidate, 0x10, 0x10, owner) {
            Ok(lease) => break lease,
            Err(ResourceError::Overlap) => candidate -= 0x20,
            Err(error) => return Err(error),
        }
    };

    let overlap_rejected = match reserve(ResourceSpace::IoPort, candidate + 8, 8, 8, owner) {
        Err(ResourceError::Overlap) => true,
        Ok(lease) => {
            // The test-created claim is synthetic and was never given to hardware.
            let _ = unsafe { lease.release_after_quiesce() };
            false
        }
        Err(_) => false,
    };
    if !overlap_rejected {
        let _ = unsafe { first.release_after_quiesce() };
        return Err(ResourceError::Overlap);
    }

    let adjacent = match reserve(ResourceSpace::IoPort, candidate + 0x10, 0x10, 0x10, owner) {
        Ok(lease) => lease,
        Err(error) => {
            let _ = unsafe { first.release_after_quiesce() };
            return Err(error);
        }
    };
    // Neither synthetic reservation was connected to a device or port-I/O path.
    let first_release = unsafe { first.release_after_quiesce() };
    let adjacent_release = unsafe { adjacent.release_after_quiesce() };
    if first_release.is_err() || adjacent_release.is_err() { return Err(ResourceError::StaleLease); }

    let after = stats();
    if after.reservations != before.reservations
        || after.io_port_reservations != before.io_port_reservations
        || after.mmio_reservations != before.mmio_reservations
    {
        return Err(ResourceError::StaleLease);
    }
    Ok(3)
}
