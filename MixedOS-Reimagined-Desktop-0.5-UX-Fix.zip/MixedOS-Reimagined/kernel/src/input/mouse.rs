//! PS/2 mouse decoder supporting standard three-byte and IntelliMouse four-byte packets.

use core::sync::atomic::{AtomicBool, AtomicI32, AtomicU8, AtomicUsize, Ordering};

use super::{InputEvent, MouseEvent};

static PACKET: [AtomicU8; 4] = [
    AtomicU8::new(0), AtomicU8::new(0), AtomicU8::new(0), AtomicU8::new(0),
];
static PACKET_INDEX: AtomicUsize = AtomicUsize::new(0);
static WHEEL_PROTOCOL: AtomicBool = AtomicBool::new(false);
static X: AtomicI32 = AtomicI32::new(0);
static Y: AtomicI32 = AtomicI32::new(0);
static BUTTONS: AtomicU8 = AtomicU8::new(0);
static WHEEL_DELTA: AtomicI32 = AtomicI32::new(0);
static RECEIVED_BYTES: AtomicUsize = AtomicUsize::new(0);
static LAST_BYTE: AtomicU8 = AtomicU8::new(0);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct MouseStats {
    pub bytes: usize,
    pub last_byte: u8,
    pub x: i32,
    pub y: i32,
    pub buttons: u8,
    pub wheel_delta: i32,
    pub wheel_protocol: bool,
}

pub fn reset() {
    PACKET_INDEX.store(0, Ordering::Relaxed);
    WHEEL_PROTOCOL.store(false, Ordering::Relaxed);
    // Pointer state is normalized to 0..4095, starting at screen center.
    X.store(2048, Ordering::Relaxed);
    Y.store(2048, Ordering::Relaxed);
    BUTTONS.store(0, Ordering::Relaxed);
    WHEEL_DELTA.store(0, Ordering::Relaxed);
    RECEIVED_BYTES.store(0, Ordering::Relaxed);
    LAST_BYTE.store(0, Ordering::Relaxed);
}

/// Select the four-byte IntelliMouse packet format only after device negotiation.
pub fn set_wheel_protocol(enabled: bool) {
    PACKET_INDEX.store(0, Ordering::Relaxed);
    WHEEL_PROTOCOL.store(enabled, Ordering::Relaxed);
}

pub fn handle_byte(byte: u8) {
    RECEIVED_BYTES.fetch_add(1, Ordering::Relaxed);
    LAST_BYTE.store(byte, Ordering::Relaxed);

    let mut index = PACKET_INDEX.load(Ordering::Relaxed);
    if index == 0 && byte & 0x08 == 0 {
        return; // discard bytes until a packet header is aligned
    }
    PACKET[index].store(byte, Ordering::Relaxed);
    index += 1;
    let packet_len = if WHEEL_PROTOCOL.load(Ordering::Relaxed) { 4 } else { 3 };
    if index < packet_len {
        PACKET_INDEX.store(index, Ordering::Relaxed);
        return;
    }
    PACKET_INDEX.store(0, Ordering::Relaxed);

    let flags = PACKET[0].load(Ordering::Relaxed);
    let raw_x = PACKET[1].load(Ordering::Relaxed);
    let raw_y = PACKET[2].load(Ordering::Relaxed);
    let buttons = flags & 0x07;
    let old_buttons = BUTTONS.swap(buttons, Ordering::Relaxed);

    // Overflow means the movement delta saturated; keep button state but ignore
    // the invalid movement sample. PS/2 positive Y is upward on screen.
    let (dx, dy) = if flags & 0xC0 == 0 {
        (raw_x as i8 as i16, -(raw_y as i8 as i16))
    } else {
        (0, 0)
    };

    // Normalize wheel polarity so positive events always mean physical wheel-up.
    let wheel = if packet_len == 4 {
        let nibble = PACKET[3].load(Ordering::Relaxed) & 0x0F;
        let raw_steps = if nibble & 0x08 != 0 { (nibble as i8) - 16 } else { nibble as i8 };
        -raw_steps
    } else { 0 };

    // Conservative acceleration keeps the cursor precise at high framebuffer
    // resolutions. The previous 28..48 multiplier made ordinary packet movement
    // jump too far, especially on a 1920x1080 desktop.
    let accelerate = |delta: i16| -> i32 {
        let magnitude = i32::from(delta).abs();
        let multiplier = if magnitude <= 1 { 2 } else if magnitude <= 4 { 3 } else if magnitude <= 12 { 4 } else { 5 };
        i32::from(delta).saturating_mul(multiplier)
    };
    let x = (X.load(Ordering::Relaxed) + accelerate(dx)).clamp(0, 4095);
    let y = (Y.load(Ordering::Relaxed) + accelerate(dy)).clamp(0, 4095);
    X.store(x, Ordering::Relaxed);
    Y.store(y, Ordering::Relaxed);
    if wheel != 0 { WHEEL_DELTA.fetch_add(wheel as i32, Ordering::Relaxed); }

    if dx != 0 || dy != 0 || buttons != old_buttons || wheel != 0 {
        super::push_event(InputEvent::Mouse(MouseEvent {
            delta_x: dx,
            delta_y: dy,
            x,
            y,
            buttons,
            wheel_delta: wheel,
        }));
    }
}

pub fn stats() -> MouseStats {
    MouseStats {
        bytes: RECEIVED_BYTES.load(Ordering::Relaxed),
        last_byte: LAST_BYTE.load(Ordering::Relaxed),
        x: X.load(Ordering::Relaxed),
        y: Y.load(Ordering::Relaxed),
        buttons: BUTTONS.load(Ordering::Relaxed),
        wheel_delta: WHEEL_DELTA.load(Ordering::Relaxed),
        wheel_protocol: WHEEL_PROTOCOL.load(Ordering::Relaxed),
    }
}
