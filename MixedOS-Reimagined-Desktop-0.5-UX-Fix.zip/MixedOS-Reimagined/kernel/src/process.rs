//! Stage 6: first real user-mode processes and a small uniprocessor scheduler.
//!
//! The initial milestone deliberately runs two built-in, integer-only ring-3
//! test programs. Each process receives a cloned kernel PML4 root plus its own
//! user PML4 slot, code page, stack page, and kernel interrupt stack. Kernel
//! mappings are shared read-only by page-table structure and remain supervisor
//! mappings. Timer IRQs provide preemption; int 0x80 provides yield/report/exit.
//!
//! This is not yet a general executable loader, POSIX process API, SMP scheduler,
//! or per-process FPU context switch. Heap operations are done only with IRQs
//! disabled in normal kernel context, never from an interrupt handler.

use core::cell::UnsafeCell;
use core::ptr;
use core::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};

use crate::{
    arch,
    arch::{USER_CODE_SELECTOR, USER_DATA_SELECTOR},
    console::{framebuffer::Terminal, serial},
    interrupts::InterruptFrame,
    memory::{heap, paging, physical},
};

const MAX_PROCESSES: usize = 2;
const USER_PML4_SLOT: usize = 1;
const USER_BASE: u64 = (USER_PML4_SLOT as u64) << 39;
const USER_CODE: u64 = USER_BASE + 0x1000;
const USER_STACK: u64 = USER_BASE + 0x3000;
const USER_STACK_TOP: u64 = USER_BASE + 0x4000;
const USER_CODE_PTE: usize = ((USER_CODE >> 12) & 0x1FF) as usize;
const USER_STACK_PTE: usize = ((USER_STACK >> 12) & 0x1FF) as usize;
const KERNEL_STACK_BYTES: usize = 16 * 1024;
const PRESENT: u64 = 1 << 0;
const WRITABLE: u64 = 1 << 1;
const USER: u64 = 1 << 2;
const NO_EXECUTE: u64 = 1 << 63;
const SYS_REPORT: u64 = 1;
const SYS_YIELD: u64 = 2;
const SYS_EXIT: u64 = 3;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum ProcessState {
    Empty,
    Ready,
    Running,
    Exited,
    Faulted,
}

#[derive(Clone, Copy)]
struct Process {
    #[allow(dead_code)] // Stable process identity; exposed when general process inspection lands.
    pid: u64,
    state: ProcessState,
    context: UserInterruptFrame,
    // [root, PDPT, PD, PT, code, stack] physical frame addresses.
    frames: [u64; 6],
    kernel_stack: usize,
    reports: u64,
}

impl Process {
    const EMPTY: Self = Self {
        pid: 0,
        state: ProcessState::Empty,
        context: empty_context(),
        frames: [0; 6],
        kernel_stack: 0,
        reports: 0,
    };
}

/// Hardware adds RSP/SS only when an interrupt or exception transitions from
/// CPL3 to CPL0. Keep these two words out of InterruptFrame itself because
/// ring-0 interrupts do not have them on the stack.
#[repr(C)]
#[derive(Clone, Copy)]
struct UserInterruptFrame {
    base: InterruptFrame,
    user_rsp: u64,
    user_ss: u64,
}

// Hardware/assembly layout contracts: the ISR stub pushes 15 GPRs, vector,
// error code, RIP, CS, and RFLAGS. CPL3 transitions additionally push RSP/SS.
const _: [(); 20 * 8] = [(); core::mem::size_of::<InterruptFrame>()];
const _: [(); 22 * 8] = [(); core::mem::size_of::<UserInterruptFrame>()];

const fn empty_context() -> UserInterruptFrame {
    UserInterruptFrame {
        base: InterruptFrame {
            r15: 0, r14: 0, r13: 0, r12: 0, r11: 0, r10: 0, r9: 0, r8: 0,
            rdi: 0, rsi: 0, rbp: 0, rdx: 0, rcx: 0, rbx: 0, rax: 0,
            vector: 0, error_code: 0, instruction_pointer: 0,
            code_segment: USER_CODE_SELECTOR as u64, flags: 0x202,
        },
        user_rsp: USER_STACK_TOP,
        user_ss: USER_DATA_SELECTOR as u64,
    }
}

/// The caller must have checked that the saved CS has RPL3. Only then did the
/// CPU push the two tail qwords that make this larger view valid.
#[inline]
unsafe fn user_frame_ptr(frame: *mut InterruptFrame) -> *mut UserInterruptFrame {
    // SAFETY: callers invoke this only after checking the saved CS RPL is 3;
    // the CPU then pushed user RSP and SS after the 20-qword base frame.
    frame.cast::<UserInterruptFrame>()
}

struct ProcessTable(UnsafeCell<[Process; MAX_PROCESSES]>);
unsafe impl Sync for ProcessTable {}
static PROCESSES: ProcessTable = ProcessTable(UnsafeCell::new([Process::EMPTY; MAX_PROCESSES]));

static SESSION_ACTIVE: AtomicBool = AtomicBool::new(false);
static CURRENT_PROCESS: AtomicUsize = AtomicUsize::new(0);
static KERNEL_ROOT: AtomicU64 = AtomicU64::new(0);
static COMPLETED: AtomicU64 = AtomicU64::new(0);
static FAULTED: AtomicU64 = AtomicU64::new(0);
static REPORTS: AtomicU64 = AtomicU64::new(0);
static CONTEXT_SWITCHES: AtomicU64 = AtomicU64::new(0);
static TIMER_PREEMPTIONS: AtomicU64 = AtomicU64::new(0);
static CLEANUP_ERRORS: AtomicU64 = AtomicU64::new(0);
// The shell registers its live terminal only while the synchronous proctest is
// running. Interrupt gates clear IF and this is a uniprocessor kernel, so user
// syscall/fault breadcrumbs can safely update the framebuffer while the shell
// itself is suspended inside run_demo(). A zero pointer means no console hook.
static PROGRESS_TERMINAL: AtomicUsize = AtomicUsize::new(0);

/// Register the shell terminal for live process-test diagnostics. The pointer
/// remains valid because run_demo() is called synchronously from the shell.
pub(crate) fn set_progress_terminal(terminal: *mut Option<Terminal>) {
    PROGRESS_TERMINAL.store(terminal as usize, Ordering::Release);
}

pub(crate) fn clear_progress_terminal() {
    PROGRESS_TERMINAL.store(0, Ordering::Release);
}

fn progress_line(message: &str) {
    let address = PROGRESS_TERMINAL.load(Ordering::Acquire);
    if address == 0 { return; }
    // SAFETY: the shell owns this Option<Terminal> for the entire synchronous
    // proctest call. While user code runs, the shell is suspended; all entry
    // paths are interrupt gates on the single CPU, so no concurrent writer
    // touches the terminal. The shell clears the hook as soon as run_demo returns.
    unsafe {
        let terminal = &mut *(address as *mut Option<Terminal>);
        if let Some(view) = terminal.as_mut() { view.write_line(message); }
    }
}

/// Written by the assembly entry stub and consumed by the final return stub.
#[unsafe(no_mangle)]
pub static mut mixedos_kernel_return_rsp: u64 = 0;
/// Original kernel CR3 consumed by the assembly return stub before it restores
/// the suspended shell stack. The Rust caller verifies it again before cleanup.
#[unsafe(no_mangle)]
pub static mut mixedos_kernel_return_cr3: u64 = 0;
/// One-shot request set by the final user EXIT handler. The common ISR checks
/// it after Rust dispatch and FPU restoration, then jumps directly to the leaf
/// kernel-return stub instead of constructing a synthetic CPL0 IRETQ frame.
#[unsafe(no_mangle)]
pub static mut mixedos_return_to_kernel: u64 = 0;

unsafe extern "C" {
    fn mixedos_enter_user(user_rip: u64, user_rsp: u64);
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ProcessError {
    AlreadyActive,
    GdtUnavailable,
    PagingUnavailable,
    PhysicalMemoryUnavailable,
    HeapUnavailable,
    NxUnavailable,
    FiveLevelPagingUnsupported,
    ActiveRootChanged,
    OutOfFrames,
    HhdmUnavailable,
    UserSlotOccupied,
    InheritedUserMapping,
    AddressSpaceSetupFailed,
    KernelStackAllocationFailed,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ProcessStats {
    pub active: bool,
    pub completed: u64,
    pub faulted: u64,
    pub reports: u64,
    pub context_switches: u64,
    pub timer_preemptions: u64,
    pub cleanup_errors: u64,
}

#[inline]
fn table_mut() -> &'static mut [Process; MAX_PROCESSES] {
    // The scheduler is uniprocessor-only. Creation/cleanup run with IF=0;
    // interrupt dispatch is entered with IF cleared by an interrupt gate.
    unsafe { &mut *PROCESSES.0.get() }
}

fn free_frame_address(address: u64) -> bool {
    address == 0 || physical::free_allocated_frame_at(address).is_ok()
}

fn cleanup_process(process: &mut Process) {
    // This runs only after the original kernel CR3 has been restored and verified.
    // Phase markers help locate a stalled frame/heap release on the framebuffer.
    let mut clean = true;
    progress_line("[proc] cleanup: releasing user code and stack frames...");
    for index in [4usize, 5] {
        if !free_frame_address(process.frames[index]) { clean = false; }
        process.frames[index] = 0;
    }
    progress_line("[proc] cleanup: releasing private page-table frames...");
    for index in [1usize, 2, 3, 0] {
        if !free_frame_address(process.frames[index]) { clean = false; }
        process.frames[index] = 0;
    }
    progress_line("[proc] cleanup: releasing process kernel stack...");
    if process.kernel_stack != 0 {
        if let Some(pointer) = core::ptr::NonNull::new(process.kernel_stack as *mut u8) {
            if unsafe { heap::deallocate(pointer) }.is_err() { clean = false; }
        } else {
            clean = false;
        }
        process.kernel_stack = 0;
    }
    if !clean { CLEANUP_ERRORS.fetch_add(1, Ordering::Relaxed); }
    *process = Process::EMPTY;
    progress_line("[proc] cleanup: one process resource set reclaimed.");
}

fn cleanup_all() {
    let processes = table_mut();
    for process in processes.iter_mut() {
        if process.state != ProcessState::Empty {
            cleanup_process(process);
        }
    }
}

fn allocate_frame_address() -> Result<u64, ProcessError> {
    physical::allocate_zeroed_frame()
        .map(|frame| frame.physical_address())
        .ok_or(ProcessError::OutOfFrames)
}

fn frame_pointer(address: u64) -> Result<*mut u8, ProcessError> {
    if address & 0xFFF != 0 { return Err(ProcessError::HhdmUnavailable); }
    physical::hhdm_pointer_for_page_table(address)
        .map(|pointer| pointer.as_ptr())
        .ok_or(ProcessError::HhdmUnavailable)
}

fn write_table_entry(table_address: u64, index: usize, value: u64) -> Result<(), ProcessError> {
    if index >= 512 { return Err(ProcessError::AddressSpaceSetupFailed); }
    let ptr = frame_pointer(table_address)? as *mut u64;
    unsafe { ptr.add(index).write_volatile(value); }
    Ok(())
}

/// Make every inherited mapping in this process root supervisor-only.
///
/// The x86 U/S permission is the AND of the bit at every paging level. A
/// bootloader may legitimately leave U/S set in a PML4 parent while all of its
/// leaf mappings remain supervisor-only. Rejecting that parent bit alone is
/// therefore too strict. Since this is a private PML4 clone, clearing U/S only
/// in the cloned top-level entries is safe: kernel accesses still run at CPL0,
/// while no inherited subtree can be reached from CPL3. The dedicated user
/// slot is checked separately and populated only after sanitization.
fn sanitize_inherited_kernel_entries(root: *mut u64) -> Result<(), ProcessError> {
    for index in 0..512 {
        let entry = unsafe { root.add(index).read_volatile() };
        if index == USER_PML4_SLOT {
            if entry != 0 { return Err(ProcessError::UserSlotOccupied); }
            continue;
        }
        if entry & PRESENT != 0 && entry & USER != 0 {
            unsafe { root.add(index).write_volatile(entry & !USER); }
        }
    }

    // Read back the sanitized root so a malformed or failed write is rejected
    // before any user code can run.
    for index in 0..512 {
        if index == USER_PML4_SLOT { continue; }
        let entry = unsafe { root.add(index).read_volatile() };
        if entry & PRESENT != 0 && entry & USER != 0 {
            return Err(ProcessError::InheritedUserMapping);
        }
    }
    Ok(())
}

fn create_process(pid: u64, code_tag: u32, kernel_stack: usize, kernel_root: u64) -> Result<Process, ProcessError> {
    if !physical::stats().initialized || !physical::stats().hhdm_ready {
        return Err(ProcessError::PhysicalMemoryUnavailable);
    }
    if !paging::stats().initialized { return Err(ProcessError::PagingUnavailable); }
    if !paging::stats().nx_enabled { return Err(ProcessError::NxUnavailable); }

    let mut frames = [0u64; 6];
    for index in 0..frames.len() {
        match allocate_frame_address() {
            Ok(address) => frames[index] = address,
            Err(error) => {
                for address in frames { let _ = free_frame_address(address); }
                return Err(error);
            }
        }
    }

    let result = (|| -> Result<Process, ProcessError> {
        let source_root = physical::hhdm_pointer_for_page_table(kernel_root)
            .ok_or(ProcessError::HhdmUnavailable)?;
        let new_root = frame_pointer(frames[0])? as *mut u64;
        unsafe {
            ptr::copy_nonoverlapping(source_root.as_ptr().cast::<u8>(), new_root.cast::<u8>(), 4096);
        }

        // The bootloader may set U/S on PML4 parents even when every leaf is
        // supervisor-only. Sanitize our private clone rather than rejecting a
        // safe parent bit. The original active kernel root is never modified.
        sanitize_inherited_kernel_entries(new_root)?;

        // USER_BASE + offsets gives PML4[1], PDPT[0], PD[0], PTE[1] and PTE[3].
        let parent_flags = PRESENT | WRITABLE | USER;
        if write_table_entry(frames[0], USER_PML4_SLOT, frames[1] | parent_flags).is_err()
            || write_table_entry(frames[1], 0, frames[2] | parent_flags).is_err()
            || write_table_entry(frames[2], 0, frames[3] | parent_flags).is_err()
            || write_table_entry(frames[3], USER_CODE_PTE, frames[4] | PRESENT | USER).is_err()
            || write_table_entry(frames[3], USER_STACK_PTE, frames[5] | PRESENT | WRITABLE | USER | NO_EXECUTE).is_err()
        {
            return Err(ProcessError::AddressSpaceSetupFailed);
        }

        let code_ptr = frame_pointer(frames[4])?;
        let mut code = [0x90u8; 64];
        let length = build_demo_code(&mut code, code_tag);
        unsafe { ptr::copy_nonoverlapping(code.as_ptr(), code_ptr, length); }

        let mut context = empty_context();
        context.base.instruction_pointer = USER_CODE;
        context.base.code_segment = USER_CODE_SELECTOR as u64;
        context.base.flags = 0x202;
        context.user_rsp = USER_STACK_TOP;
        context.user_ss = USER_DATA_SELECTOR as u64;

        Ok(Process {
            pid,
            state: ProcessState::Ready,
            context,
            frames,
            kernel_stack,
            reports: 0,
        })
    })();

    if result.is_err() {
        // The cloned root was never loaded into CR3, so all six owned pages
        // can be returned directly after any partially written private tables.
        for address in frames { let _ = free_frame_address(address); }
    }
    result
}

fn build_demo_code(output: &mut [u8; 64], tag: u32) -> usize {
    let mut cursor = 0usize;
    fn emit_imm(output: &mut [u8; 64], cursor: &mut usize, opcode: u8, value: u32) {
        output[*cursor] = opcode;
        output[*cursor + 1..*cursor + 5].copy_from_slice(&value.to_le_bytes());
        *cursor += 5;
    }
    fn emit_int80(output: &mut [u8; 64], cursor: &mut usize) {
        output[*cursor] = 0xCD;
        output[*cursor + 1] = 0x80;
        *cursor += 2;
    }

    emit_imm(output, &mut cursor, 0xB8, SYS_REPORT as u32); // mov eax, SYS_REPORT
    emit_imm(output, &mut cursor, 0xBF, tag);               // mov edi, tag
    emit_int80(output, &mut cursor);
    emit_imm(output, &mut cursor, 0xB8, SYS_YIELD as u32);
    emit_int80(output, &mut cursor);
    emit_imm(output, &mut cursor, 0xB8, SYS_REPORT as u32);
    emit_imm(output, &mut cursor, 0xBF, tag + 1);
    emit_int80(output, &mut cursor);
    emit_imm(output, &mut cursor, 0xB8, SYS_YIELD as u32);
    emit_int80(output, &mut cursor);
    emit_imm(output, &mut cursor, 0xB8, SYS_EXIT as u32);
    emit_int80(output, &mut cursor);
    output[cursor] = 0x0F; // ud2 as a fail-closed guard if SYS_EXIT returns.
    output[cursor + 1] = 0x0B;
    cursor + 2
}

fn next_ready_after(current: usize) -> Option<usize> {
    let processes = table_mut();
    // Search every other PCB exactly once; do not select the current process
    // again when it is the only task left in READY state.
    for offset in 1..MAX_PROCESSES {
        let candidate = (current + offset) % MAX_PROCESSES;
        if processes[candidate].state == ProcessState::Ready {
            return Some(candidate);
        }
    }
    None
}

fn switch_to(frame: *mut InterruptFrame, next: usize) {
    let processes = table_mut();
    processes[next].state = ProcessState::Running;
    CURRENT_PROCESS.store(next, Ordering::Release);
    let next_stack_top = processes[next].kernel_stack + KERNEL_STACK_BYTES;
    let next_root = processes[next].frames[0];
    let next_context = processes[next].context;
    arch::set_kernel_stack(next_stack_top as u64);
    unsafe { arch::write_cr3(next_root); }
    // This frame is a CPL3 interrupt frame, so hardware supplied the two tail
    // words. Keep it as a raw pointer: a ring-0 frame is only 20 qwords long.
    unsafe {
        frame.write(next_context.base);
        let tail = frame.cast::<u64>().wrapping_add(20);
        tail.write(next_context.user_rsp);
        tail.wrapping_add(1).write(next_context.user_ss);
    }
    CONTEXT_SWITCHES.fetch_add(1, Ordering::Relaxed);
}

fn switch_out_current(frame: *mut InterruptFrame, timer_preempt: bool) -> bool {
    let current = CURRENT_PROCESS.load(Ordering::Acquire);
    if current >= MAX_PROCESSES { return false; }
    {
        let processes = table_mut();
        if processes[current].state != ProcessState::Running { return false; }
        // This scheduler is called only from CPL3 timer/syscall/fault frames.
        // The raw read copies the complete 22-qword hardware frame without
        // constructing an oversized Rust reference for a ring-0 frame.
        processes[current].context = unsafe { ptr::read(user_frame_ptr(frame)) };
        processes[current].state = ProcessState::Ready;
    }
    if let Some(next) = next_ready_after(current) {
        switch_to(frame, next);
        if timer_preempt { TIMER_PREEMPTIONS.fetch_add(1, Ordering::Relaxed); }
        true
    } else {
        table_mut()[current].state = ProcessState::Running;
        false
    }
}

fn request_kernel_return() {
    // The assembly common ISR observes this after the dispatcher returns.
    // Volatile access makes the Rust-to-assembly hand-off explicit. This is a
    // uniprocessor, interrupt-gate path; the flag is cleared before IRQs resume.
    unsafe {
        ptr::write_volatile(ptr::addr_of_mut!(mixedos_return_to_kernel), 1);
    }
}

fn exit_current(frame: *mut InterruptFrame, faulted: bool) {
    let current = CURRENT_PROCESS.load(Ordering::Acquire);
    if current >= MAX_PROCESSES {
        progress_line("[proc] exit handler has no valid current process; returning to kernel.");
        request_kernel_return();
        return;
    }
    progress_line("[proc] exit handler entered; updating current process state...");
    {
        let processes = table_mut();
        if processes[current].state == ProcessState::Running {
            processes[current].state = if faulted { ProcessState::Faulted } else { ProcessState::Exited };
            if faulted { FAULTED.fetch_add(1, Ordering::Relaxed); }
            else { COMPLETED.fetch_add(1, Ordering::Relaxed); }
        } else {
            progress_line("[proc] WARNING: exiting task was not marked RUNNING.");
        }
    }
    progress_line("[proc] exit state updated; scanning for another READY process...");
    if let Some(next) = next_ready_after(current) {
        progress_line(if next == 0 {
            "[proc] scheduler selected process 1 after exit."
        } else {
            "[proc] scheduler selected process 2 after exit."
        });
        switch_to(frame, next);
        progress_line("[proc] exit-time context switch prepared; returning through IRETQ.");
    } else {
        progress_line("[proc] no READY processes remain; requesting direct ISR return to kernel.");
        request_kernel_return();
    }
}

/// Called by PIT IRQ0 when the interrupted context is in ring 3.
pub(crate) fn on_timer(frame: *mut InterruptFrame) {
    let from_user = unsafe { !frame.is_null() && (*frame).code_segment & 3 == 3 };
    if SESSION_ACTIVE.load(Ordering::Acquire) && from_user {
        let _ = switch_out_current(frame, true);
    }
}

/// Dispatch the deliberately small int 0x80 ABI used by the initial user tasks.
pub(crate) fn handle_syscall(frame: *mut InterruptFrame) {
    if frame.is_null() { return; }
    let from_user = unsafe { (*frame).code_segment & 3 == 3 };
    if !SESSION_ACTIVE.load(Ordering::Acquire) || !from_user {
        unsafe { (*frame).rax = u64::MAX; }
        return;
    }
    let syscall_number = unsafe { (*frame).rax };
    match syscall_number {
        SYS_REPORT => {
            let current = CURRENT_PROCESS.load(Ordering::Acquire);
            if current < MAX_PROCESSES {
                let processes = table_mut();
                processes[current].reports = processes[current].reports.saturating_add(1);
                REPORTS.fetch_add(1, Ordering::Relaxed);
                progress_line("[proc] ring-3 REPORT syscall received.");
                unsafe { (*frame).rax = 0; }
            } else {
                unsafe { (*frame).rax = u64::MAX; }
            }
        }
        SYS_YIELD => {
            progress_line("[proc] ring-3 YIELD syscall received; selecting next task.");
            let _ = switch_out_current(frame, false);
        }
        SYS_EXIT => {
            progress_line("[proc] ring-3 EXIT syscall received.");
            exit_current(frame, false);
        },
        _ => unsafe { (*frame).rax = u64::MAX; },
    }
}

/// Recover from a fault in ring 3 by retiring that process and scheduling the
/// next ready process. Kernel-mode faults remain fatal in the interrupt layer.
pub(crate) fn handle_fault(frame: *mut InterruptFrame, _vector: u64, _fault_address: u64) -> bool {
    if frame.is_null() { return false; }
    let from_user = unsafe { (*frame).code_segment & 3 == 3 };
    if !SESSION_ACTIVE.load(Ordering::Acquire) || !from_user { return false; }
    progress_line("[proc] USER-MODE FAULT: retiring this task and trying its peer.");
    exit_current(frame, true);
    true
}

/// Run two tiny, isolated ring-3 tasks to prove GDT/TSS, user page permissions,
/// syscall entry, round-robin yield, timer preemption, and process cleanup.
pub fn run_demo() -> Result<ProcessStats, ProcessError> {
    progress_line("[proc] validating GDT, TSS, CR3, and memory prerequisites...");
    arch::disable_interrupts();
    if SESSION_ACTIVE.swap(true, Ordering::AcqRel) {
        arch::enable_interrupts();
        return Err(ProcessError::AlreadyActive);
    }

    if !arch::gdt_tss_ready() {
        SESSION_ACTIVE.store(false, Ordering::Release);
        arch::enable_interrupts();
        return Err(ProcessError::GdtUnavailable);
    }
    let paging_stats = paging::stats();
    if !paging_stats.initialized {
        SESSION_ACTIVE.store(false, Ordering::Release);
        arch::enable_interrupts();
        return Err(ProcessError::PagingUnavailable);
    }
    if paging_stats.la57_enabled {
        SESSION_ACTIVE.store(false, Ordering::Release);
        arch::enable_interrupts();
        return Err(ProcessError::FiveLevelPagingUnsupported);
    }
    if arch::read_cr3() != paging_stats.root_physical_address {
        SESSION_ACTIVE.store(false, Ordering::Release);
        arch::enable_interrupts();
        return Err(ProcessError::ActiveRootChanged);
    }
    if !physical::stats().initialized || !physical::stats().hhdm_ready {
        SESSION_ACTIVE.store(false, Ordering::Release);
        arch::enable_interrupts();
        return Err(ProcessError::PhysicalMemoryUnavailable);
    }
    if !paging_stats.nx_enabled {
        SESSION_ACTIVE.store(false, Ordering::Release);
        arch::enable_interrupts();
        return Err(ProcessError::NxUnavailable);
    }
    if !heap::initialize() {
        SESSION_ACTIVE.store(false, Ordering::Release);
        arch::enable_interrupts();
        return Err(ProcessError::HeapUnavailable);
    }

    let kernel_root = paging_stats.root_physical_address;
    KERNEL_ROOT.store(kernel_root, Ordering::Release);
    COMPLETED.store(0, Ordering::Relaxed);
    FAULTED.store(0, Ordering::Relaxed);
    REPORTS.store(0, Ordering::Relaxed);
    CONTEXT_SWITCHES.store(0, Ordering::Relaxed);
    TIMER_PREEMPTIONS.store(0, Ordering::Relaxed);
    CLEANUP_ERRORS.store(0, Ordering::Relaxed);
    unsafe {
        mixedos_kernel_return_rsp = 0;
        mixedos_kernel_return_cr3 = 0;
        mixedos_return_to_kernel = 0;
    }

    progress_line("[proc] prerequisites verified; allocating process kernel stacks...");
    let mut kernel_stacks = [0usize; MAX_PROCESSES];
    for index in 0..MAX_PROCESSES {
        match heap::allocate(KERNEL_STACK_BYTES, 16) {
            Ok(pointer) => {
                // Begin with a deterministic, clean interrupt stack.
                unsafe { pointer.as_ptr().write_bytes(0, KERNEL_STACK_BYTES); }
                kernel_stacks[index] = pointer.as_ptr() as usize;
            },
            Err(_) => {
                for stack in kernel_stacks {
                    if stack != 0 {
                        if let Some(pointer) = core::ptr::NonNull::new(stack as *mut u8) {
                            let _ = unsafe { heap::deallocate(pointer) };
                        }
                    }
                }
                KERNEL_ROOT.store(0, Ordering::Release);
                SESSION_ACTIVE.store(false, Ordering::Release);
                arch::set_kernel_stack(arch::kernel_interrupt_stack_top());
                arch::enable_interrupts();
                return Err(ProcessError::KernelStackAllocationFailed);
            }
        }
    }

    let mut new_processes = [Process::EMPTY; MAX_PROCESSES];
    for index in 0..MAX_PROCESSES {
        match create_process(index as u64 + 1, 0xA0 + (index as u32 * 0x10), kernel_stacks[index], kernel_root) {
            Ok(process) => new_processes[index] = process,
            Err(error) => {
                for process in new_processes.iter_mut() {
                    if process.state != ProcessState::Empty { cleanup_process(process); }
                }
                // The current and later stack allocations have not transferred
                // to a Process yet; release any stack not already cleaned.
                for stack in kernel_stacks.iter().skip(index) {
                    if *stack != 0 {
                        if let Some(pointer) = core::ptr::NonNull::new(*stack as *mut u8) {
                            let _ = unsafe { heap::deallocate(pointer) };
                        }
                    }
                }
                KERNEL_ROOT.store(0, Ordering::Release);
                SESSION_ACTIVE.store(false, Ordering::Release);
                arch::set_kernel_stack(arch::kernel_interrupt_stack_top());
                arch::enable_interrupts();
                return Err(error);
            }
        }
    }

    progress_line("[proc] both private address spaces created; preparing scheduler...");
    let processes = table_mut();
    for index in 0..MAX_PROCESSES { processes[index] = new_processes[index]; }
    processes[0].state = ProcessState::Running;
    processes[1].state = ProcessState::Ready;
    CURRENT_PROCESS.store(0, Ordering::Release);
    arch::set_kernel_stack((processes[0].kernel_stack + KERNEL_STACK_BYTES) as u64);
    unsafe {
        // The assembly-only return stub uses this value to restore the kernel
        // address space before switching back to the suspended shell stack.
        mixedos_kernel_return_cr3 = kernel_root;
        arch::write_cr3(processes[0].frames[0]);
    }
    progress_line("[proc] private CR3 active; attempting first IRETQ to CPL3.");

    unsafe { mixedos_enter_user(USER_CODE, USER_STACK_TOP); }

    // The ISR took the one-shot direct-return branch only after the last task
    // exited. Refuse cleanup if the hand-off flag was not observed/retained.
    if unsafe { ptr::read_volatile(ptr::addr_of!(mixedos_return_to_kernel)) } != 1 {
        CLEANUP_ERRORS.fetch_add(1, Ordering::Relaxed);
        serial::write_line("[fatal] process session returned without direct-return handoff flag");
        arch::halt_forever();
    }

    // The return stub has restored the original shell stack and kernel CR3.
    // Verify both invariants before touching any process-owned resources. All
    // cleanup now runs in an ordinary Rust call context, not from a synthetic
    // interrupt-return callback.
    arch::disable_interrupts();
    progress_line("[proc] returned from user mode; verifying restored kernel CR3...");
    if arch::read_cr3() != kernel_root {
        CLEANUP_ERRORS.fetch_add(1, Ordering::Relaxed);
        serial::write_line("[fatal] process cleanup refused: return stub did not restore kernel CR3");
        arch::halt_forever();
    }
    progress_line("[proc] kernel CR3 restored and verified.");
    progress_line("[proc] restoring kernel interrupt stack...");
    arch::set_kernel_stack(arch::kernel_interrupt_stack_top());
    progress_line("[proc] beginning process resource reclamation...");
    cleanup_all();
    progress_line("[proc] all process resources reclaimed.");
    SESSION_ACTIVE.store(false, Ordering::Release);
    KERNEL_ROOT.store(0, Ordering::Release);
    unsafe {
        mixedos_kernel_return_rsp = 0;
        mixedos_kernel_return_cr3 = 0;
        mixedos_return_to_kernel = 0;
    }
    progress_line("[proc] returned to kernel; private address spaces and stacks reclaimed.");
    serial::write_line("[proc] all user tasks returned to the kernel; address spaces and stacks reclaimed");
    arch::enable_interrupts();
    Ok(stats())
}

pub fn stats() -> ProcessStats {
    ProcessStats {
        active: SESSION_ACTIVE.load(Ordering::Acquire),
        completed: COMPLETED.load(Ordering::Relaxed),
        faulted: FAULTED.load(Ordering::Relaxed),
        reports: REPORTS.load(Ordering::Relaxed),
        context_switches: CONTEXT_SWITCHES.load(Ordering::Relaxed),
        timer_preemptions: TIMER_PREEMPTIONS.load(Ordering::Relaxed),
        cleanup_errors: CLEANUP_ERRORS.load(Ordering::Relaxed),
    }
}
