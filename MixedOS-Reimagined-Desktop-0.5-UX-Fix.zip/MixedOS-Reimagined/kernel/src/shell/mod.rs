use core::fmt::Write;

use crate::{
    console::{framebuffer::Terminal, serial},
    input::{self, InputEvent},
    interrupts,
    memory::boot_map::MemorySummary,
};

const INPUT_CAPACITY: usize = 128;
const COMMAND_HISTORY_CAPACITY: usize = 16;

struct CommandHistory {
    lines: [[u8; INPUT_CAPACITY]; COMMAND_HISTORY_CAPACITY],
    lengths: [usize; COMMAND_HISTORY_CAPACITY],
    next: usize,
    count: usize,
}

impl CommandHistory {
    const fn new() -> Self {
        Self {
            lines: [[0; INPUT_CAPACITY]; COMMAND_HISTORY_CAPACITY],
            lengths: [0; COMMAND_HISTORY_CAPACITY],
            next: 0,
            count: 0,
        }
    }

    fn push(&mut self, command: &[u8]) {
        if command.is_empty() { return; }
        if self.count != 0 {
            let last = (self.next + COMMAND_HISTORY_CAPACITY - 1) % COMMAND_HISTORY_CAPACITY;
            if self.lengths[last] == command.len() && &self.lines[last][..command.len()] == command {
                return;
            }
        }
        let length = command.len().min(INPUT_CAPACITY);
        self.lines[self.next].fill(0);
        self.lines[self.next][..length].copy_from_slice(&command[..length]);
        self.lengths[self.next] = length;
        self.next = (self.next + 1) % COMMAND_HISTORY_CAPACITY;
        self.count = (self.count + 1).min(COMMAND_HISTORY_CAPACITY);
    }

    fn newest(&self, age: usize) -> Option<&[u8]> {
        if age == 0 || age > self.count { return None; }
        let index = (self.next + COMMAND_HISTORY_CAPACITY - age) % COMMAND_HISTORY_CAPACITY;
        Some(&self.lines[index][..self.lengths[index]])
    }
}

fn replace_input_line(
    terminal: &mut Option<Terminal>,
    line: &mut [u8; INPUT_CAPACITY],
    line_len: &mut usize,
    replacement: &[u8],
) {
    if let Some(view) = terminal.as_mut() {
        view.scroll_to_bottom();
        for _ in 0..*line_len { view.write("\x08"); }
    }
    for _ in 0..*line_len { serial::write_fmt(format_args!("\x08 \x08")); }
    let length = replacement.len().min(INPUT_CAPACITY - 1);
    line.fill(0);
    line[..length].copy_from_slice(&replacement[..length]);
    *line_len = length;
    if let Ok(text) = core::str::from_utf8(&line[..length]) { emit(terminal, text); }
}

pub fn run(terminal: &mut Option<Terminal>, memory: Option<MemorySummary>) -> ! {
    // Recovery mode intentionally stays in the shell even if EXIT is typed.
    loop { let _ = run_loop(terminal, memory, false, None, None, None); }
}

/// Run the desktop's Terminal app. EXIT or Escape closes the app and returns
/// control to the desktop event loop; it never shuts down the kernel.
pub fn run_terminal(framebuffer: crate::boot::limine::Framebuffer, memory: Option<MemorySummary>) -> bool {
    let Some(view) = Terminal::new_cmd(framebuffer) else { return false; };
    let mut terminal = Some(view);
    run_loop(&mut terminal, memory, true, None, None, None)
}

/// Run the CMD Terminal inside a desktop window. The framebuffer view is
/// clipped to the client rectangle, so terminal painting cannot cover the
/// wallpaper, taskbar, or neighbouring desktop surfaces.
pub fn run_terminal_window(
    framebuffer: crate::boot::limine::Framebuffer,
    memory: Option<MemorySummary>,
    x: usize, y: usize, width: usize, height: usize,
    close_rect: (usize, usize, usize, usize),
) -> bool {
    let Some(view) = Terminal::new_cmd_window(framebuffer, x, y, width, height) else { return false; };
    let mut terminal = Some(view);
    run_loop(&mut terminal, memory, true, Some(close_rect), None, None)
}

pub fn run_terminal_desktop_window(
    framebuffer: crate::boot::limine::Framebuffer,
    memory: Option<MemorySummary>,
    x: usize, y: usize, width: usize, height: usize,
    _close_rect: (usize, usize, usize, usize),
    cursor: &mut crate::desktop::MouseCursor,
) -> bool {
    let Some(view) = Terminal::new_cmd_window(framebuffer, x, y, width, height) else { return false; };
    let mut terminal = Some(view);
    let titlebar = crate::desktop::ui_titlebar_height(framebuffer);
    run_loop(&mut terminal, memory, true, None, Some((framebuffer, cursor)),
        Some((framebuffer, (x.saturating_sub(1), y.saturating_sub(titlebar), width + 2, height + 1 + titlebar))))
}

fn run_loop<'a>(terminal: &mut Option<Terminal>, memory: Option<MemorySummary>, can_exit: bool,
    window_close: Option<(usize, usize, usize, usize)>,
    mut desktop_cursor: Option<(crate::boot::limine::Framebuffer, &'a mut crate::desktop::MouseCursor)>,
    desktop_window: Option<(crate::boot::limine::Framebuffer, (usize, usize, usize, usize))>) -> bool {

    let initial = input::stats();
    if can_exit {
        emit_line(terminal, "MixedOS Command Processor [Version 0.1.0]");
        emit_line(terminal, "(c) MixedOS contributors. All rights reserved.");
        emit_line(terminal, "Type HELP for a list of commands. Type EXIT to return to the desktop.");
        emit_line(terminal, "Keyboard: PS/2 online. Use Up/Down for command history; mouse wheel to scroll.");
    } else {
        emit_line(terminal, "MIXEDOS RECOVERY CONSOLE");
        emit_line(terminal, "Kernel services are running. Type HELP or DIAGNOSTICS.");
        emit_device_status(terminal, initial);
        emit_line(terminal, "USB HID: not implemented; COM1 serial input is available as fallback.");
    }
    if let Some(view) = terminal.as_mut() { view.set_input_status(initial); }
    prompt(terminal, can_exit);

    let mut line = [0u8; INPUT_CAPACITY];
    let mut line_len = 0usize;
    let mut serial_previous_was_cr = false;
    let mut command_history = CommandHistory::new();
    let mut history_position = 0usize;
    let mut scrollbar_dragging = false;
    let mut left_was_down = false;
    let mut dragging_window = false;
    let mut drag_offset = (0usize, 0usize);
    let mut window_rect = desktop_window.map(|(_, rect)| rect);
    let mut restore_rect = window_rect;
    let mut maximized = false;
    let mut minimized = false;

    loop {
        input::poll();
        while let Some(event) = input::pop_event() {
            let byte = match event {
                InputEvent::Key(key) => {
                    if !key.pressed { continue; }
                    if let Some((fb, cursor)) = desktop_cursor.as_mut() { cursor.remove(*fb); }
                    if can_exit && !key.extended && key.scancode == 0x01 { return true; }
                    if minimized {
                        if let Some((fb, cursor)) = desktop_cursor.as_mut() { cursor.draw(*fb); }
                        continue;
                    }
                    if key.extended {
                        match key.scancode {
                            0x48 => {
                                if history_position < command_history.count {
                                    history_position += 1;
                                    if let Some(previous) = command_history.newest(history_position) {
                                        replace_input_line(terminal, &mut line, &mut line_len, previous);
                                    }
                                }
                            }
                            0x50 => {
                                if history_position > 0 {
                                    history_position -= 1;
                                    if history_position == 0 {
                                        replace_input_line(terminal, &mut line, &mut line_len, &[]);
                                    } else if let Some(next) = command_history.newest(history_position) {
                                        replace_input_line(terminal, &mut line, &mut line_len, next);
                                    }
                                }
                            }
                            _ => {}
                        }
                        if let Some((fb, cursor)) = desktop_cursor.as_mut() { cursor.draw(*fb); }
                        continue;
                    }
                    if let Some(view) = terminal.as_mut() { view.scroll_to_bottom(); }
                    match key.ascii { Some(value) => value, None => { if let Some((fb, cursor)) = desktop_cursor.as_mut() { cursor.draw(*fb); } continue; } }
                }
                InputEvent::SerialByte(value) => {
                    if let Some((fb, cursor)) = desktop_cursor.as_mut() { cursor.remove(*fb); }
                    if can_exit && value == 0x1B { return true; }
                    if minimized { if let Some((fb, cursor)) = desktop_cursor.as_mut() { cursor.draw(*fb); } continue; }
                    if value == b'\n' && serial_previous_was_cr {
                        serial_previous_was_cr = false;
                        if let Some((fb, cursor)) = desktop_cursor.as_mut() { cursor.draw(*fb); }
                        continue;
                    }
                    serial_previous_was_cr = value == b'\r';
                    value
                }
                InputEvent::Mouse(mouse) => {
                    if let Some((fb, cursor)) = desktop_cursor.as_mut() { cursor.move_to(*fb, mouse.x, mouse.y); cursor.set_buttons(mouse.buttons); }
                    let left_down = mouse.buttons & 1 != 0;
                    let just_pressed = left_down && !left_was_down;
                    left_was_down = left_down;
                    let mut consumed_pointer = false;
                    let pointer_position = desktop_cursor.as_ref().map(|(_, cursor)| cursor.position());
                    let pointer_framebuffer = desktop_cursor.as_ref().map(|(fb, _)| *fb);
                    if let (Some(fb), Some((px, py))) = (pointer_framebuffer, pointer_position) {
                        if minimized {
                            if just_pressed && crate::desktop::taskbar_hit(fb.width as usize, fb.height as usize, px, py) == Some(0) {
                                minimized = false;
                                if let Some((wx,wy,ww,wh)) = window_rect {
                                    crate::desktop::render_desktop(Some(fb));
                                    crate::desktop::draw_window_frame_state(fb,wx,wy,ww,wh,"Terminal",0x00e07e85,maximized);
                                    let title_h=crate::desktop::ui_titlebar_height(fb);
                                    if let Some(view)=terminal.as_mut(){let _=view.move_cmd_window(fb,wx+1,wy+title_h,ww.saturating_sub(2),wh.saturating_sub(title_h+1));}
                                    if let Some((cursor_fb,cursor))=desktop_cursor.as_mut(){cursor.invalidate();cursor.draw(*cursor_fb);}
                                }
                            }
                            consumed_pointer = true;
                        } else if let Some((wx, wy, ww, wh)) = window_rect {
                            let title_h=crate::desktop::ui_titlebar_height(fb);
                            if let Some((cursor_fb,cursor))=desktop_cursor.as_mut(){
                                cursor.remove(*cursor_fb);
                                crate::desktop::refresh_window_controls(fb,(wx,wy,ww,wh),maximized);
                                cursor.draw(*cursor_fb);
                            }
                            if just_pressed && px >= wx && px < wx.saturating_add(ww) && py >= wy && py < wy.saturating_add(title_h) {
                                if let Some(control)=crate::desktop::window_control_hit(fb,(wx,wy,ww,wh),px,py) {
                                    match control {
                                        0=>{
                                            dragging_window=false;
                                            minimized=true;
                                            if let Some((cursor_fb,cursor))=desktop_cursor.as_mut(){cursor.remove(*cursor_fb);}
                                            crate::desktop::render_desktop(Some(fb));
                                            crate::desktop::draw_minimized_hint(fb,"Terminal");
                                            if let Some((cursor_fb,cursor))=desktop_cursor.as_mut(){cursor.invalidate();cursor.draw(*cursor_fb);}
                                        },
                                        1=>{
                                            dragging_window=false;
                                            if maximized { window_rect=restore_rect; maximized=false; }
                                            else { restore_rect=window_rect; window_rect=Some(crate::desktop::maximized_window_geometry(fb)); maximized=true; }
                                            if let Some((nx,ny,nw,nh))=window_rect {
                                                if let Some((cursor_fb,cursor))=desktop_cursor.as_mut(){cursor.remove(*cursor_fb);}
                                                crate::desktop::render_desktop(Some(fb));
                                                crate::desktop::draw_window_frame_state(fb,nx,ny,nw,nh,"Terminal",0x00e07e85,maximized);
                                                if let Some(view)=terminal.as_mut(){let _=view.move_cmd_window(fb,nx+1,ny+title_h,nw.saturating_sub(2),nh.saturating_sub(title_h+1));}
                                                if let Some((cursor_fb,cursor))=desktop_cursor.as_mut(){cursor.invalidate();cursor.draw(*cursor_fb);}
                                            }
                                        },
                                        2=>return true,
                                        _=>{}
                                    }
                                } else {
                                    dragging_window = true;
                                    drag_offset = (px.saturating_sub(wx), py.saturating_sub(wy));
                                }
                                consumed_pointer = true;
                            }
                            if !left_down { dragging_window = false; }
                            if left_down && dragging_window {
                                let max_x = (fb.width as usize).saturating_sub(ww);
                                let top_limit = title_h.max(1);
                                let max_y = (fb.height as usize).saturating_sub(wh).saturating_sub(crate::desktop::ui_taskbar_height(fb)).max(top_limit);
                                let new_x = px.saturating_sub(drag_offset.0).min(max_x);
                                let new_y = py.saturating_sub(drag_offset.1).clamp(top_limit, max_y);
                                if new_x != wx || new_y != wy {
                                    if let Some((cursor_fb,cursor))=desktop_cursor.as_mut(){cursor.remove(*cursor_fb);}
                                    crate::desktop::render_desktop(Some(fb));
                                    crate::desktop::draw_window_frame_state(fb,new_x,new_y,ww,wh,"Terminal",0x00e07e85,maximized);
                                    if let Some(view) = terminal.as_mut() {
                                        let _ = view.move_cmd_window(fb, new_x + 1, new_y + title_h, ww.saturating_sub(2), wh.saturating_sub(title_h+1));
                                    }
                                    window_rect = Some((new_x, new_y, ww, wh));
                                    if let Some((cursor_fb, cursor)) = desktop_cursor.as_mut() { cursor.invalidate(); cursor.draw(*cursor_fb); }
                                }
                                consumed_pointer = true;
                            }
                        }
                    }
                    if window_rect.is_none() && just_pressed {
                        if let Some((left, top, width, height)) = window_close {
                            // Non-desktop callers supply close rectangles in normalized PS/2 coordinates.
                            let px = mouse.x.max(0) as usize;
                            let py = mouse.y.max(0) as usize;
                            if px >= left && px < left.saturating_add(width)
                                && py >= top && py < top.saturating_add(height) { return true; }
                        }
                    }
                    if mouse.wheel_delta != 0 || mouse.buttons & 1 != 0 {
                        if let Some((fb, cursor)) = desktop_cursor.as_mut() { cursor.remove(*fb); }
                    }
                    if !consumed_pointer {
                        if mouse.wheel_delta > 0 {
                            if let Some(view) = terminal.as_mut() { view.scroll_up((mouse.wheel_delta as usize).saturating_mul(3)); }
                        } else if mouse.wheel_delta < 0 {
                            if let Some(view) = terminal.as_mut() { view.scroll_down((-(mouse.wheel_delta as i16)) as usize * 3); }
                        }
                        if left_down {
                            if let Some(view) = terminal.as_mut() {
                                if scrollbar_dragging { view.scrollbar_drag_to(mouse.y); }
                                else { scrollbar_dragging = view.scrollbar_pointer(mouse.x, mouse.y, true); }
                            }
                        } else { scrollbar_dragging = false; }
                    }
                    if let Some((fb, cursor)) = desktop_cursor.as_mut() { cursor.draw(*fb); }
                    continue;
                },
            };

            match byte {
                b'\r' | b'\n' => {
                    emit(terminal, "\n");
                    command_history.push(&line[..line_len]);
                    let should_exit = execute(terminal, &line[..line_len], memory, &command_history, can_exit);
                    if should_exit { return true; }
                    line_len = 0;
                    line.fill(0);
                    history_position = 0;
                    prompt(terminal, can_exit);
                }
                8 | 127 => {
                    history_position = 0;
                    if line_len > 0 {
                        line_len -= 1;
                        if let Some(view) = terminal.as_mut() { view.write("\x08"); }
                        serial::write_fmt(format_args!("\x08 \x08"));
                    }
                }
                b'\t' => {
                    history_position = 0;
                    for _ in 0..4 {
                        if line_len < INPUT_CAPACITY - 1 {
                            line[line_len] = b' ';
                            line_len += 1;
                            emit(terminal, " ");
                        }
                    }
                }
                0x20..=0x7e if line_len < INPUT_CAPACITY - 1 => {
                    history_position = 0;
                    line[line_len] = byte;
                    line_len += 1;
                    let one = [byte];
                    emit(terminal, core::str::from_utf8(&one).unwrap_or(""));
                }
                _ => {}
            }
            if let Some((fb, cursor)) = desktop_cursor.as_mut() { cursor.draw(*fb); }
        }

        // Polling is intentionally active until the kernel has an idle task
        // and scheduler. The loop does not HLT or depend on IRQ1/IRQ12.
        core::hint::spin_loop();
    }
}

fn emit_device_status(terminal: &mut Option<Terminal>, status: input::InputStats) {
    emit_format_line(
        terminal,
        format_args!(
            "[input] i8042={} config={} kbd={} mouse={} (PS/2)",
            yes_no(status.controller_present),
            if status.command_byte_verified { "verified" } else { "unverified" },
            yes_no(status.keyboard_ready),
            yes_no(status.mouse_ready),
        ),
    );
}

fn yes_no(value: bool) -> &'static str { if value { "ready" } else { "absent" } }

fn execute(terminal: &mut Option<Terminal>, command: &[u8], memory: Option<MemorySummary>, command_history: &CommandHistory, can_exit: bool) -> bool {
    let command = trim_ascii(command);
    if command.is_empty() { return false; }
    let (verb, args) = split_command(command);

    if verb.eq_ignore_ascii_case(b"exit") || verb.eq_ignore_ascii_case(b"quit") {
        if can_exit {
            emit_line(terminal, "Closing Terminal and returning to MixedOS Desktop...");
            return true;
        }
        emit_line(terminal, "EXIT is unavailable in recovery mode. Return with the desktop session shortcut.");
        return false;
    }

    if verb.eq_ignore_ascii_case(b"help") || verb == b"?" || verb.eq_ignore_ascii_case(b"commands") {
        emit_line(terminal, "MIXEDOS COMMANDS");
        emit_line(terminal, "help - Show everyday commands.");
        emit_line(terminal, "diagnostics - Show developer and hardware diagnostics.");
        emit_line(terminal, "cls (clear) - Clear the terminal screen.");
        emit_line(terminal, "echo TEXT - Print text.");
        emit_line(terminal, "history - Show recent commands.");
        emit_line(terminal, "log [clear] - View or clear the in-memory kernel log.");
        emit_line(terminal, "uptime - Show time since kernel timer initialization.");
        emit_line(terminal, "version - Show MixedOS kernel and ABI versions.");
        emit_line(terminal, "drivers - Show driver subsystem readiness.");
        emit_line(terminal, "devices - List the boot-time PCI device inventory.");
        emit_line(terminal, "resources [test] - List or test PCI I/O/MMIO reservations.");
        emit_line(terminal, "dma - Show contiguous DMA32 allocator status.");
        emit_line(terminal, "dmatest - Verify two contiguous DMA32 pages and release them safely.");
        emit_line(terminal, "mkh preview - Preview the kernel-halt screen; press ESC to return.");
        emit_line(terminal, "scroll up|down|top|bottom - Navigate console history.");
        emit_line(terminal, "dir [PATH] (ls alias) - List files and directories.");
        emit_line(terminal, "md PATH (mkdir alias) - Create a directory.");
        emit_line(terminal, "write PATH TEXT - Create a text file.");
        emit_line(terminal, "overwrite PATH TEXT - Replace file contents.");
        emit_line(terminal, "append PATH TEXT - Add text to a file.");
        emit_line(terminal, "rename PATH NAME - Rename a file.");
        emit_line(terminal, "type PATH (cat alias) - Display a text file.");
        emit_line(terminal, "del PATH (rm) / rd PATH (rmdir) - Remove items.");
        emit_line(terminal, "ver - Show the MixedOS version.");
        emit_line(terminal, "exit - Close Terminal and return to the desktop.");
        emit_line(terminal, "reboot - Restart MixedOS.");
        emit_line(terminal, "Filesystem paths use / (example: /notes.txt). Commands are case-insensitive.");
    } else if verb.eq_ignore_ascii_case(b"diagnostics") {
        emit_line(terminal, "DEVELOPER / HARDWARE DIAGNOSTICS");
        emit_line(terminal, "mkh preview - Show the fatal-screen design; press ESC to return.");
        emit_line(terminal, "status commands: sysinfo, mem, memmap, frames, paging, heap, procs, uptime, input");
        emit_line(terminal, "hardware: pci, devices, pci resources, resources, dma");
        emit_line(terminal, "hardware: acpi, memmap, sysinfo, disk, fs");
        emit_line(terminal, "self-tests: memtest, vmtest, heaptest, proctest, fstest, dmatest, resources test");
        emit_line(terminal, "filesystem checks: fsck, sync");
        emit_line(terminal, "system tools: log, uptime, version, drivers");
        emit_line(terminal, "scroll commands: scroll up|down|top|bottom");
        emit_line(terminal, "Destructive: format ataN --erase-dedicated-disk (erases target disk).");
    } else if verb.eq_ignore_ascii_case(b"mkh") {
        if args.eq_ignore_ascii_case(b"preview") {
            if crate::mkh::preview_screen(terminal) {
                emit_line(terminal, "[ok] MKH preview finished; no halt or crash was triggered.");
            } else {
                emit_line(terminal, "[fail] MKH preview could not use the current framebuffer.");
            }
        } else {
            emit_line(terminal, "Usage: mkh preview");
        }
    } else if verb.eq_ignore_ascii_case(b"clear") || verb.eq_ignore_ascii_case(b"cls") {
        if let Some(view) = terminal.as_mut() { view.clear(); view.set_input_status(input::stats()); }
        serial::write_fmt(format_args!("\x1b[2J\x1b[H"));
        emit_line(terminal, "Terminal screen cleared.");
    } else if verb.eq_ignore_ascii_case(b"scroll") {
        match args {
            b"up" => { if let Some(view) = terminal.as_mut() { view.scroll_up(12); } else { emit_line(terminal, "Framebuffer scrollback is unavailable; use COM1 logging."); } }
            b"down" => { if let Some(view) = terminal.as_mut() { view.scroll_down(12); } else { emit_line(terminal, "Framebuffer scrollback is unavailable; use COM1 logging."); } }
            b"top" => { if let Some(view) = terminal.as_mut() { view.scroll_to_top(); } else { emit_line(terminal, "Framebuffer scrollback is unavailable; use COM1 logging."); } }
            b"bottom" => { if let Some(view) = terminal.as_mut() { view.scroll_to_bottom(); } else { emit_line(terminal, "Framebuffer scrollback is unavailable; use COM1 logging."); } }
            _ => emit_line(terminal, "Usage: scroll up|down|top|bottom"),
        }
    } else if verb.eq_ignore_ascii_case(b"echo") {
        let text = core::str::from_utf8(args).unwrap_or("");
        emit_line(terminal, text);
    } else if verb.eq_ignore_ascii_case(b"log") {
        if args.eq_ignore_ascii_case(b"clear") {
            crate::log::clear();
            emit_line(terminal, "Kernel log cleared.");
        } else {
            let count = crate::log::count();
            emit_format_line(terminal, format_args!("KERNEL LOG: {} retained records / {} dropped or truncated.", count, crate::log::dropped()));
            crate::log::visit(|level, message| {
                emit_format_line(terminal, format_args!("[{}] {}", crate::log::level_name(level), message));
            });
        }
    } else if verb.eq_ignore_ascii_case(b"uptime") {
        let ticks = interrupts::ticks();
        let seconds = ticks / 100;
        emit_format_line(terminal, format_args!("Uptime: {} days, {:02}:{:02}:{:02} ({} timer ticks at 100 Hz).", seconds / 86_400, (seconds / 3_600) % 24, (seconds / 60) % 60, seconds % 60, ticks));
    } else if verb.eq_ignore_ascii_case(b"version") || verb.eq_ignore_ascii_case(b"ver") {
        emit_line(terminal, "MixedOS kernel 0.1.0 / x86_64 / Limine base revision 6");
        emit_line(terminal, "Kernel ABI revision 1 / MIXFS v1 / Zig CRC32 backend");
        emit_line(terminal, "Build channel: development; Desktop 0.1 interactive shell and application surfaces.");
    } else if verb.eq_ignore_ascii_case(b"drivers") || verb.eq_ignore_ascii_case(b"driverquery") {
        emit_line(terminal, "MIXEDOS DRIVER SUBSYSTEM STATUS");
        emit_line(terminal, "PS/2 controller: initialized / keyboard: polling / mouse: polling");
        emit_line(terminal, "Legacy ATA PIO: available / MIXFS: mounted when a supported volume is found");
        let inventory = crate::device::stats();
        emit_format_line(terminal, format_args!("PCI inventory: {} discovered / {} recorded / {} driver-bound.", inventory.discovered, inventory.recorded, 0));
        emit_line(terminal, "PCI resource registry: available / BAR sizing and activation not yet implemented");
        emit_line(terminal, "USB xHCI/HID: not implemented / AHCI/NVMe: not implemented");
        emit_line(terminal, "Network, audio, Bluetooth, and GPU acceleration: not implemented");
    } else if verb.eq_ignore_ascii_case(b"history") {
        if command_history.count == 0 {
            emit_line(terminal, "No commands in this session yet.");
        } else {
            let first = command_history.count;
            for age in (1..=first).rev() {
                if let Some(entry) = command_history.newest(age) {
                    let text = core::str::from_utf8(entry).unwrap_or("?");
                    emit_format_line(terminal, format_args!("{:>2}: {}", first - age + 1, text));
                }
            }
        }
    } else if verb.eq_ignore_ascii_case(b"acpi") {
        let info = crate::acpi::inspect();
        emit_format_line(terminal, format_args!("ACPI state: {:?} / RSDP revision {} / root {}.", info.state, info.rsdp_revision, core::str::from_utf8(&info.root_signature).unwrap_or("????")));
        emit_format_line(terminal, format_args!("Tables validated: {} / rejected: {} / entry cap reached: {}.", info.tables_validated, info.tables_rejected, yes_no(info.entries_truncated)));
        emit_format_line(terminal, format_args!("MADT: {} (local APIC entries {}, I/O APIC entries {}) / MCFG segments: {}.", yes_no(info.has_madt), info.local_apic_entries, info.io_apic_entries, info.mcfg_segments));
        emit_format_line(terminal, format_args!("FADT: {} / HPET: {}.", yes_no(info.has_fadt), yes_no(info.has_hpet)));
        emit_line(terminal, "Read-only discovery only: no AML execution, APIC activation, or PCI changes.");
    } else if verb.eq_ignore_ascii_case(b"memmap") {
        match crate::boot::limine::memory_regions() {
            Some(regions) => {
                let mut total = 0usize;
                for region in regions {
                    if total >= 24 { emit_line(terminal, "... additional memory-map regions omitted."); break; }
                    emit_format_line(terminal, format_args!(
                        "{:#018x} + {:#010x} {} ({})",
                        region.base, region.length,
                        crate::boot::limine::memory_type_name(region.entry_type),
                        region.entry_type,
                    ));
                    total += 1;
                }
                emit_format_line(terminal, format_args!("Displayed {} memory-map entries (maximum 24).", total));
            }
            None => emit_line(terminal, "Bootloader memory map is unavailable."),
        }
    } else if verb.eq_ignore_ascii_case(b"sysinfo") || verb.eq_ignore_ascii_case(b"systeminfo") {
        let (usable_bytes, usable_regions) = crate::boot::limine::usable_memory();
        let frames = crate::memory::physical::stats();
        let pci = crate::device::stats();
        let acpi = crate::acpi::inspect();
        let resource = crate::resources::stats();
        let dma = crate::memory::dma::stats();
        emit_line(terminal, "MIXEDOS SYSTEM SUMMARY");
        emit_format_line(terminal, format_args!("Usable boot memory: {} MiB across {} regions.", usable_bytes / (1024 * 1024), usable_regions));
        emit_format_line(terminal, format_args!("Physical allocator: {} / {} free frames.", if frames.initialized { "ready" } else { "not initialized" }, frames.free_frames));
        emit_format_line(terminal, format_args!("PCI devices: {} discovered / {} recorded{}.", pci.discovered, pci.recorded, if pci.truncated { " (registry capped)" } else { "" }));
        emit_format_line(terminal, format_args!("Resource claims: {} / I/O {} / MMIO {}.", resource.reservations, resource.io_port_reservations, resource.mmio_reservations));
        emit_format_line(terminal, format_args!("DMA32 buffers: {} active / {} KiB / {} orphaned.", dma.active_buffers, dma.active_bytes / 1024, dma.orphaned_buffers));
        emit_format_line(terminal, format_args!("ACPI: {:?} / MADT {} / MCFG {}.", acpi.state, yes_no(acpi.has_madt), yes_no(acpi.has_mcfg)));
        emit_format_line(terminal, format_args!("Kernel mode: x86-64 / boot protocol: Limine / timer: {} Hz.", 100));
    } else if verb.eq_ignore_ascii_case(b"mem") {
        match memory {
            Some(summary) => emit_format_line(
                terminal,
                format_args!("Boot map: {} MiB usable across {} regions.", summary.usable_bytes / (1024 * 1024), summary.usable_regions),
            ),
            None => emit_line(terminal, "Boot memory map is unavailable."),
        }
        let stats = crate::memory::physical::stats();
        if stats.initialized {
            emit_format_line(terminal, format_args!(
                "Frames: {} MiB managed / {} MiB free / {} MiB allocated.",
                stats.managed_frames * crate::memory::physical::PAGE_SIZE / (1024 * 1024),
                stats.free_frames * crate::memory::physical::PAGE_SIZE / (1024 * 1024),
                stats.allocated_frames * crate::memory::physical::PAGE_SIZE / (1024 * 1024),
            ));
            emit_format_line(terminal, format_args!("HHDM: {} (64 GiB physical tracking limit).", if stats.hhdm_ready { "ready" } else { "unavailable" }));
            emit_line(terminal, if stats.free_frames.saturating_add(stats.allocated_frames) == stats.managed_frames { "[ok] frame accounting consistent." } else { "[warn] frame accounting mismatch." });
        } else {
            emit_line(terminal, "Physical frame allocator: unavailable.");
        }
    } else if verb.eq_ignore_ascii_case(b"frames") {
        let stats = crate::memory::physical::stats();
        if !stats.initialized {
            emit_line(terminal, "Physical frame allocator is not initialized.");
        } else {
            emit_format_line(terminal, format_args!("Managed: {} pages ({} MiB).", stats.managed_frames, stats.managed_frames * crate::memory::physical::PAGE_SIZE / (1024 * 1024)));
            emit_format_line(terminal, format_args!("Free: {} pages ({} MiB).", stats.free_frames, stats.free_frames * crate::memory::physical::PAGE_SIZE / (1024 * 1024)));
            emit_format_line(terminal, format_args!("Allocated: {} pages ({} MiB).", stats.allocated_frames, stats.allocated_frames * crate::memory::physical::PAGE_SIZE / (1024 * 1024)));
            emit_format_line(terminal, format_args!("Calls: alloc {} / failed {} / free {} / free errors {}.", stats.allocation_calls, stats.allocation_failures, stats.free_calls, stats.free_errors));
            emit_format_line(terminal, format_args!("HHDM: {} / base {:#018x} / maximum tracked {:#x} bytes.", if stats.hhdm_ready { "ready" } else { "unavailable" }, stats.hhdm_offset, stats.max_tracked_bytes));
            emit_line(terminal, if stats.free_frames.saturating_add(stats.allocated_frames) == stats.managed_frames { "[ok] frame accounting consistent." } else { "[warn] frame accounting mismatch." });
        }
    } else if verb.eq_ignore_ascii_case(b"memtest") {
        match crate::memory::physical::self_test(8) {
            Ok(count) => emit_format_line(terminal, format_args!("[ok] Physical memory test passed: {} pages written, verified, zeroed, and freed.", count)),
            Err(reason) => emit_format_line(terminal, format_args!("[fail] Physical memory test: {}.", reason)),
        }
    } else if verb.eq_ignore_ascii_case(b"paging") {
        let stats = crate::memory::paging::stats();
        if !stats.initialized {
            emit_line(terminal, "Virtual memory manager is unavailable; Limine mappings were preserved.");
        } else {
            emit_format_line(terminal, format_args!("Active CR3 root: {:#018x}.", stats.root_physical_address));
            emit_format_line(terminal, format_args!("Address width: {} physical bits / 48-bit virtual addresses.", stats.physical_address_bits));
            emit_format_line(terminal, format_args!("NX: {} / CR0.WP: {} / LA57: {}.", yes_no(stats.nx_enabled), yes_no(stats.write_protect_enabled), if stats.la57_enabled { "enabled" } else { "disabled" }));
            emit_format_line(terminal, format_args!("MixedOS-owned page-table pages: {}.", stats.owned_table_pages));
            emit_format_line(terminal, format_args!("Operations: map {} / unmap {} / map failures {} / TLB invalidations {}.", stats.map_calls, stats.unmap_calls, stats.map_failures, stats.tlb_invalidations));
            emit_line(terminal, "Active Limine CR3 is not replaced; only verified 4 KiB mappings can be added.");
        }
    } else if verb.eq_ignore_ascii_case(b"vmtest") {
        match crate::memory::paging::self_test() {
            Ok(count) => emit_format_line(terminal, format_args!("[ok] Virtual memory test passed: {} pages mapped, accessed, translated, unmapped, and reclaimed.", count)),
            Err(error) => emit_format_line(terminal, format_args!("[fail] Virtual memory test stopped safely: {:?}.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"heap") {
        if !crate::memory::heap::initialize() {
            emit_line(terminal, "[fail] Kernel heap initialization failed; existing boot/input mappings were preserved.");
        } else {
            let stats = crate::memory::heap::stats();
            if !stats.initialized {
                emit_line(terminal, "Kernel heap is unavailable.");
            } else {
                emit_format_line(terminal, format_args!("Arena: {:#018x} / {} pages / {} KiB capacity.", stats.base, stats.mapped_pages, stats.capacity_bytes / 1024));
                emit_format_line(terminal, format_args!("Used: {} bytes / free: {} bytes / largest free: {} bytes.", stats.used_bytes, stats.free_bytes, stats.largest_free_block));
                emit_format_line(terminal, format_args!("Free blocks: {} / active allocations: {} / peak used: {} bytes.", stats.free_blocks, stats.active_allocations, stats.peak_used_bytes));
                emit_format_line(terminal, format_args!("Calls: allocate {} / failed {} / free {} / free errors {}.", stats.allocation_calls, stats.allocation_failures, stats.free_calls, stats.free_errors));
                emit_line(terminal, if stats.free_bytes.saturating_add(stats.used_bytes) == stats.capacity_bytes { "[ok] Heap byte accounting consistent." } else { "[warn] Heap byte accounting mismatch." });
            }
        }
    } else if verb.eq_ignore_ascii_case(b"heaptest") {
        if !crate::memory::heap::initialize() {
            emit_line(terminal, "[fail] Kernel heap initialization failed; no heap test was run.");
        } else {
            match crate::memory::heap::self_test() {
                Ok(count) => emit_format_line(terminal, format_args!("[ok] Kernel heap test passed: {} aligned allocations written, verified, freed, and coalesced.", count)),
                Err(error) => emit_format_line(terminal, format_args!("[fail] Kernel heap test stopped safely: {:?}.", error)),
            }
        }
    } else if verb.eq_ignore_ascii_case(b"proctest") {
        emit_line(terminal, "Starting Stage 6 ring-3 process and scheduler test...");
        // Keep the framebuffer live while the shell is synchronously inside
        // run_demo(). User syscalls/faults can now leave visible breadcrumbs.
        crate::process::set_progress_terminal(terminal as *mut Option<Terminal>);
        let result = crate::process::run_demo();
        crate::process::clear_progress_terminal();
        match result {
            Ok(stats) => {
                emit_format_line(terminal, format_args!("[ok] User-mode test finished: {} processes exited, {} faulted, {} syscall reports.", stats.completed, stats.faulted, stats.reports));
                emit_format_line(terminal, format_args!("Context switches: {} / timer preemptions: {} / cleanup errors: {}.", stats.context_switches, stats.timer_preemptions, stats.cleanup_errors));
                emit_line(terminal, if stats.completed == 2 && stats.faulted == 0 && stats.cleanup_errors == 0 && stats.reports >= 4 { "[ok] Two private user address spaces returned cleanly to the kernel." } else { "[warn] Process test returned, but one or more expected checks did not pass." });
            }
            Err(error) => emit_format_line(terminal, format_args!("[fail] Process test could not start safely: {:?}.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"procs") || verb.eq_ignore_ascii_case(b"tasklist") {
        let stats = crate::process::stats();
        emit_format_line(terminal, format_args!("Scheduler active: {} / completed: {} / faulted: {}.", yes_no(stats.active), stats.completed, stats.faulted));
        emit_format_line(terminal, format_args!("User reports: {} / context switches: {} / timer preemptions: {}.", stats.reports, stats.context_switches, stats.timer_preemptions));
        emit_format_line(terminal, format_args!("Cleanup errors: {}.", stats.cleanup_errors));
        emit_line(terminal, "Two demo processes use separate ring-3 page-table roots; kernel mappings remain supervisor-only and shared.");
    } else if verb.eq_ignore_ascii_case(b"devices") {
        let summary = crate::device::stats();
        emit_line(terminal, "MIXEDOS DEVICE INVENTORY (READ-ONLY PCI SNAPSHOT)");
        emit_format_line(terminal, format_args!("Initialized: {} / discovered: {} / recorded: {}{}.", yes_no(summary.initialized), summary.discovered, summary.recorded, if summary.truncated { " (registry cap reached)" } else { "" }));
        crate::device::visit(|device| {
            emit_format_line(terminal, format_args!(
                "PCI {:02X}:{:02X}.{} {:04X}:{:04X} {} / {} / prog-if {:02X} / rev {:02X} / pin {} / {:?} (unbound)",
                device.bus, device.device, device.function, device.vendor_id, device.device_id,
                crate::device::class_name(device.class_code),
                crate::device::subclass_name(device.class_code, device.subclass),
                device.programming_interface, device.revision_id, device.interrupt_pin, device.state,
            ));
        });
        emit_line(terminal, "Inventory entries are discovered only; no PCI function has been activated by this registry.");
    } else if verb.eq_ignore_ascii_case(b"pci") && args.eq_ignore_ascii_case(b"resources") {
        let resources = crate::pci::resource_summary();
        emit_line(terminal, "PCI RESOURCE INVENTORY (READ-ONLY SNAPSHOT)");
        emit_format_line(terminal, format_args!(
            "Devices: {} found / {} examined{}.",
            resources.devices_found, resources.devices_examined,
            if resources.devices_truncated { " (device cap reached)" } else { "" },
        ));
        emit_format_line(terminal, format_args!(
            "Assigned I/O BARs: {} / MMIO32: {} / MMIO64: {}.",
            resources.io_bars, resources.mmio32_bars, resources.mmio64_bars,
        ));
        emit_format_line(terminal, format_args!(
            "Prefetchable MMIO: {} / unassigned or zero-base: {} / reserved encodings: {}.",
            resources.prefetchable_mmio_bars, resources.zero_base_bars, resources.reserved_bars,
        ));
        emit_line(terminal, "BAR sizes are unknown until a separately quiesced sizing phase; no resources were claimed, mapped, or changed.");
    } else if verb.eq_ignore_ascii_case(b"resources") && args.eq_ignore_ascii_case(b"test") {
        match crate::resources::self_test() {
            Ok(checks) => emit_format_line(terminal, format_args!("[ok] Resource registry test passed: {} checks (overlap rejection, adjacent acceptance, cleanup). No hardware was accessed.", checks)),
            Err(error) => emit_format_line(terminal, format_args!("[fail] Resource registry test stopped safely: {:?}.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"resources") {
        let stats = crate::resources::stats();
        emit_line(terminal, "MIXEDOS RESOURCE RESERVATION REGISTRY");
        emit_format_line(terminal, format_args!("Active claims: {} / {} (I/O {} / MMIO {}).", stats.reservations, crate::resources::MAX_RESERVATIONS, stats.io_port_reservations, stats.mmio_reservations));
        emit_format_line(terminal, format_args!("Rejected: {} / overlaps: {} / orphaned leases: {}.", stats.rejected_requests, stats.overlap_rejections, stats.orphaned_leases));
        if stats.reservations == 0 {
            emit_line(terminal, "No driver claims yet. PCI BAR sizes are still unknown; no hardware ranges have been assigned.");
        } else {
            crate::resources::visit(|entry| {
                emit_format_line(terminal, format_args!(
                    "{} {:#018x} + {:#x} / PCI {:02X}:{:02X}.{} BAR{} / lease {}",
                    if entry.space == crate::resources::ResourceSpace::IoPort { "I/O " } else { "MMIO" },
                    entry.start, entry.length, entry.owner.bus, entry.owner.device,
                    entry.owner.function, entry.owner.bar, entry.generation,
                ));
            });
        }
        emit_line(terminal, "Software reservations only; no BAR sizing, MMIO mapping, or device activation is performed here.");
    } else if verb.eq_ignore_ascii_case(b"dma") {
        let dma = crate::memory::dma::stats();
        let frames = crate::memory::physical::stats();
        emit_line(terminal, "DMA32 ALLOCATOR");
        emit_line(terminal, "Physical buffers are contiguous, page-aligned, zeroed, and constrained below 4 GiB.");
        emit_format_line(terminal, format_args!("Limit: below {:#010x} / maximum buffer: {} KiB.", crate::memory::dma::DMA32_LIMIT_EXCLUSIVE, crate::memory::dma::MAX_DMA_BUFFER_BYTES / 1024));
        emit_format_line(terminal, format_args!("Active buffers: {} / allocated bytes: {} / total allocations: {}.", dma.active_buffers, dma.active_bytes, dma.total_allocations));
        emit_format_line(terminal, format_args!("Allocation failures: {} / orphaned buffers: {} / release errors: {}.", dma.allocation_failures, dma.orphaned_buffers, dma.release_errors));
        emit_format_line(terminal, format_args!("HHDM: {} / frame allocator: {}.", yes_no(frames.hhdm_ready), yes_no(frames.initialized)));
        emit_line(terminal, "No device currently receives these buffers. Drivers must quiesce hardware before explicit release.");
    } else if verb.eq_ignore_ascii_case(b"dmatest") {
        match crate::memory::dma::self_test() {
            Ok(pages) => emit_format_line(terminal, format_args!("[ok] DMA32 self-test passed: {} contiguous pages below 4 GiB were zero-checked, written, read back, zeroed, and released.", pages)),
            Err(error) => emit_format_line(terminal, format_args!("[fail] DMA32 self-test stopped safely: {:?}.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"pci") {
        let details = args.eq_ignore_ascii_case(b"detail");
        emit_line(terminal, if details {
            "Scanning conventional PCI configuration space (read-only, detailed)..."
        } else {
            "Scanning conventional PCI configuration space (read-only)..."
        });
        let summary = crate::pci::enumerate(|device| {
            emit_format_line(terminal, format_args!(
                "PCI {:02X}:{:02X}.{} {:04X}:{:04X} class {:02X}:{:02X}:{:02X} rev {:02X} hdr {}",
                device.bus, device.device, device.function, device.vendor_id,
                device.device_id, device.class_code, device.subclass,
                device.programming_interface, device.revision_id, device.header_type,
            ));
            if details {
                if let (Some(subsystem_vendor), Some(subsystem_device)) =
                    (device.subsystem_vendor_id, device.subsystem_device_id)
                {
                    emit_format_line(terminal, format_args!(
                        "  subsystem {:04X}:{:04X}", subsystem_vendor, subsystem_device,
                    ));
                }
                emit_format_line(terminal, format_args!(
                    "  interrupt line {} pin {}", device.interrupt_line, device.interrupt_pin,
                ));
                if let Some(bridge) = device.bridge {
                    emit_format_line(terminal, format_args!(
                        "  bridge buses {} -> {}..{} / latency {}",
                        bridge.primary_bus, bridge.secondary_bus, bridge.subordinate_bus,
                        bridge.secondary_latency_timer,
                    ));
                }
                for index in 0..usize::from(device.bar_count) {
                    match device.bars[index] {
                        crate::pci::PciBar::Unused | crate::pci::PciBar::Continuation => {}
                        crate::pci::PciBar::Io { base } => emit_format_line(terminal, format_args!(
                            "  BAR{} I/O base {:#010X}", index, base,
                        )),
                        crate::pci::PciBar::Memory32 { base, prefetchable } => emit_format_line(terminal, format_args!(
                            "  BAR{} MMIO32 base {:#010X} prefetchable={}", index, base, prefetchable,
                        )),
                        crate::pci::PciBar::Memory64 { base, prefetchable } => emit_format_line(terminal, format_args!(
                            "  BAR{} MMIO64 base {:#018X} prefetchable={}", index, base, prefetchable,
                        )),
                        crate::pci::PciBar::Reserved { raw } => emit_format_line(terminal, format_args!(
                            "  BAR{} reserved encoding {:#010X}", index, raw,
                        )),
                    }
                }
            }
        });
        emit_format_line(terminal, format_args!(
            "PCI scan: {} devices found, {} listed{}.",
            summary.devices_found, summary.devices_reported,
            if summary.truncated { " (output capped at 32)" } else { "" },
        ));
        emit_line(terminal, if details {
            "BAR values are read-only snapshots; no BAR sizing, mapping, or drivers were activated."
        } else {
            "Use 'pci detail' for BAR, interrupt, subsystem, and bridge information."
        });
    } else if verb.eq_ignore_ascii_case(b"disk") {
        let selected = crate::storage::ata::selected_index();
        let protected = crate::storage::ata::protected_index();
        let mut found = false;
        for index in 0..crate::storage::ata::DEVICE_SLOTS {
            if let Some(disk) = crate::storage::ata::disk_info(index) {
                found = true;
                let model = core::str::from_utf8(&disk.model).unwrap_or("ATA disk").trim_end();
                let role = if Some(index) == protected { "PROTECTED" } else { "format-capable target" };
                let selection = if Some(index) == selected { " / SELECTED" } else { "" };
                emit_format_line(terminal, format_args!("ata{}: {}{} / {} / {} sectors / {} MiB / {}-byte sectors.", index, role, selection, model, disk.sectors, disk.sectors.saturating_mul(512) / (1024 * 1024), 512));
                emit_format_line(terminal, format_args!("  Addressing: {} / cache flush: {} / reads {} / writes {} / errors {}.", if disk.lba28 { "LBA28" } else { "unsupported" }, yes_no(disk.flush_supported), disk.reads, disk.writes, disk.io_errors));
            }
        }
        if !found {
            emit_line(terminal, "No legacy IDE ATA hard disk detected.");
        } else {
            emit_line(terminal, "The first detected ATA disk is protected and cannot be formatted.");
            emit_line(terminal, "Only a separately detected ATA disk can be named as a MIXFS format target.");
        }
    } else if verb.eq_ignore_ascii_case(b"fs") {
        let fs = crate::storage::vfs::info();
        if !fs.mounted {
            emit_line(terminal, "No MIXFS volume is mounted. Use disk to inspect all ATA devices.");
            emit_line(terminal, "Formatting requires an explicit non-protected target: format ataN --erase-dedicated-disk.");
        } else {
            emit_format_line(terminal, format_args!("MIXFS v1: {} / {} sectors / {} free / {} inodes.", if fs.read_only { "READ-ONLY" } else { "READ-WRITE" }, fs.total_sectors, fs.free_sectors, fs.total_inodes));
            emit_format_line(terminal, format_args!("Generation: {} / clean: {} / file reads: {} / writes: {} / errors: {}.", fs.generation, yes_no(fs.clean), fs.file_reads, fs.file_writes, fs.errors));
        }
    } else if verb.eq_ignore_ascii_case(b"format") {
        let (target, confirmation) = split_first_argument(args);
        let target_index = parse_ata_id(target);
        match target_index {
            None => {
                emit_line(terminal, "No disk was changed.");
                emit_line(terminal, "Usage: format ataN --erase-dedicated-disk");
                emit_line(terminal, "Run disk first. The first detected ATA disk is protected.");
            }
            Some(_) if confirmation != b"--erase-dedicated-disk" => {
                emit_line(terminal, "No disk was changed. The exact destructive confirmation is required.");
                emit_line(terminal, "Usage: format ataN --erase-dedicated-disk");
            }
            Some(index) => {
                emit_format_line(terminal, format_args!("Checking ata{} as the explicit MIXFS target...", index));
                match crate::storage::vfs::format(index, confirmation) {
                    Ok(info) => emit_format_line(terminal, format_args!("[ok] MIXFS v1 formatted and mounted on ata{}: {} sectors free.", index, info.free_sectors)),
                    Err(crate::storage::mixfs::FsError::ProtectedDisk) => emit_line(terminal, "[blocked] That is the protected first-detected disk. No sectors were written."),
                    Err(crate::storage::mixfs::FsError::TargetTooLarge) => emit_line(terminal, "[blocked] Stage 7 only formats test disks up to 512 MiB. No sectors were written."),
                    Err(error) => emit_format_line(terminal, format_args!("[fail] Format refused or failed: {:?}. Inspect disk and filesystem state before retrying.", error)),
                }
            }
        }
    } else if verb.eq_ignore_ascii_case(b"ls") || verb.eq_ignore_ascii_case(b"dir") {
        let path = if args.is_empty() { "/" } else { match core::str::from_utf8(args) { Ok(value) => value, Err(_) => { emit_line(terminal, "Path must be UTF-8."); return false; } } };
        let mut entries: crate::storage::vfs::DirectoryListing = [crate::storage::mixfs::ListEntry::EMPTY; crate::storage::vfs::MAX_LIST_ENTRIES];
        match crate::storage::vfs::list(path, &mut entries) {
            Ok(count) => {
                if count == 0 { emit_line(terminal, "(empty directory)"); }
                for entry in entries.iter().take(count) {
                    let name = core::str::from_utf8(&entry.name[..entry.name_len as usize]).unwrap_or("<invalid-name>");
                    emit_format_line(terminal, format_args!("{} {:>10} {}", if entry.kind == 2 { "DIR " } else { "FILE" }, entry.size, name));
                }
            }
            Err(error) => emit_format_line(terminal, format_args!("[fail] ls: {:?}.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"mkdir") || verb.eq_ignore_ascii_case(b"md") {
        let path = match core::str::from_utf8(args) { Ok(value) if !value.is_empty() => value, _ => { emit_line(terminal, "Usage: mkdir /path"); return false; } };
        match crate::storage::vfs::mkdir(path) {
            Ok(()) => emit_line(terminal, "[ok] Directory created."),
            Err(error) => emit_format_line(terminal, format_args!("[fail] mkdir: {:?}.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"write") {
        let (path_bytes, content) = split_first_argument(args);
        let path = match core::str::from_utf8(path_bytes) { Ok(value) if !value.is_empty() => value, _ => { emit_line(terminal, "Usage: write /path/file.txt text to store"); return false; } };
        match crate::storage::vfs::write_file(path, content) {
            Ok(()) => emit_format_line(terminal, format_args!("[ok] Created {} bytes at {}.", content.len(), path)),
            Err(crate::storage::mixfs::FsError::AlreadyExists) => emit_line(terminal, "[fail] FILE ALREADY EXISTS. Use overwrite to replace its contents."),
            Err(error) => emit_format_line(terminal, format_args!("[fail] write: {:?}.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"overwrite") {
        let (path_bytes, content) = split_first_argument(args);
        let path = match core::str::from_utf8(path_bytes) { Ok(value) if !value.is_empty() => value, _ => { emit_line(terminal, "Usage: overwrite /path/file.txt replacement text"); return false; } };
        match crate::storage::vfs::overwrite_file(path, content) {
            Ok(()) => emit_format_line(terminal, format_args!("[ok] Replaced {} bytes in {}.", content.len(), path)),
            Err(error) => emit_format_line(terminal, format_args!("[fail] overwrite: {:?}.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"append") {
        let (path_bytes, content) = split_first_argument(args);
        let path = match core::str::from_utf8(path_bytes) { Ok(value) if !value.is_empty() => value, _ => { emit_line(terminal, "Usage: append /path/file.txt text to add"); return false; } };
        match crate::storage::vfs::append_file(path, content) {
            Ok(()) => emit_format_line(terminal, format_args!("[ok] Appended {} bytes to {}.", content.len(), path)),
            Err(error) => emit_format_line(terminal, format_args!("[fail] append: {:?}.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"rename") {
        let (path_bytes, new_name_bytes) = split_first_argument(args);
        let path = match core::str::from_utf8(path_bytes) { Ok(value) if !value.is_empty() => value, _ => { emit_line(terminal, "Usage: rename /path/old-name.txt new-name.txt"); return false; } };
        let new_name = match core::str::from_utf8(new_name_bytes) { Ok(value) if !value.is_empty() => value, _ => { emit_line(terminal, "Usage: rename /path/old-name.txt new-name.txt"); return false; } };
        match crate::storage::vfs::rename_file(path, new_name) {
            Ok(()) => emit_format_line(terminal, format_args!("[ok] Renamed {} to {} in the same directory.", path, new_name)),
            Err(error) => emit_format_line(terminal, format_args!("[fail] rename: {:?}.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"cat") || verb.eq_ignore_ascii_case(b"type") {
        let path = match core::str::from_utf8(args) { Ok(value) if !value.is_empty() => value, _ => { emit_line(terminal, "Usage: cat /path/file.txt"); return false; } };
        let mut data = [0u8; 2048];
        match crate::storage::vfs::read_file(path, &mut data) {
            Ok(count) => match core::str::from_utf8(&data[..count]) {
                Ok(text) => { emit(terminal, text); if !text.ends_with('\n') { emit(terminal, "\n"); } },
                Err(_) => emit_line(terminal, "[binary file; use a future file utility to inspect raw bytes]"),
            },
            Err(error) => emit_format_line(terminal, format_args!("[fail] cat: {:?}. File may exceed the 2 KiB console read limit.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"rm") || verb.eq_ignore_ascii_case(b"del") {
        let path = match core::str::from_utf8(args) { Ok(value) if !value.is_empty() => value, _ => { emit_line(terminal, "Usage: rm /path"); return false; } };
        match crate::storage::vfs::remove_file(path) {
            Ok(()) => emit_line(terminal, "[ok] File removed."),
            Err(error) => emit_format_line(terminal, format_args!("[fail] rm: {:?}. This command removes files only.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"rmdir") || verb.eq_ignore_ascii_case(b"rd") {
        let path = match core::str::from_utf8(args) { Ok(value) if !value.is_empty() => value, _ => { emit_line(terminal, "Usage: rmdir /empty-directory"); return false; } };
        match crate::storage::vfs::remove_dir(path) {
            Ok(()) => emit_line(terminal, "[ok] Empty directory removed."),
            Err(error) => emit_format_line(terminal, format_args!("[fail] rmdir: {:?}. Only empty directories can be removed.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"fsck") || verb.eq_ignore_ascii_case(b"chkdsk") {
        match crate::storage::vfs::check() {
            Ok(sectors) => emit_format_line(terminal, format_args!("[ok] MIXFS check passed: {} data sectors referenced; volume is now clean/read-write.", sectors)),
            Err(error) => emit_format_line(terminal, format_args!("[fail] MIXFS check found a problem: {:?}. Volume remains read-only if it was dirty.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"fstest") {
        match crate::storage::vfs::self_test() {
            Ok(_) => emit_line(terminal, "[ok] Persistent filesystem test passed: create, write, read, verify, delete, and free-space accounting."),
            Err(error) => emit_format_line(terminal, format_args!("[fail] Filesystem test: {:?}.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"sync") {
        match crate::storage::vfs::sync() {
            Ok(()) => emit_line(terminal, "[ok] Storage flush completed."),
            Err(error) => emit_format_line(terminal, format_args!("[fail] sync: {:?}.", error)),
        }
    } else if verb.eq_ignore_ascii_case(b"uptime") {
        let seconds = interrupts::ticks() / 100;
        emit_format_line(terminal, format_args!("Uptime: {}m {}s (100 Hz PIT).", seconds / 60, seconds % 60));
    } else if verb.eq_ignore_ascii_case(b"input") {
        let s = input::stats();
        emit_format_line(terminal, format_args!("i8042: {} / status 0x{:02X} / command byte 0x{:02X} ({})", yes_no(s.controller_present), s.controller_status, s.command_byte, if s.command_byte_verified { "verified" } else { "unverified" }));
        emit_format_line(terminal, format_args!("Keyboard: {} / bytes {} / last 0x{:02X}", yes_no(s.keyboard_ready), s.keyboard_bytes, s.last_keyboard_byte));
        emit_format_line(terminal, format_args!("PS/2 mouse: {} / wheel protocol {} / bytes {} / last 0x{:02X}", yes_no(s.mouse_ready), if s.mouse_wheel_protocol { "ID3" } else { "3-byte" }, s.mouse_bytes, s.last_mouse_byte));
        emit_format_line(terminal, format_args!("Mouse position: {},{} / buttons 0b{:03b} / wheel total {}", s.mouse_x, s.mouse_y, s.mouse_buttons, s.mouse_wheel_delta));
        emit_format_line(terminal, format_args!("Controller errors: {} / dropped events: {}", s.controller_errors, s.dropped_events));
        emit_line(terminal, "USB HID: not implemented. COM1 serial input remains available.");
    } else if verb.eq_ignore_ascii_case(b"reboot") {
        emit_line(terminal, "Requesting a system reset...");
        for _ in 0..100_000 {
            if unsafe { crate::arch::inb(0x64) } & 0x02 == 0 {
                unsafe { crate::arch::outb(0x64, 0xFE); }
                break;
            }
            core::hint::spin_loop();
        }
        crate::arch::disable_interrupts();
        crate::arch::halt_forever();
    } else {
        let name = core::str::from_utf8(verb).unwrap_or("?");
        emit_format_line(terminal, format_args!("'{}' is not recognized as an internal or external command.", name));
        emit_line(terminal, "Type HELP for available commands.");
    }
    false
}

fn parse_ata_id(input: &[u8]) -> Option<usize> {
    match input {
        b"ata0" => Some(0),
        b"ata1" => Some(1),
        b"ata2" => Some(2),
        b"ata3" => Some(3),
        _ => None,
    }
}

fn split_command(command: &[u8]) -> (&[u8], &[u8]) {
    match command.iter().position(|byte| byte.is_ascii_whitespace()) {
        Some(index) => (&command[..index], trim_ascii(&command[index..])),
        None => (command, &[]),
    }
}

fn split_first_argument(args: &[u8]) -> (&[u8], &[u8]) {
    match args.iter().position(|byte| byte.is_ascii_whitespace()) {
        Some(index) => (&args[..index], trim_ascii(&args[index..])),
        None => (args, &[]),
    }
}

fn trim_ascii(mut bytes: &[u8]) -> &[u8] {
    while bytes.first().is_some_and(u8::is_ascii_whitespace) { bytes = &bytes[1..]; }
    while bytes.last().is_some_and(u8::is_ascii_whitespace) { bytes = &bytes[..bytes.len() - 1]; }
    bytes
}

fn emit(terminal: &mut Option<Terminal>, text: &str) {
    if let Some(view) = terminal.as_mut() { view.write(text); }
    serial::write_fmt(format_args!("{}", text));
}

fn emit_line(terminal: &mut Option<Terminal>, text: &str) {
    if let Some(view) = terminal.as_mut() { view.write_line(text); }
    serial::write_line(text);
}

fn prompt(terminal: &mut Option<Terminal>, cmd_mode: bool) {
    if cmd_mode { emit(terminal, "C:\\MIXEDOS> "); }
    else { emit(terminal, "MIXEDOS-RECOVERY> "); }
}

fn emit_format_line(terminal: &mut Option<Terminal>, arguments: core::fmt::Arguments<'_>) {
    struct Output<'a> { terminal: &'a mut Option<Terminal> }
    impl core::fmt::Write for Output<'_> {
        fn write_str(&mut self, text: &str) -> core::fmt::Result {
            if let Some(view) = self.terminal.as_mut() { view.write(text); }
            serial::write_fmt(format_args!("{}", text));
            Ok(())
        }
    }
    let mut output = Output { terminal };
    let _ = output.write_fmt(arguments);
    if let Some(view) = output.terminal.as_mut() { view.write("\n"); }
    serial::write_line("");
}
