//! MixedOS Desktop 0.5: C-composited desktop shell with Rust-owned app surfaces.
//!
//! The normal boot destination is the desktop. Terminal opens the CMD-style
//! shell; F1 remains a separate kernel recovery console.

use crate::boot::limine::Framebuffer;
use crate::console::{font_arimo, framebuffer::Terminal, serial};
use crate::input::{self, InputEvent, MOD_ALT, MOD_CONTROL};
use crate::memory::boot_map::MemorySummary;

const WALLPAPER_RLE: &[u8] = include_bytes!("../assets/wallpaper/mixedos.rle");
const WALLPAPER_MAGIC: &[u8; 8] = b"MIXWALL1";
const HEADER_LEN: usize = 22;

pub fn render_preview(framebuffer: Option<Framebuffer>) -> bool { render_framebuffer(framebuffer, true) }
pub fn render_desktop(framebuffer: Option<Framebuffer>) -> bool { render_framebuffer(framebuffer, false) }

unsafe extern "C" {
    fn mixedos_ui_init(address: *mut u8, width: u32, height: u32, pitch: u32, bpp: u16,
        red_size: u8, red_shift: u8, green_size: u8, green_shift: u8,
        blue_size: u8, blue_shift: u8) -> i32;
    fn mixedos_ui_set_pointer(x: i32, y: i32, buttons: u8);
    fn mixedos_ui_draw_desktop(preview: i32);
    fn mixedos_ui_draw_window(x: i32, y: i32, width: i32, height: i32,
        title: *const u8, accent: u32, maximized: i32);
    fn mixedos_ui_draw_minimized_hint(title: *const u8);
    fn mixedos_ui_draw_window_controls(x: i32, y: i32, width: i32, maximized: i32);
}

fn init_ui_framebuffer(framebuffer: Framebuffer) -> bool {
    if framebuffer.address.is_null() || framebuffer.memory_model != 1
        || (framebuffer.bpp != 24 && framebuffer.bpp != 32)
        || framebuffer.width > u32::MAX as u64 || framebuffer.height > u32::MAX as u64
        || framebuffer.pitch > u32::MAX as u64 { return false; }
    unsafe {
        mixedos_ui_init(framebuffer.address, framebuffer.width as u32, framebuffer.height as u32,
            framebuffer.pitch as u32, framebuffer.bpp, framebuffer.red_mask_size,
            framebuffer.red_mask_shift, framebuffer.green_mask_size, framebuffer.green_mask_shift,
            framebuffer.blue_mask_size, framebuffer.blue_mask_shift) != 0
    }
}

fn ui_scale(framebuffer: Framebuffer, value: usize) -> usize {
    value.saturating_mul(framebuffer.height as usize).saturating_add(540) / 1080
}
pub(crate) fn ui_taskbar_height(framebuffer: Framebuffer) -> usize { ui_scale(framebuffer, 76).max(1) }
pub(crate) fn ui_titlebar_height(framebuffer: Framebuffer) -> usize { ui_scale(framebuffer, 43).max(1) }
fn ui_button_width(framebuffer: Framebuffer) -> usize { ui_scale(framebuffer, 40).max(1) }

pub(crate) fn maximized_window_geometry(framebuffer: Framebuffer) -> (usize, usize, usize, usize) {
    let sw=framebuffer.width as usize; let sh=framebuffer.height as usize;
    let margin=ui_scale(framebuffer, 10).max(4);
    let top=ui_scale(framebuffer, 48).max(24);
    let bottom=ui_taskbar_height(framebuffer).saturating_add(margin);
    let x=margin; let y=top;
    (x,y,sw.saturating_sub(margin*2),sh.saturating_sub(y).saturating_sub(bottom))
}

pub(crate) fn window_control_hit(framebuffer: Framebuffer, rect:(usize,usize,usize,usize), x:usize, y:usize) -> Option<usize> {
    let (wx,wy,ww,_)=rect;
    let title_h=ui_titlebar_height(framebuffer);
    if y<wy || y>=wy.saturating_add(title_h) || ww<ui_button_width(framebuffer)*3 { return None; }
    let button=ui_button_width(framebuffer);
    let controls=wx.saturating_add(ww).saturating_sub(button*3);
    if x<controls || x>=controls+button*3 { return None; }
    Some((x-controls)/button)
}

fn draw_ui_desktop(framebuffer: Framebuffer, preview: bool) -> bool {
    if !init_ui_framebuffer(framebuffer) { return false; }
    unsafe { mixedos_ui_draw_desktop(if preview { 1 } else { 0 }); }
    true
}

fn render_framebuffer(framebuffer: Option<Framebuffer>, preview: bool) -> bool {
    let Some(framebuffer) = framebuffer else { return false; };
    let Some(mut canvas) = DesktopCanvas::new(framebuffer) else { return false; };
    if !canvas.draw_wallpaper(WALLPAPER_RLE) { return false; }
    drop(canvas);
    draw_ui_desktop(framebuffer, preview)
}

/// Called by the freestanding C renderer to fetch glyph metadata and pixels
/// from the kernel's bundled Arimo atlases. The renderer never allocates.
#[unsafe(no_mangle)]
pub extern "C" fn mixedos_ui_font_glyph(character: u8, bold: u8, bitmap: *mut u8,
    bitmap_capacity: u32, width: *mut i32, height: *mut i32, left: *mut i32,
    top: *mut i32, advance: *mut i32, ascent: *mut i32) {
    if bitmap.is_null() || width.is_null() || height.is_null() || left.is_null()
        || top.is_null() || advance.is_null() || ascent.is_null() { return; }
    let weight = if bold != 0 { font_arimo::Weight::Bold } else { font_arimo::Weight::Regular };
    let (glyph, atlas) = font_arimo::glyph(character, weight);
    let bytes = glyph.width as usize * glyph.height as usize;
    if bytes > bitmap_capacity as usize { return; }
    unsafe {
        *width = glyph.width as i32;
        *height = glyph.height as i32;
        *left = glyph.left as i32;
        *top = glyph.top as i32;
        *advance = glyph.advance as i32;
        *ascent = font_arimo::ascent(weight) as i32;
        if bytes != 0 { core::ptr::copy_nonoverlapping(atlas.as_ptr(), bitmap, bytes); }
    }
}

/// Main desktop event loop. F1 enters recovery; Ctrl+Alt+T and the taskbar
/// launch Terminal in a normal decorated window. Apps return to this loop.
pub fn run(framebuffer: Option<Framebuffer>, memory: Option<MemorySummary>) -> ! {
    let Some(info) = framebuffer else {
        serial::write_line("[desktop] framebuffer unavailable; entering recovery console");
        let mut terminal: Option<Terminal> = None;
        crate::shell::run(&mut terminal, memory);
    };
    if !render_desktop(Some(info)) {
        serial::write_line("[desktop] framebuffer or wallpaper unsupported; entering recovery console");
        let mut terminal = Terminal::new(info);
        crate::shell::run(&mut terminal, memory);
    }
    serial::write_line("[desktop] MixedOS Desktop 0.2 active");
    let mut cursor = MouseCursor::new(info);
    cursor.draw(info);
    let mut left_was_down = false;
    loop {
        input::poll();
        while let Some(event) = input::pop_event() {
            match event {
                InputEvent::Key(key) if key.pressed => {
                    if !key.extended && key.scancode == 0x3B {
                        serial::write_line("[desktop] entering kernel recovery console");
                        cursor.invalidate();
                        let mut terminal = Terminal::new(info);
                        crate::shell::run(&mut terminal, memory);
                    }
                    if matches!(key.ascii, Some(b't') | Some(b'T'))
                        && key.modifiers & (MOD_CONTROL | MOD_ALT) == (MOD_CONTROL | MOD_ALT)
                    {
                        open_terminal_window(info, memory, &mut cursor);
                    }
                }
                InputEvent::SerialByte(0x14) => open_terminal_window(info, memory, &mut cursor),
                InputEvent::Mouse(mouse) => {
                    cursor.move_to(info, mouse.x, mouse.y);
                    let left_down = mouse.buttons & 1 != 0;
                    let just_pressed = left_down && !left_was_down;
                    left_was_down = left_down;
                    if just_pressed {
                        let (x, y) = cursor.position();
                        match taskbar_hit(info.width as usize, info.height as usize, x, y)
                            .or_else(|| desktop_launcher_hit(info, x, y)) {
                            Some(0) => open_terminal_window(info, memory, &mut cursor),
                            Some(1) => run_files_app(info, &mut cursor),
                            Some(2) => run_settings_app(info, &mut cursor),
                            Some(3) => run_start_menu(info, memory, &mut cursor),
                            _ => {}
                        }
                    }
                }
                _ => {}
            }
        }
        core::hint::spin_loop();
    }
}

const CURSOR_WIDTH: usize = 20;
const CURSOR_HEIGHT: usize = 26;
const CURSOR_PIXELS: usize = CURSOR_WIDTH * CURSOR_HEIGHT;
const CURSOR_ROWS: [&str; CURSOR_HEIGHT] = [
    "o...................",
    "oo..................",
    "oxo.................",
    "oxxo................",
    "oxxxo...............",
    "oxxxxo..............",
    "oxxxxxo.............",
    "oxxxxxxo............",
    "oxxxxxxxo...........",
    "oxxxxxxxxo..........",
    "oxxxxxxxxxo.........",
    "oxxxxxxxxxxo........",
    "oxxxxxxxxxxxo.......",
    "oxxxxxxxxxxxxo......",
    "oxxxxxxxxxxxxxo.....",
    "oxxxxxxxxxxxxxxo....",
    "oxxxxxxxxxoooooo....",
    "oxxxxxoooo..ox......",
    "oxxxxo......ox......",
    "oxxo........ox......",
    "oxo.........ox......",
    "oo..........ox......",
    "o............ox.....",
    ".............ox.....",
    "..............o.....",
    "....................",
];

/// Black arrow with a gray border. Relative, accelerated movement is applied
/// to raw PS/2 deltas; the old 0..4095 absolute scaling made the pointer feel
/// extremely sluggish at modern framebuffer resolutions.
pub(crate) struct MouseCursor { x: usize, y: usize, saved: [u32; CURSOR_PIXELS], visible: bool }
impl MouseCursor {
    fn new(framebuffer: Framebuffer) -> Self {
        Self { x: (framebuffer.width as usize).saturating_sub(CURSOR_WIDTH) / 2,
            y: (framebuffer.height as usize).saturating_sub(CURSOR_HEIGHT) / 2,
            saved: [0; CURSOR_PIXELS], visible: false }
    }
    pub(crate) fn position(&self) -> (usize, usize) { (self.x, self.y) }
    pub(crate) fn set_buttons(&self, buttons:u8) { unsafe { mixedos_ui_set_pointer(self.x as i32, self.y as i32, buttons); } }
    pub(crate) fn invalidate(&mut self) { self.visible = false; }
    pub(crate) fn move_to(&mut self, framebuffer: Framebuffer, logical_x: i32, logical_y: i32) {
        let Some(mut canvas) = DesktopCanvas::new(framebuffer) else { return; };
        let next_x = (logical_x.clamp(0, 4095) as usize).saturating_mul(canvas.width) / 4096;
        let next_y = (logical_y.clamp(0, 4095) as usize).saturating_mul(canvas.height) / 4096;
        let next_x = next_x.min(canvas.width.saturating_sub(CURSOR_WIDTH));
        let next_y = next_y.min(canvas.height.saturating_sub(CURSOR_HEIGHT));
        if self.visible && self.x == next_x && self.y == next_y { return; }
        if self.visible { self.restore(&mut canvas); }
        self.x = next_x;
        self.y = next_y;
        unsafe { mixedos_ui_set_pointer(self.x as i32, self.y as i32, 0); }
        self.save_and_draw(&mut canvas);
    }
    pub(crate) fn remove(&mut self, framebuffer: Framebuffer) {
        let Some(mut canvas) = DesktopCanvas::new(framebuffer) else { return; };
        if self.visible { self.restore(&mut canvas); }
    }
    pub(crate) fn draw(&mut self, framebuffer: Framebuffer) {
        let Some(mut canvas) = DesktopCanvas::new(framebuffer) else { return; };
        self.x = self.x.min(canvas.width.saturating_sub(CURSOR_WIDTH));
        self.y = self.y.min(canvas.height.saturating_sub(CURSOR_HEIGHT));
        unsafe { mixedos_ui_set_pointer(self.x as i32, self.y as i32, 0); }
        if self.visible { self.restore(&mut canvas); }
        self.save_and_draw(&mut canvas);
    }
    fn restore(&mut self, canvas: &mut DesktopCanvas) {
        for row in 0..CURSOR_HEIGHT { for col in 0..CURSOR_WIDTH {
            canvas.write_raw(self.x + col, self.y + row, self.saved[row * CURSOR_WIDTH + col]);
        }}
        self.visible = false;
    }
    fn save_and_draw(&mut self, canvas: &mut DesktopCanvas) {
        for row in 0..CURSOR_HEIGHT { for col in 0..CURSOR_WIDTH {
            self.saved[row * CURSOR_WIDTH + col] = canvas.read_raw(self.x + col, self.y + row);
        }}
        for (row, shape) in CURSOR_ROWS.iter().enumerate() { for (col, pixel) in shape.bytes().enumerate() {
            let color = match pixel { b'o' => rgb(154, 158, 168), b'x' => rgb(5, 6, 9), _ => continue };
            canvas.pixel(self.x + col, self.y + row, color);
        }}
        self.visible = true;
    }
}


fn taskbar_geometry(_width: usize, height: usize) -> (usize, usize) {
    let taskbar = (76usize.saturating_mul(height).saturating_add(540) / 1080).max(1);
    (height.saturating_sub(taskbar), taskbar)
}
fn dock_start(width: usize, height: usize) -> usize {
    let dock = (252usize.saturating_mul(height).saturating_add(540) / 1080).max(1);
    width.saturating_sub(dock) / 2
}

fn visible_file_rows(window_height: usize) -> usize {
    window_height.saturating_sub(246).checked_div(27).unwrap_or(0).clamp(3, 24)
}

fn file_window_geometry(framebuffer: Framebuffer) -> (usize, usize, usize, usize) {
    let sw = framebuffer.width as usize;
    let sh = framebuffer.height as usize;
    // Keep Files compact like a normal desktop app; scale the preferred
    // dimensions against framebuffer height instead of consuming the screen.
    let width = sw.saturating_sub(ui_scale(framebuffer, 80)).min(ui_scale(framebuffer, 1120));
    let bar = ui_taskbar_height(framebuffer);
    let height = sh.saturating_sub(bar + ui_scale(framebuffer, 120)).min(ui_scale(framebuffer, 680));
    let x = sw.saturating_sub(width) / 2;
    let y = ui_scale(framebuffer, 52) + sh.saturating_sub(bar + ui_scale(framebuffer, 52) + height) / 2;
    (x, y, width, height)
}

pub(crate) fn taskbar_hit(width: usize, height: usize, x: usize, y: usize) -> Option<usize> {
    let (top, _) = taskbar_geometry(width, height);
    if y < top { return None; }
    let scale = height.max(1);
    let margin = 18usize.saturating_mul(scale).saturating_add(540) / 1080;
    if (margin..margin.saturating_add(52usize.saturating_mul(scale).saturating_add(540)/1080)).contains(&x) { return Some(3); }
    let start = dock_start(width, height);
    let unit = |v: usize| v.saturating_mul(scale).saturating_add(540) / 1080;
    for index in 0..3 {
        let left = start + unit(14 + index * 76);
        if x >= left.saturating_sub(unit(4)) && x < left.saturating_add(unit(54)) { return Some(index); }
    }
    None
}

fn desktop_launcher_hit(framebuffer: Framebuffer, x: usize, y: usize) -> Option<usize> {
    let top = (42usize.saturating_mul(framebuffer.height as usize).saturating_add(540) / 1080).max(1);
    let margin = (18usize.saturating_mul(framebuffer.height as usize).saturating_add(540) / 1080).max(1);
    let icon = (44usize.saturating_mul(framebuffer.height as usize).saturating_add(540) / 1080).max(1);
    let step = (112usize.saturating_mul(framebuffer.height as usize).saturating_add(540) / 1080).max(1);
    if x < margin.saturating_sub(8) || x > margin.saturating_add(icon+16) || y < top+30 { return None; }
    let index = (y-(top+30))/step;
    if index < 3 && y < top+30+index*step+step-8 { Some(index) } else { None }
}

fn open_terminal_window(framebuffer: Framebuffer, memory: Option<MemorySummary>, cursor: &mut MouseCursor) {
    let sw = framebuffer.width as usize; let sh = framebuffer.height as usize;
    let width = sw.saturating_sub(32).min(1120).max(300).min(sw.saturating_sub(16));
    let top = ui_scale(framebuffer, 52);
    let available_height = sh.saturating_sub(top + ui_taskbar_height(framebuffer) + ui_scale(framebuffer, 16));
    let height = available_height.min(ui_scale(framebuffer, 680).max(240));
    let x = sw.saturating_sub(width) / 2;
    let y = top + available_height.saturating_sub(height) / 2;
    cursor.remove(framebuffer);
    let _ = render_desktop(Some(framebuffer));
    draw_window_frame(framebuffer, x, y, width, height, "Terminal", rgb(224, 126, 133));
    cursor.invalidate(); cursor.draw(framebuffer);
    let titlebar = ui_titlebar_height(framebuffer);
    let client_x = x + 1; let client_y = y + titlebar;
    let client_w = width.saturating_sub(2); let client_h = height.saturating_sub(titlebar + 1);
    if client_w < 240 || client_h < 160 {
        let _ = crate::shell::run_terminal(framebuffer, memory);
        cursor.remove(framebuffer);
        let _ = render_desktop(Some(framebuffer));
        cursor.draw(framebuffer);
        return;
    }
    let sw = framebuffer.width as usize; let sh = framebuffer.height as usize;
    let close_rect = (
        (x + width.saturating_sub(ui_scale(framebuffer, 30))).saturating_mul(4096) / sw.max(1),
        (y + ui_scale(framebuffer, 8)).saturating_mul(4096) / sh.max(1),
        ui_scale(framebuffer, 22).saturating_mul(4096) / sw.max(1),
        ui_scale(framebuffer, 24).saturating_mul(4096) / sh.max(1),
    );
    let _ = crate::shell::run_terminal_desktop_window(framebuffer, memory, client_x, client_y, client_w, client_h, close_rect, cursor);
    cursor.remove(framebuffer);
    let _ = render_desktop(Some(framebuffer));
    cursor.draw(framebuffer);
}

pub(crate) fn draw_window_frame(framebuffer: Framebuffer, x: usize, y: usize, width: usize, height: usize, title: &str, accent: u32) {
    draw_window_frame_state(framebuffer, x, y, width, height, title, accent, false);
}

pub(crate) fn draw_window_frame_state(framebuffer: Framebuffer, x: usize, y: usize,
    width: usize, height: usize, title: &str, accent: u32, maximized: bool) {
    if !init_ui_framebuffer(framebuffer) { return; }
    let mut title_bytes = [0u8; 48];
    let bytes = title.as_bytes();
    let n = bytes.len().min(title_bytes.len()-1);
    title_bytes[..n].copy_from_slice(&bytes[..n]);
    unsafe { mixedos_ui_draw_window(x as i32, y as i32, width as i32, height as i32,
        title_bytes.as_ptr(), accent, if maximized { 1 } else { 0 }); }
}

pub(crate) fn refresh_window_controls(framebuffer: Framebuffer, rect:(usize,usize,usize,usize), maximized:bool) {
    if !init_ui_framebuffer(framebuffer) { return; }
    unsafe { mixedos_ui_draw_window_controls(rect.0 as i32, rect.1 as i32, rect.2 as i32, if maximized { 1 } else { 0 }); }
}

pub(crate) fn draw_minimized_hint(framebuffer: Framebuffer, title: &str) {
    if !init_ui_framebuffer(framebuffer) { return; }
    let mut title_bytes = [0u8; 24];
    let bytes=title.as_bytes(); let n=bytes.len().min(title_bytes.len()-1);
    title_bytes[..n].copy_from_slice(&bytes[..n]);
    unsafe { mixedos_ui_draw_minimized_hint(title_bytes.as_ptr()); }
}

fn run_start_menu(framebuffer: Framebuffer, memory: Option<MemorySummary>, cursor: &mut MouseCursor) {
    let sw = framebuffer.width as usize; let sh = framebuffer.height as usize;
    let x = ui_scale(framebuffer, 14); let h = ui_scale(framebuffer, 284).min(sh.saturating_sub(ui_taskbar_height(framebuffer) + ui_scale(framebuffer, 22))); let y = sh.saturating_sub(ui_taskbar_height(framebuffer) + h + ui_scale(framebuffer, 10));
    let w = ui_scale(framebuffer, 310).min(sw.saturating_sub(ui_scale(framebuffer, 28)));
    cursor.remove(framebuffer);
    for slide in [0usize] {
        let _ = render_desktop(Some(framebuffer));
        if let Some(mut frame) = DesktopCanvas::new(framebuffer) {
            let panel_y = y + slide;
            frame.alpha_rect(x, panel_y, w, h, rgb(23,18,34), 248);
            frame.rect(x, panel_y, w, 3, rgb(235,131,106));
            frame.text_ui(x+20,panel_y+18,"MIXEDOS",rgb(248,237,232),font_arimo::Weight::Bold);
            frame.text_ui(x+20,panel_y+52,"PINNED APPLICATIONS",rgb(191,174,198),font_arimo::Weight::Bold);
            for (i,label) in ["Terminal","Files","Settings"].iter().enumerate() {
                let yy=panel_y+80+i*48;
                frame.alpha_rect(x+12,yy,w-24,40,rgb(48,36,55),235);
                frame.text_ui(x+28,yy+10,label,rgb(248,237,232),font_arimo::Weight::Regular);
            }
            frame.text_ui(x+20,panel_y+h.saturating_sub(28),"ESC  CLOSE",rgb(181,164,190),font_arimo::Weight::Regular);
        }
    }
    cursor.invalidate(); cursor.draw(framebuffer);
    loop {
        input::poll(); let mut close=false; let mut launch=None;
        while let Some(e)=input::pop_event(){ match e {
            InputEvent::Key(k) if k.pressed => { if !k.extended && k.scancode==0x01 { close=true; } else if let Some(b)=k.ascii { launch=match b.to_ascii_lowercase(){b't'=>Some(0),b'f'=>Some(1),b's'=>Some(2),_=>None}; } },
            InputEvent::Mouse(m)=>{cursor.move_to(framebuffer,m.x,m.y);if m.buttons&1!=0{let(mx,my)=cursor.position();if mx>=x&&mx<x+w&&my>=y+80&&my<y+h.saturating_sub(30){launch=Some(((my-(y+80))/48).min(2));}}},
            _=>{}
        }}
        if let Some(which)=launch { match which {0=>open_terminal_window(framebuffer,memory,cursor),1=>run_files_app(framebuffer,cursor),_=>run_settings_app(framebuffer,cursor)} return; }
        if close { cursor.remove(framebuffer);let _=render_desktop(Some(framebuffer));cursor.draw(framebuffer);return; }
        core::hint::spin_loop();
    }
}

fn draw_settings_surface(framebuffer: Framebuffer, x: usize, y: usize, w: usize, h: usize, maximized: bool) {
    let _=render_desktop(Some(framebuffer));
    draw_window_frame_state(framebuffer,x,y,w,h,"Settings",rgb(173,128,191),maximized);
    let Some(mut c)=DesktopCanvas::new(framebuffer) else { return; };
    let rows=[("Appearance","Wallpaper and desktop colors","ACTIVE"),("Display","Framebuffer mode and resolution","CONNECTED"),("Input","PS/2 pointer acceleration","READY"),("System","MixedOS kernel / x86-64","DEVELOPMENT"),("Storage","MIXFS persistent volume","CHECK STATUS")];
    let scale=|v:usize| ui_scale(framebuffer,v);
    for(i,(a,b,status))in rows.iter().enumerate(){let yy=y+scale(62)+i*scale(70);let row_h=scale(58).max(28);c.alpha_rect(x+scale(24),yy,w.saturating_sub(scale(48)),row_h,rgb(39,30,48),240);c.rect(x+scale(24),yy,scale(3).max(1),row_h,rgb(173,128,191));c.text_ui(x+scale(44),yy+scale(8),a,rgb(248,237,232),font_arimo::Weight::Bold);c.text_ui(x+scale(44),yy+scale(31),b,rgb(195,178,201),font_arimo::Weight::Regular);c.text_ui(x+w.saturating_sub(scale(148)),yy+scale(18),status,rgb(235,131,106),font_arimo::Weight::Regular);}
    c.text_ui(x+scale(24),y+h.saturating_sub(scale(30)),"ESC  CLOSE SETTINGS",rgb(195,178,201),font_arimo::Weight::Regular);
}

fn run_settings_app(framebuffer: Framebuffer, cursor: &mut MouseCursor) {
    let sw=framebuffer.width as usize;let sh=framebuffer.height as usize;
    let w=sw.saturating_sub(ui_scale(framebuffer,100)).min(ui_scale(framebuffer,900));
    let h=sh.saturating_sub(ui_taskbar_height(framebuffer)+ui_scale(framebuffer,150)).min(ui_scale(framebuffer,600));
    let x=(sw-w)/2;let y=(sh-h)/2;
    if w<ui_scale(framebuffer,360)||h<ui_scale(framebuffer,280){return;}
    let mut rect=(x,y,w,h);let mut restore_rect=rect;let mut maximized=false;let mut minimized=false;
    let mut dragging=false;let mut drag_offset=(0usize,0usize);
    cursor.remove(framebuffer);draw_settings_surface(framebuffer,x,y,w,h,false);cursor.invalidate();cursor.draw(framebuffer);
    let mut left_was_down=false;
    loop{
        input::poll();let mut close=false;let mut redraw=false;
        while let Some(e)=input::pop_event(){match e{
            InputEvent::Key(k)if k.pressed&&!k.extended&&k.scancode==0x01=>close=true,
            InputEvent::Mouse(m)=>{
                cursor.move_to(framebuffer,m.x,m.y);
                let down=m.buttons&1!=0;let just=down&&!left_was_down;left_was_down=down;
                let(mx,my)=cursor.position();
                if minimized{
                    dragging=false;
                    if just&&taskbar_hit(sw,sh,mx,my)==Some(2){minimized=false;redraw=true;}
                }else{
                    cursor.remove(framebuffer);refresh_window_controls(framebuffer,rect,maximized);cursor.draw(framebuffer);
                    if just{
                        if let Some(control)=window_control_hit(framebuffer,rect,mx,my){
                            match control{
                                0=>{minimized=true;dragging=false;redraw=true;},
                                1=>{if maximized{rect=restore_rect;maximized=false;}else{restore_rect=rect;rect=maximized_window_geometry(framebuffer);maximized=true;}dragging=false;redraw=true;},
                                2=>close=true,_=>{}
                            }
                        }else{
                            let title_h=ui_titlebar_height(framebuffer);
                            if my>=rect.1&&my<rect.1+title_h&&mx>=rect.0&&mx<rect.0+rect.2{dragging=true;drag_offset=(mx.saturating_sub(rect.0),my.saturating_sub(rect.1));}
                        }
                    }
                    if !down{dragging=false;}
                    if down&&dragging{
                        let nx=mx.saturating_sub(drag_offset.0).min(sw.saturating_sub(rect.2));
                        let min_y=ui_titlebar_height(framebuffer).max(1);
                        let max_y=sh.saturating_sub(rect.3).saturating_sub(ui_taskbar_height(framebuffer)).max(min_y);
                        let ny=my.saturating_sub(drag_offset.1).clamp(min_y,max_y);
                        if nx!=rect.0||ny!=rect.1{rect.0=nx;rect.1=ny;redraw=true;}
                    }
                }
            },_=>{}
        }}
        if close{cursor.remove(framebuffer);let _=render_desktop(Some(framebuffer));cursor.draw(framebuffer);return;}
        if redraw {
            cursor.remove(framebuffer);
            if minimized {
                let _=render_desktop(Some(framebuffer));
                draw_minimized_hint(framebuffer,"Settings");
            } else {
                let(rx,ry,rw,rh)=rect;
                draw_settings_surface(framebuffer,rx,ry,rw,rh,maximized);
            }
            cursor.invalidate();cursor.draw(framebuffer);
        }
        core::hint::spin_loop();
    }
}

fn run_files_app(framebuffer: Framebuffer, cursor: &mut MouseCursor) {
    let mut cwd=[0u8;128];cwd[0]=b'/';let mut cwd_len=1usize;let mut selected=0usize;let mut first=0usize;let mut notice=[0u8;64];let mut notice_len=0usize;let mut left_was_down=false;
    let (mut window_x, mut window_y, mut window_w, mut window_h) = file_window_geometry(framebuffer);
    if window_w < 300 || window_h < 340 { return; }
    let mut restore_rect=(window_x,window_y,window_w,window_h);
    let mut maximized=false;let mut minimized=false;
    let mut dragging=false;let mut drag_offset=(0usize,0usize);
    let mut file_rows=visible_file_rows(window_h);
    let mut last_click_row: Option<usize>=None;
    let mut last_click_tick=0u64;
    let mut first_open=true;
    let mut needs_redraw=true;
    let mut entries: crate::storage::vfs::DirectoryListing=[crate::storage::mixfs::ListEntry::EMPTY;crate::storage::vfs::MAX_LIST_ENTRIES];
    let mut count: usize = 0;
    loop {
        if needs_redraw && !minimized {
            cursor.remove(framebuffer);
            let path=core::str::from_utf8(&cwd[..cwd_len]).unwrap_or("/");
            let list_result=crate::storage::vfs::list(path,&mut entries);
            count=match list_result { Ok(n)=>n, Err(_) => { notice_from_text(&mut notice,&mut notice_len,"MIXFS is unavailable or this folder cannot be read."); 0 } };
            if count==0 { selected=0;first=0; } else {selected=selected.min(count-1);first=first.min(count.saturating_sub(file_rows));}
            if first_open { draw_files_surface(framebuffer,&cwd[..cwd_len],&entries,count,selected,first,file_rows,&notice[..notice_len],window_x,window_y,window_w,window_h,0,maximized); first_open=false; }
            else { draw_files_surface(framebuffer,&cwd[..cwd_len],&entries,count,selected,first,file_rows,&notice[..notice_len],window_x,window_y,window_w,window_h,0,maximized); }
            cursor.invalidate();cursor.draw(framebuffer);
            needs_redraw=false;
        }
        let mut close=false;let mut refresh=false;
        input::poll();
        while let Some(event)=input::pop_event(){match event{
            InputEvent::Key(k) if k.pressed=>{
                if !k.extended&&k.scancode==0x01 {close=true;}
                else if !minimized {
                    if k.extended&&k.scancode==0x48 {selected=selected.saturating_sub(1);if selected<first{first=selected;}refresh=true;}
                    else if k.extended&&k.scancode==0x50 {if count>0{selected=(selected+1).min(count-1);if selected>=first+file_rows{first=selected+1-file_rows;}}refresh=true;}
                    else if !k.extended&&k.scancode==0x0E {go_parent(&mut cwd,&mut cwd_len);selected=0;first=0;refresh=true;}
                    else if !k.extended&&k.scancode==0x1C {if let Some(entry)=entries.get(selected).filter(|_|selected<count){if let Some((pathbuf,pathlen))=join_path(&cwd[..cwd_len],&entry.name[..entry.name_len as usize]){if entry.kind==2{cwd=pathbuf;cwd_len=pathlen;selected=0;first=0;}else if let Ok(full_path)=core::str::from_utf8(&pathbuf[..pathlen]){edit_file(framebuffer,cursor,full_path);}}}refresh=true;}
                    else if matches!(k.ascii,Some(b'f')|Some(b'F')) {if let Some((name,len))=prompt_name(framebuffer,cursor,"Create new folder"){if let Some((pathbuf,plen))=join_path(&cwd[..cwd_len],&name[..len]){notice_from_result(&mut notice,&mut notice_len,crate::storage::vfs::mkdir(core::str::from_utf8(&pathbuf[..plen]).unwrap_or("/")));}refresh=true;}}
                    else if matches!(k.ascii,Some(b'n')|Some(b'N')) {if let Some((name,len))=prompt_name(framebuffer,cursor,"Create new file"){if let Some((pathbuf,plen))=join_path(&cwd[..cwd_len],&name[..len]){notice_from_result(&mut notice,&mut notice_len,crate::storage::vfs::write_file(core::str::from_utf8(&pathbuf[..plen]).unwrap_or("/"),&[]));}refresh=true;}}
                    else if k.extended&&k.scancode==0x53 {if selected<count{remove_selected(&cwd[..cwd_len],&entries[selected],&mut notice,&mut notice_len);refresh=true;}}
                    else if matches!(k.ascii,Some(b'r')|Some(b'R')) {if selected<count{if let Some((name,len))=prompt_name(framebuffer,cursor,"Rename selected item"){let old=join_path(&cwd[..cwd_len],&entries[selected].name[..entries[selected].name_len as usize]);if let Some((oldbuf,oldlen))=old{notice_from_result(&mut notice,&mut notice_len,crate::storage::vfs::rename_file(core::str::from_utf8(&oldbuf[..oldlen]).unwrap_or("/"),core::str::from_utf8(&name[..len]).unwrap_or("")));refresh=true;}}}}
                }
            }
            InputEvent::Mouse(m)=>{
                cursor.move_to(framebuffer,m.x,m.y);
                let down=m.buttons&1!=0;let just=down&&!left_was_down;left_was_down=down;
                let(mx,my)=cursor.position();
                if minimized {
                    dragging=false;
                    if just && taskbar_hit(framebuffer.width as usize,framebuffer.height as usize,mx,my)==Some(1){minimized=false;needs_redraw=true;}
                } else {
                    cursor.remove(framebuffer);refresh_window_controls(framebuffer,(window_x,window_y,window_w,window_h),maximized);cursor.draw(framebuffer);
                    if m.wheel_delta>0{selected=selected.saturating_sub(1);if selected<first{first=selected;}refresh=true;}
                    else if m.wheel_delta<0&&count>0{selected=(selected+1).min(count-1);if selected>=first+file_rows{first=selected+1-file_rows;}refresh=true;}
                    if just {
                        let(mx,my)=cursor.position();let rect=(window_x,window_y,window_w,window_h);
                        if let Some(control)=window_control_hit(framebuffer,rect,mx,my){
                            match control {
                                0=>{minimized=true;dragging=false;let _=render_desktop(Some(framebuffer));draw_minimized_hint(framebuffer,"Files");cursor.invalidate();cursor.draw(framebuffer);},
                                1=>{if maximized{(window_x,window_y,window_w,window_h)=restore_rect;maximized=false;}else{restore_rect=(window_x,window_y,window_w,window_h);(window_x,window_y,window_w,window_h)=maximized_window_geometry(framebuffer);maximized=true;}dragging=false;file_rows=visible_file_rows(window_h);first=first.min(count.saturating_sub(file_rows));refresh=true;},
                                2=>close=true,_=>{}
                            }
                        } else {
                            let title_h=ui_titlebar_height(framebuffer);
                            if my>=window_y&&my<window_y+title_h&&mx>=window_x&&mx<window_x+window_w{
                                dragging=true;drag_offset=(mx.saturating_sub(window_x),my.saturating_sub(window_y));
                            }
                            let x=window_x;let top=window_y;let ww=window_w;let list_top=top+181;let row_h=27;
                            if my>=top+54&&my<top+96{if mx>=x+18&&mx<x+120{if let Some((name,len))=prompt_name(framebuffer,cursor,"Create new folder"){if let Some((p,l))=join_path(&cwd[..cwd_len],&name[..len]){notice_from_result(&mut notice,&mut notice_len,crate::storage::vfs::mkdir(core::str::from_utf8(&p[..l]).unwrap_or("/")));}refresh=true;}}else if mx>=x+130&&mx<x+222{if let Some((name,len))=prompt_name(framebuffer,cursor,"Create new file"){if let Some((p,l))=join_path(&cwd[..cwd_len],&name[..len]){notice_from_result(&mut notice,&mut notice_len,crate::storage::vfs::write_file(core::str::from_utf8(&p[..l]).unwrap_or("/"),&[]));}refresh=true;}}else if mx>=x+228&&mx<x+320{if selected<count{remove_selected(&cwd[..cwd_len],&entries[selected],&mut notice,&mut notice_len);refresh=true;}}else if mx>=x+322&&mx<x+384{go_parent(&mut cwd,&mut cwd_len);refresh=true;}else if mx>=x+410&&mx<x+504&&selected<count{if let Some((name,len))=prompt_name(framebuffer,cursor,"Rename selected item"){let old=join_path(&cwd[..cwd_len],&entries[selected].name[..entries[selected].name_len as usize]);if let Some((oldbuf,oldlen))=old{notice_from_result(&mut notice,&mut notice_len,crate::storage::vfs::rename_file(core::str::from_utf8(&oldbuf[..oldlen]).unwrap_or("/"),core::str::from_utf8(&name[..len]).unwrap_or("")));refresh=true;}}}}
                            else if my>=list_top&&my<list_top+file_rows*row_h&&mx>=x+210{
                                let row=(my-list_top)/row_h+first;
                                if row<count {selected=row;let now=crate::interrupts::ticks();let double_click=last_click_row==Some(row)&&now.wrapping_sub(last_click_tick)<=45;
                                    if double_click {last_click_row=None;let entry=&entries[row];if let Some((pathbuf,pathlen))=join_path(&cwd[..cwd_len],&entry.name[..entry.name_len as usize]){if entry.kind==2{cwd=pathbuf;cwd_len=pathlen;selected=0;first=0;}else if let Ok(full_path)=core::str::from_utf8(&pathbuf[..pathlen]){edit_file(framebuffer,cursor,full_path);}}}
                                    else{last_click_row=Some(row);last_click_tick=now;}refresh=true;
                                }
                            }
                        }
                    }
                    if !down{dragging=false;}
                    if down&&dragging{
                        let nx=mx.saturating_sub(drag_offset.0).min((framebuffer.width as usize).saturating_sub(window_w));
                        let min_y=ui_titlebar_height(framebuffer).max(1);
                        let max_y=(framebuffer.height as usize).saturating_sub(window_h).saturating_sub(ui_taskbar_height(framebuffer)).max(min_y);
                        let ny=my.saturating_sub(drag_offset.1).clamp(min_y,max_y);
                        if nx!=window_x||ny!=window_y{window_x=nx;window_y=ny;refresh=true;}
                    }
                }
            }
            InputEvent::SerialByte(0x1B)=>close=true,_=>{}
        }}
        if close{cursor.remove(framebuffer);let _=render_desktop(Some(framebuffer));cursor.draw(framebuffer);return;}
        if refresh { needs_redraw=true; }
        core::hint::spin_loop();
    }
}

fn go_parent(path:&mut [u8;128],len:&mut usize){if *len<=1{return;}if let Some(pos)=path[..*len].iter().rposition(|b|*b==b'/'){if pos==0{*len=1;}else{*len=pos;}path[*len]=0;}}
fn join_path(parent:&[u8],name:&[u8])->Option<([u8;128],usize)>{
    if name.is_empty() || name.len()>55 || name.contains(&b'/') { return None; }
    let mut out=[0u8;128];
    let mut n=if parent.is_empty(){out[0]=b'/';1}else{
        if parent.len()+name.len()+1>127{return None;}
        out[..parent.len()].copy_from_slice(parent);
        parent.len()
    };
    if n>1{out[n]=b'/';n+=1;}
    if n+name.len()>out.len(){return None;}
    out[n..n+name.len()].copy_from_slice(name);
    n+=name.len();
    Some((out,n))
}
fn notice_from_text(buffer:&mut[u8;64],len:&mut usize,text:&str){*len=text.len().min(buffer.len());buffer[..*len].copy_from_slice(&text.as_bytes()[..*len]);}
fn notice_from_result(buffer:&mut[u8;64],len:&mut usize,result:Result<(),crate::storage::mixfs::FsError>){let text=match result{Ok(())=>"Operation completed.",Err(crate::storage::mixfs::FsError::NotMounted)=>"MIXFS volume is not mounted.",Err(crate::storage::mixfs::FsError::ReadOnlyNeedsCheck)=>"Volume is read-only; run CHKDSK.",Err(crate::storage::mixfs::FsError::AlreadyExists)=>"An item with that name already exists.",Err(crate::storage::mixfs::FsError::NoSpace)=>"The volume is full.",Err(crate::storage::mixfs::FsError::NameTooLong)=>"Name is too long.",Err(_)=>"Operation failed; check volume status."};*len=text.len().min(buffer.len());buffer[..*len].copy_from_slice(&text.as_bytes()[..*len]);}
fn remove_selected(path:&[u8],entry:&crate::storage::mixfs::ListEntry,notice:&mut[u8;64],notice_len:&mut usize){if let Some((p,n))=join_path(path,&entry.name[..entry.name_len as usize]){let full=core::str::from_utf8(&p[..n]).unwrap_or("/");let result=if entry.kind==2{crate::storage::vfs::remove_dir(full)}else{crate::storage::vfs::remove_file(full)};notice_from_result(notice,notice_len,result);}}

fn prompt_name(framebuffer:Framebuffer,cursor:&mut MouseCursor,title:&str)->Option<([u8;56],usize)>{let mut name=[0u8;56];let mut len=0usize;loop{cursor.remove(framebuffer);let _=render_desktop(Some(framebuffer));let x=(framebuffer.width as usize).saturating_sub(440)/2;let y=(framebuffer.height as usize).saturating_sub(180)/2;let Some(mut c)=DesktopCanvas::new(framebuffer)else{return None;};c.alpha_rect(x,y,440,180,rgb(25,19,34),250);c.rect(x,y,440,3,rgb(235,131,106));c.text_ui(x+24,y+22,title,rgb(248,237,232),font_arimo::Weight::Bold);c.alpha_rect(x+24,y+68,392,42,rgb(47,37,55),250);if let Ok(s)=core::str::from_utf8(&name[..len]){c.text_ui(x+36,y+79,s,rgb(248,237,232),font_arimo::Weight::Regular);}c.text_ui(x+24,y+132,"ENTER  CONFIRM     ESC  CANCEL",rgb(188,170,194),font_arimo::Weight::Regular);cursor.invalidate();cursor.draw(framebuffer);input::poll();while let Some(e)=input::pop_event(){match e{InputEvent::Key(k)if k.pressed=>{if !k.extended&&k.scancode==0x01{return None;}if !k.extended&&k.scancode==0x1C{return if len>0{Some((name,len))}else{None};}if !k.extended&&k.scancode==0x0E{len=len.saturating_sub(1);name[len]=0;}else if let Some(b @ 0x20..=0x7e)=k.ascii{if len<55&&b!=b'/'{name[len]=b;len+=1;}}},InputEvent::Mouse(m)=>cursor.move_to(framebuffer,m.x,m.y),_=>{}}}core::hint::spin_loop();}}

const FILE_EDITOR_CAPACITY: usize = 2048;

fn edit_file(framebuffer: Framebuffer, cursor: &mut MouseCursor, path: &str) {
    let mut content = [0u8; FILE_EDITOR_CAPACITY];
    let mut length = match crate::storage::vfs::read_file(path, &mut content) {
        Ok(size) => size,
        Err(_) => return,
    };
    let mut caret = length;
    let mut notice = "CTRL+S SAVE   ESC CLOSE";
    let sw = framebuffer.width as usize;
    let sh = framebuffer.height as usize;
    let w = sw.saturating_sub(ui_scale(framebuffer, 320)).min(ui_scale(framebuffer, 1120));
    let h = sh.saturating_sub(ui_taskbar_height(framebuffer) + ui_scale(framebuffer, 160)).min(ui_scale(framebuffer, 700));
    if w < 300 || h < 260 { return; }
    let top = ui_scale(framebuffer, 52);
    let y = top + sh.saturating_sub(ui_taskbar_height(framebuffer) + top + h) / 2;
    let mut rect = (sw.saturating_sub(w) / 2, y, w, h);
    let mut restore_rect = rect;
    let mut maximized = false;
    let mut minimized = false;
    let mut dragging = false;
    let mut drag_offset = (0usize, 0usize);
    let mut left_was_down = false;
    let mut needs_redraw = true;

    loop {
        if needs_redraw {
            cursor.remove(framebuffer);
            let _ = render_desktop(Some(framebuffer));
            if minimized {
                draw_minimized_hint(framebuffer, "Text Editor");
            } else {
                let (wx, wy, ww, wh) = rect;
                draw_window_frame_state(framebuffer, wx, wy, ww, wh, "Text Editor", rgb(235, 131, 106), maximized);
                let Some(mut c) = DesktopCanvas::new(framebuffer) else { return; };
                let title_h = ui_titlebar_height(framebuffer);
                let toolbar_y = wy + title_h + ui_scale(framebuffer, 8);
                c.alpha_rect(wx + ui_scale(framebuffer, 16), toolbar_y,
                    ww.saturating_sub(ui_scale(framebuffer, 32)), ui_scale(framebuffer, 36), rgb(39, 31, 47), 245);
                c.text_ui(wx + ui_scale(framebuffer, 28), toolbar_y + ui_scale(framebuffer, 10), path,
                    rgb(205, 189, 211), font_arimo::Weight::Regular);
                let save_x = wx + ww.saturating_sub(ui_scale(framebuffer, 104));
                c.alpha_rect(save_x, toolbar_y + ui_scale(framebuffer, 4), ui_scale(framebuffer, 84), ui_scale(framebuffer, 28), rgb(76, 51, 74), 250);
                c.text_ui(save_x + ui_scale(framebuffer, 20), toolbar_y + ui_scale(framebuffer, 10), "SAVE",
                    rgb(248, 237, 232), font_arimo::Weight::Bold);

                let content_y = wy + title_h + ui_scale(framebuffer, 54);
                let footer_h = ui_scale(framebuffer, 34);
                let area_h = wh.saturating_sub(title_h + ui_scale(framebuffer, 94));
                c.alpha_rect(wx + ui_scale(framebuffer, 18), content_y,
                    ww.saturating_sub(ui_scale(framebuffer, 36)), area_h, rgb(13, 13, 22), 250);
                let max_columns = (ww.saturating_sub(ui_scale(framebuffer, 80)) / 9).max(1);
                let max_rows = area_h.saturating_sub(ui_scale(framebuffer, 18)).checked_div(20).unwrap_or(0).max(1);
                let mut row = 0usize;
                let mut start = 0usize;
                let mut caret_row = 0usize;
                let mut caret_col = 0usize;
                for pos in 0..=length {
                    if pos == caret { caret_row = row; caret_col = pos.saturating_sub(start); }
                    if pos == length || content[pos] == b'\n' || pos.saturating_sub(start) >= max_columns {
                        if row < max_rows {
                            if let Ok(text) = core::str::from_utf8(&content[start..pos]) {
                                c.text_ui(wx + ui_scale(framebuffer, 34), content_y + ui_scale(framebuffer, 12) + row * 20,
                                    text, rgb(236, 226, 234), font_arimo::Weight::Regular);
                            }
                        }
                        row += 1;
                        start = if pos < length && content[pos] == b'\n' { pos + 1 } else { pos };
                    }
                }
                if caret_row < max_rows {
                    let caret_x = wx + ui_scale(framebuffer, 34) + caret_col * 9;
                    let caret_y = content_y + ui_scale(framebuffer, 10) + caret_row * 20;
                    c.rect(caret_x, caret_y, 2, 18, rgb(235, 131, 106));
                }
                c.text_ui(wx + ui_scale(framebuffer, 22), wy + wh.saturating_sub(footer_h), notice,
                    rgb(126, 211, 180), font_arimo::Weight::Regular);
            }
            cursor.invalidate();
            cursor.draw(framebuffer);
            needs_redraw = false;
        }

        input::poll();
        let mut close = false;
        while let Some(event) = input::pop_event() {
            match event {
                InputEvent::Key(key) if key.pressed => {
                    if !key.extended && key.scancode == 0x01 { close = true; }
                    else if !minimized && key.modifiers & MOD_CONTROL != 0 && !key.extended && key.scancode == 0x1F {
                        notice = match crate::storage::vfs::overwrite_file(path, &content[..length]) {
                            Ok(()) => "Saved to MIXFS.",
                            Err(crate::storage::mixfs::FsError::ReadOnlyNeedsCheck) => "MIXFS is read-only; run CHKDSK.",
                            Err(crate::storage::mixfs::FsError::NoSpace) => "MIXFS is full; save failed.",
                            Err(_) => "Save failed; check MIXFS status.",
                        };
                        needs_redraw = true;
                    }
                    else if !minimized && key.extended && key.scancode == 0x4B { caret = caret.saturating_sub(1); needs_redraw = true; }
                    else if !minimized && key.extended && key.scancode == 0x4D { caret = (caret + 1).min(length); needs_redraw = true; }
                    else if !minimized && !key.extended && key.scancode == 0x0E && caret > 0 {
                        content.copy_within(caret..length, caret - 1); caret -= 1; length -= 1; needs_redraw = true;
                    }
                    else if !minimized && !key.extended && key.scancode == 0x1C && length < FILE_EDITOR_CAPACITY {
                        content.copy_within(caret..length, caret + 1); content[caret] = b'\n'; caret += 1; length += 1; needs_redraw = true;
                    }
                    else if !minimized && !key.extended && key.ascii.is_some_and(|b| (0x20..=0x7e).contains(&b)) {
                        let byte = key.ascii.unwrap_or_default();
                        if length < FILE_EDITOR_CAPACITY {
                            content.copy_within(caret..length, caret + 1); content[caret] = byte; caret += 1; length += 1;
                            notice = "CTRL+S SAVE   ESC CLOSE";
                            needs_redraw = true;
                        }
                    }
                }
                InputEvent::Mouse(mouse) => {
                    cursor.move_to(framebuffer, mouse.x, mouse.y);
                    let down = mouse.buttons & 1 != 0;
                    let just = down && !left_was_down;
                    left_was_down = down;
                    let (mx, my) = cursor.position();
                    if minimized {
                        dragging = false;
                        if just && taskbar_hit(sw, sh, mx, my) == Some(1) {
                            minimized = false;
                            needs_redraw = true;
                        }
                    } else {
                        cursor.remove(framebuffer);
                        refresh_window_controls(framebuffer, rect, maximized);
                        cursor.draw(framebuffer);
                        if just {
                            if let Some(control) = window_control_hit(framebuffer, rect, mx, my) {
                                match control {
                                    0 => { minimized = true; dragging = false; needs_redraw = true; }
                                    1 => {
                                        if maximized { rect = restore_rect; maximized = false; }
                                        else { restore_rect = rect; rect = maximized_window_geometry(framebuffer); maximized = true; }
                                        dragging = false;
                                        needs_redraw = true;
                                    }
                                    2 => close = true,
                                    _ => {}
                                }
                            } else {
                                let title_h = ui_titlebar_height(framebuffer);
                                let (wx, wy, ww, _) = rect;
                                if my >= wy && my < wy + title_h && mx >= wx && mx < wx + ww {
                                    dragging = true;
                                    drag_offset = (mx.saturating_sub(wx), my.saturating_sub(wy));
                                } else {
                                    let save_x = wx + ww.saturating_sub(ui_scale(framebuffer, 104));
                                    let toolbar_y = wy + title_h + ui_scale(framebuffer, 8);
                                    if my >= toolbar_y + ui_scale(framebuffer, 4)
                                        && my < toolbar_y + ui_scale(framebuffer, 32)
                                        && mx >= save_x && mx < save_x + ui_scale(framebuffer, 84) {
                                        notice = match crate::storage::vfs::overwrite_file(path, &content[..length]) {
                                            Ok(()) => "Saved to MIXFS.",
                                            Err(_) => "Save failed; check MIXFS status.",
                                        };
                                        needs_redraw = true;
                                    }
                                }
                            }
                        }
                        if !down { dragging = false; }
                        if down && dragging {
                            let (_, _, ww, wh) = rect;
                            let nx = mx.saturating_sub(drag_offset.0).min(sw.saturating_sub(ww));
                            let min_y = ui_titlebar_height(framebuffer).max(1);
                            let max_y = sh.saturating_sub(wh).saturating_sub(ui_taskbar_height(framebuffer)).max(min_y);
                            let ny = my.saturating_sub(drag_offset.1).clamp(min_y, max_y);
                            if nx != rect.0 || ny != rect.1 { rect.0 = nx; rect.1 = ny; needs_redraw = true; }
                        }
                    }
                }
                InputEvent::SerialByte(0x1B) => close = true,
                _ => {}
            }
        }
        if close {
            cursor.remove(framebuffer);
            let _ = render_desktop(Some(framebuffer));
            cursor.draw(framebuffer);
            return;
        }
        core::hint::spin_loop();
    }
}

fn draw_files_surface(framebuffer:Framebuffer,path:&[u8],entries:&crate::storage::vfs::DirectoryListing,count:usize,selected:usize,first:usize,file_rows:usize,notice:&[u8],x:usize,base_y:usize,w:usize,h:usize,slide:usize,maximized:bool){
    let Some(mut bg)=DesktopCanvas::new(framebuffer)else{return;};if !bg.draw_wallpaper(WALLPAPER_RLE){return;}drop(bg);if !draw_ui_desktop(framebuffer,false){return;}
    let y=base_y.saturating_add(slide);
    draw_window_frame_state(framebuffer,x,y,w,h,"Files",rgb(232,167,105),maximized);
    let Some(mut c)=DesktopCanvas::new(framebuffer)else{return;};
    c.rect(x+12,y+54,w.saturating_sub(24),40,rgb(43,33,51));
    for (i,label) in ["+ FOLDER","+ FILE","DELETE","UP","RENAME"].iter().enumerate(){let bx=x+18+[0,112,214,314,392][i];let bw=[102,92,92,62,94][i];c.alpha_rect(bx,y+60,bw,28,rgb(69,48,68),245);c.text_ui(bx+10,y+67,label,rgb(248,237,232),font_arimo::Weight::Regular);}
    let side=184usize.min(w/3);c.alpha_rect(x+12,y+106,side,h.saturating_sub(118),rgb(31,25,42),245);c.text_ui(x+28,y+124,"QUICK ACCESS",rgb(185,163,193),font_arimo::Weight::Bold);c.text_ui(x+30,y+160,"Home",rgb(248,237,232),font_arimo::Weight::Regular);c.text_ui(x+30,y+193,"System",rgb(196,178,203),font_arimo::Weight::Regular);c.text_ui(x+30,y+226,"Storage",rgb(196,178,203),font_arimo::Weight::Regular);
    let list_x=x+side+28;let list_w=w.saturating_sub(side+52);let p=core::str::from_utf8(path).unwrap_or("/");c.text_ui(list_x,y+118,p,rgb(235,131,106),font_arimo::Weight::Bold);c.rect(list_x,y+145,list_w,1,rgb(80,61,86));c.text_ui(list_x+8,y+157,"NAME",rgb(185,163,193),font_arimo::Weight::Bold);c.text_ui(list_x+list_w.saturating_sub(125),y+157,"SIZE",rgb(185,163,193),font_arimo::Weight::Bold);
    for visible in 0..file_rows{let idx=first+visible;if idx>=count{break;}let row_y=y+181+visible*27;if idx==selected{c.alpha_rect(list_x,row_y-4,list_w,27,rgb(83,53,78),230);}let e=&entries[idx];let nm=core::str::from_utf8(&e.name[..e.name_len as usize]).unwrap_or("<invalid>");let label=if e.kind==2{"[DIR]"}else{"[FILE]"};c.text_ui(list_x+8,row_y,label,rgb(235,131,106),font_arimo::Weight::Bold);c.text_ui(list_x+62,row_y,nm,rgb(248,237,232),font_arimo::Weight::Regular);if e.kind!=2{let mut size=[b' ';12];let mut v=e.size;let mut n=0;loop{size[11-n]=b'0'+(v%10)as u8;v/=10;n+=1;if v==0||n==10{break;}}let s=core::str::from_utf8(&size[12-n..]).unwrap_or("0");c.text_ui(list_x+list_w.saturating_sub(125),row_y,s,rgb(183,169,191),font_arimo::Weight::Regular);}}
    if count==0{c.text_ui(list_x+10,y+205,"This folder is empty. Use + FOLDER or + FILE.",rgb(193,177,201),font_arimo::Weight::Regular);}
    if !notice.is_empty(){if let Ok(s)=core::str::from_utf8(notice){c.text_ui(x+20,y+h.saturating_sub(48),s,rgb(126,211,180),font_arimo::Weight::Regular);}}
    c.text_ui(x+20,y+h.saturating_sub(26),if notice.is_empty(){"F  NEW FOLDER   N  NEW FILE   R  RENAME   DEL  DELETE   ENTER  OPEN / EDIT"}else{"F  NEW FOLDER   N  NEW FILE   R  RENAME   DEL  DELETE"},rgb(186,169,196),font_arimo::Weight::Regular);
}

struct DesktopCanvas {
    address: *mut u8,
    width: usize,
    height: usize,
    pitch: usize,
    bytes_per_pixel: usize,
    red_size: u8,
    red_shift: u8,
    green_size: u8,
    green_shift: u8,
    blue_size: u8,
    blue_shift: u8,
}

impl DesktopCanvas {
    fn new(fb: Framebuffer) -> Option<Self> {
        if fb.address.is_null() || fb.memory_model != 1 || (fb.bpp != 24 && fb.bpp != 32) {
            return None;
        }
        let width = usize::try_from(fb.width).ok()?;
        let height = usize::try_from(fb.height).ok()?;
        let pitch = usize::try_from(fb.pitch).ok()?;
        let bytes_per_pixel = usize::from(fb.bpp / 8);
        if width < 480 || height < 270 || pitch < width.checked_mul(bytes_per_pixel)? {
            return None;
        }
        pitch.checked_mul(height)?;
        Some(Self {
            address: fb.address,
            width,
            height,
            pitch,
            bytes_per_pixel,
            red_size: fb.red_mask_size,
            red_shift: fb.red_mask_shift,
            green_size: fb.green_mask_size,
            green_shift: fb.green_mask_shift,
            blue_size: fb.blue_mask_size,
            blue_shift: fb.blue_mask_shift,
        })
    }

    fn draw_wallpaper(&mut self, data: &[u8]) -> bool {
        if data.len() < HEADER_LEN || data.get(..8) != Some(WALLPAPER_MAGIC.as_slice()) {
            return false;
        }
        let read_u16 = |offset: usize| -> Option<u16> {
            Some(u16::from_le_bytes([*data.get(offset)?, *data.get(offset + 1)?]))
        };
        let read_u32 = |offset: usize| -> Option<u32> {
            Some(u32::from_le_bytes([
                *data.get(offset)?, *data.get(offset + 1)?,
                *data.get(offset + 2)?, *data.get(offset + 3)?,
            ]))
        };
        let Some(source_width_value) = read_u32(8) else { return false; };
        let Some(source_height_value) = read_u32(12) else { return false; };
        let Some(palette_count_value) = read_u16(16) else { return false; };
        let Some(run_count_value) = read_u32(18) else { return false; };
        let source_width = source_width_value as usize;
        let source_height = source_height_value as usize;
        let palette_count = palette_count_value as usize;
        let run_count = run_count_value as usize;
        if source_width == 0 || source_height == 0 || palette_count == 0 || palette_count > 256
            || run_count == 0 || run_count > 2_000_000
        {
            return false;
        }
        let expected_pixels = match source_width.checked_mul(source_height) {
            Some(value) if value <= 16_777_216 => value,
            _ => return false,
        };
        let palette_bytes = match palette_count.checked_mul(3) { Some(v) => v, None => return false };
        let runs_start = match HEADER_LEN.checked_add(palette_bytes) {
            Some(value) if value <= data.len() => value,
            _ => return false,
        };
        let runs_bytes = match run_count.checked_mul(3) { Some(v) => v, None => return false };
        if runs_start.checked_add(runs_bytes) != Some(data.len()) { return false; }

        // Validate the complete RLE stream before changing framebuffer pixels.
        let mut validated_pixels = 0usize;
        for run_index in 0..run_count {
            let offset = runs_start + run_index * 3;
            let length = u16::from_le_bytes([data[offset], data[offset + 1]]) as usize;
            let palette_index = data[offset + 2] as usize;
            if length == 0 || palette_index >= palette_count { return false; }
            validated_pixels = match validated_pixels.checked_add(length) {
                Some(value) if value <= expected_pixels => value,
                _ => return false,
            };
        }
        if validated_pixels != expected_pixels { return false; }

        self.fill(rgb(9, 9, 10));
        let sw = source_width as u64;
        let sh = source_height as u64;
        let fw = self.width as u64;
        let fh = self.height as u64;
        // Fit the 16:9 image without cropping; letterbox with its night-sky color.
        let (draw_width, draw_height) = if fw.saturating_mul(sh) > fh.saturating_mul(sw) {
            ((fh.saturating_mul(sw) / sh).max(1), fh)
        } else {
            (fw, (fw.saturating_mul(sh) / sw).max(1))
        };
        let offset_x = (fw.saturating_sub(draw_width)) / 2;
        let offset_y = (fh.saturating_sub(draw_height)) / 2;
        let mut source_index = 0usize;
        for run_index in 0..run_count {
            let offset = runs_start + run_index * 3;
            let length = u16::from_le_bytes([data[offset], data[offset + 1]]) as usize;
            let palette_index = data[offset + 2] as usize;
            let palette_offset = HEADER_LEN + palette_index * 3;
            let color = rgb(data[palette_offset], data[palette_offset + 1], data[palette_offset + 2]);
            for _ in 0..length {
                let sx = (source_index % source_width) as u64;
                let sy = (source_index / source_width) as u64;
                let x0 = offset_x + sx * draw_width / sw;
                let x1 = offset_x + (sx + 1) * draw_width / sw;
                let y0 = offset_y + sy * draw_height / sh;
                let y1 = offset_y + (sy + 1) * draw_height / sh;
                if x1 > x0 && y1 > y0 {
                    let x = x0 as usize;
                    let y = y0 as usize;
                    let width = (x1 - x0) as usize;
                    let height = (y1 - y0) as usize;
                    if width == 1 && height == 1 { self.pixel(x, y, color); }
                    else { self.rect(x, y, width, height, color); }
                }
                source_index += 1;
            }
        }
        true
    }

    fn fill(&mut self, color: u32) { self.rect(0, 0, self.width, self.height, color); }

    fn rect(&mut self, x: usize, y: usize, width: usize, height: usize, color: u32) {
        let x_end = x.saturating_add(width).min(self.width);
        let y_end = y.saturating_add(height).min(self.height);
        for py in y.min(self.height)..y_end {
            for px in x.min(self.width)..x_end { self.pixel(px, py, color); }
        }
    }

    fn alpha_rect(&mut self, x: usize, y: usize, width: usize, height: usize, color: u32, alpha: u8) {
        let x_end = x.saturating_add(width).min(self.width);
        let y_end = y.saturating_add(height).min(self.height);
        for py in y.min(self.height)..y_end {
            for px in x.min(self.width)..x_end { self.pixel_coverage(px, py, color, alpha); }
        }
    }

    fn text_ui(&mut self, x: usize, y: usize, text: &str, color: u32, weight: font_arimo::Weight) {
        // Compact desktop typography: render the bundled 16px Arimo atlas at 75%.
        let mut cursor = x;
        let ascent = font_arimo::ascent(weight) * 3 / 4;
        for character in text.chars() {
            let byte = if character.is_ascii() { character as u8 } else { b'?' };
            let (glyph, bitmap) = font_arimo::glyph(byte, weight);
            let gw = glyph.width as usize; let gh = glyph.height as usize;
            let out_w = (gw * 3 + 3) / 4; let out_h = (gh * 3 + 3) / 4;
            for row in 0..out_h {
                let py = y as isize + ascent as isize + (glyph.top as isize * 3 / 4) + row as isize;
                if py < 0 || py as usize >= self.height { continue; }
                for column in 0..out_w {
                    let px = cursor as isize + (glyph.left as isize * 3 / 4) + column as isize;
                    if px < 0 || px as usize >= self.width { continue; }
                    let coverage = bitmap[(row * 4 / 3) * gw + (column * 4 / 3)];
                    if coverage != 0 { self.pixel_coverage(px as usize, py as usize, color, coverage); }
                }
            }
            cursor = cursor.saturating_add((glyph.advance as usize * 3 + 3) / 4);
            if cursor >= self.width { break; }
        }
    }

    fn measure_ui_text(&self, text: &str, weight: font_arimo::Weight) -> usize {
        text.bytes().map(|byte| font_arimo::advance(byte, weight)).sum()
    }

    fn pixel_coverage(&mut self, x: usize, y: usize, color: u32, coverage: u8) {
        if coverage == 0 { return; }
        if coverage == 255 { self.pixel(x, y, color); return; }
        let offset = y * self.pitch + x * self.bytes_per_pixel;
        let raw = unsafe {
            if self.bytes_per_pixel == 4 {
                self.address.add(offset).cast::<u32>().read_volatile()
            } else {
                u32::from(self.address.add(offset).read_volatile())
                    | (u32::from(self.address.add(offset + 1).read_volatile()) << 8)
                    | (u32::from(self.address.add(offset + 2).read_volatile()) << 16)
            }
        };
        let bg_r = unpack_channel(raw, self.red_size, self.red_shift);
        let bg_g = unpack_channel(raw, self.green_size, self.green_shift);
        let bg_b = unpack_channel(raw, self.blue_size, self.blue_shift);
        let alpha = u32::from(coverage);
        let inverse = 255 - alpha;
        let fg_r = (color >> 16) & 0xff;
        let fg_g = (color >> 8) & 0xff;
        let fg_b = color & 0xff;
        let blend = |foreground: u32, background: u8| -> u8 {
            ((foreground * alpha + u32::from(background) * inverse + 127) / 255) as u8
        };
        self.pixel(x, y, rgb(blend(fg_r, bg_r), blend(fg_g, bg_g), blend(fg_b, bg_b)));
    }

    fn read_raw(&self, x: usize, y: usize) -> u32 {
        let offset = y * self.pitch + x * self.bytes_per_pixel;
        unsafe {
            if self.bytes_per_pixel == 4 {
                self.address.add(offset).cast::<u32>().read_volatile()
            } else {
                u32::from(self.address.add(offset).read_volatile())
                    | (u32::from(self.address.add(offset + 1).read_volatile()) << 8)
                    | (u32::from(self.address.add(offset + 2).read_volatile()) << 16)
            }
        }
    }

    fn write_raw(&mut self, x: usize, y: usize, pixel: u32) {
        let offset = y * self.pitch + x * self.bytes_per_pixel;
        unsafe {
            if self.bytes_per_pixel == 4 {
                self.address.add(offset).cast::<u32>().write_volatile(pixel);
            } else {
                self.address.add(offset).write_volatile((pixel & 0xff) as u8);
                self.address.add(offset + 1).write_volatile(((pixel >> 8) & 0xff) as u8);
                self.address.add(offset + 2).write_volatile(((pixel >> 16) & 0xff) as u8);
            }
        }
    }

    fn pixel(&mut self, x: usize, y: usize, color: u32) {
        let offset = y * self.pitch + x * self.bytes_per_pixel;
        let pixel = self.pack(color);
        unsafe {
            if self.bytes_per_pixel == 4 {
                self.address.add(offset).cast::<u32>().write_volatile(pixel);
            } else {
                self.address.add(offset).write_volatile((pixel & 0xff) as u8);
                self.address.add(offset + 1).write_volatile(((pixel >> 8) & 0xff) as u8);
                self.address.add(offset + 2).write_volatile(((pixel >> 16) & 0xff) as u8);
            }
        }
    }

    fn pack(&self, color: u32) -> u32 {
        channel(((color >> 16) & 0xff) as u8, self.red_size, self.red_shift)
            | channel(((color >> 8) & 0xff) as u8, self.green_size, self.green_shift)
            | channel((color & 0xff) as u8, self.blue_size, self.blue_shift)
    }
}

fn channel(value: u8, size: u8, shift: u8) -> u32 {
    if size == 0 || size > 8 || shift >= 32 || size.saturating_add(shift) > 32 { return 0; }
    let maximum = (1u32 << size) - 1;
    (((value as u32 * maximum) / 255) & maximum) << shift
}

fn unpack_channel(pixel: u32, size: u8, shift: u8) -> u8 {
    if size == 0 || size > 8 || shift >= 32 || size.saturating_add(shift) > 32 { return 0; }
    let maximum = (1u32 << size) - 1;
    let value = (pixel >> shift) & maximum;
    ((value * 255 + maximum / 2) / maximum) as u8
}

const fn rgb(red: u8, green: u8, blue: u8) -> u32 {
    ((red as u32) << 16) | ((green as u32) << 8) | (blue as u32)
}
