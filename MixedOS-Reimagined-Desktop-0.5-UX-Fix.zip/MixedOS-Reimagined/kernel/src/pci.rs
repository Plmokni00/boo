//! Read-only PCI configuration-space discovery using legacy mechanism #1.
//! This records device identity, bridge topology, interrupt routing fields,
//! and the currently programmed BAR values. It deliberately does not size or
//! write BARs, map MMIO, claim I/O ports, enable bus mastering, or load drivers.
//! The scanner is synchronous and the current kernel is single-core; add a
//! configuration-space lock before introducing concurrent PCI clients or SMP.

use crate::arch;

const CONFIG_ADDRESS: u16 = 0x0CF8;
const CONFIG_DATA: u16 = 0x0CFC;
const MAX_REPORTED_DEVICES: usize = 32;
const BAR_COUNT: usize = 6;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PciBar {
    /// An unimplemented or currently unassigned BAR.
    Unused,
    /// The upper 32 bits of the preceding 64-bit memory BAR.
    Continuation,
    Io { base: u32 },
    Memory32 { base: u32, prefetchable: bool },
    Memory64 { base: u64, prefetchable: bool },
    /// Reserved memory BAR encoding; retained for diagnostics, not activated.
    Reserved { raw: u32 },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct PciBridgeInfo {
    pub primary_bus: u8,
    pub secondary_bus: u8,
    pub subordinate_bus: u8,
    pub secondary_latency_timer: u8,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct PciDevice {
    pub bus: u8,
    pub device: u8,
    pub function: u8,
    pub vendor_id: u16,
    pub device_id: u16,
    pub revision_id: u8,
    pub class_code: u8,
    pub subclass: u8,
    pub programming_interface: u8,
    /// Header type with the multifunction bit removed.
    pub header_type: u8,
    pub subsystem_vendor_id: Option<u16>,
    pub subsystem_device_id: Option<u16>,
    pub interrupt_line: u8,
    /// PCI interrupt pin: 0 means none, 1..=4 mean INTA#..INTD#.
    pub interrupt_pin: u8,
    pub bars: [PciBar; BAR_COUNT],
    /// Number of BAR register slots defined by this header type.
    pub bar_count: u8,
    pub bridge: Option<PciBridgeInfo>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct PciScanSummary {
    pub devices_found: usize,
    pub devices_reported: usize,
    pub truncated: bool,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct PciResourceSummary {
    pub devices_found: usize,
    pub devices_examined: usize,
    pub devices_truncated: bool,
    pub io_bars: usize,
    pub mmio32_bars: usize,
    pub mmio64_bars: usize,
    pub prefetchable_mmio_bars: usize,
    pub zero_base_bars: usize,
    pub reserved_bars: usize,
}

/// Inventory the currently programmed BAR snapshots on the reported devices.
/// This is intentionally not a resource allocator: BAR sizes are unknown, no
/// configuration registers are written, and no address ranges are claimed.
pub fn resource_summary() -> PciResourceSummary {
    let mut summary = PciResourceSummary::default();
    let scan = enumerate(|device| {
        summary.devices_examined = summary.devices_examined.saturating_add(1);
        for bar in device.bars.iter().take(usize::from(device.bar_count)) {
            match *bar {
                PciBar::Unused | PciBar::Continuation => {}
                PciBar::Io { base } => {
                    if base == 0 { summary.zero_base_bars = summary.zero_base_bars.saturating_add(1); }
                    else { summary.io_bars = summary.io_bars.saturating_add(1); }
                }
                PciBar::Memory32 { base, prefetchable } => {
                    if base == 0 {
                        summary.zero_base_bars = summary.zero_base_bars.saturating_add(1);
                    } else {
                        summary.mmio32_bars = summary.mmio32_bars.saturating_add(1);
                        if prefetchable {
                            summary.prefetchable_mmio_bars = summary.prefetchable_mmio_bars.saturating_add(1);
                        }
                    }
                }
                PciBar::Memory64 { base, prefetchable } => {
                    if base == 0 {
                        summary.zero_base_bars = summary.zero_base_bars.saturating_add(1);
                    } else {
                        summary.mmio64_bars = summary.mmio64_bars.saturating_add(1);
                        if prefetchable {
                            summary.prefetchable_mmio_bars = summary.prefetchable_mmio_bars.saturating_add(1);
                        }
                    }
                }
                PciBar::Reserved { .. } => {
                    summary.reserved_bars = summary.reserved_bars.saturating_add(1);
                }
            }
        }
    });
    summary.devices_found = scan.devices_found;
    summary.devices_truncated = scan.truncated;
    summary
}

/// Enumerate conventional PCI configuration space without modifying devices.
/// Scans all bus numbers and honors the multifunction bit on function zero.
pub fn enumerate(mut visit: impl FnMut(PciDevice)) -> PciScanSummary {
    let mut found = 0usize;
    let mut reported = 0usize;

    for bus in 0u16..=255 {
        for device in 0u8..32 {
            let id0 = read_config_u32(bus as u8, device, 0, 0x00);
            if id0 as u16 == 0xFFFF {
                continue;
            }

            let header0 = read_config_u32(bus as u8, device, 0, 0x0C);
            let header_type = ((header0 >> 16) & 0xFF) as u8;
            let function_count = if header_type & 0x80 != 0 { 8 } else { 1 };

            for function in 0u8..function_count {
                let id = if function == 0 {
                    id0
                } else {
                    read_config_u32(bus as u8, device, function, 0x00)
                };
                let vendor_id = id as u16;
                if vendor_id == 0xFFFF {
                    continue;
                }

                let class_info = read_config_u32(bus as u8, device, function, 0x08);
                let header_info = if function == 0 {
                    header0
                } else {
                    read_config_u32(bus as u8, device, function, 0x0C)
                };
                let normalized_header_type = ((header_info >> 16) & 0x7F) as u8;
                // Offset 0x2C contains subsystem IDs only in a type-0
                // endpoint header. In a type-1 bridge header it is part of
                // the upper prefetchable-memory window, so do not mislabel it.
                let subsystem = if normalized_header_type == 0 {
                    let value = read_config_u32(bus as u8, device, function, 0x2C);
                    Some((value as u16, (value >> 16) as u16))
                } else {
                    None
                };
                let interrupt_info = read_config_u32(bus as u8, device, function, 0x3C);
                let (bars, bar_count) = read_bars(
                    bus as u8,
                    device,
                    function,
                    normalized_header_type,
                );
                let bridge = if normalized_header_type == 1 {
                    let buses = read_config_u32(bus as u8, device, function, 0x18);
                    Some(PciBridgeInfo {
                        primary_bus: buses as u8,
                        secondary_bus: (buses >> 8) as u8,
                        subordinate_bus: (buses >> 16) as u8,
                        secondary_latency_timer: (buses >> 24) as u8,
                    })
                } else {
                    None
                };

                let entry = PciDevice {
                    bus: bus as u8,
                    device,
                    function,
                    vendor_id,
                    device_id: (id >> 16) as u16,
                    revision_id: class_info as u8,
                    programming_interface: (class_info >> 8) as u8,
                    subclass: (class_info >> 16) as u8,
                    class_code: (class_info >> 24) as u8,
                    header_type: normalized_header_type,
                    subsystem_vendor_id: subsystem.map(|ids| ids.0),
                    subsystem_device_id: subsystem.map(|ids| ids.1),
                    interrupt_line: interrupt_info as u8,
                    interrupt_pin: (interrupt_info >> 8) as u8,
                    bars,
                    bar_count,
                    bridge,
                };

                found = found.saturating_add(1);
                if reported < MAX_REPORTED_DEVICES {
                    visit(entry);
                    reported += 1;
                }
            }
        }
    }

    PciScanSummary {
        devices_found: found,
        devices_reported: reported,
        truncated: found > reported,
    }
}

/// Read the BAR values currently programmed by firmware or an earlier owner.
/// BAR sizing requires writing all ones and is intentionally not done here.
fn read_bars(
    bus: u8,
    device: u8,
    function: u8,
    header_type: u8,
) -> ([PciBar; BAR_COUNT], u8) {
    let count = match header_type {
        0 => 6,
        1 => 2,
        // CardBus uses a different header layout; keep it out of the
        // type-0/type-1 BAR decoder until its registers have a dedicated model.
        _ => 0,
    };
    let mut bars = [PciBar::Unused; BAR_COUNT];
    let mut index = 0usize;

    while index < count {
        let offset = 0x10 + (index as u8 * 4);
        let raw = read_config_u32(bus, device, function, offset);
        if raw == 0 || raw == u32::MAX {
            index += 1;
            continue;
        }

        if raw & 1 != 0 {
            bars[index] = PciBar::Io { base: raw & !0x03 };
            index += 1;
            continue;
        }

        let memory_type = (raw >> 1) & 0x03;
        let prefetchable = raw & 0x08 != 0;
        match memory_type {
            0 => {
                bars[index] = PciBar::Memory32 {
                    base: raw & !0x0F,
                    prefetchable,
                };
                index += 1;
            }
            2 if index + 1 < count => {
                let high_offset = 0x10 + ((index as u8 + 1) * 4);
                let high = read_config_u32(bus, device, function, high_offset);
                let base = ((high as u64) << 32) | u64::from(raw & !0x0F);
                bars[index] = PciBar::Memory64 { base, prefetchable };
                bars[index + 1] = PciBar::Continuation;
                index += 2;
            }
            _ => {
                bars[index] = PciBar::Reserved { raw };
                index += 1;
            }
        }
    }

    (bars, count as u8)
}

fn read_config_u32(bus: u8, device: u8, function: u8, offset: u8) -> u32 {
    let address = 0x8000_0000u32
        | ((bus as u32) << 16)
        | ((device as u32) << 11)
        | ((function as u32) << 8)
        | ((offset as u32) & 0xFC);
    unsafe {
        arch::outl(CONFIG_ADDRESS, address);
        arch::inl(CONFIG_DATA)
    }
}
