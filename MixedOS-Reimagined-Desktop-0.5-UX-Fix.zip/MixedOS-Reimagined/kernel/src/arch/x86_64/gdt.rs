//! Minimal long-mode GDT and TSS setup for CPL3 tasks.
//! The kernel keeps a dedicated interrupt stack for ring-0 execution and
//! updates TSS.RSP0 whenever the uniprocessor scheduler selects a task.

use core::cell::UnsafeCell;
use core::ptr;

#[allow(dead_code)] // Kept in the descriptor contract for architecture consumers.
pub const KERNEL_CODE_SELECTOR: u16 = 0x08;
#[allow(dead_code)] // Kept in the descriptor contract for architecture consumers.
pub const KERNEL_DATA_SELECTOR: u16 = 0x10;
pub const USER_DATA_SELECTOR: u16 = 0x1B;
pub const USER_CODE_SELECTOR: u16 = 0x23;
pub const TSS_SELECTOR: u16 = 0x28;
const KERNEL_STACK_BYTES: usize = 16 * 1024;
const EXCEPTION_STACK_BYTES: usize = 16 * 1024;

#[repr(C, packed)]
struct TaskStateSegment {
    reserved0: u32,
    rsp: [u64; 3],
    reserved1: u64,
    ist: [u64; 7],
    reserved2: u64,
    reserved3: u16,
    io_map_base: u16,
}

impl TaskStateSegment {
    const fn new() -> Self {
        Self {
            reserved0: 0,
            rsp: [0; 3],
            reserved1: 0,
            ist: [0; 7],
            reserved2: 0,
            reserved3: 0,
            io_map_base: core::mem::size_of::<Self>() as u16,
        }
    }
}

struct TssCell(UnsafeCell<TaskStateSegment>);
unsafe impl Sync for TssCell {}
static TSS: TssCell = TssCell(UnsafeCell::new(TaskStateSegment::new()));

struct GdtCell(UnsafeCell<[u64; 7]>);
unsafe impl Sync for GdtCell {}
static GDT: GdtCell = GdtCell(UnsafeCell::new([0; 7]));

#[repr(C, packed)]
struct DescriptorTablePointer {
    limit: u16,
    base: u64,
}

#[repr(align(16))]
struct KernelInterruptStack([u8; KERNEL_STACK_BYTES]);
static KERNEL_INTERRUPT_STACK: KernelInterruptStack = KernelInterruptStack([0; KERNEL_STACK_BYTES]);

// Emergency stacks keep critical exceptions from reusing a damaged kernel stack.
// IST1 is dedicated to double faults; IST2 to NMI; IST3 to machine checks.
#[repr(align(16))]
struct ExceptionStack([u8; EXCEPTION_STACK_BYTES]);
static DOUBLE_FAULT_STACK: ExceptionStack = ExceptionStack([0; EXCEPTION_STACK_BYTES]);
static NMI_STACK: ExceptionStack = ExceptionStack([0; EXCEPTION_STACK_BYTES]);
static MACHINE_CHECK_STACK: ExceptionStack = ExceptionStack([0; EXCEPTION_STACK_BYTES]);

static mut READY: bool = false;

unsafe extern "C" {
    fn mixedos_gdt_reload();
}

/// Install known kernel/user code and data descriptors plus a 64-bit TSS.
/// Must run before the IDT is loaded and before interrupts are enabled.
pub fn initialize() -> bool {
    if unsafe { READY } { return true; }

    let tss_pointer = TSS.0.get();
    let stack_top = kernel_interrupt_stack_top();
    unsafe {
        ptr::addr_of_mut!((*tss_pointer).rsp).write_unaligned([stack_top, 0, 0]);
        ptr::addr_of_mut!((*tss_pointer).ist).write_unaligned([
            exception_stack_top(&DOUBLE_FAULT_STACK),
            exception_stack_top(&NMI_STACK),
            exception_stack_top(&MACHINE_CHECK_STACK),
            0, 0, 0, 0,
        ]);
        ptr::addr_of_mut!((*tss_pointer).io_map_base).write_unaligned(core::mem::size_of::<TaskStateSegment>() as u16);
    }

    let base = tss_pointer as u64;
    let limit = (core::mem::size_of::<TaskStateSegment>() - 1) as u64;
    let tss_low = (limit & 0xFFFF)
        | ((base & 0x00FF_FFFF) << 16)
        | (0x89u64 << 40)
        | (((limit >> 16) & 0x0F) << 48)
        | (((base >> 24) & 0xFF) << 56);
    let tss_high = base >> 32;

    let table = GDT.0.get();
    unsafe {
        (*table)[0] = 0;
        (*table)[1] = 0x00AF_9A00_0000_FFFF; // ring-0 64-bit code
        (*table)[2] = 0x00CF_9200_0000_FFFF; // ring-0 data
        (*table)[3] = 0x00CF_F200_0000_FFFF; // ring-3 data
        (*table)[4] = 0x00AF_FA00_0000_FFFF; // ring-3 64-bit code
        (*table)[5] = tss_low;
        (*table)[6] = tss_high;
    }

    let gdtr = DescriptorTablePointer {
        limit: (core::mem::size_of::<[u64; 7]>() - 1) as u16,
        base: table as u64,
    };
    unsafe {
        core::arch::asm!("lgdt [{}]", in(reg) &gdtr, options(readonly, nostack, preserves_flags));
        mixedos_gdt_reload();
        core::arch::asm!("ltr ax", in("ax") TSS_SELECTOR, options(nostack, preserves_flags));
        READY = true;
    }
    true
}

#[inline]
pub fn is_ready() -> bool { unsafe { READY } }

/// Update the privilege-transition stack used when a user task traps/interrupts.
pub fn set_kernel_stack(stack_top: u64) {
    if !is_ready() || stack_top == 0 { return; }
    let tss_pointer = TSS.0.get();
    unsafe { ptr::addr_of_mut!((*tss_pointer).rsp).write_unaligned([stack_top, 0, 0]); }
}

pub fn kernel_interrupt_stack_top() -> u64 {
    core::ptr::addr_of!(KERNEL_INTERRUPT_STACK.0) as *const u8 as u64 + KERNEL_STACK_BYTES as u64
}


fn exception_stack_top(stack: &'static ExceptionStack) -> u64 {
    stack.0.as_ptr() as u64 + EXCEPTION_STACK_BYTES as u64
}
