mod port;
mod gdt;

pub use port::{inb, inl, inw, outb, outl, outw};
pub use gdt::{initialize as initialize_gdt_tss, is_ready as gdt_tss_ready, kernel_interrupt_stack_top, set_kernel_stack, KERNEL_CODE_SELECTOR, KERNEL_DATA_SELECTOR, USER_CODE_SELECTOR, USER_DATA_SELECTOR};

// Read by the common ISR entry stub. Until the architectural FPU/SSE state is
// enabled, early exceptions must not execute FXSAVE/FXRSTOR themselves.
#[unsafe(no_mangle)]
pub static mut MIXEDOS_FPU_READY: u8 = 0;

#[inline]
pub fn disable_interrupts() {
    // The early boot path deliberately keeps interrupts disabled until an IDT exists.
    unsafe { core::arch::asm!("cli", options(nostack)); }
}

/// Verify the x87/SSE state installed by the assembly ELF-entry trampoline.
/// This must remain a verification-only routine: compiler-generated Rust may
/// already contain SSE2 instructions before this function is reached.
pub fn verify_early_fpu_state() {
    let ready = unsafe { core::ptr::read_volatile(core::ptr::addr_of!(MIXEDOS_FPU_READY)) };
    let cr0: u64;
    let cr4: u64;
    unsafe {
        core::arch::asm!("mov {}, cr0", out(reg) cr0, options(nostack, preserves_flags));
        core::arch::asm!("mov {}, cr4", out(reg) cr4, options(nostack, preserves_flags));
    }
    let cr0_required = 1 << 1; // MP
    let cr0_forbidden = (1 << 2) | (1 << 3); // EM | TS
    let cr4_required = (1 << 9) | (1 << 10); // OSFXSR | OSXMMEXCPT
    if ready != 1 || cr0 & cr0_required == 0 || cr0 & cr0_forbidden != 0
        || cr4 & cr4_required != cr4_required
    {
        panic!("assembly entry did not establish required x87/SSE state (ready={}, CR0={:#x}, CR4={:#x})", ready, cr0, cr4);
    }
}

#[inline]
pub fn enable_interrupts() {
    unsafe { core::arch::asm!("sti", options(nostack)); }
}

#[allow(dead_code)] // Used by the future scheduler idle path once IRQ-driven sleep is enabled.
#[inline]
pub fn wait_for_interrupt() {
    unsafe { core::arch::asm!("hlt", options(nostack)); }
}

#[inline(never)]
pub fn halt_forever() -> ! {
    loop {
        unsafe { core::arch::asm!("hlt", options(nostack)); }
    }
}


/// Read the active page-table root physical address.
#[inline]
pub fn read_cr3() -> u64 {
    let value: u64;
    unsafe { core::arch::asm!("mov {}, cr3", out(reg) value, options(nomem, nostack, preserves_flags)); }
    value & 0x000F_FFFF_FFFF_F000
}

/// Switch to a previously validated CR3 root. The caller must ensure that the
/// current instruction, stack, IDT, GDT, TSS, and all kernel data are mapped
/// identically in both roots.
#[inline]
pub unsafe fn write_cr3(root_physical: u64) {
    unsafe { core::arch::asm!("mov cr3, {}", in(reg) root_physical, options(nostack, preserves_flags)); }
}
