use crate::boot::limine::Framebuffer;
use crate::console::{font5x7, font_arimo};
use crate::input::InputStats;

/// Draw the MKH fatal screen or its explicitly labeled non-fatal preview.
/// Both use only the bootloader framebuffer, not heap/filesystem/terminal state.
pub fn render_mkh_screen(
    framebuffer: Framebuffer,
    kind: &str,
    code: &str,
    detail: &str,
    registers: Option<(u64, u64, u64)>,
    fault_address: Option<u64>,
    preview: bool,
) -> bool {
    let Some(mut canvas) = Canvas::new(framebuffer) else { return false; };
    let width = canvas.width;
    let height = canvas.height;
    // Arimo provides proportional, antialiased UI text. Keep this renderer
    // allocation-free so it remains safe before the kernel heap is available.
    let line_step = 26;
    let value_x = 220;
    let background = rgb(10, 12, 22);
    let panel = rgb(20, 24, 39);
    let accent = rgb(226, 91, 121);
    let bright = rgb(246, 239, 246);
    let muted = rgb(170, 177, 199);
    let warning = rgb(255, 173, 120);

    canvas.fill(background);
    canvas.rect(0, 0, width, 7, accent);
    canvas.rect(0, 7, 12, height.saturating_sub(7), rgb(95, 46, 89));
    canvas.text_ui(42, 28, "MIXEDOS KERNEL HALT", bright, font_arimo::Weight::Bold);
    canvas.text_ui(
        44,
        60,
        if preview { "MKH / PREVIEW - KERNEL RUNNING" } else { "MKH / CRITICAL KERNEL FAILURE" },
        accent,
        font_arimo::Weight::Regular,
    );
    canvas.rect(42, 98, width.saturating_sub(84), 1, rgb(65, 55, 78));

    let panel_y = 122;
    let panel_height = height.saturating_sub(panel_y + 54).min(360);
    canvas.rect(36, panel_y, width.saturating_sub(72), panel_height, panel);
    canvas.rect(36, panel_y, 5, panel_height, accent);
    canvas.text_ui(
        58,
        panel_y + 18,
        if preview { "PREVIEW ONLY - NO FAILURE HAS OCCURRED" } else { "THE KERNEL STOPPED TO PROTECT SYSTEM STATE" },
        bright,
        font_arimo::Weight::Bold,
    );
    canvas.text_ui(
        58,
        panel_y + 18 + line_step,
        if preview { "KERNEL EXECUTION CONTINUES AFTER THIS TEST" } else { "NO FURTHER KERNEL WORK WILL BE EXECUTED" },
        muted,
        font_arimo::Weight::Regular,
    );
    canvas.text_ui(58, panel_y + 18 + 3 * line_step, "FAILURE TYPE:", muted, font_arimo::Weight::Regular);
    canvas.text_ui(value_x, panel_y + 18 + 3 * line_step, kind, warning, font_arimo::Weight::Regular);
    canvas.text_ui(58, panel_y + 18 + 4 * line_step, "CRASH CODE:", muted, font_arimo::Weight::Regular);
    canvas.text_ui(value_x, panel_y + 18 + 4 * line_step, code, bright, font_arimo::Weight::Regular);

    let mut info_y = panel_y + 18 + 6 * line_step;
    if let Some((vector, error_code, instruction_pointer)) = registers {
        canvas.text_ui(58, info_y, "CPU VECTOR:", muted, font_arimo::Weight::Regular);
        canvas.text_ui_dec(value_x, info_y, vector.min(u32::MAX as u64) as u32, 3, bright);
        info_y += line_step;
        canvas.text_ui(58, info_y, "ERROR CODE:", muted, font_arimo::Weight::Regular);
        canvas.text_ui_hex64(value_x, info_y, error_code, warning);
        info_y += line_step;
        canvas.text_ui(58, info_y, "INSTRUCTION:", muted, font_arimo::Weight::Regular);
        canvas.text_ui_hex64(value_x, info_y, instruction_pointer, bright);
        info_y += line_step;
    }
    if let Some(address) = fault_address {
        canvas.text_ui(58, info_y, "FAULT ADDRESS:", muted, font_arimo::Weight::Regular);
        canvas.text_ui_hex64(value_x, info_y, address, warning);
        info_y += line_step;
    }

    if info_y + 45 < panel_y + panel_height {
        canvas.rect(58, info_y + 4, width.saturating_sub(116), 1, rgb(65, 55, 78));
        canvas.text_ui(58, info_y + 12, "DETAIL:", muted, font_arimo::Weight::Bold);
        draw_wrapped_text(&mut canvas, 58, info_y + 42, detail, bright, width.saturating_sub(116), 2);
    }

    let footer_y = height.saturating_sub(36);
    if preview {
        let footer = "SAMPLE DATA ONLY";
        canvas.text_ui(42, footer_y, "PREVIEW: PRESS ESC TO RETURN (COM1: ESC)", muted, font_arimo::Weight::Regular);
        let footer_x = width.saturating_sub(42 + canvas.measure_ui_text(footer, font_arimo::Weight::Bold));
        canvas.text_ui(footer_x, footer_y, footer, accent, font_arimo::Weight::Bold);
    } else {
        let footer = "RESTART THE MACHINE TO CONTINUE";
        canvas.text_ui(42, footer_y, "DIAGNOSTICS: CHECK THE COM1 SERIAL LOG", muted, font_arimo::Weight::Regular);
        let footer_x = width.saturating_sub(42 + canvas.measure_ui_text(footer, font_arimo::Weight::Bold));
        canvas.text_ui(footer_x, footer_y, footer, accent, font_arimo::Weight::Bold);
    }
    true
}

fn draw_wrapped_text(canvas: &mut Canvas, x: usize, y: usize, text: &str, color: u32, available_width: usize, max_lines: usize) {
    let mut line = [0u8; 100];
    let mut length = 0usize;
    let mut line_width = 0usize;
    let mut row = 0usize;
    for byte in text.bytes() {
        if byte == b'\n' || (length > 0 && (length >= line.len() || line_width + font_arimo::advance(byte, font_arimo::Weight::Regular) > available_width)) {
            if let Ok(value) = core::str::from_utf8(&line[..length]) {
                canvas.text_ui(x, y + row * 22, value, color, font_arimo::Weight::Regular);
            }
            row += 1;
            length = 0;
            line_width = 0;
            if row >= max_lines { return; }
            if byte == b'\n' { continue; }
        }
        if byte.is_ascii_graphic() || byte == b' ' {
            if length < line.len() {
                line[length] = byte;
                length += 1;
                line_width += font_arimo::advance(byte, font_arimo::Weight::Regular);
            }
        }
    }
    if row < max_lines {
        if let Ok(value) = core::str::from_utf8(&line[..length]) {
            canvas.text_ui(x, y + row * 22, value, color, font_arimo::Weight::Regular);
        }
    }
}

pub fn render_boot_screen(framebuffer: Framebuffer) -> bool {
    let Some(mut canvas) = Canvas::new(framebuffer) else {
        return false;
    };

    let width = framebuffer.width as usize;
    let height = framebuffer.height as usize;
    canvas.fill(rgb(12, 17, 29));

    canvas.rect(0, 0, width, 5, rgb(48, 116, 238));
    canvas.rect(42, 42, 5, 58, rgb(72, 190, 173));
    canvas.rect(55, 42, 5, 58, rgb(48, 116, 238));
    canvas.rect(68, 42, 5, 58, rgb(160, 116, 238));

    canvas.text_ui(94, 42, "MIXEDOS", rgb(242, 246, 255), font_arimo::Weight::Bold);
    canvas.text_ui(95, 82, "INDEPENDENT KERNEL", rgb(178, 192, 215), font_arimo::Weight::Regular);
    canvas.rect(94, 112, width.saturating_sub(188).min(520), 1, rgb(58, 76, 104));
    canvas.text_ui(94, 132, "LIMINE BOOT CONFIRMED", rgb(114, 215, 185), font_arimo::Weight::Regular);
    canvas.text_ui(94, 151, "FRAMEBUFFER ONLINE", rgb(178, 192, 215), font_arimo::Weight::Regular);
    canvas.text_ui(94, 170, "C ABI LINKED", rgb(178, 192, 215), font_arimo::Weight::Regular);

    let footer_y = height.saturating_sub(35);
    canvas.text_ui(42, footer_y, "STAGE 2 / X86_64 / INTERACTIVE CONSOLE", rgb(118, 135, 162), font_arimo::Weight::Regular);
    true
}

const HISTORY_LINES: usize = 256;
const HISTORY_COLUMNS: usize = 256;
const CONTENT_TOP: usize = 116;
const CONSOLE_LINE_HEIGHT: usize = 20;
const CONSOLE_BACKGROUND: u32 = 0x000A0F1A;
const CONSOLE_FOREGROUND: u32 = 0x00D3DEF1;

#[derive(Clone, Copy)]
struct HistoryLine {
    bytes: [u8; HISTORY_COLUMNS],
    len: usize,
}

impl HistoryLine {
    const fn empty() -> Self { Self { bytes: [0; HISTORY_COLUMNS], len: 0 } }
}

struct Scrollback {
    lines: [HistoryLine; HISTORY_LINES],
    oldest: usize,
    count: usize,
    column: usize,
}

impl Scrollback {
    const fn new() -> Self {
        Self {
            lines: [HistoryLine::empty(); HISTORY_LINES],
            oldest: 0,
            count: 0,
            column: 0,
        }
    }

    fn reset(&mut self) {
        self.lines.fill(HistoryLine::empty());
        self.oldest = 0;
        self.count = 0;
        self.column = 0;
        self.push_line();
    }

    fn current_index(&self) -> usize {
        if self.count == 0 { self.oldest } else { (self.oldest + self.count - 1) % HISTORY_LINES }
    }

    fn push_line(&mut self) {
        let index = if self.count < HISTORY_LINES {
            let index = (self.oldest + self.count) % HISTORY_LINES;
            self.count += 1;
            index
        } else {
            self.oldest = (self.oldest + 1) % HISTORY_LINES;
            (self.oldest + self.count - 1) % HISTORY_LINES
        };
        self.lines[index] = HistoryLine::empty();
        self.column = 0;
    }

    fn append(&mut self, byte: u8) {
        let index = self.current_index();
        if self.column < HISTORY_COLUMNS {
            self.lines[index].bytes[self.column] = byte;
            self.column += 1;
            self.lines[index].len = self.lines[index].len.max(self.column);
        }
    }

    fn backspace(&mut self) {
        if self.column == 0 { return; }
        self.column -= 1;
        let index = self.current_index();
        self.lines[index].bytes[self.column] = 0;
        self.lines[index].len = self.column;
    }
}

struct ScrollbackCell(core::cell::UnsafeCell<Scrollback>);
unsafe impl Sync for ScrollbackCell {}
static SCROLLBACK: ScrollbackCell = ScrollbackCell(core::cell::UnsafeCell::new(Scrollback::new()));

pub struct Terminal {
    canvas: Canvas,
    cursor_x: usize,
    cursor_y: usize,
    line_height: usize,
    text_left: usize,
    text_right: usize,
    text_bottom: usize,
    scroll_offset: usize,
    // Only repaint the status strip when device readiness/configuration changes.
    // Packet counters and mouse coordinates are available through the `input`
    // command; they must not trigger framebuffer writes on every input event.
    status_signature: Option<(bool, bool, bool, bool, bool)>,
    cmd_mode: bool,
}

impl Terminal {
    pub fn new(framebuffer: Framebuffer) -> Option<Self> {
        Self::new_with_style(framebuffer, false)
    }

    /// Construct the user-facing CMD-style terminal app. The same scrollback
    /// and input renderer are used, but recovery-console branding is omitted.
    pub fn new_cmd(framebuffer: Framebuffer) -> Option<Self> {
        Self::new_with_style(framebuffer, true)
    }

    /// Construct CMD Terminal inside a bounded desktop window.
    pub fn new_cmd_window(framebuffer: Framebuffer, x: usize, y: usize, width: usize, height: usize) -> Option<Self> {
        Self::new_with_canvas(Canvas::new_view(framebuffer, x, y, width, height)?, true)
    }

    /// Relocate a CMD Terminal client area without discarding its scrollback or
    /// current input line. The caller redraws the desktop/window frame first.
    pub fn move_cmd_window(&mut self, framebuffer: Framebuffer, x: usize, y: usize, width: usize, height: usize) -> bool {
        if !self.cmd_mode { return false; }
        let Some(canvas) = Canvas::new_view(framebuffer, x, y, width, height) else { return false; };
        self.canvas = canvas;
        self.redraw();
        true
    }

    fn new_with_style(framebuffer: Framebuffer, cmd_mode: bool) -> Option<Self> {
        let canvas = Canvas::new(framebuffer)?;
        Self::new_with_canvas(canvas, cmd_mode)
    }

    fn new_with_canvas(canvas: Canvas, cmd_mode: bool) -> Option<Self> {
        if canvas.width < 240 || canvas.height < 160 { return None; }
        let mut terminal = Self {
            canvas,
            cursor_x: 34,
            cursor_y: CONTENT_TOP,
            line_height: CONSOLE_LINE_HEIGHT,
            text_left: 34,
            text_right: 24,
            text_bottom: 22,
            scroll_offset: 0,
            status_signature: None,
            cmd_mode,
        };
        terminal.clear();
        Some(terminal)
    }

    fn history(&mut self) -> &mut Scrollback {
        // The terminal is single-owner and called only by the polling shell.
        // The fixed history lives in BSS so it does not consume the boot stack.
        unsafe { &mut *SCROLLBACK.0.get() }
    }

    fn visible_lines(&self) -> usize {
        self.canvas.height
            .saturating_sub(self.text_bottom + CONTENT_TOP)
            .checked_div(self.line_height.max(1))
            .unwrap_or(1)
            .max(1)
    }

    fn maximum_y(&self) -> usize { self.canvas.height.saturating_sub(self.text_bottom) }

    fn current_line_metrics(&mut self) -> (usize, usize) {
        let (bytes, len, column) = {
            let history = self.history();
            let line = history.lines[history.current_index()];
            (line.bytes, line.len, history.column)
        };
        (console_text_width(&bytes[..len]), column)
    }

    fn redraw_current_line(&mut self) {
        if self.scroll_offset != 0 { return; }
        let (bytes, len) = {
            let history = self.history();
            let line = history.lines[history.current_index()];
            (line.bytes, line.len)
        };
        let available = self.canvas.width.saturating_sub(self.text_left + self.text_right);
        self.canvas.rect(self.text_left, self.cursor_y, available, self.line_height, CONSOLE_BACKGROUND);
        if let Ok(text) = core::str::from_utf8(&bytes[..len]) {
            self.canvas.text(self.text_left, self.cursor_y, text, CONSOLE_FOREGROUND, 1);
        }
        self.cursor_x = self.text_left + console_text_width(&bytes[..len]);
    }

    pub fn clear(&mut self) {
        self.draw_chrome();
        self.history().reset();
        self.scroll_offset = 0;
        self.cursor_x = self.text_left;
        self.cursor_y = CONTENT_TOP;
        self.draw_scrollbar();
    }

    /// Redraw the shell after an external framebuffer screen was displayed.
    /// Unlike `clear`, this preserves scrollback, cursor, and scroll position.
    pub fn redraw(&mut self) {
        self.draw_chrome();
        self.render_history();
    }

    fn draw_chrome(&mut self) {
        self.status_signature = None;
        self.canvas.fill(if self.cmd_mode { rgb(13, 12, 20) } else { CONSOLE_BACKGROUND });
        if self.cmd_mode {
            self.canvas.rect(0, 0, self.canvas.width, 4, rgb(224, 126, 133));
            self.canvas.rect(0, 4, self.canvas.width, 38, rgb(25, 20, 32));
            self.canvas.text_ui(34, 12, "MIXEDOS TERMINAL", rgb(249, 238, 238), font_arimo::Weight::Bold);
            self.canvas.text_ui(226, 14, "COMMAND PROCESSOR", rgb(192, 163, 190), font_arimo::Weight::Regular);
            self.canvas.rect(34, 61, self.canvas.width.saturating_sub(68), 1, rgb(79, 53, 77));
            self.canvas.text_ui(34, 76, "SESSION  C:\\MIXEDOS", rgb(205, 181, 203), font_arimo::Weight::Regular);
            self.canvas.text_ui(260, 76, "PS/2 INPUT ONLINE", rgb(115, 207, 173), font_arimo::Weight::Regular);
            self.canvas.rect(34, 108, self.canvas.width.saturating_sub(68), 1, rgb(79, 53, 77));
        } else {
            self.canvas.rect(0, 0, self.canvas.width, 4, rgb(72, 143, 255));
            self.canvas.text_ui(34, 14, "MIXEDOS KERNEL RECOVERY", rgb(236, 242, 255), font_arimo::Weight::Bold);
            self.canvas.text_ui(34, 39, "DEVELOPER CONSOLE / RECOVERY SESSION", rgb(110, 207, 187), font_arimo::Weight::Regular);
            self.canvas.rect(34, 61, self.canvas.width.saturating_sub(68), 1, rgb(47, 64, 91));
            self.draw_status_bar(None);
            self.canvas.rect(34, 108, self.canvas.width.saturating_sub(68), 1, rgb(47, 64, 91));
        }
    }

    fn draw_status_bar(&mut self, status: Option<InputStats>) {
        let width = self.canvas.width;
        let right = width.saturating_sub(28);
        self.canvas.rect(30, 62, width.saturating_sub(60), 45, CONSOLE_BACKGROUND);

        let muted = rgb(118, 135, 162);
        let good = rgb(114, 215, 185);
        let warning = rgb(238, 171, 96);
        let keyboard_ready = status.map(|value| value.keyboard_ready).unwrap_or(false);
        let mouse_ready = status.map(|value| value.mouse_ready).unwrap_or(false);
        let controller_ready = status.map(|value| value.controller_present).unwrap_or(false);
        let config_verified = status.map(|value| value.command_byte_verified).unwrap_or(false);
        let wheel_protocol = status.map(|value| value.mouse_wheel_protocol).unwrap_or(false);

        let mut x = 34;
        self.status_label(&mut x, right, 64, "KEYBOARD", muted);
        self.status_label(
            &mut x, right, 64,
            if keyboard_ready { "READY" } else { "OFFLINE" },
            if keyboard_ready { good } else { warning },
        );
        self.status_label(&mut x, right, 64, "MOUSE", muted);
        self.status_label(
            &mut x, right, 64,
            if mouse_ready { "READY" } else { "OFFLINE" },
            if mouse_ready { good } else { warning },
        );

        let mut x = 34;
        self.status_label(&mut x, right, 84, "PS/2", muted);
        self.status_label(
            &mut x, right, 84,
            if controller_ready { "CONTROLLER READY" } else { "CONTROLLER OFFLINE" },
            if controller_ready { good } else { warning },
        );
        if width >= 650 {
            self.status_label(&mut x, right, 84, "CONFIG", muted);
            self.status_label(
                &mut x, right, 84,
                if config_verified { "VERIFIED" } else { "UNVERIFIED" },
                if config_verified { good } else { warning },
            );
            self.status_label(&mut x, right, 84, "WHEEL", muted);
            self.status_label(&mut x, right, 84, if wheel_protocol { "ID3" } else { "STANDARD" }, muted);
        }
    }

    fn status_label(&mut self, x: &mut usize, right: usize, y: usize, value: &str, color: u32) {
        let width = self.canvas.measure_console_text(value);
        if (*x).saturating_add(width) <= right {
            self.canvas.text(*x, y, value, color, 1);
            *x = (*x).saturating_add(width + 9);
        }
    }

    pub fn set_input_status(&mut self, status: InputStats) {
        if self.cmd_mode { return; }
        let signature = (
            status.controller_present,
            status.command_byte_verified,
            status.keyboard_ready,
            status.mouse_ready,
            status.mouse_wheel_protocol,
        );
        if self.status_signature == Some(signature) {
            return;
        }
        self.status_signature = Some(signature);
        self.draw_status_bar(Some(status));
    }

    /// Scroll by dragging/clicking the visible scrollbar with the left mouse button.
    /// Mouse coordinates are normalized by the PS/2 driver to the 0..4095 range.
    pub fn scrollbar_pointer(&mut self, mouse_x: i32, mouse_y: i32, left_down: bool) -> bool {
        let screen_x = (mouse_x.max(0) as usize).saturating_mul(self.canvas.screen_width) / 4096;
        let screen_y = (mouse_y.max(0) as usize).saturating_mul(self.canvas.screen_height) / 4096;
        let x = screen_x.saturating_sub(self.canvas.origin_x);
        let y = screen_y.saturating_sub(self.canvas.origin_y);
        let track_x = self.canvas.width.saturating_sub(18);
        let track_bottom = self.maximum_y();
        if left_down && x >= track_x && y >= CONTENT_TOP && y < track_bottom {
            self.scrollbar_drag_to(mouse_y);
            return true;
        }
        false
    }

    pub fn scrollbar_drag_to(&mut self, mouse_y: i32) {
        let screen_y = (mouse_y.max(0) as usize).saturating_mul(self.canvas.screen_height) / 4096;
        let y = screen_y.saturating_sub(self.canvas.origin_y);
        let visible = self.visible_lines();
        let max_offset = self.history().count.saturating_sub(visible);
        let track_height = self.maximum_y().saturating_sub(CONTENT_TOP).max(1);
        let relative = y.saturating_sub(CONTENT_TOP).min(track_height);
        let next_offset = max_offset.saturating_mul(track_height.saturating_sub(relative)) / track_height;
        if next_offset == self.scroll_offset {
            return;
        }
        self.set_scroll_offset(next_offset);
    }

    pub fn write(&mut self, text: &str) {
        for byte in text.bytes() {
            match byte {
                b'\r' => {}
                b'\n' => self.newline(),
                8 | 127 => self.backspace(),
                0x20..=0x7e => self.put_byte(byte),
                _ => {}
            }
        }
    }

    pub fn write_line(&mut self, text: &str) {
        self.write(text);
        self.newline();
    }

    pub fn scroll_up(&mut self, lines: usize) {
        let visible = self.visible_lines();
        let max_offset = {
            let history = self.history();
            history.count.saturating_sub(visible)
        };
        let next_offset = self.scroll_offset.saturating_add(lines.max(1)).min(max_offset);
        if next_offset == self.scroll_offset {
            return;
        }
        self.set_scroll_offset(next_offset);
    }

    pub fn scroll_down(&mut self, lines: usize) {
        let next_offset = self.scroll_offset.saturating_sub(lines.max(1));
        if next_offset == self.scroll_offset {
            return;
        }
        self.set_scroll_offset(next_offset);
    }

    pub fn scroll_to_top(&mut self) {
        let visible = self.visible_lines();
        let max_offset = {
            let history = self.history();
            history.count.saturating_sub(visible)
        };
        if self.scroll_offset == max_offset {
            return;
        }
        self.set_scroll_offset(max_offset);
    }

    pub fn scroll_to_bottom(&mut self) {
        if self.scroll_offset == 0 {
            return;
        }
        self.set_scroll_offset(0);
    }

    /// Move the visible history using an overlapping framebuffer blit. Only
    /// newly exposed rows are rasterized; a large jump falls back to a full
    /// viewport render. The copy is bounded to the text viewport and uses
    /// memmove semantics because source and destination overlap.
    fn set_scroll_offset(&mut self, next_offset: usize) {
        let old_offset = self.scroll_offset;
        if next_offset == old_offset { return; }
        let visible = self.visible_lines();
        let delta = next_offset.abs_diff(old_offset);
        self.scroll_offset = next_offset;
        if delta >= visible {
            self.render_history();
            return;
        }

        let top = CONTENT_TOP;
        let bottom = self.maximum_y();
        let viewport_height = bottom.saturating_sub(top);
        let shift = delta.saturating_mul(self.line_height).min(viewport_height);
        let copy_height = viewport_height.saturating_sub(shift);
        if copy_height > 0 {
            let byte_count = copy_height.saturating_mul(self.canvas.pitch);
            let base = self.canvas.address;
            let pitch = self.canvas.pitch;
            unsafe {
                let source = if next_offset > old_offset {
                    base.add(top * pitch)
                } else {
                    base.add((top + shift) * pitch)
                };
                let destination = if next_offset > old_offset {
                    base.add((top + shift) * pitch)
                } else {
                    base.add(top * pitch)
                };
                core::ptr::copy(source, destination, byte_count);
            }
        }

        let (count, oldest) = {
            let history = self.history();
            (history.count, history.oldest)
        };
        let end = count.saturating_sub(next_offset);
        let start = end.saturating_sub(visible);
        if next_offset > old_offset {
            for row in 0..delta {
                self.draw_history_row(row, oldest, start + row);
            }
        } else {
            for row in visible.saturating_sub(delta)..visible {
                let history_index = start + row;
                if history_index < end {
                    self.draw_history_row(row, oldest, history_index);
                } else {
                    self.canvas.rect(0, top + row * self.line_height, self.canvas.width, self.line_height, CONSOLE_BACKGROUND);
                }
            }
        }
        if next_offset == 0 {
            let current_row = end.saturating_sub(start + 1);
            self.cursor_y = top + current_row * self.line_height;
            let (bytes, len) = {
                let history = self.history();
                let line = history.lines[history.current_index()];
                (line.bytes, line.len)
            };
            self.cursor_x = self.text_left + console_text_width(&bytes[..len]);
        }
        self.draw_scrollbar();
    }

    fn draw_history_row(&mut self, screen_row: usize, oldest: usize, history_index: usize) {
        let (bytes, len) = {
            let history = self.history();
            let line = history.lines[(oldest + history_index) % HISTORY_LINES];
            (line.bytes, line.len)
        };
        let y = CONTENT_TOP + screen_row * self.line_height;
        self.canvas.rect(0, y, self.canvas.width, self.line_height, CONSOLE_BACKGROUND);
        if len != 0 {
            if let Ok(text) = core::str::from_utf8(&bytes[..len]) {
                self.canvas.text(self.text_left, y, text, CONSOLE_FOREGROUND, 1);
            }
        }
    }

    fn render_history(&mut self) {
        let visible = self.visible_lines();
        let offset = self.scroll_offset;
        let (count, oldest) = {
            let history = self.history();
            (history.count, history.oldest)
        };
        let end = count.saturating_sub(offset);
        let start = end.saturating_sub(visible);
        let maximum = self.maximum_y();
        self.canvas.rect(0, CONTENT_TOP, self.canvas.width, maximum.saturating_sub(CONTENT_TOP), CONSOLE_BACKGROUND);
        for row in 0..end.saturating_sub(start) {
            let (bytes, len) = {
                let history = self.history();
                let line = history.lines[(oldest + start + row) % HISTORY_LINES];
                (line.bytes, line.len)
            };
            if len != 0 {
                if let Ok(text) = core::str::from_utf8(&bytes[..len]) {
                    self.canvas.text(self.text_left, CONTENT_TOP + row * self.line_height, text, CONSOLE_FOREGROUND, 1);
                }
            }
        }
        if offset == 0 {
            let current_row = end.saturating_sub(start + 1);
            self.cursor_y = CONTENT_TOP + current_row * self.line_height;
            let (bytes, len) = {
                let history = self.history();
                let line = history.lines[history.current_index()];
                (line.bytes, line.len)
            };
            self.cursor_x = self.text_left + console_text_width(&bytes[..len]);
        }
        self.draw_scrollbar();
    }

    fn draw_scrollbar(&mut self) {
        let x = self.canvas.width.saturating_sub(14);
        let top = CONTENT_TOP;
        let bottom = self.maximum_y();
        let track_height = bottom.saturating_sub(top).max(1);
        self.canvas.rect(x, top, 5, track_height, rgb(30, 42, 61));
        let (count, visible) = (self.history().count, self.visible_lines());
        let max_offset = count.saturating_sub(visible);
        let thumb_height = if count == 0 { track_height } else {
            (track_height.saturating_mul(visible) / count).max(18).min(track_height)
        };
        let travel = track_height.saturating_sub(thumb_height);
        let thumb_top = top + if max_offset == 0 { 0 } else { travel.saturating_mul(max_offset.saturating_sub(self.scroll_offset)) / max_offset };
        self.canvas.rect(x.saturating_sub(2), thumb_top, 9, thumb_height, rgb(82, 143, 232));
    }

    fn put_byte(&mut self, byte: u8) {
        let available = self.canvas.width.saturating_sub(self.text_left + self.text_right);
        let (line_width, column) = self.current_line_metrics();
        let advance = console_glyph_advance(byte);
        if column >= HISTORY_COLUMNS || (column > 0 && line_width.saturating_add(advance) > available) {
            self.newline();
        }
        self.history().append(byte);
        if self.scroll_offset == 0 {
            self.canvas.text(
                self.cursor_x,
                self.cursor_y,
                core::str::from_utf8(&[byte]).unwrap_or("?"),
                CONSOLE_FOREGROUND,
                1,
            );
        }
        self.cursor_x = self.cursor_x.saturating_add(advance);
    }

    fn backspace(&mut self) {
        if self.history().column == 0 { return; }
        self.history().backspace();
        self.redraw_current_line();
    }

    fn newline(&mut self) {
        self.history().push_line();
        if self.scroll_offset != 0 {
            let visible = self.visible_lines();
            let max_offset = {
                let history = self.history();
                history.count.saturating_sub(visible)
            };
            self.scroll_offset = self.scroll_offset.saturating_add(1).min(max_offset);
            // New output is below the user's current viewport. Advancing the
            // offset preserves the same visible history; only the thumb moves.
            self.draw_scrollbar();
            return;
        }

        self.cursor_x = self.text_left;
        self.cursor_y += self.line_height;
        let maximum = self.maximum_y();
        if self.cursor_y + self.line_height > maximum {
            let source_y = CONTENT_TOP + self.line_height;
            let copy_rows = maximum.saturating_sub(source_y);
            if copy_rows > 0 {
                let row_bytes = self.canvas.width * self.canvas.bytes_per_pixel;
                for row in 0..copy_rows {
                    let destination_offset = (self.canvas.origin_y + CONTENT_TOP + row) * self.canvas.pitch
                        + self.canvas.origin_x * self.canvas.bytes_per_pixel;
                    let source_offset = (self.canvas.origin_y + source_y + row) * self.canvas.pitch
                        + self.canvas.origin_x * self.canvas.bytes_per_pixel;
                    let destination = unsafe { self.canvas.address.add(destination_offset) };
                    let source = unsafe { self.canvas.address.add(source_offset) };
                    unsafe { core::ptr::copy(source, destination, row_bytes); }
                }
            }
            self.canvas.rect(0, maximum.saturating_sub(self.line_height), self.canvas.width, self.line_height, CONSOLE_BACKGROUND);
            self.cursor_y = maximum.saturating_sub(self.line_height);
        }
        self.draw_scrollbar();
    }
}

fn console_glyph_advance(byte: u8) -> usize {
    if font_arimo::available() { font_arimo::advance(byte, font_arimo::Weight::Regular) }
    else { 6 }
}

fn console_text_width(bytes: &[u8]) -> usize {
    bytes.iter().fold(0usize, |width, byte| width.saturating_add(console_glyph_advance(*byte)))
}

struct Canvas {
    address: *mut u8,
    width: usize,
    height: usize,
    pitch: usize,
    bytes_per_pixel: usize,
    red_size: u8,
    red_shift: u8,
    green_size: u8,
    green_shift: u8,
    blue_size: u8,
    blue_shift: u8,
    origin_x: usize,
    origin_y: usize,
    screen_width: usize,
    screen_height: usize,
}

impl Canvas {
    fn new(fb: Framebuffer) -> Option<Self> {
        Self::new_view(fb, 0, 0, fb.width as usize, fb.height as usize)
    }

    /// Create a clipped framebuffer view. Coordinates used by the renderer are
    /// local to this view, so a Terminal can live inside a desktop window.
    fn new_view(fb: Framebuffer, origin_x: usize, origin_y: usize, width: usize, height: usize) -> Option<Self> {
        if fb.address.is_null() || fb.memory_model != 1 || (fb.bpp != 24 && fb.bpp != 32) {
            return None;
        }
        let screen_width = usize::try_from(fb.width).ok()?;
        let screen_height = usize::try_from(fb.height).ok()?;
        let pitch = usize::try_from(fb.pitch).ok()?;
        let bytes_per_pixel = usize::from(fb.bpp / 8);
        if width == 0 || height == 0 || origin_x.checked_add(width)? > screen_width
            || origin_y.checked_add(height)? > screen_height
            || pitch < screen_width.checked_mul(bytes_per_pixel)? {
            return None;
        }
        // Prove that every later row/pixel offset fits in the target address space.
        pitch.checked_mul(screen_height)?;
        Some(Self {
            address: fb.address,
            width,
            height,
            pitch,
            bytes_per_pixel,
            red_size: fb.red_mask_size,
            red_shift: fb.red_mask_shift,
            green_size: fb.green_mask_size,
            green_shift: fb.green_mask_shift,
            blue_size: fb.blue_mask_size,
            blue_shift: fb.blue_mask_shift,
            origin_x,
            origin_y,
            screen_width,
            screen_height,
        })
    }

    fn fill(&mut self, color: u32) {
        self.rect(0, 0, self.width, self.height, color);
    }

    fn rect(&mut self, x: usize, y: usize, width: usize, height: usize, color: u32) {
        let x_end = x.saturating_add(width).min(self.width);
        let y_end = y.saturating_add(height).min(self.height);
        for py in y.min(self.height)..y_end {
            for px in x.min(self.width)..x_end {
                self.pixel(px, py, color);
            }
        }
    }

    /// Default console text path: proportional, antialiased Arimo. If the
    /// embedded atlas is unavailable, retain the compact bitmap emergency font.
    fn text(&mut self, x: usize, y: usize, text: &str, color: u32, scale: usize) {
        if scale == 0 { return; }
        if font_arimo::available() {
            self.text_ui(x, y, text, color, font_arimo::Weight::Regular);
        } else {
            self.text_bitmap_fallback(x, y, text, color, scale);
        }
    }

    #[allow(dead_code)]
    fn text_bitmap_fallback(&mut self, x: usize, y: usize, text: &str, color: u32, scale: usize) {
        if scale == 0 { return; }
        let mut cursor = x;
        for character in text.bytes() {
            let glyph = font5x7::glyph(character);
            for (row, bits) in glyph.iter().enumerate() {
                for column in 0..5 {
                    if *bits & (1 << (4 - column)) != 0 {
                        self.rect(
                            cursor + column * scale,
                            y + row * scale,
                            scale,
                            scale,
                            color,
                        );
                    }
                }
            }
            cursor = cursor.saturating_add(6 * scale);
            if cursor >= self.width { break; }
        }
    }

    /// Draw proportional Arimo UI text from a pre-rasterized coverage atlas.
    /// This path performs no allocation and is safe before the kernel heap is ready.
    fn text_ui(&mut self, x: usize, y: usize, text: &str, color: u32, weight: font_arimo::Weight) {
        let mut cursor = x;
        let baseline = y.saturating_add(font_arimo::ascent(weight));
        for character in text.chars() {
            let byte = if character.is_ascii() { character as u8 } else { b'?' };
            let (glyph, bitmap) = font_arimo::glyph(byte, weight);
            for row in 0..glyph.height as usize {
                let py = baseline as isize + glyph.top as isize + row as isize;
                if py < 0 || py as usize >= self.height { continue; }
                for column in 0..glyph.width as usize {
                    let px = cursor as isize + glyph.left as isize + column as isize;
                    if px < 0 || px as usize >= self.width { continue; }
                    let coverage = bitmap[row * glyph.width as usize + column];
                    if coverage != 0 {
                        self.pixel_coverage(px as usize, py as usize, color, coverage);
                    }
                }
            }
            cursor = cursor.saturating_add(glyph.advance as usize);
            if cursor >= self.width { break; }
        }
    }

    fn measure_ui_text(&self, text: &str, weight: font_arimo::Weight) -> usize {
        text.bytes().map(|byte| font_arimo::advance(byte, weight)).sum()
    }

    fn measure_console_text(&self, text: &str) -> usize {
        if font_arimo::available() { self.measure_ui_text(text, font_arimo::Weight::Regular) }
        else { text.len().saturating_mul(6) }
    }

    fn text_ui_dec(&mut self, x: usize, y: usize, value: u32, digits: usize, color: u32) {
        let digits = digits.clamp(1, 10);
        let mut bytes = [b'0'; 10];
        let mut remaining = value;
        for index in (0..digits).rev() {
            bytes[index] = b'0' + (remaining % 10) as u8;
            remaining /= 10;
        }
        if let Ok(text) = core::str::from_utf8(&bytes[..digits]) {
            self.text_ui(x, y, text, color, font_arimo::Weight::Regular);
        }
    }

    fn text_ui_hex64(&mut self, x: usize, y: usize, value: u64, color: u32) {
        const HEX: &[u8; 16] = b"0123456789ABCDEF";
        let mut bytes = [b'0'; 18];
        bytes[1] = b'x';
        for index in 0..16 {
            let shift = (15 - index) * 4;
            bytes[index + 2] = HEX[((value >> shift) & 0x0F) as usize];
        }
        if let Ok(text) = core::str::from_utf8(&bytes) {
            self.text_ui(x, y, text, color, font_arimo::Weight::Regular);
        }
    }

    /// Alpha-blend a coverage pixel over the existing framebuffer contents.
    fn pixel_coverage(&mut self, x: usize, y: usize, color: u32, coverage: u8) {
        if coverage == 0 { return; }
        if coverage == 255 { self.pixel(x, y, color); return; }
        let offset = (self.origin_y + y) * self.pitch + (self.origin_x + x) * self.bytes_per_pixel;
        let raw = unsafe {
            if self.bytes_per_pixel == 4 {
                self.address.add(offset).cast::<u32>().read_volatile()
            } else {
                u32::from(self.address.add(offset).read_volatile())
                    | (u32::from(self.address.add(offset + 1).read_volatile()) << 8)
                    | (u32::from(self.address.add(offset + 2).read_volatile()) << 16)
            }
        };
        let bg_r = unpack_channel(raw, self.red_size, self.red_shift);
        let bg_g = unpack_channel(raw, self.green_size, self.green_shift);
        let bg_b = unpack_channel(raw, self.blue_size, self.blue_shift);
        let alpha = u32::from(coverage);
        let inverse = 255 - alpha;
        let fg_r = (color >> 16) & 0xff;
        let fg_g = (color >> 8) & 0xff;
        let fg_b = color & 0xff;
        let blend = |foreground: u32, background: u8| -> u8 {
            ((foreground * alpha + u32::from(background) * inverse + 127) / 255) as u8
        };
        self.pixel(x, y, rgb(blend(fg_r, bg_r), blend(fg_g, bg_g), blend(fg_b, bg_b)));
    }

    fn text_dec(&mut self, x: usize, y: usize, value: u32, digits: usize, color: u32) {
        let digits = digits.clamp(1, 10);
        let mut bytes = [b'0'; 10];
        let mut remaining = value;
        for index in (0..digits).rev() {
            bytes[index] = b'0' + (remaining % 10) as u8;
            remaining /= 10;
        }
        let text = core::str::from_utf8(&bytes[..digits]).unwrap_or("0");
        self.text(x, y, text, color, 1);
    }

    fn text_hex(&mut self, x: usize, y: usize, value: u32, digits: usize, color: u32) {
        const HEX: &[u8; 16] = b"0123456789ABCDEF";
        let digits = digits.min(8);
        let mut bytes = [b'0'; 8];
        for index in 0..digits {
            let shift = (digits - index - 1) * 4;
            bytes[index] = HEX[((value >> shift) & 0x0F) as usize];
        }
        let text = core::str::from_utf8(&bytes[..digits]).unwrap_or("00000000");
        self.text(x, y, text, color, 1);
    }

    fn text_hex64(&mut self, x: usize, y: usize, value: u64, color: u32) {
        const HEX: &[u8; 16] = b"0123456789ABCDEF";
        let mut bytes = [b'0'; 18];
        bytes[1] = b'x';
        for index in 0..16 {
            let shift = (15 - index) * 4;
            bytes[index + 2] = HEX[((value >> shift) & 0x0F) as usize];
        }
        if let Ok(text) = core::str::from_utf8(&bytes) {
            self.text(x, y, text, color, 1);
        }
    }

    fn pixel(&mut self, x: usize, y: usize, color: u32) {
        let offset = (self.origin_y + y) * self.pitch + (self.origin_x + x) * self.bytes_per_pixel;
        let pixel = self.pack(color);
        unsafe {
            if self.bytes_per_pixel == 4 {
                self.address.add(offset).cast::<u32>().write_volatile(pixel);
            } else {
                self.address.add(offset).write_volatile((pixel & 0xff) as u8);
                self.address.add(offset + 1).write_volatile(((pixel >> 8) & 0xff) as u8);
                self.address.add(offset + 2).write_volatile(((pixel >> 16) & 0xff) as u8);
            }
        }
    }

    fn pack(&self, color: u32) -> u32 {
        let red = ((color >> 16) & 0xff) as u8;
        let green = ((color >> 8) & 0xff) as u8;
        let blue = (color & 0xff) as u8;
        channel(red, self.red_size, self.red_shift)
            | channel(green, self.green_size, self.green_shift)
            | channel(blue, self.blue_size, self.blue_shift)
    }
}

fn channel(value: u8, size: u8, shift: u8) -> u32 {
    if size == 0 || size > 8 || shift >= 32 || size.saturating_add(shift) > 32 {
        return 0;
    }
    let max = (1u32 << size) - 1;
    (((value as u32 * max) / 255) & max) << shift
}

fn unpack_channel(pixel: u32, size: u8, shift: u8) -> u8 {
    if size == 0 || size > 8 || shift >= 32 || size.saturating_add(shift) > 32 { return 0; }
    let maximum = (1u32 << size) - 1;
    let value = (pixel >> shift) & maximum;
    ((value * 255 + maximum / 2) / maximum) as u8
}

const fn rgb(red: u8, green: u8, blue: u8) -> u32 {
    ((red as u32) << 16) | ((green as u32) << 8) | (blue as u32)
}
