//! MixedOS Kernel Halt (MKH): allocation-free fatal error reporting.
//!
//! The fatal path intentionally does not touch the heap, scheduler, terminal
//! history, filesystem, or block devices. Those systems may be the reason the
//! kernel stopped in the first place.

use core::fmt::{self, Write};
use core::sync::atomic::{AtomicBool, AtomicU64, Ordering};

use crate::boot::limine::Framebuffer;
use crate::console::{framebuffer as screen, serial};
use crate::interrupts::InterruptFrame;

static HALTING: AtomicBool = AtomicBool::new(false);
static FRAMEBUFFER_READY: AtomicBool = AtomicBool::new(false);
static FB_ADDRESS: AtomicU64 = AtomicU64::new(0);
static FB_WIDTH: AtomicU64 = AtomicU64::new(0);
static FB_HEIGHT: AtomicU64 = AtomicU64::new(0);
static FB_PITCH: AtomicU64 = AtomicU64::new(0);
static FB_BPP: AtomicU64 = AtomicU64::new(0);
static FB_MEMORY_MODEL: AtomicU64 = AtomicU64::new(0);
static FB_RED_SIZE: AtomicU64 = AtomicU64::new(0);
static FB_RED_SHIFT: AtomicU64 = AtomicU64::new(0);
static FB_GREEN_SIZE: AtomicU64 = AtomicU64::new(0);
static FB_GREEN_SHIFT: AtomicU64 = AtomicU64::new(0);
static FB_BLUE_SIZE: AtomicU64 = AtomicU64::new(0);
static FB_BLUE_SHIFT: AtomicU64 = AtomicU64::new(0);

/// Remember the bootloader framebuffer before the interactive console starts.
/// Atomic fields let the crash handler read a stable copy without borrowing the
/// shell's live Terminal or its mutable drawing state.
pub fn set_framebuffer(framebuffer: Framebuffer) {
    FRAMEBUFFER_READY.store(false, Ordering::Release);
    FB_ADDRESS.store(framebuffer.address as u64, Ordering::Relaxed);
    FB_WIDTH.store(framebuffer.width, Ordering::Relaxed);
    FB_HEIGHT.store(framebuffer.height, Ordering::Relaxed);
    FB_PITCH.store(framebuffer.pitch, Ordering::Relaxed);
    FB_BPP.store(framebuffer.bpp as u64, Ordering::Relaxed);
    FB_MEMORY_MODEL.store(framebuffer.memory_model as u64, Ordering::Relaxed);
    FB_RED_SIZE.store(framebuffer.red_mask_size as u64, Ordering::Relaxed);
    FB_RED_SHIFT.store(framebuffer.red_mask_shift as u64, Ordering::Relaxed);
    FB_GREEN_SIZE.store(framebuffer.green_mask_size as u64, Ordering::Relaxed);
    FB_GREEN_SHIFT.store(framebuffer.green_mask_shift as u64, Ordering::Relaxed);
    FB_BLUE_SIZE.store(framebuffer.blue_mask_size as u64, Ordering::Relaxed);
    FB_BLUE_SHIFT.store(framebuffer.blue_mask_shift as u64, Ordering::Relaxed);
    FRAMEBUFFER_READY.store(true, Ordering::Release);
}

fn framebuffer() -> Option<Framebuffer> {
    if !FRAMEBUFFER_READY.load(Ordering::Acquire) { return None; }
    Some(Framebuffer {
        address: FB_ADDRESS.load(Ordering::Relaxed) as *mut u8,
        width: FB_WIDTH.load(Ordering::Relaxed),
        height: FB_HEIGHT.load(Ordering::Relaxed),
        pitch: FB_PITCH.load(Ordering::Relaxed),
        bpp: FB_BPP.load(Ordering::Relaxed) as u16,
        memory_model: FB_MEMORY_MODEL.load(Ordering::Relaxed) as u8,
        red_mask_size: FB_RED_SIZE.load(Ordering::Relaxed) as u8,
        red_mask_shift: FB_RED_SHIFT.load(Ordering::Relaxed) as u8,
        green_mask_size: FB_GREEN_SIZE.load(Ordering::Relaxed) as u8,
        green_mask_shift: FB_GREEN_SHIFT.load(Ordering::Relaxed) as u8,
        blue_mask_size: FB_BLUE_SIZE.load(Ordering::Relaxed) as u8,
        blue_mask_shift: FB_BLUE_SHIFT.load(Ordering::Relaxed) as u8,
    })
}

fn claim_fatal_path() {
    crate::arch::disable_interrupts();
    if HALTING.swap(true, Ordering::AcqRel) {
        serial::write_line("[MKH] recursive fatal error while already halted; stopping immediately");
        crate::arch::halt_forever();
    }
}

/// The Rust panic handler enters here. Formatting is bounded and allocation-free.
pub fn rust_panic(info: &core::panic::PanicInfo<'_>) -> ! {
    claim_fatal_path();
    let mut detail = FixedText::new();
    let _ = fmt::write(&mut detail, format_args!("{}", info));

    serial::write_line("");
    serial::write_line("================ MIXEDOS KERNEL HALT ================");
    serial::write_line("[MKH] Fatal Rust panic; kernel execution stopped");
    serial::write_fmt(format_args!("[MKH] {}\r\n", info));
    let stack_pointer: u64;
    unsafe { core::arch::asm!("mov {}, rsp", out(reg) stack_pointer, options(nomem, nostack, preserves_flags)); }
    serial::write_fmt(format_args!("[MKH] handler stack pointer: {:#018x}\r\n", stack_pointer));
    serial::write_line("[MKH] No filesystem or disk writes were attempted.");

    render("RUST KERNEL PANIC", "MKH-PANIC", detail.as_str(), None, None);
    crate::arch::halt_forever()
}

/// Handle an unrecoverable ring-0 processor exception.
pub fn cpu_exception(frame: &InterruptFrame, fault_address: Option<u64>) -> ! {
    claim_fatal_path();
    let vector = frame.vector;
    let name = exception_name(vector);
    serial::write_line("");
    serial::write_line("================ MIXEDOS KERNEL HALT ================");
    serial::write_fmt(format_args!(
        "[MKH] CPU exception: {} (vector {}, error {:#018x})\r\n",
        name, vector, frame.error_code
    ));
    serial::write_fmt(format_args!(
        "[MKH] RIP={:#018x} CS={:#06x} RFLAGS={:#018x}\r\n",
        frame.instruction_pointer, frame.code_segment, frame.flags
    ));
    serial::write_fmt(format_args!(
        "[MKH] RAX={:#018x} RBX={:#018x} RCX={:#018x} RDX={:#018x}\r\n",
        frame.rax, frame.rbx, frame.rcx, frame.rdx
    ));
    serial::write_fmt(format_args!(
        "[MKH] RSI={:#018x} RDI={:#018x} RBP={:#018x}\r\n",
        frame.rsi, frame.rdi, frame.rbp
    ));
    serial::write_fmt(format_args!(
        "[MKH] R8={:#018x} R9={:#018x} R10={:#018x} R11={:#018x}\r\n",
        frame.r8, frame.r9, frame.r10, frame.r11
    ));
    serial::write_fmt(format_args!(
        "[MKH] R12={:#018x} R13={:#018x} R14={:#018x} R15={:#018x}\r\n",
        frame.r12, frame.r13, frame.r14, frame.r15
    ));
    if let Some(address) = fault_address {
        serial::write_fmt(format_args!("[MKH] CR2 fault address: {:#018x}\r\n", address));
    }
    serial::write_line("[MKH] No filesystem or disk writes were attempted.");

    render(name, "MKH-CPU-EXCEPTION", "See COM1 serial output for the full register dump.",
        Some((vector, frame.error_code, frame.instruction_pointer)), fault_address);
    crate::arch::halt_forever()
}

/// Fail closed when an internal interrupt invariant is violated.
pub fn fatal_message(message: &str) -> ! {
    claim_fatal_path();
    serial::write_line("================ MIXEDOS KERNEL HALT ================");
    serial::write_fmt(format_args!("[MKH] Fatal kernel invariant: {}\r\n", message));
    serial::write_line("[MKH] No filesystem or disk writes were attempted.");
    render("KERNEL INVARIANT FAILURE", "MKH-INTERNAL", message, None, None);
    crate::arch::halt_forever()
}

/// Display a sample MKH screen without entering the fatal path or changing
/// the HALTING guard. A keyboard key returns to the shell; COM1 users send ESC.
pub fn preview_screen(terminal: &mut Option<screen::Terminal>) -> bool {
    let Some(framebuffer) = framebuffer() else {
        serial::write_line("[MKH] preview unavailable: no boot framebuffer was registered");
        return false;
    };

    let rendered = screen::render_mkh_screen(
        framebuffer,
        "SAMPLE PAGE FAULT",
        "MKH-PREVIEW",
        "Sample diagnostic text. This is only a visual preview; no CPU exception occurred.",
        Some((14, 0x0000_0000_0000_0005, 0xFFFF_8000_0010_2040)),
        Some(0xDEAD_BEEF_CAFE_0000),
        true,
    );
    if !rendered {
        serial::write_line("[MKH] preview unavailable: framebuffer format or dimensions are unsupported");
        return false;
    }

    serial::write_line("[MKH] non-fatal screen preview active; press ESC to return (or send ESC over COM1)");
    let mut dismiss = false;
    while !dismiss {
        crate::input::poll();
        while let Some(event) = crate::input::pop_event() {
            match event {
                // Keep the diagnostic screen visible while the user takes a
                // screenshot. Only the dedicated Escape key dismisses it.
                crate::input::InputEvent::Key(key)
                    if key.pressed && !key.extended && key.scancode == 0x01 =>
                {
                    dismiss = true;
                    break;
                }
                crate::input::InputEvent::SerialByte(0x1B) => {
                    dismiss = true;
                    break;
                }
                _ => {}
            }
        }
        if !dismiss { core::hint::spin_loop(); }
    }

    // The preview replaced the framebuffer pixels, but the Terminal object
    // and its fixed scrollback buffer remained intact. Redraw without clearing
    // history or resetting the user's scroll position.
    if let Some(view) = terminal.as_mut() {
        view.redraw();
        view.set_input_status(crate::input::stats());
    }
    serial::write_line("[MKH] preview closed; kernel remains running");
    true
}

fn render(kind: &str, code: &str, detail: &str, registers: Option<(u64, u64, u64)>, fault_address: Option<u64>) {
    serial::write_fmt(format_args!("[MKH] crash code: {}\r\n", code));
    if let Some(framebuffer) = framebuffer() {
        if !screen::render_mkh_screen(framebuffer, kind, code, detail, registers, fault_address, false) {
            serial::write_line("[MKH] framebuffer crash screen unavailable; serial report remains available");
        }
    } else {
        serial::write_line("[MKH] no framebuffer was registered; serial report remains available");
    }
}

fn exception_name(vector: u64) -> &'static str {
    match vector {
        0 => "DIVIDE ERROR",
        1 => "DEBUG EXCEPTION",
        2 => "NON-MASKABLE INTERRUPT",
        3 => "BREAKPOINT",
        4 => "OVERFLOW",
        5 => "BOUND RANGE EXCEEDED",
        6 => "INVALID OPCODE",
        7 => "DEVICE NOT AVAILABLE",
        8 => "DOUBLE FAULT",
        9 => "COPROCESSOR SEGMENT OVERRUN",
        10 => "INVALID TSS",
        11 => "SEGMENT NOT PRESENT",
        12 => "STACK-SEGMENT FAULT",
        13 => "GENERAL PROTECTION FAULT",
        14 => "PAGE FAULT",
        16 => "X87 FLOATING-POINT EXCEPTION",
        17 => "ALIGNMENT CHECK",
        18 => "MACHINE CHECK",
        19 => "SIMD FLOATING-POINT EXCEPTION",
        20 => "VIRTUALIZATION EXCEPTION",
        21 => "CONTROL PROTECTION EXCEPTION",
        28 => "HYPERVISOR INJECTION EXCEPTION",
        29 => "VMM COMMUNICATION EXCEPTION",
        30 => "SECURITY EXCEPTION",
        _ => "UNKNOWN CPU EXCEPTION",
    }
}

struct FixedText {
    bytes: [u8; 192],
    length: usize,
}

impl FixedText {
    const fn new() -> Self { Self { bytes: [0; 192], length: 0 } }
    fn as_str(&self) -> &str {
        core::str::from_utf8(&self.bytes[..self.length]).unwrap_or("Panic details unavailable")
    }
}

impl Write for FixedText {
    fn write_str(&mut self, value: &str) -> fmt::Result {
        let available = self.bytes.len().saturating_sub(self.length);
        let count = value.len().min(available);
        self.bytes[self.length..self.length + count].copy_from_slice(&value.as_bytes()[..count]);
        self.length += count;
        Ok(())
    }
}
