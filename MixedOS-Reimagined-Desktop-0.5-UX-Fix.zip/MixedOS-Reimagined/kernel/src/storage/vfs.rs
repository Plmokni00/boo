//! Path-based VFS facade. The native MIXFS driver is the first mounted backend.
use super::mixfs::{self, FsError, FsInfo, ListEntry};

pub const MAX_LIST_ENTRIES: usize = 64;
pub type DirectoryListing = [ListEntry; MAX_LIST_ENTRIES];

pub fn mount() -> Result<FsInfo, FsError> { mixfs::mount() }
pub fn format(target_index: usize, confirmation: &[u8]) -> Result<FsInfo, FsError> { mixfs::format(target_index, confirmation) }
pub fn info() -> FsInfo { mixfs::info() }
pub fn list(path: &str, output: &mut DirectoryListing) -> Result<usize, FsError> { mixfs::list(path, output) }
pub fn read_file(path: &str, output: &mut [u8]) -> Result<usize, FsError> { mixfs::read_file(path, output) }
pub fn write_file(path: &str, data: &[u8]) -> Result<(), FsError> { mixfs::write_file(path, data) }
pub fn overwrite_file(path: &str, data: &[u8]) -> Result<(), FsError> { mixfs::overwrite_file(path, data) }
pub fn append_file(path: &str, data: &[u8]) -> Result<(), FsError> { mixfs::append_file(path, data) }
pub fn rename_file(path: &str, new_name: &str) -> Result<(), FsError> { mixfs::rename_file(path, new_name) }
pub fn mkdir(path: &str) -> Result<(), FsError> { mixfs::mkdir(path) }
pub fn remove_file(path: &str) -> Result<(), FsError> { mixfs::remove_file(path) }
pub fn remove_dir(path: &str) -> Result<(), FsError> { mixfs::remove_dir(path) }
pub fn check() -> Result<u64, FsError> { mixfs::check() }
pub fn sync() -> Result<(), FsError> { mixfs::sync() }
pub fn self_test() -> Result<usize, FsError> { mixfs::self_test() }
