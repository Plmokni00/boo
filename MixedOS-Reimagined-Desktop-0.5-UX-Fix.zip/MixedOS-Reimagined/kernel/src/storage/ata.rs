//! Legacy ATA PIO block driver for VirtualBox IDE hard disks.
//! It enumerates four positions, protects the first detected disk, and never formats media.
use core::cell::UnsafeCell;
use core::hint::spin_loop;
use core::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};

use crate::arch;

pub const SECTOR_SIZE: usize = 512;
const STATUS_BSY: u8 = 0x80;
const STATUS_DF: u8 = 0x20;
const STATUS_DRQ: u8 = 0x08;
const STATUS_ERR: u8 = 0x01;
const MAX_LBA28_SECTORS: u64 = 0x1000_0000;
const POLL_LIMIT: usize = 1_000_000;
pub const DEVICE_SLOTS: usize = 4;
const NO_DEVICE_INDEX: usize = usize::MAX;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum AtaError {
    NotInitialized,
    NoDevice,
    OutOfRange,
    Timeout,
    DeviceFault,
    CommandError,
    UnsupportedDevice,
}

#[derive(Clone, Copy)]
struct AtaDevice {
    io: u16,
    control: u16,
    slave: bool,
    sectors: u64,
    flush_supported: bool,
    model: [u8; 40],
}

struct DeviceCell(UnsafeCell<[Option<AtaDevice>; DEVICE_SLOTS]>);
unsafe impl Sync for DeviceCell {}
static DEVICE: DeviceCell = DeviceCell(UnsafeCell::new([None; DEVICE_SLOTS]));
static LOCKED: AtomicBool = AtomicBool::new(false);
static INITIALIZED: AtomicBool = AtomicBool::new(false);
static SELECTED_INDEX: AtomicUsize = AtomicUsize::new(NO_DEVICE_INDEX);
static PROTECTED_INDEX: AtomicUsize = AtomicUsize::new(NO_DEVICE_INDEX);
static READS: AtomicU64 = AtomicU64::new(0);
static WRITES: AtomicU64 = AtomicU64::new(0);
static IO_ERRORS: AtomicU64 = AtomicU64::new(0);

struct LockGuard;
fn lock() -> LockGuard {
    while LOCKED.compare_exchange_weak(false, true, Ordering::Acquire, Ordering::Relaxed).is_err() {
        spin_loop();
    }
    LockGuard
}
impl Drop for LockGuard {
    fn drop(&mut self) { LOCKED.store(false, Ordering::Release); }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DiskInfo {
    pub present: bool,
    pub sectors: u64,
    pub model: [u8; 40],
    pub reads: u64,
    pub writes: u64,
    pub io_errors: u64,
    pub flush_supported: bool,
    pub lba28: bool,
}

fn delay_400ns(control: u16) {
    for _ in 0..4 { let _ = unsafe { arch::inb(control) }; }
}

fn wait_not_busy(io: u16, control: u16) -> Result<u8, AtaError> {
    for _ in 0..POLL_LIMIT {
        let status = unsafe { arch::inb(io + 7) };
        if status == 0 || status == 0xFF { return Err(AtaError::NoDevice); }
        if status & STATUS_BSY == 0 {
            if status & STATUS_DF != 0 { return Err(AtaError::DeviceFault); }
            if status & STATUS_ERR != 0 { return Err(AtaError::CommandError); }
            return Ok(status);
        }
        spin_loop();
    }
    let _ = unsafe { arch::inb(control) };
    Err(AtaError::Timeout)
}

fn wait_data_request(io: u16, control: u16) -> Result<(), AtaError> {
    for _ in 0..POLL_LIMIT {
        let status = unsafe { arch::inb(io + 7) };
        if status == 0 || status == 0xFF { return Err(AtaError::NoDevice); }
        if status & STATUS_BSY == 0 {
            if status & STATUS_DF != 0 { return Err(AtaError::DeviceFault); }
            if status & STATUS_ERR != 0 { return Err(AtaError::CommandError); }
            if status & STATUS_DRQ != 0 { return Ok(()); }
        }
        spin_loop();
    }
    let _ = unsafe { arch::inb(control) };
    Err(AtaError::Timeout)
}

fn identify(io: u16, control: u16, slave: bool) -> Result<AtaDevice, AtaError> {
    unsafe {
        arch::outb(control, 0x02); // Disable device IRQs; all I/O is polled.
        arch::outb(io + 6, if slave { 0xB0 } else { 0xA0 });
    }
    delay_400ns(control);
    let before = unsafe { arch::inb(io + 7) };
    if before == 0 || before == 0xFF { return Err(AtaError::NoDevice); }
    unsafe {
        arch::outb(io + 2, 0);
        arch::outb(io + 3, 0);
        arch::outb(io + 4, 0);
        arch::outb(io + 5, 0);
        arch::outb(io + 7, 0xEC);
    }
    let status = unsafe { arch::inb(io + 7) };
    if status == 0 { return Err(AtaError::NoDevice); }
    let status = wait_data_request(io, control)?;
    let _ = status;

    let mut words = [0u16; 256];
    for word in words.iter_mut() { *word = unsafe { arch::inw(io) }; }
    let capabilities = words[49];
    if capabilities & (1 << 9) == 0 { return Err(AtaError::UnsupportedDevice); }
    let sectors = (u32::from(words[61]) << 16) | u32::from(words[60]);
    if sectors == 0 { return Err(AtaError::UnsupportedDevice); }
    let sectors = u64::from(sectors).min(MAX_LBA28_SECTORS);

    let mut model = [b' '; 40];
    for i in 0..20 {
        let word = words[27 + i].to_be_bytes();
        model[i * 2] = word[0];
        model[i * 2 + 1] = word[1];
    }
    let mut end = model.len();
    while end > 0 && model[end - 1] == b' ' { end -= 1; }
    for byte in model.iter_mut().take(end) {
        if !byte.is_ascii_graphic() { *byte = b'?'; }
    }
    Ok(AtaDevice {
        io,
        control,
        slave,
        sectors,
        flush_supported: (words[83] & 0xC000) == 0x4000 && (words[83] & (1 << 12)) != 0,
        model,
    })
}

/// Probe all four legacy IDE positions. All ATA hard disks are retained so
/// the shell can address a specific device. The first detected disk is marked
/// protected and can never be passed to the MIXFS formatter.
pub fn initialize() -> bool {
    if INITIALIZED.load(Ordering::Acquire) { return selected_index().is_some(); }
    let _guard = lock();
    if INITIALIZED.load(Ordering::Relaxed) {
        return SELECTED_INDEX.load(Ordering::Relaxed) != NO_DEVICE_INDEX;
    }

    let positions = [
        (0x1F0u16, 0x3F6u16, false), // ata0: primary master
        (0x1F0u16, 0x3F6u16, true),  // ata1: primary slave
        (0x170u16, 0x376u16, false), // ata2: secondary master
        (0x170u16, 0x376u16, true),  // ata3: secondary slave
    ];
    let mut first_detected = None;
    for (index, (io, control, slave)) in positions.into_iter().enumerate() {
        if let Ok(device) = identify(io, control, slave) {
            unsafe { (*DEVICE.0.get())[index] = Some(device); }
            if first_detected.is_none() { first_detected = Some(index); }
        }
    }

    let chosen = first_detected.unwrap_or(NO_DEVICE_INDEX);
    SELECTED_INDEX.store(chosen, Ordering::Release);
    PROTECTED_INDEX.store(chosen, Ordering::Release);
    INITIALIZED.store(true, Ordering::Release);
    chosen != NO_DEVICE_INDEX
}

pub fn selected_index() -> Option<usize> {
    let index = SELECTED_INDEX.load(Ordering::Acquire);
    if index == NO_DEVICE_INDEX { None } else { Some(index) }
}

pub fn protected_index() -> Option<usize> {
    let index = PROTECTED_INDEX.load(Ordering::Acquire);
    if index == NO_DEVICE_INDEX { None } else { Some(index) }
}

pub fn select(index: usize) -> Result<(), AtaError> {
    if !INITIALIZED.load(Ordering::Acquire) { return Err(AtaError::NotInitialized); }
    if index >= DEVICE_SLOTS { return Err(AtaError::NoDevice); }
    let _guard = lock();
    let present = unsafe { (*DEVICE.0.get())[index].is_some() };
    if !present { return Err(AtaError::NoDevice); }
    SELECTED_INDEX.store(index, Ordering::Release);
    Ok(())
}

/// Return information for one physical legacy IDE position (ata0..ata3).
pub fn disk_info(index: usize) -> Option<DiskInfo> {
    if index >= DEVICE_SLOTS { return None; }
    let _guard = lock();
    let device = unsafe { (*DEVICE.0.get())[index] }?;
    Some(DiskInfo {
        present: true,
        sectors: device.sectors,
        model: device.model,
        reads: READS.load(Ordering::Relaxed),
        writes: WRITES.load(Ordering::Relaxed),
        io_errors: IO_ERRORS.load(Ordering::Relaxed),
        flush_supported: device.flush_supported,
        lba28: true,
    })
}

/// The first detected disk is a safety anchor. Formatting is allowed only on
/// a different, explicitly identified ATA device.
pub fn is_safe_format_target(index: usize) -> bool {
    index < DEVICE_SLOTS && Some(index) != protected_index() && disk_info(index).is_some()
}

pub fn info() -> DiskInfo {
    match selected_index().and_then(disk_info) {
        Some(info) => info,
        None => DiskInfo {
            present: false, sectors: 0, model: [0; 40],
            reads: READS.load(Ordering::Relaxed),
            writes: WRITES.load(Ordering::Relaxed),
            io_errors: IO_ERRORS.load(Ordering::Relaxed),
            flush_supported: false, lba28: false,
        },
    }
}

fn select_lba(device: AtaDevice, lba: u64) -> Result<(), AtaError> {
    if lba >= device.sectors || lba >= MAX_LBA28_SECTORS { return Err(AtaError::OutOfRange); }
    unsafe {
        arch::outb(device.io + 6, 0xE0 | (if device.slave { 0x10 } else { 0 }) | (((lba >> 24) & 0x0F) as u8));
    }
    delay_400ns(device.control);
    wait_not_busy(device.io, device.control)?;
    unsafe {
        arch::outb(device.io + 1, 0);
        arch::outb(device.io + 2, 1);
        arch::outb(device.io + 3, lba as u8);
        arch::outb(device.io + 4, (lba >> 8) as u8);
        arch::outb(device.io + 5, (lba >> 16) as u8);
    }
    Ok(())
}

fn read_locked(device: AtaDevice, lba: u64, out: &mut [u8; SECTOR_SIZE]) -> Result<(), AtaError> {
    select_lba(device, lba)?;
    unsafe { arch::outb(device.io + 7, 0x20); }
    wait_data_request(device.io, device.control)?;
    for i in 0..256 {
        let bytes = unsafe { arch::inw(device.io) }.to_le_bytes();
        out[i * 2] = bytes[0];
        out[i * 2 + 1] = bytes[1];
    }
    wait_not_busy(device.io, device.control)?;
    Ok(())
}

fn flush_locked(device: AtaDevice) -> Result<(), AtaError> {
    if !device.flush_supported { return Ok(()); }
    unsafe { arch::outb(device.io + 7, 0xE7); }
    wait_not_busy(device.io, device.control)?;
    Ok(())
}

fn write_locked(device: AtaDevice, lba: u64, data: &[u8; SECTOR_SIZE]) -> Result<(), AtaError> {
    select_lba(device, lba)?;
    unsafe { arch::outb(device.io + 7, 0x30); }
    wait_data_request(device.io, device.control)?;
    for i in 0..256 {
        let value = u16::from_le_bytes([data[i * 2], data[i * 2 + 1]]);
        unsafe { arch::outw(device.io, value); }
    }
    wait_not_busy(device.io, device.control)?;
    Ok(())
}

pub fn read_sector(lba: u64, out: &mut [u8; SECTOR_SIZE]) -> Result<(), AtaError> {
    if !INITIALIZED.load(Ordering::Acquire) { return Err(AtaError::NotInitialized); }
    let _guard = lock();
    let index = selected_index().ok_or(AtaError::NoDevice)?;
    let device = unsafe { (*DEVICE.0.get())[index].ok_or(AtaError::NoDevice)? };
    match read_locked(device, lba, out) {
        Ok(()) => { READS.fetch_add(1, Ordering::Relaxed); Ok(()) }
        Err(error) => { IO_ERRORS.fetch_add(1, Ordering::Relaxed); Err(error) }
    }
}

pub fn write_sector(lba: u64, data: &[u8; SECTOR_SIZE]) -> Result<(), AtaError> {
    if !INITIALIZED.load(Ordering::Acquire) { return Err(AtaError::NotInitialized); }
    let _guard = lock();
    let index = selected_index().ok_or(AtaError::NoDevice)?;
    let device = unsafe { (*DEVICE.0.get())[index].ok_or(AtaError::NoDevice)? };
    match write_locked(device, lba, data) {
        Ok(()) => { WRITES.fetch_add(1, Ordering::Relaxed); Ok(()) }
        Err(error) => { IO_ERRORS.fetch_add(1, Ordering::Relaxed); Err(error) }
    }
}

pub fn flush() -> Result<(), AtaError> {
    if !INITIALIZED.load(Ordering::Acquire) { return Err(AtaError::NotInitialized); }
    let _guard = lock();
    let index = selected_index().ok_or(AtaError::NoDevice)?;
    let device = unsafe { (*DEVICE.0.get())[index].ok_or(AtaError::NoDevice)? };
    flush_locked(device)
}
