pub mod ata;
pub mod block;
pub mod mixfs;
pub mod vfs;

use ata::DiskInfo;
use mixfs::{FsError, FsInfo};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct StorageStatus {
    pub disk: DiskInfo,
    pub filesystem: Result<FsInfo, FsError>,
}

/// Detect a legacy IDE ATA disk and mount MIXFS if an initialized volume exists.
/// This never formats media; formatting is an explicit shell operation.
pub fn initialize() -> StorageStatus {
    let _ = ata::initialize();
    let protected = ata::protected_index();
    let mut filesystem = Err(FsError::NoDisk);

    if let Some(first) = protected {
        let _ = ata::select(first);
        filesystem = vfs::mount();

        // If the protected first disk is not MIXFS, look for an already
        // formatted data disk on the remaining IDE positions. Mount performs
        // reads only; it never formats or writes an unrecognized device.
        if filesystem.is_err() {
            for index in 0..ata::DEVICE_SLOTS {
                if Some(index) == protected || ata::disk_info(index).is_none() { continue; }
                if ata::select(index).is_err() { continue; }
                match vfs::mount() {
                    Ok(info) => { filesystem = Ok(info); break; }
                    Err(error) => filesystem = Err(error),
                }
            }
        }

        // When no MIXFS volume was found, leave the safe default selection on
        // the protected disk. Formatting still requires a separate explicit ID.
        if filesystem.is_err() { let _ = ata::select(first); }
    }

    let disk = ata::info();
    StorageStatus { disk, filesystem }
}
