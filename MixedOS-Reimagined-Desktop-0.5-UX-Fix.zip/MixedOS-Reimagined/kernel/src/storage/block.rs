//! Common block-device contract. MIXFS talks only to this layer, so future
//! AHCI/NVMe/USB storage drivers can be added without changing filesystem code.
use super::ata::{self, AtaError, SECTOR_SIZE};

pub const BLOCK_SIZE: usize = SECTOR_SIZE;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct BlockGeometry {
    pub present: bool,
    pub sectors: u64,
    pub sector_size: u16,
    pub lba28: bool,
}

pub trait BlockDevice {
    fn geometry(&self) -> BlockGeometry;
    fn read_block(&self, block: u64, output: &mut [u8; BLOCK_SIZE]) -> Result<(), AtaError>;
    fn write_block(&self, block: u64, input: &[u8; BLOCK_SIZE]) -> Result<(), AtaError>;
    fn flush(&self) -> Result<(), AtaError>;
}

/// First backend: legacy IDE ATA PIO. The concrete backend is deliberately
/// private to this module; callers use the common block API below.
pub struct AtaPioBlockDevice;

impl BlockDevice for AtaPioBlockDevice {
    fn geometry(&self) -> BlockGeometry {
        let info = ata::info();
        BlockGeometry {
            present: info.present,
            sectors: info.sectors,
            sector_size: SECTOR_SIZE as u16,
            lba28: info.lba28,
        }
    }
    fn read_block(&self, block: u64, output: &mut [u8; BLOCK_SIZE]) -> Result<(), AtaError> {
        ata::read_sector(block, output)
    }
    fn write_block(&self, block: u64, input: &[u8; BLOCK_SIZE]) -> Result<(), AtaError> {
        ata::write_sector(block, input)
    }
    fn flush(&self) -> Result<(), AtaError> { ata::flush() }
}

static ATA_PIO: AtaPioBlockDevice = AtaPioBlockDevice;

pub fn geometry() -> BlockGeometry { ATA_PIO.geometry() }
pub fn select_device(index: usize) -> Result<(), AtaError> { ata::select(index) }
pub fn disk_info(index: usize) -> Option<ata::DiskInfo> { ata::disk_info(index) }
pub fn is_safe_format_target(index: usize) -> bool { ata::is_safe_format_target(index) }
pub fn read(block: u64, output: &mut [u8; BLOCK_SIZE]) -> Result<(), AtaError> {
    ATA_PIO.read_block(block, output)
}
pub fn write(block: u64, input: &[u8; BLOCK_SIZE]) -> Result<(), AtaError> {
    ATA_PIO.write_block(block, input)
}
pub fn flush() -> Result<(), AtaError> { ATA_PIO.flush() }
