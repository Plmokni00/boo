use core::cell::UnsafeCell;
use core::sync::atomic::{AtomicBool, AtomicU64, Ordering};

use crate::{arch, console::serial};

core::arch::global_asm!(include_str!("../arch/x86_64/interrupts.S"));

const IDT_ENTRIES: usize = 256;
const PIC1_COMMAND: u16 = 0x20;
const PIC1_DATA: u16 = 0x21;
const PIC2_COMMAND: u16 = 0xA0;
const PIC2_DATA: u16 = 0xA1;
const PIT_COMMAND: u16 = 0x43;
const PIT_CHANNEL_0: u16 = 0x40;
const PIT_HZ: u32 = 100;

#[repr(C, packed)]
#[derive(Clone, Copy)]
struct IdtEntry {
    offset_low: u16,
    selector: u16,
    ist: u8,
    attributes: u8,
    offset_middle: u16,
    offset_high: u32,
    reserved: u32,
}

impl IdtEntry {
    const MISSING: Self = Self {
        offset_low: 0,
        selector: 0,
        ist: 0,
        attributes: 0,
        offset_middle: 0,
        offset_high: 0,
        reserved: 0,
    };

    fn interrupt_gate(handler: usize, selector: u16, dpl: u8, ist: u8) -> Self {
        Self {
            offset_low: handler as u16,
            selector,
            ist: ist & 0x07,
            attributes: 0x8E | ((dpl & 3) << 5),
            offset_middle: (handler >> 16) as u16,
            offset_high: (handler >> 32) as u32,
            reserved: 0,
        }
    }
}

#[repr(C, align(16))]
struct IdtTable(UnsafeCell<[IdtEntry; IDT_ENTRIES]>);
unsafe impl Sync for IdtTable {}

static IDT: IdtTable = IdtTable(UnsafeCell::new([IdtEntry::MISSING; IDT_ENTRIES]));
static TIMER_TICKS: AtomicU64 = AtomicU64::new(0);
static IDT_READY: AtomicBool = AtomicBool::new(false);

#[repr(C, packed)]
struct Idtr {
    limit: u16,
    base: u64,
}

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct InterruptFrame {
    pub r15: u64,
    pub r14: u64,
    pub r13: u64,
    pub r12: u64,
    pub r11: u64,
    pub r10: u64,
    pub r9: u64,
    pub r8: u64,
    pub rdi: u64,
    pub rsi: u64,
    pub rbp: u64,
    pub rdx: u64,
    pub rcx: u64,
    pub rbx: u64,
    pub rax: u64,
    pub vector: u64,
    pub error_code: u64,
    pub instruction_pointer: u64,
    pub code_segment: u64,
    pub flags: u64,
    // This is the common 20-qword prefix. CPL changes and IST stack switches
    // may append old RSP/SS; scheduler code reads that tail only after RPL3,
    // while MKH deliberately consumes only this common prefix.
}

unsafe extern "C" {
    static mixedos_isr_table: [usize; IDT_ENTRIES];
}

/// Load the IDT before the rest of kernel initialization can fault.
/// This does not enable hardware interrupts; it only makes CPU exceptions diagnosable.
pub fn install_exception_handlers() {
    if IDT_READY.load(Ordering::Acquire) { return; }
    unsafe {
        let selector: u16;
        core::arch::asm!("mov {0:x}, cs", out(reg) selector, options(nomem, nostack, preserves_flags));

        let table = IDT.0.get();
        for vector in 0..IDT_ENTRIES {
            let handler = mixedos_isr_table.as_ptr().add(vector).read();
            let dpl = if vector == 128 { 3 } else { 0 };
            // TSS IST slots are configured by initialize_gdt_tss().
            let ist = match vector { 8 => 1, 2 => 2, 18 => 3, _ => 0 };
            (*table)[vector] = IdtEntry::interrupt_gate(handler, selector, dpl, ist);
        }

        let idtr = Idtr {
            limit: (core::mem::size_of::<[IdtEntry; IDT_ENTRIES]>() - 1) as u16,
            base: table as u64,
        };
        core::arch::asm!("lidt [{}]", in(reg) &idtr, options(readonly, nostack, preserves_flags));
    }
    IDT_READY.store(true, Ordering::Release);
    serial::write_line("[ok] MKH exception handlers installed; double-fault, NMI, and machine-check emergency stacks ready");
}

/// Complete interrupt-controller setup only after exception handling is active.
pub fn initialize() {
    install_exception_handlers();
    remap_and_enable_pic();
    initialize_pit();
    arch::enable_interrupts();
    serial::write_line("[ok] PIT timer IRQ enabled; legacy input is initialized separately");
}

fn remap_and_enable_pic() {
    unsafe {
        arch::outb(PIC1_COMMAND, 0x11); io_wait();
        arch::outb(PIC2_COMMAND, 0x11); io_wait();
        arch::outb(PIC1_DATA, 0x20); io_wait();
        arch::outb(PIC2_DATA, 0x28); io_wait();
        arch::outb(PIC1_DATA, 0x04); io_wait();
        arch::outb(PIC2_DATA, 0x02); io_wait();
        arch::outb(PIC1_DATA, 0x01); io_wait();
        arch::outb(PIC2_DATA, 0x01); io_wait();
        // Unmask IRQ0 (PIT) only. PS/2 IRQ1/IRQ12 are disabled in the i8042
        // command byte and the shared poller is the sole owner of port 0x60.
        // 0xFE = IRQ0 enabled, IRQ1 masked; all other master IRQs masked.
        arch::outb(PIC1_DATA, 0xFE);
        arch::outb(PIC2_DATA, 0xFF);
    }
}

fn io_wait() {
    unsafe { arch::outb(0x80, 0); }
}

fn initialize_pit() {
    let divisor = 1_193_182u32 / PIT_HZ;
    unsafe {
        arch::outb(PIT_COMMAND, 0x36);
        arch::outb(PIT_CHANNEL_0, divisor as u8);
        arch::outb(PIT_CHANNEL_0, (divisor >> 8) as u8);
    }
}

pub fn ticks() -> u64 {
    TIMER_TICKS.load(Ordering::Relaxed)
}

#[unsafe(no_mangle)]
pub extern "C" fn mixedos_interrupt_dispatch(frame: *mut InterruptFrame) {
    if frame.is_null() {
        crate::mkh::fatal_message("interrupt dispatcher received a null frame");
    }
    // Keep the interrupt frame as a raw pointer. Ring-0 interrupts do not
    // have the user RSP/SS tail words, so never create a larger reference.
    let vector = unsafe { (*frame).vector };
    let code_segment = unsafe { (*frame).code_segment };
    match vector {
        32 => {
            TIMER_TICKS.fetch_add(1, Ordering::Relaxed);
            if code_segment & 3 == 3 { crate::process::on_timer(frame); }
            unsafe { arch::outb(PIC1_COMMAND, 0x20); }
        }
        33 => {
            // PS/2 input runs in polling mode. A stale/spurious IRQ is
            // acknowledged without touching port 0x60; the unified input
            // poller remains the only owner of controller output bytes.
            unsafe { arch::outb(PIC1_COMMAND, 0x20); }
        }
        128 => {
            if code_segment & 3 == 3 {
                crate::process::handle_syscall(frame);
            } else {
                serial::write_line("[warn] int 0x80 invoked from kernel mode");
            }
        }
        0..=31 => {
            if code_segment & 3 == 3 {
                let fault_address = if vector == 14 {
                    let address: u64;
                    unsafe { core::arch::asm!("mov {}, cr2", out(reg) address, options(nomem, nostack, preserves_flags)); }
                    address
                } else { 0 };
                let error_code = unsafe { (*frame).error_code };
                let instruction_pointer = unsafe { (*frame).instruction_pointer };
                serial::write_fmt(format_args!("[proc] user task faulted: vector {} error {:#x} RIP {:#018x} CR2 {:#018x}\r\n", vector, error_code, instruction_pointer, fault_address));
                if crate::process::handle_fault(frame, vector, fault_address) { return; }
                crate::mkh::fatal_message("no scheduler recovery path for user fault");
            }
            // MKH records the Page fault address from CR2 before halting.
            let fault_address = if vector == 14 {
                let address: u64;
                unsafe { core::arch::asm!("mov {}, cr2", out(reg) address, options(nomem, nostack, preserves_flags)); }
                Some(address)
            } else { None };
            crate::mkh::cpu_exception(unsafe { &*frame }, fault_address);
        }
        34..=39 => {
            serial::write_fmt(format_args!("\r\n[warn] unexpected master PIC IRQ vector {}\r\n", vector));
            unsafe { arch::outb(PIC1_COMMAND, 0x20); }
        }
        40..=47 => {
            serial::write_fmt(format_args!("\r\n[warn] unexpected slave PIC IRQ vector {}\r\n", vector));
            unsafe {
                arch::outb(PIC2_COMMAND, 0x20);
                arch::outb(PIC1_COMMAND, 0x20);
            }
        }
        _ => {
            serial::write_fmt(format_args!("\r\n[warn] unexpected interrupt vector {}\r\n", vector));
        }
    }
}
