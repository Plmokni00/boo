use std::{env, path::Path};

fn required_object(variable: &str, description: &str) -> String {
    let object = env::var(variable).unwrap_or_else(|_| {
        panic!(
            "{variable} is missing. Build through Build.bat/build.ps1 so the {description} is compiled and linked."
        )
    });
    if !Path::new(&object).is_file() {
        panic!("{variable} does not point to a compiled object file: {object}");
    }
    object
}

fn main() {
    for variable in ["MIXEDOS_C_OBJECT", "MIXEDOS_UI_OBJECT", "MIXEDOS_ZIG_OBJECT"] {
        println!("cargo:rerun-if-env-changed={variable}");
    }
    let c_object = required_object("MIXEDOS_C_OBJECT", "freestanding C runtime");
    let ui_object = required_object("MIXEDOS_UI_OBJECT", "freestanding C desktop UI runtime");
    let zig_object = required_object("MIXEDOS_ZIG_OBJECT", "freestanding Zig checksum module");
    println!("cargo:rustc-link-arg={c_object}");
    println!("cargo:rustc-link-arg={ui_object}");
    println!("cargo:rustc-link-arg={zig_object}");
}
